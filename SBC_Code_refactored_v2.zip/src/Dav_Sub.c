/*cd /f/Dahlia-Verdin/GTK*/
/* RUN BAT FILE TO EXECUTE PROGRAM --> bash ./gtkboardapp_run.bat*/
/* gcc gtkrow.c src/src/OpenGL.c -o Main `pkg-config --cflags --libs gtk+-3.0` -lm -lwayland-client -lwayland-server -lwayland-egl -lEGL -lGLESv2 */
/* $CC gtkrow.c src/src/OpenGL.c -o Main `pkg-config --cflags --libs gtk+-3.0` -lm -lwayland-client -lwayland-server -lwayland-egl -lEGL -lGLESv2 */
/* $CC gtkrow.c src/src/OpenGL.c -o Main `pkg-config --cflags --libs gtk+-3.0` -lgpiod -lm -lwayland-client -lwayland-server -lwayland-egl -lEGL -lGLESv2 */
/* $CC src/src/Dav_Sub.c src/src/OpenGL.c -o Main `pkg-config --cflags --libs gtk+-3.0` -lgpiod -lm -lwayland-client -lwayland-server -lwayland-egl -lEGL -lGLESv2 */

// cd /mnt/e/2024/08-August_2024/2024-08-21/Dav_Sub
/*  bash Build_For_brd.sh */ // Use this command to Build the application to run on Board
//
//   bash ./Build_For_WSL.sh     // Build for WSL  Environment setti is not rquired
//   cd /mnt/d/
//  cd WSL_Wayland_Proj/WSL_Prog/Dav_Sub/Dav_Sub
//  . /opt/tdx-xwayland/5.7.1/environment-setup-aarch64-tdx-linux
//    which pkg-config
//    /opt/tdx-xwayland/5.7.1/sysroots/x86_64-tdxsdk-linux/usr/bin/pkg-config
//    bash Build_For_brd.sh
//    export DISPLAY=172.23.144.1:0 && export XDG_RUNTIME_DIR=/tmp/xdg && export RUNLEVEL=3 && weston

//   setup=setenv setupargs console=tty1 console=${console},${baudrate} consoleblank=0 earlycon   // set environment as below so during boot console command would not get display on screen
//   setenv setup 'setenv setupargs vt.global_cursor_default=0 console=${console},${baudrate} consoleblank=0 earlycon'
//   setenv setup 'setenv setupargs console=${console},${baudrate} consoleblank=0 earlycon'
// setenv setup 'setenv setupargs fec_mac=${ethaddr} consoleblank=0 no_console_suspend=1 console=${console},${baudrate}n8'
// setenv -> saveenv -> reset
// WSL UBUNTU PATH FROM PROGRAM FOR TESTING PURPOSE = fopen("/home/rnd1/temp1", "r"))
// CHECK DISK SPACE = df -H // To check storage in linux 

#ifdef WIN32
#include <io.h>
#define F_OK 0
#define access _access
#endif

#include <stdio.h>
#include <include/include/gpiod.h> // For WSL it is required to install libgpiod using following command in Ubuntu sudo apt-get install libgpiod-dev
#include <string.h>
#include <stdlib.h>
#include <stdint.h>
#include <math.h>
#include <stdbool.h>
#include <stdint.h>
#include <cairo.h>
#include <cairo-pdf.h>

#include <gtk/gtk.h>

#include "include/include/gtkdeclarations.h"
#include "include/include/Dav_Sub.h"
#include "include/include/dataval.h"
#include "include/include/cbentry.h"
#include "include/include/cbentry_safe1.h"
#include "include/include/OpenGL.h"
#include "include/include/shp_prf.h"
#include "include/include/Ruler.h"
#include "include/include/thick_log.h"
#include "include/include/plot_data.h"

#include <unistd.h>
#include <getopt.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <sys/wait.h>
#include <linux/types.h>
#include <linux/spi/spidev.h>

// #define ARRAY_SIZE(a) (sizeof(a) / sizeof((a)[0]))

gdouble Scr_stp_pre = 10.0;
int fd_SPI;

bool Spi_test = true;
struct OGLData ogl;

int Key_ck = 100;  // Key Check timer counter
int Key_Delay = 0; // Key Delay time control
bool Key_press = false;
int Measure_dsp = 0, Batt_dsp = 0, Batt_val = 0; // Measurement Display rate is controlle by this value
extern int tx_bufidx;
extern int Key_Scn_code;
extern int Key_stp;
extern GLubyte row_y[256];

extern cairo_t *Ascan_cr;
extern cairo_surface_t *Ascan_surface;
extern GdkPixbuf *Ascan_pixbuf;

void Keypad_rd(); // Read Keypad Data
void Read_rd();	  // Read Keypad Data
void Read_rd2();
void Read_Peak_amp();

void Init_all();
int Init_SPI(); // int main(int argc, char *argv[])  //int main(int argc, char *argv[])

void Start_up_Scr();
void Key_function();
void Keypad_ck(); // Read Keypad Data
void Send_SPI(int tx_nofd);
void Send_filt();
void Check_1K();
void Get_Data(); // Transfer data to Opengl Buffer from SPI Buffer
void Send_Data_to_OpenGL(void);
void Smooth_Asc();
void SPI_Receive(); // Receive Data using SPI

void DAC_Copy_for_Disp(int crvno); // Copy DAC points data for the Display
void Cal_Tval();
void Hruler_update();
void Vruler_update();

gboolean Key_perform_F(int keycodet);

static gboolean savePNG(cairo_t *cr)
{
    {
		// Take a Ascan screenshot to add in Ascan report image
        Ascan_image_data = gdk_pixbuf_get_pixels(Ascan_pixbuf);

        glBindFramebuffer(GL_READ_FRAMEBUFFER, ogl.default_framebuffer);
        glReadPixels(0, 0, frame_width, frame_height, GL_RGBA, GL_UNSIGNED_BYTE, Ascan_image_data);

        Ascan_pixbuf = gdk_pixbuf_flip (Ascan_pixbuf, false);
        /* Draw the pixbuf */
        gdk_cairo_set_source_pixbuf(Ascan_cr, Ascan_pixbuf, 0, 0);
        cairo_paint(Ascan_cr);
        cairo_surface_write_to_png(Ascan_surface, "Images/Images/screenshot.png");

        glBindFramebuffer(GL_READ_FRAMEBUFFER, ogl.framebuffer);
        glBindFramebuffer(GL_DRAW_FRAMEBUFFER, 0);
        glBlitFramebuffer(0, 0, frame_width, frame_height, // Source x, y, width and height
                             0, frame_height, frame_width, 0, // Dest x, y, width and height
                             GL_COLOR_BUFFER_BIT, GL_NEAREST);
    }

	for (i = 0; i < 5; i++)
	{
		sprintf(text_values[i], "%s", gtk_entry_get_text(GTK_ENTRY(text_h[i])));
	}

	gint x1, y1, x2, y2, xt, yt;
	cairo_surface_t *surface = cairo_image_surface_create(CAIRO_FORMAT_RGB24, 595, 842); // <<= Reduced size to get only a part of the window.
	cr = cairo_create(surface);

	cairo_set_source_rgb(cr, 1.0, 1.0, 1.0);
	cairo_paint(cr);

	image = gdk_pixbuf_new_from_file_at_scale("Images/Images/screenshot.png", frame_width, frame_height, false, NULL);

	if (val_ary[(1 * 5) + 0] == 1)
	{
		image = gdk_pixbuf_new_from_file_at_scale("Images/Images/screenshot.png", frame_width, frame_height, false, NULL);
	}

	if (val_ary[(1 * 5) + 0] == 2)
	{
		image = gdk_pixbuf_new_from_file_at_scale("Images/Images/screenshot.png", frame_width, frame_height, false, NULL);
	}

	if (val_ary[(2 * 5) + 0] == 1)
	{
		image = gdk_pixbuf_new_from_file_at_scale("Images/Images/screenshot.png", frame_width, frame_height, false, NULL);
	}

	if (val_ary[(4 * 5) + 0] == 1)
	{
		image = gdk_pixbuf_new_from_file_at_scale("Images/Images/screenshot.png", frame_width, frame_height, false, NULL);
	}

	simage = gdk_pixbuf_scale_simple(image, 550, 250, GDK_INTERP_BILINEAR);
	gdk_cairo_set_source_pixbuf(cr, simage, 22.0, 30.0);
	cairo_paint(cr);

	/******************************************************************************************************************/
	/***********************************For Menu Data and Values Section**********************************************/
	/*****************************************************************************************************************/

	/****************************FOR FIRST SET *************************************************************************************/
	cairo_set_source_rgb(cr, 0.0, 0.0, 0.0);
	for (i = 300; i < 675; i = i + 20) // For 1st Vertical line border
	{
		cairo_move_to(cr, 15, i);
		cairo_line_to(cr, 15, i + 20);
		cairo_stroke(cr);
	}

	for (i = 300; i < 675; i = i + 20) // For 2nd Vertical line border
	{
		cairo_move_to(cr, 129, i);
		cairo_line_to(cr, 129, i + 20);
		cairo_stroke(cr);
	}

	for (i = 300; i < 675; i = i + 20) // For 3rd Vertical line border
	{
		cairo_move_to(cr, 207, i);
		cairo_line_to(cr, 207, i + 20);
		cairo_stroke(cr);
	}

	for (i = 300; i < 695; i = i + 20) // For 3rd Vertical line border
	{
		cairo_move_to(cr, 15, i);
		cairo_line_to(cr, 207, i);
		cairo_stroke(cr);
	}

	cairo_set_source_rgb(cr, 0.0, 0.0, 0.0);
	cairo_select_font_face(cr, "Purisa", CAIRO_FONT_SLANT_NORMAL, CAIRO_FONT_WEIGHT_BOLD);
	cairo_set_source_rgb(cr, 0.0, 0.0, 1.0);

	// For 1st column data
	i = 20;
	for (j = 315, k = 0; j < 495, k < 18; j = j + 20, k = k + 2)
	{
		cairo_move_to(cr, i, j);
		cairo_show_text(cr, all_btnval[k]);
	}
	i = 20;
	for (j = 495, k = 20; j < 575, k < 28; j = j + 20, k = k + 2)
	{
		cairo_move_to(cr, i, j);
		cairo_show_text(cr, all_btnval[k]);
	}
	i = 20;
	for (j = 575, k = 30; j < 645, k < 38; j = j + 20, k = k + 2)
	{
		cairo_move_to(cr, i, j);
		cairo_show_text(cr, all_btnval[k]);
	}
	cairo_set_source_rgb(cr, 1.0, 0.0, 1.0);

	//For 2nd column data
	i = 134;
	for (j = 315, k = 1; j < 495, k < 19; j = j + 20, k = k + 2)
	{
		cairo_move_to(cr, i, j);
		cairo_show_text(cr, all_btnval[k]);
	}
	i = 134;
	for (j = 495, k = 21; j < 575, k < 29; j = j + 20, k = k + 2)
	{
		cairo_move_to(cr, i, j);
		cairo_show_text(cr, all_btnval[k]);
	}
	i = 134;
	for (j = 575, k = 31; j < 645, k < 39; j = j + 20, k = k + 2)
	{
		cairo_move_to(cr, i, j);
		cairo_show_text(cr, all_btnval[k]);
	}

	/****************************FOR SECOND SET *************************************************************************************/
	cairo_set_source_rgb(cr, 0.0, 0.0, 0.0);
	for (i = 300; i < 675; i = i + 20) // For 1st Vertical line border
	{
		cairo_move_to(cr, 220, i);
		cairo_line_to(cr, 220, i + 20);
		cairo_stroke(cr);
	}

	for (i = 300; i < 675; i = i + 20) // For 2nd Vertical line border
	{
		cairo_move_to(cr, 305, i);
		cairo_line_to(cr, 305, i + 20);
		cairo_stroke(cr);
	}

	for (i = 300; i < 675; i = i + 20) // For 3rd Vertical line border
	{
		cairo_move_to(cr, 390, i);
		cairo_line_to(cr, 390, i + 20);
		cairo_stroke(cr);
	}

	for (i = 300; i < 695; i = i + 20) // For 3rd Vertical line border
	{
		cairo_move_to(cr, 220, i);
		cairo_line_to(cr, 390, i);
		cairo_stroke(cr);
	}

	cairo_set_source_rgb(cr, 0.0, 0.0, 0.0);
	cairo_select_font_face(cr, "Purisa", CAIRO_FONT_SLANT_NORMAL, CAIRO_FONT_WEIGHT_BOLD);
	cairo_set_source_rgb(cr, 0.0, 0.0, 1.0);

	// For 1st column data
	i = 225;
	for (j = 315, k = 40; j < 395, k < 48; j = j + 20, k = k + 2)
	{
		cairo_move_to(cr, i, j);
		cairo_show_text(cr, all_btnval[k]);
	}
	i = 225;
	for (j = 395, k = 50; j < 475, k < 58; j = j + 20, k = k + 2)
	{
		cairo_move_to(cr, i, j);
		cairo_show_text(cr, all_btnval[k]);
	}
	i = 225;
	for (j = 475, k = 60; j < 535, k < 68; j = j + 20, k = k + 2)
	{
		cairo_move_to(cr, i, j);
		cairo_show_text(cr, all_btnval[k]);
	}
	cairo_set_source_rgb(cr, 1.0, 0.0, 1.0);

	//For 2nd column data
	i = 310;
	for (j = 315, k = 41; j < 395, k < 49; j = j + 20, k = k + 2)
	{
		cairo_move_to(cr, i, j);
		cairo_show_text(cr, all_btnval[k]);
	}
	i = 310;
	for (j = 395, k = 51; j < 475, k < 59; j = j + 20, k = k + 2)
	{
		cairo_move_to(cr, i, j);
		cairo_show_text(cr, all_btnval[k]);
	}
	i = 310;
	for (j = 475, k = 61; j < 535, k < 69; j = j + 20, k = k + 2)
	{
		cairo_move_to(cr, i, j);
		cairo_show_text(cr, all_btnval[k]);
	}

	/***********************************************************************************************************************/
	/********************************************FOR NOTE DETAIL SECTION ***************************************************/
	/***********************************************************************************************************************/
	
	cairo_set_source_rgb(cr, 0.0, 0.0, 0.0);
	for (i = 725; i < 815; i = i + 20) // For 1st Vertical line border
	{
		cairo_move_to(cr, 15, i);
		cairo_line_to(cr, 15, i + 20);
		cairo_stroke(cr);
	}

	for (i = 725; i < 815; i = i + 20) // For last Vertical line border
	{
		cairo_move_to(cr, 585, i);
		cairo_line_to(cr, 585, i + 20);
		cairo_stroke(cr);
	}

	for (i = 725; i < 815 + 20; i = i + 20) // For all Horizontal lines
	{
		cairo_move_to(cr, 15, i);
		cairo_line_to(cr, 585, i);
		cairo_stroke(cr);
	}

	for (i = 725; i < 815; i = i + 20) // For middle vertical line separating columns
	{
		cairo_move_to(cr, 295, i);
		cairo_line_to(cr, 295, i + 20);
		cairo_stroke(cr);
	}

	cairo_select_font_face(cr, "Purisa", CAIRO_FONT_SLANT_NORMAL, CAIRO_FONT_WEIGHT_NORMAL);
	cairo_set_source_rgb(cr, 1.0, 0.0, 1.0);

	// For 1st column data
	i = 20;
	for (j = 740, k = 0; j < 820, k < 5; j = j + 20, k++)
	{
		cairo_move_to(cr, i, j);
		cairo_show_text(cr, heading_name[k]);
	}

	cairo_set_source_rgb(cr, 1.0, 0.0, 0.0);
	// For 2nd column data
	i = 305;
	for (j = 740, k = 0; j < 820, k < 5; j = j + 20, k++)
	{
		cairo_move_to(cr, i, j);
		cairo_show_text(cr, text_values[k]);
	}

	cairo_fill(cr);
	cairo_surface_write_to_png(surface, "Images/Images/test.png");
}

//static gboolean Create_Pdfreport()
static gboolean CreateAscan_Pdfreport()
{
	cairo_t* cr;

	// *********************************  CODE TO GET ASCAN SCREENSHOT ON TO THE PDF *****************************************//
	// **************************  Take a Ascan screenshot to add in Ascan report image *************************************//
	Ascan_image_data = gdk_pixbuf_get_pixels(Ascan_pixbuf);

	glBindFramebuffer(GL_READ_FRAMEBUFFER, ogl.default_framebuffer);
	glReadPixels(0, 0, frame_width, frame_height, GL_RGBA, GL_UNSIGNED_BYTE, Ascan_image_data);

	Ascan_pixbuf = gdk_pixbuf_flip(Ascan_pixbuf, false);
	/* Draw the pixbuf */
	gdk_cairo_set_source_pixbuf(Ascan_cr, Ascan_pixbuf, 0, 0);
	cairo_paint(Ascan_cr);
	cairo_surface_write_to_png(Ascan_surface, "Images/Images/screenshot.png");

	glBindFramebuffer(GL_READ_FRAMEBUFFER, ogl.framebuffer);
	glBindFramebuffer(GL_DRAW_FRAMEBUFFER, 0);
	glBlitFramebuffer(0, 0, frame_width, frame_height, // Source x, y, width and height
		0, frame_height, frame_width, 0, // Dest x, y, width and height
		GL_COLOR_BUFFER_BIT, GL_NEAREST);

	for (i = 0; i < 5; i++)
	{
		sprintf(text_values[i], "%s", gtk_entry_get_text(GTK_ENTRY(text_h[i])));
	}

	/******************************CODE TO CREATE A PDF FILE******************************************/
	cairo_surface_t* surface;

	surface = cairo_pdf_surface_create(path_h, 595, 842);
	cr = cairo_create(surface);

	cairo_set_source_rgb(cr, 0, 0, 0);
	cairo_select_font_face(cr, "Sans", CAIRO_FONT_SLANT_NORMAL, CAIRO_FONT_WEIGHT_BOLD);
	cairo_set_font_size(cr, 10.0);

	cairo_move_to(cr, 200.0, 20.0);
	cairo_show_text(cr, "ULTRASONIC TEST REPORT");
	cairo_fill(cr);
	cairo_move_to(cr, 200, 25);
	cairo_line_to(cr, 350, 25);
	cairo_stroke(cr);

	image = gdk_pixbuf_new_from_file_at_scale("Images/Images/screenshot.png", frame_width, frame_height, false, NULL);
	simage = gdk_pixbuf_scale_simple(image, 380, 250, GDK_INTERP_BILINEAR); // Create a new pixbuf containing a copy of src scaled to dest_width x dest_height
	gdk_cairo_set_source_pixbuf(cr, simage, 100.0, 30.0);
	cairo_paint(cr);

	/******************************************************************************************************************/
	/***********************************For Menu Data and Values Section***********************************************/
	/******************************************************************************************************************/
	cairo_set_source_rgb(cr, 0.0, 0.0, 0.0);
	cairo_move_to(cr, 25, 305);
	cairo_line_to(cr, 145, 305);
	cairo_move_to(cr, 25, 305);
	cairo_line_to(cr, 25, 325);
	cairo_move_to(cr, 145, 305);
	cairo_line_to(cr, 145, 325);
	cairo_stroke(cr);

	cairo_move_to(cr, 30, 315); // TO DISPLAY THE GAIN VALUE
	cairo_show_text(cr, "GAIN");
	cairo_show_text(cr, all_btnval[9]);

	if (Measure_v1 == 1) // FOR ON G A VALUES
	{
		cairo_move_to(cr, 200, 300); 
		cairo_show_text(cr, "SPa: ");
		cairo_show_text(cr, mea_rd[0]);
		cairo_move_to(cr, 280, 300); 
		cairo_show_text(cr, "DPa: ");
		cairo_show_text(cr, mea_rd[1]);
		cairo_move_to(cr, 360, 300); 
		cairo_show_text(cr, "SDa: ");
		cairo_show_text(cr, mea_rd[2]);
		cairo_move_to(cr, 420, 300); 
		cairo_show_text(cr, "Ea: ");
		cairo_show_text(cr, mea_rd[3]);
	}
	else if (Measure_v1 == 2) // FOR ON G B VALUES
	{
		cairo_move_to(cr, 200, 315); 
		cairo_show_text(cr, "SPb: ");
		cairo_show_text(cr, mea_rd[0]);
		cairo_move_to(cr, 280, 315); 
		cairo_show_text(cr, "DPb: ");
		cairo_show_text(cr, mea_rd[1]);
		cairo_move_to(cr, 360, 315); 
		cairo_show_text(cr, "SDb: ");
		cairo_show_text(cr, mea_rd[2]);
		cairo_move_to(cr, 420, 315); 
		cairo_show_text(cr, "Eb: ");
		cairo_show_text(cr, mea_rd[3]);
	}
	else if (Measure_v1 == 3) // FOR DAC AWS OR DGS VALUES
	{
		if (Dac_v == 2)  // If DAC is ON
		{
			cairo_move_to(cr, 200, 315); 
			cairo_show_text(cr, "DAC: ");
			cairo_show_text(cr, mea_rd[0]);
			cairo_move_to(cr, 280, 315); 
			cairo_show_text(cr, "C dB: ");
			cairo_show_text(cr, mea_rd[1]);
			cairo_move_to(cr, 360, 315); 
			cairo_show_text(cr, " ");
			cairo_move_to(cr, 420, 315); 
			cairo_show_text(cr, "Ea: ");
			cairo_show_text(cr, mea_rd[3]);
		}
		else if (Dgs_onoff_v == 3) // If DGS is ON
		{
			cairo_move_to(cr, 200, 315);
			cairo_show_text(cr, "C dB: ");
			cairo_show_text(cr, mea_rd[0]);
			cairo_move_to(cr, 280, 315);
			cairo_show_text(cr, "ERS: ");
			cairo_show_text(cr, mea_rd[1]);
			cairo_move_to(cr, 360, 315);
			cairo_show_text(cr, "DGS c: ");
			cairo_show_text(cr, mea_rd[2]);
			cairo_move_to(cr, 420, 315);
			cairo_show_text(cr, "Ea: ");
			cairo_show_text(cr, mea_rd[3]);
		}
		else if (Aws_onoff_v == 2) // If AWS is ON then Display Reading of AWS
		{
			cairo_move_to(cr, 200, 315); 
			cairo_show_text(cr, "RG: ");
			cairo_show_text(cr, mea_rd[0]);
			cairo_move_to(cr, 280, 315); 
			cairo_show_text(cr, "IL: ");
			cairo_show_text(cr, mea_rd[1]);
			cairo_move_to(cr, 360, 315); 
			cairo_show_text(cr, "AF: ");
			cairo_show_text(cr, mea_rd[2]);
			cairo_move_to(cr, 420, 315); 
			cairo_show_text(cr, "RT: ");
			cairo_show_text(cr, mea_rd[3]);
		}
	}

	if (Measure_v2 == 1) // FOR ON G A VALUES
	{
		cairo_move_to(cr, 200, 340);
		cairo_show_text(cr, "SPa: ");
		cairo_show_text(cr, mea_rd[0]);
		cairo_move_to(cr, 280, 340);
		cairo_show_text(cr, "DPa: ");
		cairo_show_text(cr, mea_rd[1]);
		cairo_move_to(cr, 360, 340);
		cairo_show_text(cr, "SDa: ");
		cairo_show_text(cr, mea_rd[2]);
		cairo_move_to(cr, 420, 340);
		cairo_show_text(cr, "Ea: ");
		cairo_show_text(cr, mea_rd[3]);
	}
	else if (Measure_v2 == 2) // FOR ON G B VALUES
	{
		cairo_move_to(cr, 200, 315);
		cairo_show_text(cr, "SPb: ");
		cairo_show_text(cr, mea_rd[0]);
		cairo_move_to(cr, 280, 315);
		cairo_show_text(cr, "DPb: ");
		cairo_show_text(cr, mea_rd[1]);
		cairo_move_to(cr, 360, 315);
		cairo_show_text(cr, "SDb: ");
		cairo_show_text(cr, mea_rd[2]);
		cairo_move_to(cr, 420, 315);
		cairo_show_text(cr, "Eb: ");
		cairo_show_text(cr, mea_rd[3]);
	}
	else if (Measure_v2 == 3) // FOR DAC AWS OR DGS VALUES
	{
		if (Dac_v == 2)  // If DAC is ON
		{
			cairo_move_to(cr, 200, 315);
			cairo_show_text(cr, "DAC: ");
			cairo_show_text(cr, mea_rd[1]);
			cairo_move_to(cr, 280, 315);
			cairo_show_text(cr, "C dB: ");
			cairo_show_text(cr, mea_rd[2]);
			cairo_move_to(cr, 360, 315);
			cairo_show_text(cr, " ");
			cairo_move_to(cr, 420, 315);
			cairo_show_text(cr, "Ea: ");
			cairo_show_text(cr, mea_rd[3]);
		}
		else if (Dgs_onoff_v == 3) // If DGS is ON
		{
			cairo_move_to(cr, 200, 315);
			cairo_show_text(cr, "C dB: ");
			cairo_show_text(cr, mea_rd[0]);
			cairo_move_to(cr, 280, 315);
			cairo_show_text(cr, "ERS: ");
			cairo_show_text(cr, mea_rd[1]);
			cairo_move_to(cr, 360, 315);
			cairo_show_text(cr, "DGS c: ");
			cairo_show_text(cr, mea_rd[2]);
			cairo_move_to(cr, 420, 315);
			cairo_show_text(cr, "Ea: ");
			cairo_show_text(cr, mea_rd[3]);
		}
		else if (Aws_onoff_v == 2) // If AWS is ON then Display Reading of AWS
		{
			cairo_move_to(cr, 200, 315);
			cairo_show_text(cr, "RG: ");
			cairo_show_text(cr, mea_rd[0]);
			cairo_move_to(cr, 280, 315);
			cairo_show_text(cr, "IL: ");
			cairo_show_text(cr, mea_rd[1]);
			cairo_move_to(cr, 360, 315);
			cairo_show_text(cr, "AF: ");
			cairo_show_text(cr, mea_rd[2]);
			cairo_move_to(cr, 420, 315);
			cairo_show_text(cr, "RT: ");
			cairo_show_text(cr, mea_rd[3]);
		}
	}

	cairo_set_source_rgb(cr, 0.0, 0.0, 0.0);
	//for (i = 300; i < 695; i = i + 20) // For 3rd Vertical line border
	for (i = 325; i < 720; i = i + 20)
	{
		cairo_move_to(cr, 25, i);
		cairo_line_to(cr, 560, i);
		cairo_stroke(cr);
	}

	cairo_move_to(cr, 25, 325); // FIRST VERTICAL LINE
	cairo_line_to(cr, 25, 705);
	cairo_stroke(cr);

	cairo_move_to(cr, 560, 325); // LAST VERTICAL LINE
	cairo_line_to(cr, 560, 705);
	cairo_stroke(cr);

	cairo_move_to(cr, 155, 325); // FIRST COLUMN VERTICAL LINE
	cairo_line_to(cr, 155, 705);
	cairo_stroke(cr);

	cairo_move_to(cr, 285, 325); // SECOND COLUMN VERTICAL LINE
	cairo_line_to(cr, 285, 705);
	cairo_stroke(cr);

	cairo_move_to(cr, 415, 325); // THIRD COLUMN VERTICAL LINE
	cairo_line_to(cr, 415, 705);
	cairo_stroke(cr);

	for (j = 330; j < 710; j = j + 20) // FIRST VERTICAL DASHED LINE
	{
		cairo_move_to(cr, 87, j);
		cairo_line_to(cr, 87, j + 10);
		cairo_stroke(cr);
	}

	for (j = 330; j < 710; j = j + 20) // SECOND VERTICAL DASHED LINE
	{
		cairo_move_to(cr, 221, j); // 215
		cairo_line_to(cr, 221, j + 10); // 215
		cairo_stroke(cr);
	}

	for (j = 330; j < 710; j = j + 20) // THIRD VERTICAL DASHED LINE
	{
		cairo_move_to(cr, 350, j); //345 
		cairo_line_to(cr, 350, j + 10); // 345
		cairo_stroke(cr);
	}

	for (j = 330; j < 710; j = j + 20) // FOURTH VERTICAL DASHED LINE
	{
		cairo_move_to(cr, 477, j);
		cairo_line_to(cr, 477, j + 10);
		cairo_stroke(cr);
	}

	cairo_set_source_rgb(cr, 0, 0, 0);
	cairo_select_font_face(cr, "Sans", CAIRO_FONT_SLANT_NORMAL, CAIRO_FONT_WEIGHT_NORMAL);
	cairo_set_font_size(cr, 10.0);

	j = 340;  // VALUES OF 1st MENU IN 1st ROW
	for (i = 30, k = 0; i < 490, k < 8; i = i + 65, k++)
	{
		cairo_move_to(cr, i, j);
		cairo_show_text(cr, all_btnval[k]);
	}

	j = 360;  // VALUES OF 2nd MENU IN 2nd ROW
	for (i = 30, k = 10; i < 490, k < 18; i = i + 65, k++)
	{
		cairo_move_to(cr, i, j);
		cairo_show_text(cr, all_btnval[k]);
	}

	j = 380;  // VALUES OF 3rd MENU IN 3rd ROW
	for (i = 30, k = 20; i < 490, k < 28; i = i + 65, k++)
	{
		cairo_move_to(cr, i, j);
		cairo_show_text(cr, all_btnval[k]);
	}

	j = 400;  // VALUES OF 4th MENU IN 4th ROW
	for (i = 30, k = 30; i < 490, k < 38; i = i + 65, k++)
	{
		cairo_move_to(cr, i, j);
		cairo_show_text(cr, all_btnval[k]);
	}

	j = 420;  // VALUES OF 5th MENU IN 5th ROW
	for (i = 30, k = 40; i < 490, k < 48; i = i + 65, k++)
	{
		cairo_move_to(cr, i, j);
		cairo_show_text(cr, all_btnval[k]);
	}

	j = 440;  // VALUES OF 6th MENU IN 6th ROW
	for (i = 30, k = 50; i < 490, k < 58; i = i + 65, k++)
	{
		cairo_move_to(cr, i, j);
		cairo_show_text(cr, all_btnval[k]);
	}

	j = 460;  // VALUES OF 7th MENU IN 7th ROW
	for (i = 30, k = 60; i < 490, k < 68; i = i + 65, k++)
	{
		cairo_move_to(cr, i, j);
		cairo_show_text(cr, all_btnval[k]);
	}

	j = 480;  // VALUES OF 8th MENU IN 8th ROW
	for (i = 30, k = 70; i < 490, k < 78; i = i + 65, k++)
	{
		cairo_move_to(cr, i, j);
		cairo_show_text(cr, all_btnval[k]);
	}

	j = 500;  // VALUES OF 9th MENU IN 9th ROW
	for (i = 30, k = 80; i < 490, k < 88; i = i + 65, k++)
	{
		cairo_move_to(cr, i, j);
		cairo_show_text(cr, all_btnval[k]);
	}

	j = 520;  // VALUES OF 10th MENU IN 10th ROW
	for (i = 30, k = 90; i < 490, k < 98; i = i + 65, k++)
	{
		cairo_move_to(cr, i, j);
		cairo_show_text(cr, all_btnval[k]);
	}

	j = 540;  // VALUES OF 11th MENU IN 11th ROW
	for (i = 30, k = 100; i < 490, k < 108; i = i + 65, k++)
	{
		cairo_move_to(cr, i, j);
		cairo_show_text(cr, all_btnval[k]);
	}

	j = 560;  // VALUES OF 12th MENU IN 12th ROW
	cairo_move_to(cr, 30, j);
	cairo_show_text(cr, all_btnval[110]);
	cairo_move_to(cr, 90, j);
	cairo_show_text(cr, all_btnval[111]);
	for (i = 160, k = 112; i < 490, k < 118; i = i + 65, k++) // 30, 110
	{
		cairo_move_to(cr, i, j);
		cairo_show_text(cr, all_btnval[k]);
	}

	j = 580;  // VALUES OF 13th MENU IN 13th ROW
	for (i = 30, k = 120; i < 490, k < 128; i = i + 65, k++)
	{
		cairo_move_to(cr, i, j);
		cairo_show_text(cr, all_btnval[k]);
	}

	j = 600;  // VALUES OF 14th MENU IN 14th ROW
	for (i = 30, k = 130; i < 490, k < 138; i = i + 65, k++)
	{
		cairo_move_to(cr, i, j);
		cairo_show_text(cr, all_btnval[k]);
	}

	j = 620;  // VALUES OF 15th MENU IN 15th ROW
	for (i = 30, k = 140; i < 490, k < 148; i = i + 65, k++)
	{
		cairo_move_to(cr, i, j);
		cairo_show_text(cr, all_btnval[k]);
	}

	j = 640;  // VALUES OF 16th MENU IN 16th ROW
	for (i = 30, k = 150; i < 490, k < 158; i = i + 65, k++)
	{
		cairo_move_to(cr, i, j);
		cairo_show_text(cr, all_btnval[k]);
	}

	if (Evaluate_val == 2)
	{
		j = 660;  // VALUES OF DGS_FORM SCAL< DEFECT ETC.
		for (i = 30, k = 170; i < 490, k < 178; i = i + 65, k++)
		{
			cairo_move_to(cr, i, j);
			cairo_show_text(cr, all_btnval[k]);
		}

		j = 680;  // VALUES OF DGS_FORM SCAL< DEFECT ETC.
		for (i = 30, k = 180; i < 490, k < 188; i = i + 65, k++)
		{
			cairo_move_to(cr, i, j);
			cairo_show_text(cr, all_btnval[k]);
		}

		j = 700;  // VALUES OF DGS_FORM SCAL< DEFECT ETC.
		for (i = 30, k = 190; i < 490, k < 198; i = i + 65, k++)
		{
			cairo_move_to(cr, i, j);
			cairo_show_text(cr, all_btnval[k]);
		}
	}

	/***************************************************************************************************************************************/
	/********************************************FOR NOTE DETAIL SECTION *******************************************************************/
	/***************************************************************************************************************************************/
	//for (i = 525; i < imgh_line1; i = i + 20) // For 1st Vertical line border
	
	cairo_move_to(cr, 25.0, 726.0);
	cairo_select_font_face(cr, "Purisa", CAIRO_FONT_SLANT_NORMAL, CAIRO_FONT_WEIGHT_BOLD);
	cairo_show_text(cr, "NOTE DETAILS");
	cairo_fill(cr);

	cairo_set_source_rgb(cr, 0.0, 0.0, 0.0);
	for (i = 735; i < 825; i = i + 20) // For 1st Vertical line border
	{
		cairo_move_to(cr, 25, i);
		cairo_line_to(cr, 25, i + 20);
		cairo_stroke(cr);
	}

	for (i = 735; i < 825; i = i + 20) // For last Vertical line border
	{
		cairo_move_to(cr, 565, i);
		cairo_line_to(cr, 565, i + 20);
		cairo_stroke(cr);
	}

	for (i = 735; i < 825 + 20; i = i + 20) // For all Horizontal lines
	{
		cairo_move_to(cr, 25, i);
		cairo_line_to(cr, 565, i);
		cairo_stroke(cr);
	}

	for (i = 735; i < 825; i = i + 20) // For middle vertical line separating columns
	{
		cairo_move_to(cr, 295, i);
		cairo_line_to(cr, 295, i + 20);
		cairo_stroke(cr);
	}

	cairo_select_font_face(cr, "Purisa", CAIRO_FONT_SLANT_NORMAL, CAIRO_FONT_WEIGHT_NORMAL);
	cairo_set_source_rgb(cr, 1.0, 0.0, 1.0);

	// For 1st column data
	i = 30;
	for (j = 750, k = 0; j < 830, k < 5; j = j + 20, k++)
	{
		cairo_move_to(cr, i, j);
		cairo_show_text(cr, heading_name[k]);
	}

	cairo_set_source_rgb(cr, 1.0, 0.0, 0.0);
	// For 2nd column data
	i = 300;
	for (j = 750, k = 0; j < 830, k < 5; j = j + 20, k++)
	{
		cairo_move_to(cr, i, j);
		cairo_show_text(cr, text_values[k]);
	}

	cairo_show_page(cr);
	cairo_surface_destroy(surface);
	cairo_destroy(cr);
}

//***************************** SPI Interface Code Start **************************************

static void pabort(const char *s)
{
	perror(s);
	abort();
}

static const char *device = "/dev/spidev1.0";
static uint8_t mode;
static uint8_t bits = 8;
static uint32_t speed = 10000000; // 500000;
static uint16_t delay;

static void transfer(int fd)
{
	int ret;
	uint8_t tx[] = {
		0xA5,
		0xAA,
		0xFF,
		0xFF,
		0xFF,
		0xFF,
		0xAA,
		0x00,
		0x00,
		0x00,
		0x00,
		0x95,
		0xAA,
		0xAA,
		0xFF,
		0xFF,
		0xFF,
		0xFF,
		0xAA,
		0xFF,
		0xAA,
		0xFF,
		0xFF,
		0xFF,
		0xAA,
		0xFF,
		0xFF,
		0xAA,
		0xFF,
		0xFF,
		0xDE,
		0xAD,
		0xBE,
		0xEF,
		0xBA,
		0xAA,
		0x00,
		0x0D,
	};
	uint8_t rx[ARRAY_SIZE(tx)] = {
		0,
	};
	struct spi_ioc_transfer tr = {
		.tx_buf = (unsigned long)tx,
		.rx_buf = (unsigned long)rx,
		.len = ARRAY_SIZE(tx),
		.delay_usecs = delay,
		.speed_hz = speed,
		.bits_per_word = bits,
	};

	ret = ioctl(fd, SPI_IOC_MESSAGE(1), &tr);
	if (ret < 1)
		pabort("can't send spi message");

	for (ret = 0; ret < ARRAY_SIZE(tx); ret++)
	{
		if (!(ret % 6))
			puts("");
		printf("%.2X ", rx[ret]);
	}
	puts("");
}

//***************************** Send data through SPI *****************************************
// static
void Send_SPI(int tx_nofd)
{
	int ret;

	if (Spi_open == false)
	{
		return;
	}

	struct spi_ioc_transfer tr = {
		.tx_buf = (unsigned long)tx_cmd,
		.rx_buf = (unsigned long)rx_cmd,
		.len = tx_nofd, //.len = ARRAY_SIZE(tx_cmd),
		.delay_usecs = delay,
		.speed_hz = speed,
		.bits_per_word = bits,
	};

	ret = ioctl(fd_SPI, SPI_IOC_MESSAGE(1), &tr);
	if (ret < 1)
		pabort("can't send spi message");
}

static void print_usage(const char *prog)
{
	printf("Usage: %s [-DsbdlHOLC3]\n", prog);
	puts("  -D --device   device to use (default /dev/spidev1.1)\n"
		 "  -s --speed    max speed (Hz)\n"
		 "  -d --delay    delay (usec)\n"
		 "  -b --bpw      bits per word \n"
		 "  -l --loop     loopback\n"
		 "  -H --cpha     clock phase\n"
		 "  -O --cpol     clock polarity\n"
		 "  -L --lsb      least significant bit first\n"
		 "  -C --cs-high  chip select active high\n"
		 "  -3 --3wire    SI/SO signals shared\n");
	exit(1);
}

static void parse_opts(int argc, char *argv[])
{
	while (1)
	{
		static const struct option lopts[] = {
			{"device", 1, 0, 'D'},
			{"speed", 1, 0, 's'},
			{"delay", 1, 0, 'd'},
			{"bpw", 1, 0, 'b'},
			{"loop", 0, 0, 'l'},
			{"cpha", 0, 0, 'H'},
			{"cpol", 0, 0, 'O'},
			{"lsb", 0, 0, 'L'},
			{"cs-high", 0, 0, 'C'},
			{"3wire", 0, 0, '3'},
			{"no-cs", 0, 0, 'N'},
			{"ready", 0, 0, 'R'},
			{NULL, 0, 0, 0},
		};
		
		int c;

		c = getopt_long(argc, argv, "D:s:d:b:lHOLC3NR", lopts, NULL);

		if (c == -1)
			break;

		switch (c)
		{
		case 'D':
			device = optarg;
			break;
		case 's':
			speed = atoi(optarg);
			break;
		case 'd':
			delay = atoi(optarg);
			break;
		case 'b':
			bits = atoi(optarg);
			break;
		case 'l':
			mode |= SPI_LOOP;
			break;
		case 'H':
			mode |= SPI_CPHA;
			break;
		case 'O':
			mode |= SPI_CPOL;
			break;
		case 'L':
			mode |= SPI_LSB_FIRST;
			break;
		case 'C':
			mode |= SPI_CS_HIGH;
			break;
		case '3':
			mode |= SPI_3WIRE;
			break;
		case 'N':
			mode |= SPI_NO_CS;
			break;
		case 'R':
			mode |= SPI_READY;
			break;
		default:
			print_usage(argv[0]);
			break;
		}
	}
}

//***********************************************************************************************************
void Send_filt() //
{
	int i, j, k;
	int lsb, msb, data, ds;
	unsigned char wData;

	// Filt_05to40[i]
	ds = 0;
	tx_cmd[ds++] = 0x1B;
	tx_cmd[ds++] = 0x088;
	tx_cmd[ds++] = 0x016;
	tx_cmd[ds++] = 0x1B; // 1B 88 16 1B
	Send_SPI(ds);		 // Send data
	ds = 0;				 
	return;

	ds = 0;
	for (i = 0; i < 97; i++)
	{
		data = Filt_0p5to4p0[i];
		msb = data & 0x00FF00;
		msb = msb >> 8;
		wData = (unsigned char)data;
		tx_cmd[ds++] = 0x1B;
		tx_cmd[ds++] = msb;
		tx_cmd[ds++] = wData;
		tx_cmd[ds++] = 0x1B;
		printf("0=%d ,1=%d ,2=%d ,3=%d \n", tx_cmd[0], tx_cmd[1], tx_cmd[2], tx_cmd[3]);
	}
	ds = 0;
	for (i = 0; i < 97; i++)
	{
		printf("0=%d ,1=%d ,2=%d ,3=%d \n", tx_cmd[ds++], tx_cmd[ds++], tx_cmd[ds++], tx_cmd[ds++]);
	}
}

//************************************************************************************************************************
void Check_1K() //
{				// Print_data=true;
	int ret;
	SPI_Receive();

	{
		for (ret = 0; ret < 500; ret++) // for (ret = 0; ret < ARRAY_SIZE(tx_cmd); ret++) {
		{
			if (!(ret % 16))
				puts("");
			printf("%.2X ", rx_cmd[ret]); // printf("%.2X ", rx_cmd[ret]);
		}
		puts("");
	}

	Get_Data();							   // Transfer data to Opengl Buffer from SPI Buffer
	ogl_render(frame_width, frame_height); // Call Opengl to display the Data
}

//****************************************************************
void SPI_Receive()
{
	int i, j, k;
	int lsb, msb, data, ret, ds;
	unsigned char wData;

	// Filt_05to40[i]

	ds = 0;
	// if (horn_val==0)
	//   { tx_cmd[ds++]=0x1B; tx_cmd[ds++]=0x085; tx_cmd[ds++]=0x030; tx_cmd[ds++]=0x1B;  }     // 1B 85 30 1B   Ramp
	// else
	{
		tx_cmd[ds++] = 0x1B;
		tx_cmd[ds++] = 0x085;
		tx_cmd[ds++] = 0x010;
		tx_cmd[ds++] = 0x1B;
	} // 1B 85 10 1B   //RF

	tx_cmd[ds++] = 0x1B;
	tx_cmd[ds++] = 0x004;
	tx_cmd[ds++] = 0x005;
	tx_cmd[ds++] = 0x1B; // 1B 04 05 1B
	tx_cmd[ds++] = 0x1B;
	tx_cmd[ds++] = 0x004;
	tx_cmd[ds++] = 0x004;
	tx_cmd[ds++] = 0x1B; // 1B 04 04 1B

	for (i = 0; i < 500; i++)
	{
		rx_cmd[ds] = 0x0;
		tx_cmd[ds++] = 0x0; //(unsigned char) i;  // tx_cmd[ds++]=0x00;
	}
	// ds=32;
	Send_SPI(ds); // Send data
}

//************************************************************************************************************************
int Check_SPI() // int main(int argc, char *argv[])  //int main(int argc, char *argv[])
{
	int argc;
	char *argv[100];

	int ret = 0;
	int fd;

	parse_opts(argc, argv);

	fd = open(device, O_RDWR);
	if (fd < 0)
		pabort("can't open device");

	/** spi mode **/
	ret = ioctl(fd, SPI_IOC_WR_MODE, &mode);
	if (ret == -1)
		pabort("can't set spi mode");

	ret = ioctl(fd, SPI_IOC_RD_MODE, &mode);
	if (ret == -1)
		pabort("can't get spi mode");

	/** bits per word **/
	ret = ioctl(fd, SPI_IOC_WR_BITS_PER_WORD, &bits);
	if (ret == -1)
		pabort("can't set bits per word");

	ret = ioctl(fd, SPI_IOC_RD_BITS_PER_WORD, &bits);
	if (ret == -1)
		pabort("can't get bits per word");

	/** max speed hz **/
	ret = ioctl(fd, SPI_IOC_WR_MAX_SPEED_HZ, &speed);
	if (ret == -1)
		pabort("can't set max speed hz");

	ret = ioctl(fd, SPI_IOC_RD_MAX_SPEED_HZ, &speed);
	if (ret == -1)
		pabort("can't get max speed hz");

	printf("spi mode: %d\n", mode);
	printf("bits per word: %d\n", bits);
	printf("max speed: %d Hz (%d KHz)\n", speed, speed / 1000);

	transfer(fd);

	// close(fd);
	fd_SPI = fd;

	return ret;
}

void Init_all()
{
	int ds = 0;
	int Timer_tm;
	char buffer[8];
	key_scr = 1;

	Init_SPI();

	tx_cmd[ds++] = 0x1B;
	tx_cmd[ds++] = 0x090;
	tx_cmd[ds++] = 0x010;
	tx_cmd[ds++] = 0x1B;  // 1B 90 xxx1 xxxx 1B // PRF ON

	Send_SPI(ds); // Send data
	ds = 0;

	val_ary[RECTIFY_PERA] = 0;
	Rectify_f(0);

	val_ary[GATE1_PERA] = 1;
	Gatea_f(0);

	ds = val_ary[GATE1_PERA];
	
	Asc_Dsp = 1;

	Freq_f(0);		   // Set Frequency Band
	timer_flag = true; // Time would start
	Timer_Start_Stop();

	Clr_leg_sta = (Asc_Width * 2) / 10;
	Clr_leg_width = (Asc_Width * 3) / 10;
}

int Init_SPI() 
{
	int ret = 0, ds;  

	// Spi_open = false;
	// return 0;

	ret = Check_SPI();
	if (ret < 0)
	{
		Spi_open = false;
		printf("SPI ERROR \n");
	}
	else
	{
		Spi_open = true;
		printf("SPI OK \n");
	}

	//	Send_filt();
	Rectify_v = 0;
	Rectify_f(0);
	Gain_f(0);
	
	ds = 0;
	// if (beep_val==1)
	{
		tx_cmd[ds++] = 0x1B;
		tx_cmd[ds++] = 0x090;
		tx_cmd[ds++] = 0x010;
		tx_cmd[ds++] = 0x1B;
	} // 1B 90 xxx1 xxxx 1B // PRF ON

	Send_SPI(ds); // Send data
	Menu_Refresh();
}

//********************* SPI Interface Code end *************************

void timer_signal_function(GtkWidget *widget, gpointer window)
{
	Timer_Start_Stop();
}

void Timer_Start_Stop()
{
	int Timer_tm;

	Timer_tm = 50; // Timer_tm=scr_val;   // Time in Milli Second
	if (timer_flag == true)
	{
		signal_id = g_timeout_add((guint)Timer_tm, (GSourceFunc)time_handler_function, NULL);
		timer_flag = false;
	}
	else
	{
		if (signal_id)
		{
			g_source_remove(signal_id);
			signal_id = 0;
		}
		timer_flag = true;
	}
}

// timer helper function
gboolean time_handler_function(void)
{
	int ret_pwr;
	char buffer[30];
	// Key_press=false
	Key_ck = Key_ck + 1; // if (Key_ck>10000){Key_ck=100;}
	if (Key_ck > 8)
	{
		Keypad_ck(); // Read Keypad Data
		if (Key_press == true)
		{
			Key_Delay = Key_Delay + 25;
			if (Key_Delay > 100)
			{
				Key_Delay = 100;
			}
			Key_ck = Key_Delay / 10;
			Key_function();
		}
		else
		{
			Key_Delay = 0;
			Key_ck = 8;
		}

		if (opengl_update == true)
		{
			if (Asc_Dsp > 0) // if(Gate1_v>0)
			{
				refresh_opengl_display();
			}
		}
		// For acceleration rate Key_Delay value keep on increase
	}
	else
	{
		if (opengl_update == true)
		{
			if (Asc_Dsp > 0) // if(Gate1_v>0)
			{
				refresh_opengl_display();
			}
		}
	}

	if (lastCalSetupFlag == 1)
	{
		PowerKey_ck();
	}
	
	Measure_dsp++;
	
	if (Measure_dsp > 10) // Measurement Display rate is controlled by this value
	{
		Measure_dsp = 0;
		if (Measure_v1 > 0 || Measure_v2 > 0 || Measure_v3 > 0) // If measurement is ON then Get Meaurement reading and Display on LCD
		{
			Measure_f();
		} // If measurement is ON then Get Meaurement reading and Display on LCD
		Clk_ref = Clk_ref + 1;
		if (Clk_ref > 20) // Refersh Clock time
		{
			t = time(NULL);
			tm = *localtime(&t);
			sprintf(Tmstr, "Time:%02d:%02d\nDt:%02d/%02d/%d", (char)tm.tm_hour, (char)tm.tm_min, (char)tm.tm_mday, (char)tm.tm_mon + 1, (char)tm.tm_year + 1900);
			gtk_label_set_label(GTK_LABEL(Clock_lab), Tmstr);

			Clk_ref = 0;
			if (Error_msg == true)
			{
				gtk_widget_hide(b_errorbox);
				gtk_widget_show(b_btnbox);
				Error_msg = false;
			}
		}
	}

	Batt_dsp++;
	if (Batt_dsp > 40) // Measurement Display rate is controlled by this value
	{
		Batt_val = Batt_val + 5;
		if (Batt_val > 100)
		{
			Batt_val = 0;
		}
		//Battery_Symbol(Batt_val, 0);
		ADC_read();
		Batt_dsp = 0;
	}

	DetectUsb(); // To detect if pendrive connected or not
	DetectSDCard(); // To detect if SD Card connected or not

	if (Gate1_v > 0 || Gate2_v > 0)
	{
		Check_Gate_cross(); //*** If echo cross the Gate then Generate Alarm signal
	}
	return true;
}

//*******************************************************
void Get_Data()
{
	int i, temp, dst;
	int RejP, RejN;
	int Src_idx = 13; // Offset is used because starting 12 data is Command and Framing so it should be discard
	GLfloat tmpgl;
	float tfd, offst;
    offst = (50.0f + (((((float)splite_frame_height - 2.0f) - (float)Asc_Height) / 8.0f)));  // offset = 51.750000
	tfd = (50.0f * ((float)splite_frame_height - 2.0f)) / (float)Asc_Height;   				 // tfd = 51.627907

	// Asc_Dsp=1;

	if (Spi_open == false)
	{
		ogl_update(); // Display Artifical Data
		return;
	}

	if (Rectify_v == 3) // IF RF Is selected
	{
		RejP = 50 + (Reject_v / 2);
		RejN = 50 - (Reject_v / 2);

		for (i = 0; i < 256; i++) // 256+13
		{
			temp = rx_cmd[Src_idx++];
			if (temp > 127)
			{
				temp = temp - 127;
			}
			else
			{
				temp = temp + 127;
			}
			temp = temp / 2;
			temp = temp - 13; // 13+ offset 16  //   It comes to 64  (128/2 =64) but we required 50 so 64-13  so it would become about 50
			if (temp > 50 && temp < RejP)
			{
				temp = 50;
			}
			if (temp < 50 && temp > RejN)
			{
				temp = 50;
			}
			// and A-Scan position if offseted by Frameheight- A-Scan hight so that should be compensated so Base line would be at centere of Grid
			if (temp > 100)
			{
				temp = 100;
			}
			if (temp < 0)
			{
				temp = 0;
			}
			All_Ascan_data[i] = temp; // row_y[i];
			temp = temp - 2;
			row_y[i] = (GLubyte)temp;

			if (row_y[i] > 100)
				ogl.vertices_position[(i * 2) + 1] = ((0.0f - offst) / tfd);    
			else if (row_y[i] >= 98)
				ogl.vertices_position[(i * 2) + 1] = ((100.0f - offst) / tfd);
			else
				ogl.vertices_position[(i * 2) + 1] = (((GLfloat)row_y[i] - offst) / tfd);
		}

		if ((Record_Type_val == 0 || Record_Type_val == 1 || Record_Type_val == 3) && (rw_flag == 0))
		{
			write_data_in_bsc_file(&row_y[0]);
		}

		if (Ascan_peak_flag == true)
		{
			for (i = 0; i < 256; i++) // Copy Ascan data from reference
			{
				All_Ascan_peak[(i * 2) + 1] = ogl.vertices_position[(i * 2) + 1];
			}
			Ascan_peak_flag = false;
		}
	}
	else
	{
		if (Smooth_v > 0)
		{
			Smooth_Asc();
		} // For +ve. -ve and Envelop
		for (i = 0; i < 256; i++)
		{
			temp = rx_cmd[Src_idx++];
			if (temp < 0)
			{
				temp = 0;
			}
			if (temp > 100)
			{
				temp = 100;
			}
			if (temp < Reject_v)
			{
				temp = 0;
			}
			row_y[i] = (GLubyte)temp;
			All_Ascan_data[i] = (int)row_y[i];

			// ogl.vertices_position[(i * 2) + 1] = ((GLfloat)row_y[i] - 50.0f) / 50.0f;
			ogl.vertices_position[(i * 2) + 1] = (((GLfloat)row_y[i]) - offst) / tfd; // - 50.0f) / 50.0f;
		}

		if ((Record_Type_val == 0 || Record_Type_val == 1 || Record_Type_val == 3) && (rw_flag == 0))
		{			
			write_data_in_bsc_file(&row_y[0]);
		}

		if (Ascan_peak_flag == true)
		{
			for (i = 0; i < 256; i++) // Copy Ascan data fro referance
			{
				All_Ascan_peak[(i * 2) + 1] = ogl.vertices_position[(i * 2) + 1];
			}
			Ascan_peak_flag = false;
		}
	}

	if (video_val == 1) // IF Video Mode is Filled selected
	{
		for (i = 256; i > 0; i--)
		{
			tmpgl = ogl.vertices_position[(i * 2) + 1]; // Get Value of y
			dst = (i * 6) + 1;
			ogl.vertices_position[dst] = tmpgl;
			ogl.vertices_position[dst + 2] = -1; // tmpgl;
			ogl.vertices_position[dst + 4] = tmpgl;
		}
	}

	if (video_val == 2) // If Video Dynamic is selected
	{
		for (i = 0; i < 256; i++)
		{
			if (row_y[i] > Asc_Max[i])
			{
				Asc_Max[i] = row_y[i];
			}
			ogl.vertices_position[(i * 2) + 1 + 1536] = (((GLfloat)Asc_Max[i] - offst) / tfd);
			// ogl.vertices_position[(i * 2) + 1 + 1536] = (((GLfloat)Asc_Max[i] - 50.0f) / 50.0f);
		}
	}

	if (rx_cmd[12] != 0x1B)
	{
		printf("FRAME ST Error  \n");
	}
}

void Send_Data_to_OpenGL(void)
{
	GLint idx = 0;
	float tfd, offst;
    tfd = (50.0f * ((float)splite_frame_height - 2.0f)) / (float)Asc_Height;
    offst = (50.0f + ((((float)splite_frame_height - 2.0f) - (float)Asc_Height) / 8.0f));

	idx = cur_idx;
    idx = idx & 0x3FF;
    idx = idx << 8;

	for (i = 0; i < num_of_vertices; i++)
	{
		if (Dac_Bscan_flag == true)
			ogl.vertices_position[(i * 2) + 1] = ((GLfloat)bscfiledata[idx++] - offst) / tfd; // transfer data to OpenGL Buffer to Draw Bscan
		else if (Dac_Bscan_flag == false)
			ogl.vertices_position[(i * 2) + 1] = ((GLfloat)row_y[i] - offst) / tfd; // Ascan And DGS draw read from file and display to user
	}

	/*
	for (i = 0; i < num_of_vertices; i++)
	{
		if (Dac_Bscan_flag == true)
			ogl.vertices_position[(i * 2) + 1] = ((GLfloat)bscfiledata[idx++] - 50.0f) / 50.0f; // transfer data to OpenGL Buffer to Draw Bscan
		else if (Dac_Bscan_flag == false)
			ogl.vertices_position[(i * 2) + 1] = ((GLfloat)row_y[i] - 50.0f) / 50.0f; // Ascan And DGS draw read from file and display to user
	}
	*/
}

//*********************************************************************************************
void refresh_opengl_display(void)
{
	if (Spi_open == true)
	{
		if (rw_flag == -1 || rw_flag == 0)
		{
			Enc_curr = Enc_pos1;

			SPI_Receive(); // Receive Data using SPI
			Get_Data();	   // Transfer data to Opengl Buffer from SPI Buffer

			ogl_render(frame_width, frame_height); // Call Opengl to display the Data
			if (Bsc_Dsp == true && val_ary[ENCODER_PERA] == 0)  // Free run
			{
				refresh_to_plot_data();
			}
			else if (Bsc_Dsp == true && val_ary[ENCODER_PERA] == 1 &&  Enc_curr > Enc_prev) // Encoder Forword
			{
				fwbw_flag = 0;
				data_shift = Enc_curr - Enc_prev;

				Draw_Bscan_Color_encoder();

				data_shift = 0;
				Enc_prev = Enc_curr;
			}
			else if (Bsc_Dsp == true && val_ary[ENCODER_PERA] == 1 &&  Enc_curr < Enc_prev) // Encoder backword or (Reverse)
			{
				fwbw_flag == 1;
				data_shift = Enc_prev - Enc_curr;

				Draw_Bscan_Color_encoder();

				data_shift = 0;
				Enc_prev = Enc_curr;
			}
		}
		else if (rw_flag == 1)
		{
			read_data_using_button_fun_for_Board(1);
		}
	}
	else if (Spi_open == false)
	{
		if (rw_flag == -1 || rw_flag == 0)
			send_data();
		else if (rw_flag == 1)
			read_data_using_button_fun(1);	
	}
}

// update board display function
void send_data_board(void)
{
	Send_Data_to_OpenGL();
	ogl_render(frame_width, frame_height); // Call Opengl to display the Data

	if (Bsc_Dsp == true)
		refresh_to_plot_data();
}

// update display function
void send_data(void)
{
	ogl_update();
	ogl_render(frame_width, frame_height); // Call Opengl to display the Data

	if (Bsc_Dsp == true)
		refresh_to_plot_data();
}

void gate_display(void)
{
	ogl_render(width_sh, height_sh);
}

// ***************************************************************************
// *************** Echo Shape Smpoothing *************************************
// ***************************************************************************

void Smooth_Asc()
{
	int i, x1, x2, x3, x4, x5, x6, k, diff;
	int n1, n2, n3, n4, n5;

	if (Smooth_v == 1) // Check upto 3 points
	{
		for (i = 0; i < 256; i++)
		{
			x1 = rx_cmd[i];
			x2 = rx_cmd[i + 1];
			x3 = rx_cmd[i + 2];
			if ((x1 > x2) & (x3 > x1)) // Velly in Rising edge
			{
				x2 = (x1 + x3) / 2;
				rx_cmd[i + 1] = x2;
				i = i + 1;
			}
			else if ((x1 > x2) & (x3 > x2)) // Valley in Falling edge
			{
				x2 = (x1 + x3) / 2;
				rx_cmd[i + 1] = x2;
				i = i + 1;
			}
		}
	}

	if (Smooth_v == 2) // Check upto 4 points
	{
		for (i = 0; i < 256; i++)
		{
			x1 = rx_cmd[i];
			x2 = rx_cmd[i + 1];
			x3 = rx_cmd[i + 2];
			x4 = rx_cmd[i + 3];

			if ((x4 > x1) & (x1 > 10)) // Valley in Rising edge
			{
				diff = (x4 - x1) / 3;
				n2 = x1 + diff;
				n3 = x1 + diff + diff;
				if ((x2 < x1) & (x3 < x1)) // if (x2<x4 & x3<x4) // if both are lower   x3)/2; rx_cmd[i+1]=x2; i=i+1;}
				{
					rx_cmd[i + 1] = n2;
					rx_cmd[i + 2] = n3;
				}
				else if (x2 < n2)
				{
					rx_cmd[i + 1] = n2;
				}
				else if (x3 < x3)
				{
					rx_cmd[i + 2] = n3;
				}
			}
			else if (x1 > 10) // Valley in Falling edge
			{
				diff = (x1 - x4) / 3;
				n2 = x1 - diff;
				n3 = n2 - diff;
				if ((x2 < x4) & (x3 < x4)) // if both are lower   x3)/2; rx_cmd[i+1]=x2; i=i+1;}
				{
					rx_cmd[i + 1] = n2;
					rx_cmd[i + 2] = n3;
				}
				else if (x2 < n2)
				{
					rx_cmd[i + 1] = n2;
				}
				else if (x3 < x3)
				{
					rx_cmd[i + 2] = n3;
				}
			}
		}
	}

	if (Smooth_v == 3) // Check upto 5 points
	{
		for (i = 0; i < 256; i++)
		{
			x1 = rx_cmd[i];
			x2 = rx_cmd[i + 1];
			x3 = rx_cmd[i + 2];
			x4 = rx_cmd[i + 3];
			x5 = rx_cmd[i + 4];
			if ((x5 > x1) & (x1 > 10)) // Valley in Rising edge
			{
				diff = (x5 - x1) / 4;
				n2 = x1 + diff;
				n3 = n2 + diff;
				n4 = n3 + diff;
				if ((x1 > x2) & (x1 > x3) & (x1 > x4)) // if all lower   x3)/2; rx_cmd[i+1]=x2; i=i+1;}
				{
					rx_cmd[i + 1] = n2;
					rx_cmd[i + 2] = n3;
					rx_cmd[i + 3] = n4;
				}
				if (x2 < n2)
				{
					rx_cmd[i + 1] = n2;
				}
				if (x3 < n3)
				{
					rx_cmd[i + 2] = n3;
				}
				if (x4 < n4)
				{
					rx_cmd[i + 3] = n4;
				}
			}

			else if (x1 > 10) // Valley in Falling edge
			{
				diff = (x1 - x5) / 4;
				n2 = x1 - diff;
				n3 = n2 - diff;
				n4 = n3 - diff;
				if ((x5 > x2) & (x5 > x3) & (x5 > x4)) // if all lower   x3)/2; rx_cmd[i+1]=x2; i=i+1;}
				{
					rx_cmd[i + 1] = n2;
					rx_cmd[i + 2] = n3;
					rx_cmd[i + 3] = n4;
				}
				if (x2 < n2)
				{
					rx_cmd[i + 1] = n2;
				}
				if (x3 < n3)
				{
					rx_cmd[i + 2] = n3;
				}
				if (x4 < n4)
				{
					rx_cmd[i + 3] = n4;
				}
			}
		}
	}

	if (Smooth_v == 4) // Check upto 6 points
	{
		for (i = 0; i < 256; i++)
		{
			x1 = rx_cmd[i];
			x2 = rx_cmd[i + 1];
			x3 = rx_cmd[i + 2];
			x4 = rx_cmd[i + 3];
			x5 = rx_cmd[i + 4];
			x6 = rx_cmd[i + 5];
			if ((x6 > x1) & (x1 > 10)) // Valley in Rising edge
			{
				diff = (x5 - x1) / 5;
				n2 = x1 + diff;
				n3 = n2 + diff;
				n4 = n3 + diff;
				n5 = n4 + diff;
				if ((x1 > x2) & (x1 > x3) & (x1 > x4) & (x1 > x5)) // if all lower   x3)/2; rx_cmd[i+1]=x2; i=i+1;}
				{
					rx_cmd[i + 1] = n2;
					rx_cmd[i + 2] = n3;
					rx_cmd[i + 3] = n4;
					rx_cmd[i + 4] = n5;
				}
				if (x2 < n2)
				{
					rx_cmd[i + 1] = n2;
				}
				if (x3 < n3)
				{
					rx_cmd[i + 2] = n3;
				}
				if (x4 < n4)
				{
					rx_cmd[i + 3] = n4;
				}
				if (x5 < n5)
				{
					rx_cmd[i + 4] = n5;
				}
			}
			else if (x1 > 10) // Valley in Falling edge
			{
				diff = (x1 - x6) / 5;
				n2 = x1 - diff;
				n3 = n2 - diff;
				n4 = n3 - diff;
				n5 = n4 + diff;
				if ((x6 > x2) & (x6 > x3) & (x6 > x4) & (x6 > x5)) // if all lower   x3)/2; rx_cmd[i+1]=x2; i=i+1;}
				{
					rx_cmd[i + 1] = n2;
					rx_cmd[i + 2] = n3;
					rx_cmd[i + 3] = n4;
					rx_cmd[i + 4] = n5;
				}
				if (x2 < n2)
				{
					rx_cmd[i + 1] = n2;
				}
				if (x3 < n3)
				{
					rx_cmd[i + 2] = n3;
				}
				if (x4 < n4)
				{
					rx_cmd[i + 3] = n4;
				}
				if (x5 < n5)
				{
					rx_cmd[i + 4] = n5;
				}
			}
		}
	}
}

/************************************************************************************/
/********************************SCROLL FUNCTIONS************************************/
/************************************************************************************/
void OnScroll(GtkRange *range, gpointer data)
{
	gdouble step_inc = 1;
	gdouble stpg;
	key_scr = 0;
	scr_val = gtk_adjustment_get_value(adj);
	val_ary[(menu_v * 5) + btn_idx] = scr_val;
	sprintf(snum, "%d", scr_val);
	AllProcess(0);
}

/************************************************************************************/
/************************CONNECT BUTTON WITH SCROLL BAR FUNCTIONS********************/
/************************************************************************************/

void OnBtn_press(GtkWidget *widget, GdkEventButton *event, gpointer data)
{ 
	//  if (event->type == GDK_BUTTON_PRESS)   // if (event->type == GDK_BUTTON_PRESS)
	{
		if (GTK_WIDGET(widget) == btn_dv[1])
		{
			btn_idx = 0;
			if (menu_v == 0 || menu_v == 6 || menu_v == 7 || menu_v == 9)
			{
				Numerickey_Btn();
			}
		}
		if (GTK_WIDGET(widget) == btn_dv[3])
		{
			btn_idx = 1;
			if (menu_v == 0 || menu_v == 1 || menu_v == 2 || menu_v == 4 || menu_v == 8 || menu_v == 9 || menu_v == 11 || menu_v == 14)
			{
				Numerickey_Btn();
			}
		}
		if (GTK_WIDGET(widget) == btn_dv[5])
		{
			btn_idx = 2;
			if (menu_v == 0 || menu_v == 1 || menu_v == 2 || menu_v == 8 || menu_v == 9 || menu_v == 11 || menu_v == 14 || menu_v == 15)
			{
				Numerickey_Btn();
			}
		}
		if (GTK_WIDGET(widget) == btn_dv[7])
		{
			btn_idx = 3;
			if (menu_v == 0 || menu_v == 1 || menu_v == 2 || menu_v == 4 || menu_v == 11 || menu_v == 15 || menu_v == 5)
			{
				Numerickey_Btn();
			}
		}
		if (GTK_WIDGET(widget) == btn_dv[9])
		{
			btn_idx = 4;
			Numerickey_Btn();
		}

		if (GTK_WIDGET(widget) == dgs_btn[1])
		{
			btn_idx = 0;
			menu_v = Sub_st_menu;
			if (menu_v == 17)
			{
				Numerickey_Btn();
			}
		}
		if (GTK_WIDGET(widget) == dgs_btn[3])
		{
			btn_idx = 1;
			menu_v = Sub_st_menu;
			if (menu_v == 20)
			{
				Numerickey_Btn();
			}
		}
		if (GTK_WIDGET(widget) == dgs_btn[5])
		{
			btn_idx = 2;
			menu_v = Sub_st_menu;
			if (menu_v == 17 || menu_v == 20)
			{
				Numerickey_Btn();
			}
		}
		if (GTK_WIDGET(widget) == dgs_btn[7])
		{
			btn_idx = 3;
			menu_v = Sub_st_menu;
			if (menu_v == 17 || menu_v == 20)
			{
				Numerickey_Btn();
			}
		}
		if (GTK_WIDGET(widget) == dgs_btn[9])
		{
			btn_idx = 0;
			menu_v = Sub_st_menu + 1;
			if (menu_v == 18)
			{
				Numerickey_Btn();
			}
		}
		if (GTK_WIDGET(widget) == dgs_btn[11])
		{
			btn_idx = 1;
			menu_v = Sub_st_menu + 1;
			if (menu_v == 18 || menu_v == 21)
			{
				Numerickey_Btn();
			}
		}
		if (GTK_WIDGET(widget) == dgs_btn[13])
		{
			btn_idx = 2;
			menu_v = Sub_st_menu + 1;
			if (menu_v == 21)
			{
				Numerickey_Btn();
			}
		}
		if (GTK_WIDGET(widget) == dgs_btn[15])
		{
			btn_idx = 3;
			menu_v = Sub_st_menu + 1;
			if (menu_v == 18 || menu_v == 21)
			{
				Numerickey_Btn();
			}
		}
		if (GTK_WIDGET(widget) == dgs_btn[17])
		{
			btn_idx = 0;
			menu_v = Sub_st_menu + 2;
		}
		if (GTK_WIDGET(widget) == dgs_btn[19])
		{
			btn_idx = 1;
			menu_v = Sub_st_menu + 2;
			if (menu_v == 19 || menu_v == 22)
			{
				Numerickey_Btn();
			}
		}
		if (GTK_WIDGET(widget) == dgs_btn[21])
		{
			btn_idx = 2;
			menu_v = Sub_st_menu + 2;
			if (menu_v == 19 || menu_v == 22)
			{
				Numerickey_Btn();
			}
		}
		if (GTK_WIDGET(widget) == dgs_btn[23])
		{
			btn_idx = 3;
			menu_v = Sub_st_menu + 2;
			if (menu_v == 19 || menu_v == 22)
			{
				Numerickey_Btn();
			}
		}
		Set_btn_focus(); // Set Button/Controll Focus /Appropriate Color to indicate SelectedCmn_Btn(btn_idx);
	}
}

/************************************************************************************/
/*********************************SHOW KEYPAD FUNCTIONS******************************/
/************************************************************************************/
void keypad_btn()
{
	if (key_flag == false)
	{
		// key_flag = true;
	}

	if (key_flag == true)
	{
		cb_create_entry();  // Alphabetic & Numeric Keypad
		gtk_widget_show(GTK_WIDGET(p_window));
		key_flag = false;
	}
}

void Numerickey_Btn()
{
	if (key_flag == false)
	{

		//if ((gtk_widget_destroy(GTK_WIDGET(cp_window))) == true) // If window destroyed then turn the falg to true
		//if ( )
		{
			//key_flag = true;
		}
		
	}

	if (key_flag == true)
	{
		N_cb_create_entry(); // Numeric Keypad
		gtk_widget_show(GTK_WIDGET(cp_window));
		key_flag = false;
	}
}

/************************************************************************************/
/*****************************MENU REFRESH FUNCTIONS*********************************/
/************************************************************************************/
void Menu_Refresh()
{
	if (menu_v < 17) // Above 15 is SUB Menu
	{
		pos = menu_v * 10;
		gtk_label_set_label(GTK_LABEL(label_dv[0]), all_btnval[pos + 0]);
		gtk_label_set_label(GTK_LABEL(label_dv[2]), all_btnval[pos + 2]);
		gtk_label_set_label(GTK_LABEL(label_dv[4]), all_btnval[pos + 4]);
		gtk_label_set_label(GTK_LABEL(label_dv[6]), all_btnval[pos + 6]);
		// gtk_label_set_label(GTK_LABEL(label_dv[8]), all_btnval[pos + 8]);

		gtk_label_set_label(GTK_LABEL(label_dv[1]), all_btnval[pos + 1]);
		gtk_label_set_label(GTK_LABEL(label_dv[3]), all_btnval[pos + 3]);
		gtk_label_set_label(GTK_LABEL(label_dv[5]), all_btnval[pos + 5]);
		gtk_label_set_label(GTK_LABEL(label_dv[7]), all_btnval[pos + 7]);
		// gtk_label_set_label(GTK_LABEL(label_dv[9]), all_btnval[pos + 9]);
	}
	gtk_label_set_label(GTK_LABEL(label_dv[8]), all_btnval[0 + 8]); // Refresh for Gain
	gtk_label_set_label(GTK_LABEL(label_dv[9]), all_btnval[0 + 9]);
}

void pwroff_writevalues_old(void)
{
	int MAX = 100, temp;
	char buf[MAX];

	FILE* f_h;
	
	f_h = fopen("Pwr1off.set", "w");
	for (i = 0; i < 5; i++)
	{
		sprintf(text_values[i], "%s", gtk_entry_get_text(GTK_ENTRY(text_h[i])));
		fwrite(text_values[i], sizeof(char), 40, f_h);
		fprintf(f_h, "\n");
	}

	// Ascan raw data write
	for (i = 0; i < 256; i++)
	{
		fprintf(f_h, "%hhd ", row_y[i]);
		fprintf(f_h, "\n");
	}

	for (i = 0; i < 256; i++)  // Write Ascan data Peak values to memory
	{
		fprintf(f_h, "%f ", All_Ascan_peak[i]);
		fprintf(f_h, "\n");
	}

	fprintf(f_h, "%d %d %d %d %d ", Dac_v, point_v, Range_dac, Dac_tlg_v, Dac_crv_dB);
	fprintf(f_h, "%d %d %d ", Ers_v, Crv_db_dif, Dac_ph);
	fprintf(f_h, "%d %d %d %d ", Dgs_ref_gn, Dgs_gn, Dgs_ref_Nfg, Dgs_gn);
	fprintf(f_h, "%d ", dgs_fromfile);

	fprintf(f_h, "\n");
	for (i = 0; i < 40; i++)  // Write Dac Point data to memory
	{
		fprintf(f_h, "%d ", dac_pnt[i]);
	}

	fprintf(f_h, "\n");
	for (i = 0; i < 256; i++)  // Write DGS Point data to memory
	{
		fprintf(f_h, "%ld ", dgs_pnt[i]);
	}

	temp = pntArray_DACM[0].x; temp = (temp * 250) / frame_width; fprintf(f_h, "%d ", temp); //pntArray_DAC[dac_npnt].x=(frame_width *i)/250;
	for (i = 0; i < 255; i++)  // Write Ascan data Peak values to memory  
	{
		temp = pntArray_DACM[i].y; temp = (200 * (frame_height - temp)) / frame_height; fprintf(f_h, "%d ", temp);
	}  // pntArray_DACM[i].y);}   //  Main DAC

	temp = pntArray_DAC1P[0].x; temp = (temp * 250) / frame_width; fprintf(f_h, "%d ", temp);   //pntArray_DAC[dac_npnt].x=(frame_width *i)/250;
	for (i = 0; i < 255; i++)  // Write Ascan data Peak values to memory  
	{
		temp = pntArray_DAC1P[i].y; temp = (200 * (frame_height - temp)) / frame_height;  fprintf(f_h, "%d ", temp);
	}  // pntArray_DACM[i].y);}   //  Main DAC

	temp = pntArray_DAC2P[0].x; temp = (temp * 250) / frame_width; fprintf(f_h, "%d ", temp);   //pntArray_DAC[dac_npnt].x=(frame_width *i)/250;
	for (i = 0; i < 255; i++)  // Write Ascan data Peak values to memory  
	{
		temp = pntArray_DAC2P[i].y; temp = (200 * (frame_height - temp)) / frame_height;  fprintf(f_h, "%d ", temp);
	}  // pntArray_DACM[i].y);}   //  Main DAC

	temp = pntArray_DAC1N[0].x; temp = (temp * 250) / frame_width; fprintf(f_h, "%d ", temp);   //pntArray_DAC[dac_npnt].x=(frame_width *i)/250;
	for (i = 0; i < 255; i++)  // Write Ascan data Peak values to memory  
	{
		temp = pntArray_DAC1N[i].y; temp = (200 * (frame_height - temp)) / frame_height;  fprintf(f_h, "%d ", temp);
	}  // pntArray_DACM[i].y);}   //  Main DAC

	temp = pntArray_DAC2N[0].x; temp = (temp * 250) / frame_width; fprintf(f_h, "%d ", temp);   //pntArray_DAC[dac_npnt].x=(frame_width *i)/250;
	for (i = 0; i < 255; i++)  // Write Ascan data Peak values to memory  
	{
		temp = pntArray_DAC2N[i].y; temp = (200 * (frame_height - temp)) / frame_height;  fprintf(f_h, "%d ", temp);
	}  // pntArray_DACM[i].y);}   //  Main DAC

	fprintf(f_h, "\n");
	for (i = 0; i < 160; i++)
	{
		fprintf(f_h, "%d ", val_ary[i]);
	}
	//return;
	if (f_h)
	{
		fclose(f_h);
		f_h = NULL;
	}
}

void pwron_readvalues_old()
{
	FILE* file_h;
	int dmydata;
	GLubyte local_row_y[256];

	file_h = fopen("Pwr1off.set", "r");
	
	for (i = 0; i < 5; i++)
	{
		fread(&text_values[i], sizeof(char), 40, file_h); // sizeof(array_name[index])  sizeof(text_values[i])
		fscanf(file_h, "\n");
	}

	for (i = 0; i < 256; i++)
	{
		fscanf(file_h, "%hhd ", &local_row_y[i]);
		fscanf(file_h, "\n");
	}

	for (i = 0; i < 256; i++)  // Write Ascan data Peak values to memory
	{
		fscanf(file_h, "%f ", &All_Ascan_peak[i]);
		fscanf(file_h, "\n");
	}

	fscanf(file_h, "%d %d %d %d %d ", &Dac_v, &point_v, &Range_dac, &Dac_tlg_v, &Dac_crv_dB);
	fscanf(file_h, "%d %d %d ", &Ers_v, &Crv_db_dif, &Dac_ph);
	fscanf(file_h, "%d %d %d %d ", &Dgs_ref_gn, &Dgs_gn, &Dgs_ref_Nfg, &Dgs_gn);
	fscanf(file_h, "%d ", &dgs_fromfile);

	fscanf(file_h, "\n");
	// Read Dac Point data
	for (i = 0; i < 40; i++)  // Write Dac Point data to memory
	{
		fscanf(file_h, "%d ", &dac_pnt[i]);
	}

	fscanf(file_h, "\n");
	for (i = 0; i < 256; i++)  // Write DGS Point data to memory
	{
		fscanf(file_h, "%ld ", &dgs_pnt[i]);
	}

	for (i = 0; i < 256; i++)  // Write Ascan data Peak values to memory
	{
		fscanf(file_h, "%d ", &dmydata);
	}   //  Main DAC
	for (i = 0; i < 256; i++)  // Write Ascan data Peak values to memory
	{
		fscanf(file_h, "%d ", &dmydata);
	}   //  1P DAC
	for (i = 0; i < 256; i++)  // Write Ascan data Peak values to memory
	{
		fscanf(file_h, "%d ", &dmydata);
	}   //  2P DAC curve data
	for (i = 0; i < 256; i++)  // Write Ascan data Peak values to memory
	{
		fscanf(file_h, "%d ", &dmydata);
	}   //  1N DAC curve data
	for (i = 0; i < 256; i++)  // Write Ascan data Peak values to memory
	{
		fscanf(file_h, "%d ", &dmydata);
	}   // 2N DAC curve data

	fscanf(file_h, "\n");
	for (i = 0; i < 160; i++)
	{
		fscanf(file_h, "%d ", &val_ary[i]);
	}

	for (i = 0; i < 5; i++)
	{
		line_flag = false;
		for (j = 0; j < sizeof(text_values[i]); j++)
		{
			ch = text_values[i][j];
			if (ch != 32)
			{
				line_flag = true;
			}

			if (ch == 10 || ch == 13) // (ch == '\n') LF
			{
				text_values[i][j] = 0;
				break;
			}
		}
		last_idx = strlen(line[i]) - 1;

		if (text_values[i][0] == 0) // SPACE OR EMPTY LINE
		{
			break;
		}
		gtk_entry_set_text(GTK_ENTRY(text_h[i]), text_values[i]);
	}
	if (Dgs_onoff_v == 3)
	{
		dgs_fromfile = 1;
	}

	if (file_h)
	{
		fclose(file_h);
		file_h = NULL;
	}

	Refresh_Allpera_val_f(); // Required to change the values of all menu parameters according to the file
	Update_Note(); // REQUIRED TO CHANGE THE NOTE_DATA ARRAY VALUE WHILE RECALLING OR DETAIL OF THE NOTE //Menu_Refresh();

	opengl_update = false;
	Dac_Bscan_flag = false;

	for (i = 0; i < 256; i++)
	{
		row_y[i] = local_row_y[i];
	}
	Send_Data_to_OpenGL();
	ogl_render(frame_width, frame_height); // Call Opengl to display the Data
}

void pwroff_savesetup(void)
{
	int idx, temp;
	int dacd[256];
	FILE* pfile = NULL;

	pfile = fopen("LastCalSet.set", "w");
	if (pfile != NULL && lastCalSetupFlag == 1)
	{
		// Note Data 
		for (i = 0; i < 5; i++)
		{
			sprintf(text_values[i], "%s", gtk_entry_get_text(GTK_ENTRY(text_h[i])));
			fwrite(text_values[i], sizeof(char), 40, pfile);
			fprintf(pfile, "\n");
			fflush(pfile);
		}
		fprintf(pfile, "\n");
		fflush(pfile);

		// Menu Data
		for (i = 0; i < 160; i++)
		{
			fprintf(pfile, "%d ", val_ary[i]);
			fflush(pfile);
		}
		fprintf(pfile, "\n");
		fflush(pfile);

		// Ascan data
		for (i = 0; i < 256; i++)
		{
			fprintf(pfile, "%hhd ", row_y[i]);
			fflush(pfile);
		}
		fprintf(pfile, "\n");
		fflush(pfile);

		// Main DAC points 
		for (i = 0; i < 256; i++)
			dacd[i] = 0;

		for (i = 0; i < 256; i++)
		{
			idx = pntArray_DACM[i].x;
			dacd[idx] = (int)pntArray_DACM[i].y;
		}
		for (i = 0; i < 256; i++)
		{
			fprintf(pfile, "%d ", dacd[i]);
			fflush(pfile);
		}
		fprintf(pfile, "\n");
		fflush(pfile);

		//  Main 1 positive DAC
		for (i = 0; i < 256; i++)
			dacd[i] = 0;

		for (i = 0; i < 256; i++)
		{
			idx = pntArray_DAC1P[i].x;
			dacd[idx] = (int)pntArray_DAC1P[i].y;
		}
		for (i = 0; i < 256; i++)
		{
			fprintf(pfile, "%d ", dacd[i]);
			fflush(pfile);
		}
		fprintf(pfile, "\n");
		fflush(pfile);

		//  Main 2 positive DAC
		for (i = 0; i < 256; i++)
			dacd[i] = 0;
			
		for (i = 0; i < 256; i++)
		{
			idx = pntArray_DAC2P[i].x;
			dacd[idx] = (int)pntArray_DAC2P[i].y;
		}
		for (i = 0; i < 256; i++)
		{
			fprintf(pfile, "%d ", dacd[i]);
			fflush(pfile);
		}
		fprintf(pfile, "\n");
		fflush(pfile);

		//  Main 1 negative DAC
		for (i = 0; i < 256; i++)
			dacd[i] = 0;
			
		for (i = 0; i < 256; i++)
		{
			idx = pntArray_DAC1N[i].x;
			dacd[idx] = (int)pntArray_DAC1N[i].y;
		}
		for (i = 0; i < 256; i++)
		{
			fprintf(pfile, "%d ", dacd[i]);
			fflush(pfile);
		}
		fprintf(pfile, "\n");
		fflush(pfile);

		//  Main 2 negative DAC          
		for (i = 0; i < 256; i++)
			dacd[i] = 0;
			
		for (i = 0; i < 256; i++)
		{
			idx = pntArray_DAC2N[i].x;
			dacd[idx] = (int)pntArray_DAC2N[i].y;
		}
		for (i = 0; i < 256; i++)
		{
			fprintf(pfile, "%d ", dacd[i]);
			fflush(pfile);
		}
		fprintf(pfile, "\n");
		fflush(pfile);

		for (i = 0; i < 256; i++)  // Write Ascan data Peak values to memory
		{
			fprintf(pfile, "%f ", All_Ascan_peak[i]);
			fflush(pfile);
			fprintf(pfile, "\n");
			fflush(pfile);
		}

		fprintf(pfile, "%d %d %d %d %d ", Dac_v, point_v, Range_dac, Dac_tlg_v, Dac_crv_dB);
		fflush(pfile);
		fprintf(pfile, "%d %d %d ", Ers_v, Crv_db_dif, Dac_ph);
		fflush(pfile);
		fprintf(pfile, "%d %d %d %d ", Dgs_ref_gn, Dgs_gn, Dgs_ref_Nfg, Dgs_gn);
		fflush(pfile);
		fprintf(pfile, "%d", dgs_fromfile);
		fflush(pfile);
		fprintf(pfile, "\n");
		fflush(pfile);

		for (i = 0; i < 40; i++)  // Write Dac Point data to memory
		{
			fprintf(pfile, "%d ", dac_pnt[i]);
			fflush(pfile);
		}
		fprintf(pfile, "\n");
		fflush(pfile);

		for (i = 0; i < 250; i++)  // Write DGS y Point data to memory
		{
			fprintf(pfile, "%ld ", dgs_pnt[i]);
			fflush(pfile);
		}
		fprintf(pfile, "\n");
		fflush(pfile);
		

		if (Measure_v1 > 0)   // Measure 1 WRITE Values
		{
			for (i = 0; i < 4; i++)
			{
				fprintf(pfile, "%s ", mea_rd[i]);
				fprintf(pfile, "\n");
				fflush(pfile);
			}
		}

		if (Measure_v2 > 0) // Measure 2 WRITE Values
		{
			for (i = 4; i < 8; i++)
			{
				fprintf(pfile, "%s ", mea_rd[i]);
				fprintf(pfile, "\n");
				fflush(pfile);
			}
		}

		// fprintf(pfile, "%ld %ld %ld %d", G1_sp1, G1_dp1, G1_sd1, G1_Amp1); // Sound path, Depth, Surface Distance, Amplitude
		// fprintf(pfile, "%ld %ld %ld %d", G2_sp2, G2_dp2, G2_sd2, G2_Amp2); // Sound path, Depth, Surface Distance, Amplitude
		fprintf(pfile, "%d %d %d ", IL_v, Af_v, Rt_v); // AWS PARAMETER defect echo start, Width, height
		fflush(pfile);

		dgs_fromfile = 1;

		lastCalSetupFlag = 0;		

		if (pfile)
		{
			fclose(pfile);
			pfile = NULL;
			dsp_msg(47);
		}
	}
	else
	{
		dsp_msg(48);
	}
}

void pwron_readvalues(void)
{
	FILE* pfile = NULL;;
	int dmydata;
	GLubyte local_row_y[256];
	
	pfile = fopen("LastCalSet.set", "r");
	if (pfile != NULL)
	{
		// Note Data
		for (i = 0; i < 5; i++)
		{
			fread(&text_values[i], sizeof(char), 40, pfile); // sizeof(array_name[index])  sizeof(text_values[i])
			fscanf(pfile, "\n");
		}
		fscanf(pfile, "\n");

		// Menu Data
		for (i = 0; i < 160; i++)
		{
			fscanf(pfile, "%d ", &val_ary[i]);
		}
		fscanf(pfile, "\n");

		// Ascan Data
		for (i = 0; i < 256; i++)
		{
			fscanf(pfile, "%hhd ", &local_row_y[i]);		
		}	
		fscanf(pfile, "\n");	

		// Main DAC points 
		for (i = 0; i < 256; i++)
			fscanf(pfile, "%d ", (int*)(&pntArray_DACM[i].y));
		fscanf(pfile, "\n");

		// Main 1 positive DAC
		for (i = 0; i < 256; i++)
			fscanf(pfile, "%d ", (int*)(&pntArray_DAC1P[i].y));
		fscanf(pfile, "\n");

		// Main 2 positive DAC
		for (i = 0; i < 256; i++)
			fscanf(pfile, "%d ", (int*)(&pntArray_DAC2P[i].y));
		fscanf(pfile, "\n");

		//  Main 1 negative DAC
		for (i = 0; i < 256; i++)
			fscanf(pfile, "%d ", (int*)(&pntArray_DAC1N[i].y));
		fscanf(pfile, "\n");

		//  Main 2 negative DAC
		for (i = 0; i < 256; i++)
			fscanf(pfile, "%d ", (int*)(&pntArray_DAC2N[i].y));
		fscanf(pfile, "\n");

		for (i = 0; i < 256; i++)  // Write Ascan data Peak values to memory
		{
			fscanf(pfile, "%f ", &All_Ascan_peak[i]);
			fscanf(pfile, "\n");
		}

		fscanf(pfile, "%d %d %d %d %d ", &Dac_v, &point_v, &Range_dac, &Dac_tlg_v, &Dac_crv_dB);
		fscanf(pfile, "%d %d %d ", &Ers_v, &Crv_db_dif, &Dac_ph);
		fscanf(pfile, "%d %d %d %d ", &Dgs_ref_gn, &Dgs_gn, &Dgs_ref_Nfg, &Dgs_gn);
		fscanf(pfile, "%d", &dgs_fromfile);
		fscanf(pfile, "\n");

		// Read Dac Point data
		for (i = 0; i < 40; i++)  // Write Dac Point data to memory
			fscanf(pfile, "%d ", &dac_pnt[i]);
		fscanf(pfile, "\n");

		if (val_ary[DAC_PERA] == 3)
			dgs_fromfile = 1;

		for (i = 0; i < 250; i++)  // Write DGS y Point data to memory
			fscanf(pfile, "%ld ", &dgs_pnt[i]);
		fscanf(pfile, "\n");

		if (Measure_v1 > 0)   // Measure 1 Read values
		{
			for (i = 0; i < 4; i++)
			{
				fscanf(pfile, "%s ", mea_rd[i]);
				fscanf(pfile, "\n");
			}
		}

		if (Measure_v2 > 0) // Measure 2 Read values
		{
			for (i = 4; i < 8; i++)
			{
				fscanf(pfile, "%s ", mea_rd[i]);
				fscanf(pfile, "\n");
			}
		}

		///fscanf(pfile, "%ld %ld %ld %d", &G1_sp1, &G1_dp1, &G1_sd1, &G1_Amp1); // Sound path, Depth, Surface Distance, Amplitude
		// fscanf(pfile, "%ld %ld %ld %d", &G2_sp2, &G2_dp2, &G2_sd2, &G2_Amp2); // Sound path, Depth, Surface Distance, Amplitude
		fscanf(pfile, "%d %d %d ", &IL_v, &Af_v, &Rt_v); // AWS PARAMETER defect echo start, Width, height

		if (pfile)
		{
			fclose(pfile);
			pfile = NULL;
		}
	}
	else
	{
		g_print("Failed to open file for read data from LastCalSet file.\n");
	}
}

/************************************************************************************/
/*****************************READ AND WRITE FUNCTIONS*******************************/
/************************************************************************************/
void h_write() // FOR ASCAN WRITE FILE
{
	int MAX = 100, temp;
	int dacd[256];
	int idx;

	char buf[MAX];

	FILE* f_h;

	f_h = fopen(path_h, "w");

	// Note Data
	for (i = 0; i < 5; i++)
	{
		sprintf(text_values[i], "%s", gtk_entry_get_text(GTK_ENTRY(text_h[i])));
		fwrite(text_values[i], sizeof(char), 40, f_h);
		fprintf(f_h, "\n");
	}
	fprintf(f_h, "\n");

	// Menu Data
	for (i = 0; i < 160; i++)
	{
		fprintf(f_h, "%d ", val_ary[i]);
	}
	fprintf(f_h, "\n");

	// Ascan data
	for (i = 0; i < 256; i++)
	{
		fprintf(f_h, "%hhd ", row_y[i]);
	}
	fprintf(f_h, "\n");

	// Main DAC points 
	for (i = 0; i < 256; i++)
		dacd[i] = 0;

	for (i = 0; i < 256; i++)
	{
		idx = pntArray_DACM[i].x;
		dacd[idx] = (int)pntArray_DACM[i].y;
	}
	for (i = 0; i < 256; i++)
		fprintf(f_h, "%d ", dacd[i]);
	fprintf(f_h, "\n");

	//  Main 1 positive DAC
	for (i = 0; i < 256; i++)
		dacd[i] = 0;

	for (i = 0; i < 256; i++)
	{
		idx = pntArray_DAC1P[i].x;
		dacd[idx] = (int)pntArray_DAC1P[i].y;
	}
	for (i = 0; i < 256; i++)
		fprintf(f_h, "%d ", dacd[i]);
	fprintf(f_h, "\n");

	//  Main 2 positive DAC
	for (i = 0; i < 256; i++)
		dacd[i] = 0;
		
	for (i = 0; i < 256; i++)
	{
		idx = pntArray_DAC2P[i].x;
		dacd[idx] = (int)pntArray_DAC2P[i].y;
	}
	for (i = 0; i < 256; i++)
		fprintf(f_h, "%d ", dacd[i]);
	fprintf(f_h, "\n");

	//  Main 1 negative DAC
	for (i = 0; i < 256; i++)
		dacd[i] = 0;
		
	for (i = 0; i < 256; i++)
	{
		idx = pntArray_DAC1N[i].x;
		dacd[idx] = (int)pntArray_DAC1N[i].y;
	}
	for (i = 0; i < 256; i++)
		fprintf(f_h, "%d ", dacd[i]);
	fprintf(f_h, "\n");

	//  Main 2 negative DAC          
	for (i = 0; i < 256; i++)
		dacd[i] = 0;
		
	for (i = 0; i < 256; i++)
	{
		idx = pntArray_DAC2N[i].x;
		dacd[idx] = (int)pntArray_DAC2N[i].y;
	}
	for (i = 0; i < 256; i++)
		fprintf(f_h, "%d ", dacd[i]);
	fprintf(f_h, "\n");

	for (i = 0; i < 256; i++)  // Write Ascan data Peak values to memory
	{
		fprintf(f_h, "%f ", All_Ascan_peak[i]);
		fprintf(f_h, "\n");
	}

	fprintf(f_h, "%d %d %d %d %d ", Dac_v, point_v, Range_dac, Dac_tlg_v, Dac_crv_dB);
	fprintf(f_h, "%d %d %d ", Ers_v, Crv_db_dif, Dac_ph);
	fprintf(f_h, "%d %d %d %d ", Dgs_ref_gn, Dgs_gn, Dgs_ref_Nfg, Dgs_gn);
	fprintf(f_h, "%d", dgs_fromfile);
	fprintf(f_h, "\n");

	for (i = 0; i < 40; i++)  // Write Dac Point data to memory
		fprintf(f_h, "%d ", dac_pnt[i]);
	fprintf(f_h, "\n");

	for (i = 0; i < 256; i++)  // Write DGS Point data to memory
		fprintf(f_h, "%ld ", dgs_pnt[i]);
	fprintf(f_h, "\n");

	// temp = pntArray_DACM[0].x; 
	// temp = (temp * 250) / frame_width;
	// fprintf(f_h, "%d ", temp); 
	// for (i = 0; i < 255; i++)  // Write Ascan data Peak values to memory  
	// {
	// 	temp = pntArray_DACM[i].y; 
	// 	temp = (200 * (frame_height - temp)) / frame_height; 
	// 	fprintf(f_h, "%d ", temp);
	// }    //  Main DAC

	// fprintf(f_h, "\n");

	// temp = pntArray_DAC1P[0].x; 
	// temp = (temp * 250) / frame_width; 
	// fprintf(f_h, "%d ", temp);   
	// for (i = 0; i < 255; i++)  
	// {
	// 	temp = pntArray_DAC1P[i].y; 
	// 	temp = (200 * (frame_height - temp)) / frame_height;  
	// 	fprintf(f_h, "%d ", temp);
	// }    //  Main 1 positive DAC

	// fprintf(f_h, "\n");

	// temp = pntArray_DAC2P[0].x; 
	// temp = (temp * 250) / frame_width; 
	// fprintf(f_h, "%d ", temp); 
	// for (i = 0; i < 255; i++)
	// {
	// 	temp = pntArray_DAC2P[i].y; 
	// 	temp = (200 * (frame_height - temp)) / frame_height;  
	// 	fprintf(f_h, "%d ", temp);
	// }  // Main 2 positive DAC

	// fprintf(f_h, "\n");

	// temp = pntArray_DAC1N[0].x; 
	// temp = (temp * 250) / frame_width; 
	// fprintf(f_h, "%d ", temp); 
	// for (i = 0; i < 255; i++)  
	// {
	// 	temp = pntArray_DAC1N[i].y; 
	// 	temp = (200 * (frame_height - temp)) / frame_height;  
	// 	fprintf(f_h, "%d ", temp);
	// }  // DAC POINTS 1 NEGATIVE

	// fprintf(f_h, "\n");

	// temp = pntArray_DAC2N[0].x; 
	// temp = (temp * 250) / frame_width; 
	// fprintf(f_h, "%d ", temp);  
	// for (i = 0; i < 255; i++)  
	// {
	// 	temp = pntArray_DAC2N[i].y; 
	// 	temp = (200 * (frame_height - temp)) / frame_height;  
	// 	fprintf(f_h, "%d ", temp);
	// }  // DAC POINTS 2 NEGATIVE

	fprintf(f_h, "\n");
	if (Measure_v1 > 0)   // Measure 1 WRITE Values
	{
		for (i = 0; i < 4; i++)
		{
			fprintf(f_h, "%s ", mea_rd[i]);
			fprintf(f_h, "\n");
		}
	}

	if (Measure_v2 > 0) // Measure 2 WRITE Values
	{
		for (i = 4; i < 8; i++)
		{
			fprintf(f_h, "%s ", mea_rd[i]);
			fprintf(f_h, "\n");
		}
	}

	// fprintf(f_h, "%ld %ld %ld %d", G1_sp1, G1_dp1, G1_sd1, G1_Amp1); // Sound path, Depth, Surface Distance, Amplitude
	// fprintf(f_h, "%ld %ld %ld %d", G2_sp2, G2_dp2, G2_sd2, G2_Amp2); // Sound path, Depth, Surface Distance, Amplitude
	fprintf(f_h, "%d %d %d ", IL_v, Af_v, Rt_v); // AWS PARAMETER defect echo start, Width, height

	//return;
	if (f_h)
	{
		fclose(f_h);
		f_h = NULL;
	}
}

void set_write() // FOR SET UP WRITE FILE
{
	int MAX = 100, temp;
	char buf[MAX];

	FILE* f_h;
	f_h = fopen(path_h, "w");

	for (i = 0; i < 5; i++)
	{
		sprintf(text_values[i], "%s", gtk_entry_get_text(GTK_ENTRY(text_h[i])));
		fwrite(text_values[i], sizeof(char), 40, f_h);
		fprintf(f_h, "\n");
	}

	fprintf(f_h, "%d %d %d %d %d ", Dac_v, point_v, Range_dac, Dac_tlg_v, Dac_crv_dB);
	fprintf(f_h, "%d %d %d ", Ers_v, Crv_db_dif, Dac_ph);
	fprintf(f_h, "%d %d %d %d ", Dgs_ref_gn, Dgs_gn, Dgs_ref_Nfg, Dgs_gn);

	fprintf(f_h, "\n");
	for (i = 0; i < 160; i++)
	{
		fprintf(f_h, "%d ", val_ary[i]);
	}
	if (f_h)
	{
		fclose(f_h);
		f_h = NULL;
	}
}

/************************************************************************************/
/**********************************READ FUNCTION*************************************/
/************************************************************************************/
void h_read()
{
	FILE* file_h;
	int dmydata;
	GLubyte local_row_y[256];

	file_h = fopen(path_h, "r");

	// Note Data
	for (i = 0; i < 5; i++)
	{
		fread(&text_values[i], sizeof(char), 40, file_h); // sizeof(array_name[index])  sizeof(text_values[i])
		fscanf(file_h, "\n");
	}
	fscanf(file_h, "\n");

	// Menu Data
	for (i = 0; i < 160; i++)
	{
		fscanf(file_h, "%d ", &val_ary[i]);
	}
	fscanf(file_h, "\n");

	// Ascan Data
	for (i = 0; i < 256; i++)
	{
		fscanf(file_h, "%hhd ", &local_row_y[i]);		
	}	
	fscanf(file_h, "\n");	

	// Main DAC points 
	for (i = 0; i < 256; i++)
		fscanf(file_h, "%ld ", &pntArray_DACM[i].y);
	fscanf(file_h, "\n");

	// Main 1 positive DAC
	for (i = 0; i < 256; i++)
		fscanf(file_h, "%ld ", &pntArray_DAC1P[i].y);
	fscanf(file_h, "\n");

	// Main 2 positive DAC
	for (i = 0; i < 256; i++)
		fscanf(file_h, "%ld ", &pntArray_DAC2P[i].y);
	fscanf(file_h, "\n");

	//  Main 1 negative DAC
	for (i = 0; i < 256; i++)
		fscanf(file_h, "%ld ", &pntArray_DAC1N[i].y);
	fscanf(file_h, "\n");

	//  Main 2 negative DAC
	for (i = 0; i < 256; i++)
		fscanf(file_h, "%ld ", &pntArray_DAC2N[i].y);
	fscanf(file_h, "\n");

	for (i = 0; i < 256; i++)  // Write Ascan data Peak values to memory
	{
		fscanf(file_h, "%f ", &All_Ascan_peak[i]);
		fscanf(file_h, "\n");
	}

	fscanf(file_h, "%d %d %d %d %d ", &Dac_v, &point_v, &Range_dac, &Dac_tlg_v, &Dac_crv_dB);
	fscanf(file_h, "%d %d %d ", &Ers_v, &Crv_db_dif, &Dac_ph);
	fscanf(file_h, "%d %d %d %d ", &Dgs_ref_gn, &Dgs_gn, &Dgs_ref_Nfg, &Dgs_gn);
	fscanf(file_h, "%d", &dgs_fromfile);
	fscanf(file_h, "\n");

	// Read Dac Point data
	for (i = 0; i < 40; i++)  // Write Dac Point data to memory
		fscanf(file_h, "%d ", &dac_pnt[i]);
	fscanf(file_h, "\n");

	for (i = 0; i < 256; i++)  // Write DGS Point data to memory
		fscanf(file_h, "%ld ", &dgs_pnt[i]);
	fscanf(file_h, "\n");

	// for (i = 0; i < 256; i++)  // Write Ascan data Peak values to memory
	// {
	// 	fscanf(file_h, "%d ", &dmydata);
	// }   //  Main DAC
	// fscanf(file_h, "\n");
	// for (i = 0; i < 256; i++)  // Write Ascan data Peak values to memory
	// {
	// 	fscanf(file_h, "%d ", &dmydata);
	// }   //  1P DAC
	// fscanf(file_h, "\n");
	// for (i = 0; i < 256; i++)  // Write Ascan data Peak values to memory
	// {
	// 	fscanf(file_h, "%d ", &dmydata);
	// }   //  2P DAC curve data
	// fscanf(file_h, "\n");
	// for (i = 0; i < 256; i++)  // Write Ascan data Peak values to memory
	// {
	// 	fscanf(file_h, "%d ", &dmydata);
	// }   //  1N DAC curve data
	// fscanf(file_h, "\n");
	// for (i = 0; i < 256; i++)  // Write Ascan data Peak values to memory
	// {
	// 	fscanf(file_h, "%d ", &dmydata);
	// }   //  2N DAC curve data

	fscanf(file_h, "\n");
	if (Measure_v1 > 0)   // Measure 1 Read values
	{
		for (i = 0; i < 4; i++)
		{
			fscanf(file_h, "%s ", mea_rd[i]);
			//fprintf(f_h, "%s ", mea_rd[i]);
			fscanf(file_h, "\n");
		}
	}

	if (Measure_v2 > 0) // Measure 2 Read values
	{
		for (i = 4; i < 8; i++)
		{
			fscanf(file_h, "%s ", mea_rd[i]);
			//fprintf(f_h, "%s ", mea_rd[i]);
			fscanf(file_h, "\n");
		}
	}

	///fscanf(file_h, "%ld %ld %ld %d", &G1_sp1, &G1_dp1, &G1_sd1, &G1_Amp1); // Sound path, Depth, Surface Distance, Amplitude
	// fscanf(file_h, "%ld %ld %ld %d", &G2_sp2, &G2_dp2, &G2_sd2, &G2_Amp2); // Sound path, Depth, Surface Distance, Amplitude
	fscanf(file_h, "%d %d %d ", &IL_v, &Af_v, &Rt_v); // AWS PARAMETER defect echo start, Width, height

	for (i = 0; i < 5; i++)
	{
		//if (i > 14) { i = 14; }
		line_flag = false;
		for (j = 0; j < sizeof(text_values[i]); j++)
		{
			ch = text_values[i][j];
			if (ch != 32)
			{
				line_flag = true;
			}

			if (ch == 10 || ch == 13) // (ch == '\n') LF
			{
				text_values[i][j] = 0;
				break;
			}
		}
		last_idx = strlen(line[i]) - 1;

		if (text_values[i][0] == 0) // SPACE OR EMPTY LINE
		{
			break;
		}
		gtk_entry_set_text(GTK_ENTRY(text_h[i]), text_values[i]);
	}
	if (Dgs_onoff_v == 3)
	{
		dgs_fromfile = 1;
	}

	if (file_h)
	{
		fclose(file_h);
		file_h = NULL;
	}

	Refresh_Allpera_val_f(); // Required to change the values of all menu parameters according to the file
	Update_Note(); // REQUIRED TO CHANGE THE NOTE_DATA ARRAY VALUE WHILE RECALLING OR DETAIL OF THE NOTE
	
	opengl_update = false;
	Dac_Bscan_flag = false;
	
	for (i = 0; i < 256; i++)
	{
		row_y[i] = local_row_y[i];
	}		
	Send_Data_to_OpenGL();
	ogl_render(frame_width, frame_height); // Call Opengl to display the Data
}

void set_read()
{
	int MAX = 100, temp;
	char buf[MAX];

	FILE* f_h;
	f_h = fopen(path_h, "r");

	for (i = 0; i < 5; i++)
	{
		fread(&text_values[i], sizeof(char), 40, f_h);
		fscanf(f_h, "\n");
	}

	fscanf(f_h, "%d %d %d %d %d ", &Dac_v, &point_v, &Range_dac, &Dac_tlg_v, &Dac_crv_dB);
	fscanf(f_h, "%d %d %d ", &Ers_v, &Crv_db_dif, &Dac_ph);
	fscanf(f_h, "%d %d %d %d ", &Dgs_ref_gn, &Dgs_gn, &Dgs_ref_Nfg, &Dgs_gn);

	fprintf(f_h, "\n");
	for (i = 0; i < 160; i++)
	{
		fscanf(f_h, "%d ", &val_ary[i]);
	}

	for (i = 0; i < 5; i++)
	{
		line_flag = false;
		for (j = 0; j < sizeof(text_values[i]); j++)
		{
			ch = text_values[i][j];
			if (ch != 32)
			{
				line_flag = true;
			}
			if (ch == 10 || ch == 13) // (ch == '\n') LF
			{
				text_values[i][j] = 0;
				break;
			}
		}
		last_idx = strlen(line[i]) - 1;

		if (text_values[i][0] == 0) // SPACE OR EMPTY LINE
		{
			break;
		}
		gtk_entry_set_text(GTK_ENTRY(text_h[i]), text_values[i]);
	}

	if (f_h)
	{
		fclose(f_h);
		f_h = NULL;
	}

	Refresh_Allpera_val_f(); // Required to change the values of all menu parameters according to the file
	Update_Note(); // REQUIRED TO CHANGE THE NOTE_DATA ARRAY VALUE WHILE RECALLING OR DETAIL OF THE NOTE
}

void h_detail()
{
	int tempval_ary[200]; 
	float All_Ascan_peak12[512];
	char t_mea_rd[10][15];
	GLubyte row_y12[256];
	FILE* file_h;
	int dmydata;
	float tfd, offst;
	tfd = (50.0f * ((float)splite_frame_height - 2.0f)) / (float)Asc_Height;
    offst = (50.0f + ((((float)splite_frame_height - 2.0f) - (float)Asc_Height) / 8.0f));

	// char *path_f = filen;
	// key_scr = 0;

	file_h = fopen(path_h, "r");

	for (i = 0; i < 5; i++)
	{
		fread(&text_values[i], sizeof(char), 40, file_h);
		fscanf(file_h, "\n");
	}

	// for (i = 0; i < 256; i++)
	{
		fread(&row_y12[0], sizeof(char) * 256, 1, file_h);
		fscanf(file_h, "\n");
		ogl.vertices_position[(i * 2) + 1] = ((GLfloat)row_y12[i] - offst) / tfd;
		// ogl.vertices_position[(i * 2) + 1] = ((GLfloat)row_y12[i] - 50.0f) / 50.0f;
	}

	// Ascan peak data write
	// for (i = 0; i < 512; i++)
	{
		fread(&All_Ascan_peak12[0], 1, sizeof(float) * 512, file_h);
		fscanf(file_h, "\n");
	}

	fscanf(file_h, "%d %d %d %d %d ", &Dac_v, &point_v, &Range_dac, &Dac_tlg_v, &Dac_crv_dB);
	fscanf(file_h, "%d %d %d ", &Ers_v, &Crv_db_dif, &Dac_ph);
	fscanf(file_h, "%d %d %d %d ", &Dgs_ref_gn, &Dgs_gn, &Dgs_ref_Nfg, &Dgs_gn);

	fscanf(file_h, "\n");
	// Read Dac Point data
	for (i = 0; i < 40; i++)  // Write Dac Point data to memory
	{
		fscanf(file_h, "%d ", &dac_pnt[i]);
	}

	for (i = 0; i < 256; i++)  // Write Ascan data Peak values to memory
	{
		fscanf(file_h, "%d ", &dmydata);
	}   //  Main DAC
	for (i = 0; i < 256; i++)  // Write Ascan data Peak values to memory
	{
		fscanf(file_h, "%d ", &dmydata);
	}   //  1P DAC
	for (i = 0; i < 256; i++)  // Write Ascan data Peak values to memory
	{
		fscanf(file_h, "%d ", &dmydata);
	}   //  2P DAC curve data
	for (i = 0; i < 256; i++)  // Write Ascan data Peak values to memory
	{
		fscanf(file_h, "%d ", &dmydata);
	}   //  1N DAC curve data
	for (i = 0; i < 256; i++)  // Write Ascan data Peak values to memory
	{
		fscanf(file_h, "%d ", &dmydata);
	}   //  2N DAC curve data

	fscanf(file_h, "\n");
	for (i = 0; i < 160; i++) // Read all menu values
	{
		fscanf(file_h, "%d ", &tempval_ary[i]);
		fscanf(file_h, "\n");
	}

	fscanf(file_h, "\n");
	if (Measure_v1 > 0)   // Measure 1 Read values
	{
		for (i = 0; i < 4; i++)
		{
			fscanf(file_h, "%s ", t_mea_rd[i]);
			//fprintf(f_h, "%s ", mea_rd[i]);
			fscanf(file_h, "\n");
		}
	}

	if (Measure_v2 > 0) // Measure 2 Read values
	{
		for (i = 4; i < 8; i++)
		{
			fscanf(file_h, "%s ", t_mea_rd[i]);
			//fprintf(f_h, "%s ", mea_rd[i]);
			fscanf(file_h, "\n");
		}
	}

	for (i = 0; i < 5; i++)
	{
		line_flag = false;
		for (j = 0; j < sizeof(text_values[i]); j++)
		{
			ch = text_values[i][j];
			if (ch != 32)
			{
				line_flag = true;
			}
			if (ch == 10 || ch == 13) // (ch == '\n') LF
			{
				text_values[i][j] = 0;
				break;
			}
		}
		last_idx = strlen(line[i]) - 1;
		if (text_values[i][0] == 0) // SPACE OR EMPTY LINE
		{
			break;
		}
		gtk_entry_set_text(GTK_ENTRY(text_h[i]), text_values[i]);
	}

	if (file_h)
	{
		fclose(file_h);
		file_h = NULL;
	}

	Update_Note(); // REQUIRED TO CHANGE THE NOTE_DATA ARRAY VALUE WHILE RECALLING OR DETAIL OF THE NOTE
}

void Update_Note()
{
	k = 0;
	for (i = 0; i < 10; i++)
	{
		for (j = 0; j < 40; j++)
		{
			Note_data[k] = text_values[i][j];
			k++;
		}
	}
}


//*********************************************************************************************************

void Write_NoteText()
{
	FILE *f_h;
	// char* path_f = filen;

	f_h = fopen("Note1.txt", "w");
	for (i = 0; i < 14; i++)
	{
		fwrite(heading_name[i], sizeof(char), 40, f_h);
		fprintf(f_h, "\n");
	}
	fclose(f_h);
}


/************************************************************************************/
/****************************DRAW DATE AND TIME**************************************/
/************************************************************************************/
void draw_time()
{
	cairo_t *cr;
	t = time(NULL);
	tm = *localtime(&t);

	if (menu_v == 14 || menu_v == 15 && key_scr == 1)
	{
		sprintf(dtm_values[0], "%02d", val_ary[MINUTE_v]);
		sprintf(dtm_values[1], "%02d", val_ary[HOUR_v]);
		sprintf(dtm_values[2], "%02d", val_ary[DAY_v]);
		sprintf(dtm_values[3], "%02d", val_ary[MONTH_v]);
		sprintf(dtm_values[4], "%04d", val_ary[YEAR_v]);
	}
	else
	{
		sprintf(dtm_values[0], "%02d", (char)tm.tm_min);
		sprintf(dtm_values[1], "%02d", (char)tm.tm_hour);
		sprintf(dtm_values[2], "%02d", (char)tm.tm_mday);
		sprintf(dtm_values[3], "%02d", (char)tm.tm_mon + 1);
		sprintf(dtm_values[4], "%d", (char)tm.tm_year + 1900);
	}

	cairo_surface_t *surface = cairo_image_surface_create(CAIRO_FORMAT_RGB24, image_dy, 43);
	cr = cairo_create(surface);

	cairo_set_source_rgb(cr, 1.0, 1.0, 1.0);
	cairo_paint(cr);

	cairo_select_font_face(cr, "Purisa", CAIRO_FONT_SLANT_NORMAL, CAIRO_FONT_WEIGHT_NORMAL);

	cairo_set_source_rgb(cr, 1.0, 0.0, 1.0);
	cairo_set_font_size(cr, 15);
	cairo_move_to(cr, 25, 15);
	cairo_show_text(cr, dtm_values[1]);
	cairo_move_to(cr, 45, 15);
	cairo_show_text(cr, ":");
	cairo_move_to(cr, 51, 15);
	cairo_show_text(cr, dtm_values[0]);
	cairo_move_to(cr, 8, 34);
	cairo_show_text(cr, dtm_values[2]);
	cairo_move_to(cr, 27, 34);
	cairo_show_text(cr, "/");
	cairo_move_to(cr, 33, 34);
	cairo_show_text(cr, dtm_values[3]);
	cairo_move_to(cr, 52, 34);
	cairo_show_text(cr, "/");
	cairo_move_to(cr, 58, 34);
	cairo_show_text(cr, dtm_values[4]);

	cairo_fill(cr);
	cairo_surface_write_to_png(surface, "Images/Images/year.png");
}

void chng_year()
{
	draw_time();
	n_pximage[6] = gdk_pixbuf_new_from_file_at_scale(imagename[6], image_dy, image_h, false, NULL);
	gtk_image_set_from_pixbuf(GTK_IMAGE(n_image[6]), n_pximage[6]);
	gtk_widget_set_size_request(GTK_WIDGET(n_image[6]), image_w, image_h);
}

//**********************************************************************
void Creat_bk_img(int imgset, int imgset2)
{
	int imgid, i;
	char buffer[40];

	char MeaTxt[35][6] = {
						  "SPa",  "DPa",  "SDa",   "Ea",	// Gate A
						  "SPb",  "DPb",  "SDb",   "Eb",	// Gate B
						  "DAC",  "C dB", "  ",    "",		// DAC
						  "RG",   "IL",   "AF",    "RT",	// AWS
						  "ERS",  "C dB",  "DGS c", "",     // DGS
						  "E1",   "",   "",    "",    		// ENCODER
						};

	cairo_t *cr;
	imgset = imgset - 1;
	if (imgset < 0)
	{
		imgset = 0;
	}
	if (imgset == 2) //  Check DAC,DGS,AWS
	{
		if (Evaluate_val == 0)
		{
			imgset = 2;
		} // DAC is Selected
		if (Evaluate_val == 1)
		{
			imgset = 3;
		} // AWS is Selected
		if (Evaluate_val == 2)
		{
			imgset = 4;
		} // DGS is Selected
	}
	imgid = imgset * 4;

	cairo_surface_t *surface = cairo_image_surface_create(CAIRO_FORMAT_RGB24, tsbtn_width, btntop_height);
	cr = cairo_create(surface);
	for (i = 0; i < 4; i++)
	{
		cairo_set_source_rgb(cr, 0.234, 0.41, 0.88); // Set Background Color
		//cairo_set_source_rgb(cr, 1.0, 1.0, 1.0);
		if (Theme_color_val == 0)
		{
			//cairo_set_source_rgb(cr, 1.0, 1.0, 1.0); // UNCOMMENT TO MAKE THE MEASURE READING BUTTON WHITE
			cairo_set_source_rgb(cr, 0.0, 0.0, 0.0);
		} // Royal Blue Back Ground
		if (Theme_color_val == 1)
		{
			//cairo_set_source_rgb(cr, 1.0, 1.0, 1.0); // UNCOMMENT TO MAKE THE MEASURE READING BUTTON WHITE
			
			cairo_set_source_rgb(cr, 0.234, 0.41, 0.88);
		} // Black Ground
		if (Theme_color_val == 2)
		{
			//cairo_set_source_rgb(cr, 1.0, 1.0, 1.0); // UNCOMMENT TO MAKE THE MEASURE READING BUTTON WHITE
			cairo_set_source_rgb(cr, 1.0, 0.55, 0.0);
		} // Dark Orange

		cairo_paint(cr);
		cairo_select_font_face(cr, "Purisa", CAIRO_FONT_SLANT_NORMAL, CAIRO_FONT_WEIGHT_BOLD); // CAIRO_FONT_WEIGHT_NORMAL
		
		//  Set Font Color
		cairo_set_source_rgb(cr, 1.0, 0.0, 0.0);
		if (Theme_color_val == 0)
		{
			cairo_set_source_rgb(cr, 1.0, 1.0, 1.0);
			// cairo_set_source_rgb(cr, 1.0, 0.0, 0.0);
		} // Royal Blue Back Ground
		if (Theme_color_val == 1)
		{
			cairo_set_source_rgb(cr, 1.0, 0.0, 0.0);
		} // Black Ground
		if (Theme_color_val == 2)
		{
			cairo_set_source_rgb(cr, 0.0, 0.0, 0.0);
		} // Dark Orange

		cairo_set_font_size(cr, 15 + 5);
		cairo_move_to(cr, 5, 22);

		cairo_show_text(cr, MeaTxt[imgid++]); // if (Measure_v1 == 0)
		cairo_fill(cr);
		sprintf(Dsp_Str, "btnimg%d_%d.png", imgset2, i + 1);

		cairo_surface_write_to_png(surface, Dsp_Str);	
		if (Measure_v1 == 0) // This is MEA_POSI1 == OFF condition, Display nothing
		{
			cairo_surface_write_to_png(surface, "        ");

			gtk_label_set_label(GTK_LABEL(t_label[0]), "      ");
			gtk_label_set_label(GTK_LABEL(t_label[1]), "      ");
			gtk_label_set_label(GTK_LABEL(t_label[2]), "      ");
			gtk_label_set_label(GTK_LABEL(t_label[3]), "      ");
		}

		if (Measure_v2 == 0)  // This is MEA_POSI2 == OFF condition
		{
			cairo_surface_write_to_png(surface, "        ");

			gtk_label_set_label(GTK_LABEL(s_label[0]), "      ");
			gtk_label_set_label(GTK_LABEL(s_label[1]), "      ");
			gtk_label_set_label(GTK_LABEL(s_label[2]), "      ");
			gtk_label_set_label(GTK_LABEL(s_label[3]), "      ");
		}			
	}

	// Colour_Theme(Theme_color_val);               // Color theme of Screen
}

// void draw_notfcnimg(int thm_no,int not_no,int frm_no)
void Draw_notificimg(int Symbl_type, int Symbl) // Draw Sybol and DIsplay on Screen
{
	cairo_t *cr;

	/*cairo_surface_t* surface = cairo_image_surface_create(CAIRO_FORMAT_RGB24, 195, 35);*/
	cairo_surface_t *surface = cairo_image_surface_create(CAIRO_FORMAT_RGB24, image_w, image_h);
	cr = cairo_create(surface);
	cairo_set_line_width(cr, 2.0);
	// cairo_set_source_rgb(cr, 1.0, 0.55, 0.0);
	// if (thm_no == 0) { cairo_set_source_rgb(cr, 1.0, 0.87, 0.678); } // for background color
	if (Theme_color_val == 0)
	{
		cairo_set_source_rgb(cr, 0.0, 0.0, 0.0);
		// cairo_set_source_rgb(cr, 0.439, 0.50, 0.564);		
	} // Blue
	if (Theme_color_val == 1)
	{
		cairo_set_source_rgb(cr, 0.529, 0.80, 0.980);		
	} // Gray
	if (Theme_color_val == 2)
	{
		cairo_set_source_rgb(cr, 1.0, 0.87, 0.678);
	} // for background color  // Orange
	cairo_paint(cr);

	// if (thm_no == 0) { cairo_set_source_rgb(cr, 0.0, 0.0, 0.0); } //for line color whether red or black
	if (Theme_color_val == 0)
	{
		cairo_set_source_rgb(cr, 1.0, 0.0, 0.0);
	} // Blue
	if (Theme_color_val == 1)
	{
		cairo_set_source_rgb(cr, 1.0, 0.0, 0.0);
	} // Gray
	if (Theme_color_val == 2)
	{
		cairo_set_source_rgb(cr, 0.0, 0.0, 0.0);
	} // for line color whether red or black Orange

	// cairo_set_source_rgb(cr, 0.0, 0.0, 0.0);
	if (Symbl_type == MODE_S)
	{
		Mode_Symbol(Symbl, cr); // Mode Normal Probe
		//cairo_surface_write_to_png(surface, "Images/Images/n1.png");
	}

	if (Symbl_type == TRIG_S)
	{
		Trig_Symbol(Symbl, cr); // Measurement Trigger Symbol
		//cairo_surface_write_to_png(surface, "Images/Images/n2.png");
	}

	if (Symbl_type == REJECT_S)
	{
		Reject_Symbol(Symbl, cr); // Rejection Activated Symbol
		//cairo_surface_write_to_png(surface, "Images/Images/n3.png");
	}

	if ((Symbl_type == SZEVAL_S) && (Dac_v != 0 || Aws_onoff_v != 0 || Dgs_onoff_v != 0))
	{
		// if ( Dac_v != 0 || Aws_onoff_v != 0 || Dgs_onoff_v != 0)
			Size_Eval_Symbol(Symbl, cr); // Size Evalution Symbol
		//cairo_surface_write_to_png(surface, "Images/Images/n4.png");
	}

	//n_pximage[0] = gdk_pixbuf_new_from_file_at_scale(imagename[Symbl_type], image_w, image_h, false, NULL);
	n_pximage[0] = gdk_pixbuf_get_from_surface(surface, 0, 0, image_w, image_h);
	gtk_image_set_from_pixbuf(GTK_IMAGE(n_image[Symbl_type]), n_pximage[0]);
}


/************************************************************************************/
void Mode_Symbol(int Symbl, cairo_t *cr)
{
	if (Symbl == 0) // Mode Normal Probe
	{
		cairo_move_to(cr, 18, 10);
		cairo_line_to(cr, 13, 15);
		cairo_move_to(cr, 18, 10);
		cairo_line_to(cr, 23, 15);
		cairo_move_to(cr, 18, 10);
		cairo_line_to(cr, 18, 33);
		cairo_move_to(cr, 18, 33);
		cairo_line_to(cr, 13, 28);
		cairo_move_to(cr, 18, 33);
		cairo_line_to(cr, 23, 28);
		cairo_stroke(cr);
	}

	else if (Symbl == 1) // Mode TR Probe
	{
		cairo_move_to(cr, 13, 30);
		cairo_line_to(cr, 8, 22);
		cairo_move_to(cr, 13, 30);
		cairo_line_to(cr, 18, 22);
		cairo_move_to(cr, 13, 10);
		cairo_line_to(cr, 13, 30);
		cairo_move_to(cr, 23, 10);
		cairo_line_to(cr, 23, 30);
		cairo_move_to(cr, 23, 10);
		cairo_line_to(cr, 18, 18);
		cairo_move_to(cr, 23, 10);
		cairo_line_to(cr, 28, 18);
		cairo_stroke(cr);
	}
}

/************************************************************************************/
void Trig_Symbol(int Symbl, cairo_t *cr) // Measurement Trigger Symbol
{
	if (Symbl == 0) // Edge Triger
	{
		cairo_move_to(cr, 0, 30);
		cairo_line_to(cr, 5, 30);
		cairo_line_to(cr, 15, 10);
		cairo_line_to(cr, 25, 30);
		cairo_line_to(cr, 40, 30);
		cairo_stroke(cr);
		cairo_set_source_rgb(cr, 0.0, 0.0, 0.0);
		cairo_move_to(cr, 10, 15);
		cairo_line_to(cr, 10, 25);
		cairo_stroke(cr);
	}

	if (Symbl == 1) // Peak Trigger
	{
		cairo_move_to(cr, 0, 30);
		cairo_line_to(cr, 5, 30);
		cairo_line_to(cr, 15, 10);
		cairo_line_to(cr, 25, 30);
		cairo_line_to(cr, 40, 30);
		cairo_stroke(cr);
		cairo_set_source_rgb(cr, 0.0, 0.0, 0.0);
		cairo_move_to(cr, 15, 5);
		cairo_line_to(cr, 15, 20);
		cairo_stroke(cr);
	}

	if (Symbl == 2) // Zero Cross
	{
		cairo_move_to(cr, 0, 20);
		cairo_line_to(cr, 5, 20);
		cairo_line_to(cr, 10, 30);
		cairo_line_to(cr, 20, 5);
		cairo_line_to(cr, 25, 20);
		cairo_line_to(cr, 30, 20);
		cairo_stroke(cr);
		cairo_move_to(cr, 5, 30);
		cairo_line_to(cr, 5, 15);

		cairo_set_source_rgb(cr, 0.0, 0.0, 0.0);
		cairo_stroke(cr);
	}

	if (Symbl == 3) // J Cross Trigger
	{
		cairo_move_to(cr, 0, 20);
		cairo_line_to(cr, 5, 20);
		cairo_line_to(cr, 10, 30);
		cairo_line_to(cr, 20, 5);
		cairo_line_to(cr, 25, 20);
		cairo_line_to(cr, 30, 20);
		cairo_stroke(cr);
		cairo_set_source_rgb(cr, 0.0, 0.0, 0.0);
		cairo_move_to(cr, 15, 30);
		cairo_line_to(cr, 15, 10);
		cairo_stroke(cr);
	}
}

/************************************************************************************/
void Reject_Symbol(int Symbl, cairo_t *cr) // Rection Activated Symbol
{
	if (Symbl == 0) // Rejection OFF Symbol
	{
		cairo_set_source_rgb(cr, 0.0, 1.0, 0.0); // If Rejection OFF then Back Color GREEN
	}
	else
	{
		cairo_set_source_rgb(cr, 1.0, 0.0, 0.0); // If Rejection ON then Back Color RED
	}

	// cairo_set_source_rgb(cr, 1.0, 0.0, 0.0);
	cairo_translate(cr, image_w / 2, image_h / 2);
	cairo_arc(cr, 0, 0, 13, 0, 2 * M_PI);
	cairo_stroke_preserve(cr);
	cairo_fill(cr);
	cairo_set_source_rgb(cr, 0.0, 0.0, 0.0);

	cairo_set_font_size(cr, 22);
	cairo_move_to(cr, -7, 8);
	cairo_show_text(cr, "R"); // cairo_show_text(cr, "T");
	cairo_fill(cr);
}

/************************************************************************************/
void Size_Eval_Symbol(int Symbl, cairo_t *cr) // Size Evalution Symbol
{
	//char Stxt[5][5] = {"DAC", "AWS", "DGS", "T", "B"}; // D=DAC, A=AWS, G=DGS, T=TCG ON
	char Stxt[5][5] = { "DAC", "AWS", "DGS", "TCG", "B" };  // original
	{
		cairo_set_source_rgb(cr, 0.0, 1.0, 0.0);
		cairo_translate(cr, image_w / 2, image_h / 2);
		//cairo_arc(cr, 0, 0, 15, 0, 2 * M_PI); 
		cairo_arc(cr, 0, 0, 12, 0, 2 * M_PI); // original
		cairo_stroke_preserve(cr);
		cairo_fill(cr);
		cairo_set_source_rgb(cr, 0.0, 0.0, 0.0);
		cairo_set_font_size(cr, 12); // original
		//cairo_move_to(cr, -13, 5);
		cairo_move_to(cr, -13, 6);  // original
		cairo_show_text(cr, Stxt[Symbl]); // Stxt[0]); //cairo_show_text(cr, "T");
		cairo_fill(cr);
	}
}

/************************************************************************************/
/***********************ALL DATA VALUE PROCESS FUNCTION******************************/
/************************************************************************************/
void AllProcess(int key_v)
{
	num_4 = (menu_v * 5) + btn_idx;

	switch (num_4)
	{
	case ZERO_PERA:
		Zero_f(key_v);
		break; // MENU 1
	case RANGE_PERA:
		Range_f(key_v);
		dac_gen(&dac_pnt[0], &dac_cv[0], Gain_v, Range_v, Delay_rv);
		break; // If Dac ON then Draw DAC Curvebreak; // MENU 1
	case VELO_PERA:
		Velo_f(key_v);
		dac_gen(&dac_pnt[0], &dac_cv[0], Gain_v, Range_v, Delay_rv);
		break; // If Dac ON then Draw DAC Curve break; // MENU 1
	case DELAY_PERA:
		Delay_f(key_v);
		dac_gen(&dac_pnt[0], &dac_cv[0], Gain_v, Range_v, Delay_rv);
		break; // If Dac ON then Draw DAC Curve  break; // MENU 1
		// case GAIN_PERA: Gain_f(key_v);  break; // MENU 1

	case GATE1_PERA:
		Gatea_f(key_v);
		break; // MENU 2
	case GSTA1_PERA:
		STARTa_f(key_v);
		break; // MENU 2
	case GEND1_PERA:
		ENDa_f(key_v);
		break; // MENU 2
	case GTHE1_PERA:
		LEVELa_f(key_v);
		break; // MENU 2
		// case 9: REF25_f(key_v); break;

	case GATE2_PERA:
		GATEb_f(key_v);
		break; // MENU 3
	case GSTA2_PERA:
		STARTb_f(key_v);
		break; // MENU 3
	case GEND2_PERA:
		ENDb_f(key_v);
		break; // MENU 3
	case GTHE2_PERA:
		LEVELb_f(key_v);
		break; // MENU 3
		// case 14: GAIN_f(key_v); break;

	case MEM_PERA:
		MEMORY_f(key_v);
		break; // MENU 4
	case MEM_NO_PERA:  
		if (note_dsp == 1)
		{
			Note_ln_f(key_v); // MENU 4
		}
		else
		{
			MEMNO_f(key_v);// MENU 4
		}
		break; // MENU 4
	case MEM_ACT_PERA:
		if (note_dsp == 1)
		{
			Note_Cur_pos_f(key_v);
		}
		else
		{
			ACTION_f(key_v);
		}
		break; // MENU 4
	case MEM_NOTE_PERA:
		Mem_Note_f(key_v);
		break; // MENU 4
		// case 19: Gain_1f(key_v); break;

	case DAC_PERA:
		Size_Eval_f(key_v);
		break; // MENU 5
	case CURSOR_PERA:
		Size_Eval_f1(key_v);
		break; // MENU 5
	case PRESS_PERA:
		Size_Eval_f2(key_v);
		break; // MENU 5
	case POINT_PERA:
		Size_Eval_f3(key_v);
		break; // MENU 5

	case DAMP_PERA:
		DAMP_f(key_v);
		break; // MENU 6
	case MODE_PERA:
		Mode_f(key_v);
		break; // MENU 6
	case PRF_PERA:
		Prf_f(key_v);
		break; // MENU 6
	case TXVOLT_PERA:
		Txvolt_f(key_v);
		break; // MENU 6

	case REJECT_PERA:
		Reject_f(key_v);
		break; // MENU 7
	case FREQ_PERA:
		Freq_f(key_v);
		break; // MENU 7
	case RECTIFY_PERA:
		Rectify_f(key_v);
		break; // MENU 7
	case SMOOTH_PERA:
		Smooth_f(key_v);
		break; // MENU 7

	case GRID_PERA:
		Grid_f(key_v);
		break; // MENU 8
	case COL_LEG_PERA:
		Color_Leg_f(key_v);
		break; // MENU 8
	case VIDEO_PERA:
		Video_f(key_v);
		break; // MENU 8
	case SET_REF_PERA:
		Setref_f(key_v);
		break; // MENU 8

	case SCR_THEME_PERA:
		COLOR_Theme_f(key_v);
		break; // MENU 9
	case ACOLOR_PERA:
		COLOR_f(key_v);
		break; // MENU 9
	case BRIGHT_PERA:
		Brightness_f(key_v);
		break; // MENU 9
	case SCREEN_PERA:
		Screen_rotate_f(key_v);
		break; // MENU 9

	case XOFF_PERA:
		X_OFFSET_f(key_v);
		break; // MENU 10
	case ANGLE_PERA:
		ANGLE_f(key_v);
		break; // MENU 10
	case THICK_PERA:
		THICK_f(key_v);
		break; // MENU 10
	case TRIG_PERA:
		Trig_f(key_v);
		break; // MENU 10

	case CLOCK_PERA:
		CLOCK_f(key_v);
		break; // MENU 11
	case HORN_PERA:
		if (val_ary[CLOCK_PERA] == 0 || val_ary[CLOCK_PERA] == 1)
			HORN_f(key_v);
		else if (val_ary[CLOCK_PERA] == 2)
			New_Date_f(key_v);
		else if (val_ary[CLOCK_PERA] == 3)
			New_Houre_f(key_v);
		break; //MENU 11
	case BEEP_PERA:	 //MENU 11
		if (val_ary[CLOCK_PERA] == 0 || val_ary[CLOCK_PERA] == 1)
			BEEP_f(key_v);
		else if (val_ary[CLOCK_PERA] == 2)
			New_Month_f(key_v);
		else if (val_ary[CLOCK_PERA] == 3)
			New_Minute_f(key_v);
		break; // No_refresh = true; Clear_Clock_area(hWnd); break; // Clr_Ascan=true; break; // MENU 11
	case UNIT_PERA: // MENU 11
		if (val_ary[CLOCK_PERA] == 0 || val_ary[CLOCK_PERA] == 1 || val_ary[CLOCK_PERA] == 3)
			Unit_f(key_v); 
		else if (val_ary[CLOCK_PERA] == 2)
			New_Year_f(key_v);
		break;

		// case FLNAME_PERA:             //auto_flname(key_v); break;   //  Set Auto File No  //

		// Auto Cal to be Add here
	case ACAL_PERA:
		Auto_Cal_f(key_v);
		break; // Menu 12
	case STRT_GA_PERA:
		STARTa_f(key_v);
		break; // Menu 12
	case DST1_PERA:
		DST1_f(key_v); 
		break; // Menu 12
	case DST2_PERA:
		DST2_f(key_v);
		break; // Menu 12

	case SIZE_EV_PERA:
		Size_Eval_Select_f(key_v);
		break; // MENU 13
	case MEA_POSI1_PERA:
		Mea_fLn1_f(key_v);
		break; // MENU 13
	case MEA_POSI2_PERA:
		Mea_fLn2_f(key_v);
		break; // MENU 13
	case MEA_POSI3_PERA:
		// Mea_fLn3_f(key_v);
		break; // MENU 13

	case REC_TYPE_PERA:
		Record_type_f(key_v);
		break; // MENU 14
	case RECORD_NO_PERA:
		Record_No_f(key_v);
		break; // MENU 14
	case RECORD_OP_PERA:
		Bs_Action_Select_f(key_v);
		break; // MENU 14
	case REC_ACTION_PERA:
		Bs_Perf_Action(key_v);
		break; // MENU 14

	case ENCODER_PERA:
		ENCODER_f(key_v);
		break; // MENU 15
	case ENC_CAL_PERA:
		Enc_CAL_F_f(key_v);
		break; // MENU 15
	case ENC_STRT_PERA:
		Enc_CAL_F_f(key_v);
		Enc_Start_posF_f(key_v);
		break; //  MENU 15
	case ENC_KMPST_PERA:
		break; // MENU 15
		
	case WELD_PROF_PERA:
		Weld_Prof_f(key_v);
		break; // MENU 16
	case BEAM_PROF_PERA:
		Beam_Prof_f(key_v);
		break; // MENU 16
	case THICK_CLR_PERA:
		//Diameter_f(key_v);
		// Thick_color_f(key_v);
		break; // MENU 16
	case CNG_OGL_PROF_POS:
		Change_ogl_probe_pos_f(key_v);
		break; // MENU 16

	case SCALE_POS_PERA:
		Scal_f(key_v);
		break; // MENU 17 1 MINUTE_v+5              // DGS Configuration
	case PRBNM_POS_PERA:
		break; // SCALE_POS_PERA+1
	case PRFFRE_POS_PERA:
		Prb_freq_f(key_v);
		break; // PRBNM_POS_PERA+1
	case DELVEL_PERA:
		Del_Vel_f(key_v);
		break; // PRFFRE_POS_PERA+1

	case D_EFECT_PERA:
		D_efect_f(key_v);
		break; // MENU 18   SCALE_POS_PERA+5
	case DGS_CRV_PERA:
		Dgs_crv_f(key_v);
		break; // D_EFECT_PERA+1
	case REF_ECHO_PERA:
		Ref_echo_f(key_v);
		break; // DGS_CRV_PERA+1
	case REF_SIZ_PERA:
		Ref_size_f(key_v);
		break; // REF_ECHO_PERA+1

	case DGS_EX_PERA:
		Dgs_exit_f(key_v);
		Frame_menu_exit_f(key_v);
		break; //   // Exit From Frame Menu Dgs_exit_f(key_v); break;   //MENU 19  D_EFECT_PERA+5
	case ATT_REF_PERA:
		Att_ref_f(key_v);
		break; // DGS_EX_PERA+1
	case ATT_OBJ_PERA:
		Att_obg_f(key_v);
		break; // ATT_REF_PERA+1
	case AMP_COR_PERA:
		Amp_corr_f(key_v);
		break; // ATT_OBJ_PERA+1

	case WELD_TYPE_PERA:
		Weld_type_f(key_v);
		break; // MENU 20 WELD_TYPE_PERA
	case TOP_WIDTH_PERA:
		Weld_Width_f(key_v);
		break; // TOP_WIDTH_PERA
	case TOP_HEIGHT_PERA:
		Weld_TpHeight_f(key_v);
		break; // TOP_HEIGHT_PERA
	case ROOT_WIDTH_PERA:
		Weld_Root_width_f(key_v);
		break; // ROOT_WIDTH_PERA

	case OBJ_SHAPE_PERA:
		Tst_Obh_shape_f(key_v);
		break; //  Weld_EXT11_f(key_v); break;       // MENU 21  EXT_11_PERA
	case OBJ_WIDTH_PERA:
		Obj_width_f(key_v);
		break; // Weld_EXT12_f(key_v); break;       // Width / OD
	case OBJ_THICK_PERA:
		Obj_thick_f(key_v);
		break; // Weld_EXT13_f(key_v); break;       // EXT_13_PERA
	case WPROF_POS_PERA:
		Obj_Wprof_pos_f(key_v);
		break; // Weld_EXT14_f(key_v); break;       // EXT_14_PERA

	case EXT_WELD_PRF_PERA:
		Weld_Exit_f(0);
		Frame_menu_exit_f(key_v);
		recreate_surface(width_sh, height_sh, ogl_x_position, ogl_y_position);
		break; // MENU 22    EXT_21_PERA
	case PROB_POS_PERA:
		Probe_pos_f(key_v);
		break; // Weld_EXT22_f(key_v); break;  //  EXT_22_PERA
	case PROBE_ANGLE_PERA:
		Probe_angle_f(key_v);
		break; // Weld_EXT23_f(key_v); break;  //  EXT_23_PERA
	case NOOF_LEGv_PERA:
		NoofLeg_f(key_v);
		break; // Weld_EXT24_f(key_v); break;  //  EXT_24_PERA

	case EXT_21_PERA:
		break; // Tst_Obh_shape_f(key_v); break;   // MENU 23  OBJ_SHAPE_PERA           //    Test Object Shape Selection
	case EXT_22_PERA:
		break; // Probe_pos_f(key_v); break;       // PROB_POS_PERA
	case EXT_23_PERA:
		break; // Probe_angle_f(key_v); break;     // PROBE_ANGLE_PERA
	case EXT_24_PERA:
		break; // NoofLeg_f(key_v); break;      //  NOOF_LEGv_PERA

	case EXT_31_PERA:
		break; // Obj_width_f(key_v); break;      //  MENU 24  OBJ_WIDTH_PERA
	case EXT_32_PERA:
		break; // Obj_thick_f(key_v); break;      //  HEIGHT_PERA
	case EXT_33_PERA:
		break; // Obj_EXT33_f(key_v); break;      //  EXT_33_PERA
	case EXT_34_PERA:
		break; // Obj_EXT34_f(key_v); break;      //  EXT_34_PERA

	case EXT_41_PERA:
		break; // Obj_Exit_f(0); Frame_menu_exit_f(key_v); break;      //  MENU 25  EXT_41_PERA
	case EXT_42_PERA:
		break; // Obj_Wprof_pos_f(key_v); break;      //  EXT_42_PERA:
	case EXT_43_PERA:
		break; // Obj_EXT43_f(key_v); break;      //  EXT_43_PERA
	case EXT_44_PERA:
		break; // Obj_EXT44_f(key_v); break;      //  EXT_44_PERA

	case BEAM_PrbDia_PERA:
		Beam_Prof_PDia_f(key_v);
		break; // EXT_21_PERA+5      //  Probe Near Field Beam Profile
	case BEAM_PrbFreq_PERA:
		Beam_Prof_PFreq_f(key_v);
		break; // Calculate Near Field Value and Angle
	case BEAM_PRF_P13_PERA:
		break; // Beam_Prof_p13_f(key_v); break;
	case BEAM_PRF_P14_PERA:
		break; // Beam_Prof_p14_f(key_v); break;

	case BEAM_PRF_P21_PERA:
		break; // Beam_Prof_p21_f(key_v); break;
	case BEAM_PRF_P22_PERA:
		break; // Beam_Prof_p22_f(key_v); break;
	case BEAM_PRF_P23_PERA:
		break; // Beam_Prof_p23_f(key_v); break;
	case BEAM_PRF_P24_PERA:
		break; // Beam_Prof_p24_f(key_v); break;

	case BEAM_PRF_P31_PERA:
		Beam_Profile_Cal_f();
		Frame_menu_exit_f(key_v);
		break;
	case BEAM_PRF_P32_PERA:
		break; // Beam_Prof_p32_f(key_v); break;
	case BEAM_PRF_P33_PERA:
		break; // Beam_Prof_p33_f(key_v); break;
	case BEAM_PRF_P34_PERA:
		break; // Beam_Prof_p34_f(key_v); break;

	case THKFILE_TYPE_PERA:
		Thk_File_type_f(key_v);
		break; // MENU 26 THKFILE_TYPE_PERA           // Thickness file type Selection
	case START_ID_1_PERA:
		Start_ID_1_f(key_v);
		break; //  START_ID_1_PERA
	case START_ID_2_PERA:
		Start_ID_2_f(key_v);
		break; //  START_ID_2_PERA
	case START_ID_3_PERA:
		// Start_ID_3_f(key_v);
		break; //  START_ID_3_PERA

	case EXT_51_PERA:
		// Thk_EXT_51_f(key_v);  // NOT USED
		break; //  MENU 27  EXT_51_PERA
	case END_ID_1_PERA:
		END_ID_1_f(key_v);
		break; //  END_ID_1_PERA
	case END_ID_2_PERA:
		END_ID_2_f(key_v);
		break; //  END_ID_2_PERA
	case END_ID_3_PERA:
		// END_ID_3_f(key_v);
		break; //  END_ID_3_PERA

	case EXIT_PERA:
		Frame_menu_exit_f(key_v);
		Bsc_Record_Start_f(key_v);
		Thk_File_Exit_f(key_v);
		write_data_into_thk_file();
		break; // MENU 28 EXIT_PERA
	case DIM_1_SIZE_PERA:
		///Dim_1_size_f(key_v);
		break; //  DIM_1_SIZE_PERA
	case DIM_2_SIZE_PERA:
		// Dim_2_size_f(key_v);
		break; //  DIM_2_SIZE_PERA
	case DIM_3_SIZE_PERA:
		// Dim_3_size_f(key_v);
		break; //  DIM_3_SIZE_PERA

	case COLOR_METHOD_PERA:
		// Thk_Color_method_f(key_v);
		break; // MENU 29 COLOR_METHOD_PERA  EXIT_PERA:   +5           // Thickness file Color Selection
	case START_THK_1_PERA:
		Start_Thk_1_f(key_v);
		break; //  START_THK_1_PERA:
	case START_THK_2_PERA:
		Start_Thk_2_f(key_v);
		break; //  START_THK_2_PERA
	case START_THK_3_PERA:
		Start_Thk_3_f(key_v);
		break; //  START_THK_3_PERA

	case EXT_61_PERA:
		// Thk_EXT_61_f(key_v);
		break; // MENU 30 EXT_61_PERA
	case END_THK_1_PERA:
		End_Thk_1_f(key_v);
		break; //  END_THK_1_PERA
	case END_THK_2_PERA:
		End_Thk_2_f(key_v);
		break; //  END_THK_2_PERA
	case END_THK_3_PERA:
		End_Thk_3_f(key_v);
		break; //  END_THK_3_PERA

	case EXIT_71_PERA:
		Frame_menu_exit_f(key_v);
		Bsc_Record_Start_f(key_v);
		Thk_File_Exit_f(key_v);
		break; // MENU 31 EXIT_71_PERA
	case COLOR_1_PERA:
		Thk_Clr_1_f(key_v);
		break; //  COLOR_1_PERA
	case COLOR_2_PERA:
		Thk_Clr_2_f(key_v);
		break; //  COLOR_2_PERA
	case COLOR_3_PERA:
		Thk_Clr_3_f(key_v);
		break; //  COLOR_3_PERA

	case MINUTE_v:
		//MINUTE_f(key_v);
		break; // MENU 15
	case HOUR_v:
		//HOUR_f(key_v);
		break; // MENU 15
	case DAY_v:
		//DAY_f(key_v);
		break; // MENU 15
	case MONTH_v:
		//MONTH_f(key_v);
		break; // MENU 15
	case YEAR_v:
		//YEAR_f(key_v);
		break; // // MENU 15

	case GAIN_PERA:
	case 9: // Gain_f(key_v);  break;
	case 14:
	case 19:
	case 24:
	case 29:
	case 34:
	case 39:
	case 44:
	case 49:
	case 54:
	case 59:

	case 64:
	case 69:
	case 74:
	case 79:
		if (note_dsp == 1)
		{
			Note_Char_Scroll_f(key_v);
		}
		else
		{
			if (((Record_Type_val == 0 && Mem_actBS == 2) || (Record_Type_val == 1 && Mem_actBS == 2)|| (Record_Type_val == 3 && Mem_actBS == 2)) && rw_flag != -1)
			{
				if (gain_btnval_flag == false)
				{
					pos = (GAIN_PERA * 2) + 0;
					strcpy(gain_btnval[0], all_btnval[pos]);
					strcpy(gain_btnval[1], all_btnval[pos + 1]);
					strcpy(all_btnval[pos], "   Scroll   ");
					pos = pos % 10;
					gain_btnval_flag = true;
				}

				if ((key_v > 0) || ((key_v < 0) && (asc_cur_pos > 741)))
					Bsc_Analysis_thk_f(key_v);
			}
			else
			{
				Gain_f(key_v);
				if (Dac_v > 0 || Dgs_onoff_v == 2 || Dgs_onoff_v == 3) // DAC is DRAW or ON
				{
					dac_gen(&dac_pnt[0], &dac_cv[0], Gain_v, Range_v, Delay_rv); // If Dac ON then Draw DAC Curve
				}

				if (gain_btnval_flag == true)
				{
					pos = (GAIN_PERA * 2) + 0;
					strcpy(all_btnval[pos], gain_btnval[0]);
					strcpy(all_btnval[pos + 1], gain_btnval[1]);
					pos = pos % 10;
					gain_btnval_flag = false;
				}
				if (gain_btnflag == true) // To distingush between gain value from keypad and button //change value
				{
					btn_idx = l_btnidx;
				}
			}
		}
		break;

	default:
		break;
	}

	Menu_Refresh();
}

/************************************************************************************/
/***************************GO TO PREVIOUS BUTTON FUNCTION***************************/
/************************************************************************************/
void PrvBtnClick(void)
{	
	if ((rw_flag == 0 || rw_flag == 1) && (Record_Type_val == 0 || Record_Type_val == 1 || Record_Type_val == 3) && (Mem_actBS == 0 || Mem_actBS == 1))
	{
		// Pause Bscan and Thickness
		if (opengl_update == true) // pause
		{
			opengl_update = false;
			
			time_pause = time(NULL);
			gtk_widget_show(nframe[8]);
			gtk_label_set_label(GTK_LABEL(Pause_lab), "PAUSE");
		}
		else if (opengl_update == false) // play
		{
			opengl_update = true;

			time_play = time(NULL);
			stop_sec = difftime(time_play, time_pause);
			total_stop_sec = total_stop_sec + stop_sec;
			gtk_widget_show(nframe[8]);
			gtk_label_set_label(GTK_LABEL(Pause_lab), "PLAY");
		}
	}
	else if (((Record_Type_val == 0 && Mem_actBS == 2) || (Record_Type_val == 1 && Mem_actBS == 2)) || (Record_Type_val == 3 && Mem_actBS == 2) && rw_flag != -1)
	{
		int cur_x = 0, cur_y = 0, pre_x = 0;

		cursor_x_pos = cursor_x_pos - 1;

		if (cursor_x_pos < 0)
		{
			cursor_x_pos = 0;
		}
		cur_x = cursor_x_pos;
		// cur_y = (int)event->y;
		cur_y = bsc_height - 10;

		pre_x = mouse_pre_x;
		mouse_pre_x = cur_x;

		update_on_mouse_move(cur_x, pre_x);
		show_index_content(cur_x, cur_y);
	}
	else
	{
		Menu_f(-1);
	}
}

/************************************************************************************/
/*******************************GO TO NEXT BUTTON FUNCTION***************************/
/************************************************************************************/
void NxtBtnClick(void)
{
	if ((rw_flag == 0 || rw_flag == 1) && (Record_Type_val == 0 || Record_Type_val == 1 || Record_Type_val == 3) && (Mem_actBS == 0 || Mem_actBS == 1))
	{
		// Pause Bscan and Thickness
		if (opengl_update == true) // pause
		{
			opengl_update = false;

			time_pause = time(NULL);
			gtk_widget_show(nframe[8]);
			gtk_label_set_label(GTK_LABEL(Pause_lab), "PAUSE");
		}
		else if (opengl_update == false) // play
		{
			opengl_update = true;

			time_play = time(NULL);
			stop_sec = difftime(time_play, time_pause);
			total_stop_sec = total_stop_sec + stop_sec;
			gtk_widget_show(nframe[8]);
			gtk_label_set_label(GTK_LABEL(Pause_lab), "PLAY");
		}
	}
	else if (((Record_Type_val == 0 && Mem_actBS == 2) || (Record_Type_val == 1 && Mem_actBS == 2)) || (Record_Type_val == 3 && Mem_actBS == 2) && rw_flag != -1)
	{
		int cur_x = 0, cur_y = 0, pre_x = 0;

		cursor_x_pos = cursor_x_pos + 1;
		if (cursor_x_pos > width_sh)
		{
			cursor_x_pos = width_sh;
		}
		
    	cur_x = cursor_x_pos;
    	// cur_y = (int)event->y;
    	cur_y = bsc_height - 10;

    	pre_x = mouse_pre_x;
    	mouse_pre_x = cur_x;

    	update_on_mouse_move(cur_x, pre_x);
    	show_index_content(cur_x, cur_y);
	}
	else
	{
		Menu_f(1);
	}
}

/************************************************************************************/
/********************************MAIN MENU FUNCTION**********************************/
/************************************************************************************/
void Menu_f(int key_v)
{
	if (menu_v > 16 && menu_v < 20) // if (menu_v == 4 && Evaluate_val == 2 && Dgs_onoff_v == 1)
	{
		menu_v = menu_v + key_v;

		if (menu_v < 17)
		{
			menu_v = 17;
		}
		if (menu_v > 19)
		{
			menu_v = 19;
		}
		Set_btn_focus(); // Set Button/Controll Focus /Appropriate Color to indicate Selected
	}
	else if (menu_v > 19 && menu_v < 23)
	{
		menu_v = menu_v + key_v;
		if (menu_v < 20)
		{
			menu_v = 20;
		}
		if (menu_v > 22)
		{
			menu_v = 22;
		}
		Set_btn_focus(); // Set Button/Controll Focus /Appropriate Color to indicate Selected
	}
	else if (menu_v > 22 && menu_v < 26)
	{
		menu_v = menu_v + key_v;
		if (menu_v < 23)
		{
			menu_v = 23;
		}
		if (menu_v > 25)
		{
			menu_v = 25;
		}
		Set_btn_focus(); // Set Button/Controll Focus /Appropriate Color to indicate Selected
	}
	else if (menu_v > 25 && menu_v < 29)
	{
		menu_v = menu_v + key_v;
		if (menu_v < 26)
		{
			menu_v = 26;
		}
		if (menu_v > 28)
		{
			menu_v = 28;
		}
		Set_btn_focus(); // Set Button/Controll Focus /Appropriate Color to indicate Selected
	}
	else if (menu_v > 28 && menu_v < 32)
	{
		menu_v = menu_v + key_v;
		if (menu_v < 29)
		{
			menu_v = 29;
		}
		if (menu_v > 31)
		{
			menu_v = 31;
		}
		Set_btn_focus(); // Set Button/Controll Focus /Appropriate Color to indicate Selected
	}
	else if (menu_v > 31 && menu_v < 35)
	{
		menu_v = menu_v + key_v;
		if (menu_v < 32)
		{
			menu_v = 32;
		}
		if (menu_v > 34)
		{
			menu_v = 34;
		}
		Set_btn_focus(); // Set Button/Controll Focus /Appropriate Color to indicate Selected
	}
	else // ELSE INCREASE MENU NUMBER
	{
		menu_v = menu_v + key_v;
		if (menu_v < 0)
		{
			menu_v = 0;
		}
		if (menu_v > 15)  // IF MENU > 15 then MENU STOP at 15
		{
			menu_v = 15;
		}

		for (i = 0; i < 16; i++) // MENU BTN LABEL SHOW
		{
			if (menu_v == i) // Display Menu Number...
			{
				gtk_label_set_label(GTK_LABEL(label_dv[10]), menu_lbl[i]);
			}
		}
	}

	Menu_Refresh();
}

/***********************************************************************************/
/*********************SHOW AND HIDE TOP LAYER WIDGET FUNCTIONS**********************/
/***********************************************************************************/
void sh_buttons(GtkWidget *widget, GdkEventButton *event, gpointer data) // (NOT USED)
{
	if (showhide_flag == true)
	{
		sh_val = 0;
		sprintf(snum, "%s", "Hide");
		gtk_widget_show(ahbox1);
		gtk_widget_show(ahbox2);
		draw_image = gdk_pixbuf_new_from_file_at_scale("outputImages/Images/1.png", frame_width, frame_height, false, NULL);
		gtk_image_set_from_pixbuf(GTK_IMAGE(d_image), draw_image);
		gtk_widget_set_size_request(d_image, frame_width, frame_height);
		for (i = 0; i < 11; i++)
		{
			gtk_widget_set_size_request(btn_dv[i], buttonv_width, button_height);
		}
		gtk_widget_set_size_request(scrollbar, scrollbar_w, scrollbar_h);
		gtk_button_set_label(GTK_BUTTON(b_btn[0]), snum);
		showhide_flag = false;
	}

	else if (showhide_flag == false)
	{
		sh_val = 1;
		sprintf(snum, "%s", "Show");
		gtk_widget_hide(ahbox1);
		gtk_widget_hide(ahbox2);

		gtk_widget_set_size_request(d_image, frame_width, frame_heighth);
		for (i = 0; i < 8; i++)
		{
			gtk_widget_set_size_request(btn_dv[i], buttonv_width, buttonmnu_height);
		}
		gtk_widget_set_size_request(btn_dv[8], buttonv_width, buttonh_height);
		gtk_widget_set_size_request(btn_dv[9], buttonv_width, buttonmnu_height);
		gtk_widget_set_size_request(btn_dv[10], buttonv_width, button10_height);
		gtk_widget_set_size_request(scrollbar, scrollbarshw_w, scrollbarshw_h);
		gtk_button_set_label(GTK_BUTTON(b_btn[0]), snum);
		showhide_flag = true;
	}
}

/***********************************************************************************/
/*********************SHOW AND HIDE SCROLLBAR WIDGET FUNCTIONS**********************/
/***********************************************************************************/

void sh_scroll(GtkWidget *widget, GdkEventButton *event, gpointer data) // (NOT USED)
{
	if (showhide_flag == true)
	{
		//sh_val = 0;
		sprintf(snum, "%s", "Hide   ");
		gtk_widget_show(scrollbar);
		gtk_widget_show(b_btn[5]);
		gtk_widget_show(b_btn[6]);
		gtk_widget_show(bbtnkey);
		for (i = 0; i < 8; i++)
		{
			gtk_widget_set_size_request(btn_dv[i], buttonv_width, button_height);
		}
		gtk_widget_set_size_request(btn_prv, btnw_prvnxt, v_button_height);
		gtk_widget_set_size_request(btn_next, btnw_prvnxt, v_button_height);
		gtk_button_set_label(GTK_BUTTON(b_btn[1]), snum);
		showhide_flag = false;
	}

	else if (showhide_flag == false)
	{
		//sh_val = 1;
		sprintf(snum, "%s", "Show   ");
		gtk_widget_hide(scrollbar);
		gtk_widget_hide(b_btn[5]);
		gtk_widget_hide(b_btn[6]);
		gtk_widget_hide(bbtnkey);
		for (i = 0; i < 8; i++)
		{
			gtk_widget_set_size_request(btn_dv[i], btnscrhd_width, button_height);
		}
		gtk_widget_set_size_request(btn_prv, btnscrprvnxt_w, v_button_height);
		gtk_widget_set_size_request(btn_next, btnscrprvnxt_w, v_button_height);
		gtk_button_set_label(GTK_BUTTON(b_btn[1]), snum);
		showhide_flag = true;
	}
}

/************************************************************************************/
/************************ASSIGN KEY AND VALUE CHANGE FUNCTION************************/
/************************************************************************************/
gboolean my_keypress_val(GtkWidget *widget, GdkEventKey *event, gpointer data)
{
	// gchar* key;
	const int keycodet = event->keyval;
	Key_perform_F(keycodet);
}


//**************************************
gboolean Key_perform_F(int keycodet)
{
	gchar *key;
	int btn_pos;
	// switch (event->keyval)
	switch (keycodet)
	{
	// case GDK_KEY_Tab: key = "Tab";
	case GDK_KEY_W:
	case GDK_KEY_w:
		break;

	case Pera_UP_K:
	case GDK_KEY_Right:
		key = "Right";
		key_scr = 1;
		AllProcess(1);
		break;

	case Pera_DN_K:
	case GDK_KEY_Left:
		key = "Left";
		key_scr = 1;
		AllProcess(-1);
		break;

	case SLCT_UP_K:
	case GDK_KEY_Up:
		key = "Up";
		key_scr = 1;
		btn_idx = btn_idx - 1;
		l_btnidx = btn_idx;
		gain_btnflag = true;
		if (btn_idx < 0)
		{
			btn_idx = 0;
		}
		if (btn_idx > 4)
		{
			btn_idx = 0;
		}
		key_btn();
		if (note_dsp == 1)
		{
			gtk_widget_set_can_focus(GTK_WIDGET(text_h[ln_no]), true);
			OntString(0);
		} // Set Focus in Note Data after Pera Select Button press
		break;

	case SLCT_DN_K:
	case GDK_KEY_Down:
		key = "Down";
		key_scr = 1;
		btn_idx = btn_idx + 1;
		l_btnidx = btn_idx;
		gain_btnflag = true;
		if (btn_idx < 0)
		{
			btn_idx = 0;
		}
		if (btn_idx > 4)
		{
			btn_idx = 0;
		}
		key_btn();
		if (note_dsp == 1)
		{
			gtk_widget_set_can_focus(GTK_WIDGET(text_h[ln_no]), true);
			OntString(0);
		} // Set Focus in Note Data after Pera Select Button press
		break;

	case GAIN_UP_K:
	case GDK_KEY_greater: // ">" key
	case GDK_KEY_semicolon:
		key = "Gn UP";
		key_scr = 1;
		btn_idx = 4;
		AllProcess(1);
		break;

	case GAIN_DN_K:
	case GDK_KEY_less: // "<" key
	case GDK_KEY_colon:
		key = "Gn DN";
		key_scr = 1;
		btn_idx = 4;
		AllProcess(-1);
		break;

	case Menu_UP_K:
	case GDK_KEY_S:
	case GDK_KEY_s:
		if (note_dsp == 1)
		{
			Note_Char_Scroll_f(1);
		}
		else
		{
			NxtBtnClick();
			// Menu_f(1);
		}
		break;

	case Menu_DN_K:
	case GDK_KEY_A:
	case GDK_KEY_a:
		if (note_dsp == 1)
		{
			Note_Char_Scroll_f(-1);
		}
		else
		{
			PrvBtnClick();
		}
		break;

	case GDK_KEY_BackSpace:
		// pwroff_savesetup();
		// Close_Window();
		if (signal_id)
		{
			g_source_remove(signal_id);
			signal_id = 0;
		}
		gtk_widget_destroy(GTK_WIDGET(window));
		break;

	case GDK_KEY_Page_Up:
		key = "PageUp";
		if (note_dsp == 1)
		{
		
		}
		else
		{
		}
		break;

	case GDK_KEY_Page_Down:
		key = "PageDown";
		if (note_dsp == 1)
		{
			
		}
		else
		{
		}
		if (btn_idx == 4)
		{
			stp_coarse();
		}
		break;

	default:
		break;
	}
	// return TRUE;
	return true;
}

void lftBtn_valchng(GtkWidget* widget)
{
	key_scr = 1;
	if (GTK_WIDGET(widget) == btn_dv[20])
	{
		btn_idx = 0;
	}
	if (GTK_WIDGET(widget) == btn_dv[11])
	{
		btn_idx = 1;
	}
	if (GTK_WIDGET(widget) == btn_dv[12])
	{
		btn_idx = 2;
	}
	if (GTK_WIDGET(widget) == btn_dv[13])
	{
		btn_idx = 3;
	}
	if (GTK_WIDGET(widget) == btn_dv[14])
	{
		btn_idx = 4;
	}
	Set_btn_focus();
	AllProcess(-1);
}

void rghtBtn_valchng(GtkWidget* widget)
{
	key_scr = 1;
	if (GTK_WIDGET(widget) == btn_dv[15])
	{
		btn_idx = 0;
	}
	if (GTK_WIDGET(widget) == btn_dv[16])
	{
		btn_idx = 1;
	}
	if (GTK_WIDGET(widget) == btn_dv[17])
	{
		btn_idx = 2;
	}
	if (GTK_WIDGET(widget) == btn_dv[18])
	{
		btn_idx = 3;
	}
	if (GTK_WIDGET(widget) == btn_dv[19])
	{
		btn_idx = 4;
	}
	Set_btn_focus();
	AllProcess(1);
}

//************************************************************************************
void Keypad_rd() // Read Keypad Data
{
	int ds = 0;
	int data = 0;
	tx_cmd[ds++] = 0x1B;
	tx_cmd[ds++] = 0x025;
	tx_cmd[ds++] = 0x0;
	tx_cmd[ds++] = 0x1B; // 1B 25 00  1B   // Key Pad data read
	tx_cmd[ds++] = 0x0;
	tx_cmd[ds++] = 0x0;
	tx_cmd[ds++] = 0x00;
	tx_cmd[ds++] = 0x0; // Dummy data to read from SPI
	tx_cmd[ds++] = 0x0;
	tx_cmd[ds++] = 0x0;
	tx_cmd[ds++] = 0x00;
	Send_SPI(ds); // Send data
	ds = 5;

	data = rx_cmd[7];
	data = data << 8;
	ds = rx_cmd[6];
	data = data + ds;
	if ((data & 0xE020) > 0)
	{
		Key_stp = 10;
		printf("STP  Key");
	}
	else
	{
		Key_stp = 1;
	}
	data = data & 0x1FDF; // Remove Step bit
	if ((rx_cmd[5] == 0x1B) && data > 0)
	{
		printf("Valid Key ");
	}
	printf("%.4X \n", data);

	if ((data & 0xE080) > 0)
	{
		printf("Menu UP");
	} // 0x1F7F  E080
	if ((data & 0xE100) > 0)
	{
		printf("Menu DN");
	} // 0x1EFF  E100
	if ((data & 0xE002) > 0)
	{
		printf("GAIN UP");
	} // 0x1FFD  E002
	if ((data & 0xE001) > 0)
	{
		printf("GAIN DN");
	} // 0x1FFE  E001
	if ((data & 0xE010) > 0)
	{
		printf("Pera UP");
	} // 0x1FEF  E010
	if ((data & 0xE004) > 0)
	{
		printf("Pera DN");
	} // 0x1FFB  E004
	if ((data & 0xE008) > 0)
	{
		printf("SLCT UP");
	} // 0x1FF7  E008
	if ((data & 0xE040) > 0)
	{
		printf("SLCT DN");
	} // 0x1FBF  E040
	if ((data & 0xE020) > 0)
	{
		printf("STP  Key CK");
	} // 0x1FDF  E020
}

//************************************************************************************
void Keypad_ck() // Read Keypad Data
{
	static int ifreez = 0;
	int ds = 0;
	int data = 0;
	tx_cmd[ds++] = 0x1B;
	tx_cmd[ds++] = 0x025;
	tx_cmd[ds++] = 0x0;
	tx_cmd[ds++] = 0x1B; // 1B 25 00  1B   // Key Pad data read
	tx_cmd[ds++] = 0x0;
	tx_cmd[ds++] = 0x0;
	tx_cmd[ds++] = 0x00;
	tx_cmd[ds++] = 0x0; // Dummy data to read from SPI
	tx_cmd[ds++] = 0x0;
	tx_cmd[ds++] = 0x0;
	tx_cmd[ds++] = 0x00;
	Send_SPI(ds); // Send data
	ds = 5;

	data = rx_cmd[7];
	data = data << 8;
	ds = rx_cmd[6];
	data = data + ds;
	if ((data & STP_Key_K) > 0)
	{
		Key_stp = 10;  // g_print("STP  Key\n");
		// if (!Pera_UP_K || !Pera_DN_K)
		{
			if (Key_press ==  false && opengl_update == true)
			{
				ifreez++;
				if (ifreez >= 10)
				{
					ifreez = 10;
					opengl_update = false;
					gtk_label_set_label(GTK_LABEL(space51), "FREEZ");
				}
			}
			else if (Key_press ==  false && opengl_update == false)
			{
				ifreez--;
				if (ifreez <= 0)
				{
					ifreez = 0;
					opengl_update = true;
					gtk_label_set_label(GTK_LABEL(space51), "     ");
				}
			}
		}
	}
	else
	{
		if (btnstep_val == 1)
		{
			Key_stp = 10;
		}
		else
		{
			Key_stp = 1;
		}
		//Key_stp = 1;
		//Key_stp = 10;
	}
	data = data & 0x1FDF; // Remove Step bit
	if ((rx_cmd[5] == 0x1B) && (rx_cmd[10] == 0x1B) && data > 0)
	{
		Key_Scn_code = data;
		////printf("Valid Key ");   //  printf("%.4X \n",data);
		//  if((data & Menu_UP_K)>0) {Key_perform_F(Menu_UP_K);}   // Menu UP Key {printf("Menu UP");}   // 0x1F7F  E080
		//  if((data & Menu_DN_K)>0)  {Key_perform_F(Menu_UP_K);}   //{printf("Menu DN");}   // 0x1EFF  E100
		//  if((data & GAIN_UP_K)>0)  {Key_perform_F(GAIN_UP_K);}   //{printf("GAIN UP");}   // 0x1FFD  E002
		//  if((data & GAIN_DN_K)>0)  {Key_perform_F(GAIN_DN_K);}   //{printf("GAIN DN");}   // 0x1FFE  E001
		//  if((data & Pera_UP_K)>0)  {Key_perform_F(Pera_UP_K);}   //{printf("Pera UP");}   // 0x1FEF  E010
		//  if((data & Pera_DN_K)>0)  {Key_perform_F(Pera_DN_K);}   //{printf("Pera DN");}   // 0x1FFB  E004
		//  if((data & SLCT_UP_K)>0)  {Key_perform_F(SLCT_UP_K);}   //{printf("SLCT UP");}   // 0x1FF7  E008
		//  if((data & SLCT_DN_K)>0)  {Key_perform_F(SLCT_DN_K);}   //{printf("SLCT DN");}   // 0x1FBF  E040
		//  if((data & 0xE020)>0)  {Key_perform_F(Menu_UP_K);}   //{printf("STP  Key CK");}  // 0x1FDF  E020
		Key_press = true;
	}
	else
	{
		Key_press = false;
		if ((rx_cmd[5] == 0x1B) && (rx_cmd[10] == 0x1B))
		{
		}
		else
		{
			if (Spi_open == true)
			{
				printf("KEY Error  \n");
			}
		}
	}
}

void Key_function()
{ 
	// Key_Scn_code=data;
	if (beep_val == 1)
	{
		Key_Beep();
	}
	if ((Key_Scn_code & Menu_UP_K) > 0)
	{
		Key_perform_F(Menu_UP_K);
	}  // Menu UP Key {printf("Menu UP");}   // 0x1F7F  E080
	if ((Key_Scn_code & Menu_DN_K) > 0)
	{
		Key_perform_F(Menu_DN_K);
	}  // 0x1EFF  E100
	if ((Key_Scn_code & GAIN_UP_K) > 0)
	{
		Key_perform_F(GAIN_UP_K);
	}  // 0x1FFD  E002
	if ((Key_Scn_code & GAIN_DN_K) > 0)
	{
		Key_perform_F(GAIN_DN_K);
	}  // 0x1FFE  E001
	if ((Key_Scn_code & Pera_UP_K) > 0)
	{
		Key_perform_F(Pera_UP_K);
	}  // 0x1FEF  E010
	if ((Key_Scn_code & Pera_DN_K) > 0)
	{
		Key_perform_F(Pera_DN_K);
	}  // 0x1FFB  E004
	if ((Key_Scn_code & SLCT_UP_K) > 0)
	{
		Key_perform_F(SLCT_UP_K);
	}  // 0x1FF7  E008
	if ((Key_Scn_code & SLCT_DN_K) > 0)
	{
		Key_perform_F(SLCT_DN_K);
	}  // 0x1FBF  E040
}

//************************************************************************************
void Read_rd() // Read Keypad Data
{
	int ds = 0;
	int data = 0;
	int bt1, bt2, bt3, amp;
	// double Val_f;

	Hruler_update();
	return;

	tx_cmd[ds++] = 0x1B;
	tx_cmd[ds++] = 0x041;
	tx_cmd[ds++] = 0x09;
	tx_cmd[ds++] = 0x1B; // 1B 41 09 1B  No of Sample Collection,  256,512,1K Selection
	tx_cmd[ds++] = 0x1B;
	tx_cmd[ds++] = 0x042;
	tx_cmd[ds++] = 0x00;
	tx_cmd[ds++] = 0x0; // 1B 42 00 1B
	tx_cmd[ds++] = 0x1B;
	tx_cmd[ds++] = 0x043;
	tx_cmd[ds++] = 0x20;
	tx_cmd[ds++] = 0x0; // 1B 43 xx 1B  xx= 0x20 256 data,  xx= 0x40 512 data,  xx= 0x80 1 K data,
	Send_SPI(ds); // Send data

	// Measure_f();      // Read Gate Cross Data
	return;

	// Max Amp
	tx_cmd[ds++] = 0x1B;
	tx_cmd[ds++] = 0x029;
	tx_cmd[ds++] = 0x0;
	tx_cmd[ds++] = 0x1B; // 1B29001B   Threshold Cross Value
	tx_cmd[ds++] = 0x0;
	tx_cmd[ds++] = 0x0;
	tx_cmd[ds++] = 0x00;
	tx_cmd[ds++] = 0x0; // Dummy data to read from SPI
	tx_cmd[ds++] = 0x0;
	tx_cmd[ds++] = 0x0;
	tx_cmd[ds++] = 0x00;
	tx_cmd[ds++] = 0x0; // Dummy data to read from SPI
	tx_cmd[ds++] = 0x0;
	tx_cmd[ds++] = 0x0;
	tx_cmd[ds++] = 0x00;
	tx_cmd[ds++] = 0x0; // Dummy data to read from SPI
	Send_SPI(ds);		// Send data

	ds = 5;
	
	bt1 = rx_cmd[6];
	bt2 = rx_cmd[7];
	bt3 = rx_cmd[8];
	bt1 = (bt3 * 256 * 256) + (bt2 * 256) + bt1;
	amp = rx_cmd[9];
	// Thick=(cnt*Vel) / 100000   xx.xxx MM
	Val_f = (bt1 * 5920) / 100000;
	sprintf(Dsp_Str, "%.2f*", Val_f);
	gtk_label_set_label(GTK_LABEL(label_dv[0]), Dsp_Str);

	sprintf(Dsp_Str, "%d", amp);
	gtk_label_set_label(GTK_LABEL(label_dv[1]), Dsp_Str);

}

void Hruler_update()
{
	horizontal_ruler();
}

void Vruler_update()
{
	vertical_ruler();
}

void Read_rd2()
{

}

//************************************************************************************
void Read_Peak_amp()
{
	int ds = 0;
	int data = 0;
	int bt1, bt2, bt3, amp;
	double Val_f;
	// Max Amp
	tx_cmd[ds++] = 0x1B;
	tx_cmd[ds++] = 0x022;
	tx_cmd[ds++] = 0x0;
	tx_cmd[ds++] = 0x1B; // 1B 22 00  1B   //  // Max Amp
	tx_cmd[ds++] = 0x0;
	tx_cmd[ds++] = 0x0;
	tx_cmd[ds++] = 0x00;
	tx_cmd[ds++] = 0x0; // Dummy data to read from SPI
	tx_cmd[ds++] = 0x0;
	tx_cmd[ds++] = 0x0;
	tx_cmd[ds++] = 0x00;
	tx_cmd[ds++] = 0x0; // Dummy data to read from SPI
	tx_cmd[ds++] = 0x0;
	tx_cmd[ds++] = 0x0;
	tx_cmd[ds++] = 0x00;
	tx_cmd[ds++] = 0x0; // Dummy data to read from SPI
	Send_SPI(ds);		// Send data

	// tx_cmd[ds++]=0x1B; tx_cmd[ds++]=0x021; tx_cmd[ds++]=0x0; tx_cmd[ds++]=0x1B;     // 1B 21 00  1B   //Key Pad data read
	// tx_cmd[ds++]=0x0; tx_cmd[ds++]=0x0; tx_cmd[ds++]=0x00; tx_cmd[ds++]=0x0;          // Dummy data to read from SPI
	// Send_SPI(ds);    // Send data
	ds = 5;
	bt1 = rx_cmd[6];
	bt2 = rx_cmd[7];
	bt3 = rx_cmd[8];
	bt1 = (bt3 * 256 * 256) + (bt2 * 256) + bt1;
	amp = rx_cmd[9];
	//printf("5=%.2X ,6=%.2X ,7=%.2X ,8=%.2X ,9=%.2X ,10=%.2X  Cross=%05d , Amp=%02d \n", rx_cmd[5], rx_cmd[6], rx_cmd[7], rx_cmd[8], rx_cmd[9], rx_cmd[10], bt1, amp);
	// Thick=(cnt*Vel)/100000   xx.xxx MM
	Val_f = bt1;
	Val_f = (Val_f * 5920) / 100000;
	sprintf(Dsp_Str, "%3.2f*", Val_f);
	gtk_label_set_label(GTK_LABEL(label_dv[0]), Dsp_Str);

	sprintf(Dsp_Str, "%d %%", amp);
	gtk_label_set_label(GTK_LABEL(label_dv[1]), Dsp_Str);
}

//************************************************************************************
void Thresold_Zero_Cross()
{
	int ds = 0;
	int data = 0;

	tx_cmd[ds++] = 0x1B;
	tx_cmd[ds++] = 0x26;
	tx_cmd[ds++] = 0x00;
	tx_cmd[ds++] = 0x1B; // 1B 26 00 1B   // Zero Crossing read Gate 1  Receive Gate 1 zero cross address value before threshold value.
	tx_cmd[ds++] = 0x0;
	tx_cmd[ds++] = 0x00;
	tx_cmd[ds++] = 0x00;
	tx_cmd[ds++] = 0x00; // Dummy data to read from SPI
	tx_cmd[ds++] = 0x0;
	tx_cmd[ds++] = 0x00;
	tx_cmd[ds++] = 0x00;
	tx_cmd[ds++] = 0x00; // Dummy data to read from SPI
	tx_cmd[ds++] = 0x0;
	tx_cmd[ds++] = 0x00;
	tx_cmd[ds++] = 0x00;
	tx_cmd[ds++] = 0x00; // Dummy data to read from SPI
	Send_SPI(ds);		 // Send data
	ds = 0;
	printf("%.2X ,%.2X ,%.2X ,%.2X \n", rx_cmd[ds++], rx_cmd[ds++], rx_cmd[ds++], rx_cmd[ds++]);

	// key_btn();
}
//************************************************************************************
void Peak_Zero_Cross()
{
	int ds = 0;
	int data = 0;

	tx_cmd[ds++] = 0x1B;
	tx_cmd[ds++] = 0x2d;
	tx_cmd[ds++] = 0x00;
	tx_cmd[ds++] = 0x1B; // 1B 2D 00 1B   // Command for receive Gate 1 zero cross point address value before max data.
	tx_cmd[ds++] = 0x0;
	tx_cmd[ds++] = 0x00;
	tx_cmd[ds++] = 0x00;
	tx_cmd[ds++] = 0x00; // Dummy data to read from SPI
	tx_cmd[ds++] = 0x0;
	tx_cmd[ds++] = 0x00;
	tx_cmd[ds++] = 0x00;
	tx_cmd[ds++] = 0x00; // Dummy data to read from SPI
	tx_cmd[ds++] = 0x0;
	tx_cmd[ds++] = 0x00;
	tx_cmd[ds++] = 0x00;
	tx_cmd[ds++] = 0x00; // Dummy data to read from SPI
	Send_SPI(ds);		 // Send data
	ds = 0;
	//printf("%.2X ,%.2X ,%.2X ,%.2X \n", rx_cmd[ds++], rx_cmd[ds++], rx_cmd[ds++], rx_cmd[ds++]);

	// key_btn();
}

//************************************************************************************
void Filter_Dly_Set() // Read Keypad Data
{
	int ds = 0;
	int data = 0;
	tx_cmd[ds++] = 0x1B;
	tx_cmd[ds++] = 0x041;
	tx_cmd[ds++] = 0x13;
	tx_cmd[ds++] = 0x1B; // 1B 41 13  1B   // To Set Delay for Filter Start   Filter and ADC starts earlier then ADC Sample storage to stabilise Band Pass Filter responce
	tx_cmd[ds++] = 0x1B;
	tx_cmd[ds++] = 0x042;
	tx_cmd[ds++] = 0x00;
	tx_cmd[ds++] = 0x1B;
	tx_cmd[ds++] = 0x1B;
	tx_cmd[ds++] = 0x043;
	tx_cmd[ds++] = 0x80;
	tx_cmd[ds++] = 0x1B;
	tx_cmd[ds++] = 0x1B;
	tx_cmd[ds++] = 0x043;
	tx_cmd[ds++] = 0x00;
	tx_cmd[ds++] = 0x1B;
	// tx_cmd[ds++]=0x0; tx_cmd[ds++]=0x0; tx_cmd[ds++]=0x00; tx_cmd[ds++]=0x0;          // Dummy data to read from SPI
	Send_SPI(ds); // Send data
	ds = 0;
	printf("%.2X ,%.2X ,%.2X ,%.2X \n", rx_cmd[ds++], rx_cmd[ds++], rx_cmd[ds++], rx_cmd[ds++]);

	// key_btn();
}

//************************************************************************************
void Read_rd2_safe() // Read Keypad Data
{
	int ds = 0;
	int data = 0;

	tx_cmd[ds++] = 0x1B;
	tx_cmd[ds++] = 0x085;
	tx_cmd[ds++] = 0x50;
	tx_cmd[ds++] = 0x1B; // 1B 21 00  1B   //Key Pad data read

	// tx_cmd[ds++]=0x0; tx_cmd[ds++]=0x0; tx_cmd[ds++]=0x00; tx_cmd[ds++]=0x0;          // Dummy data to read from SPI
	Send_SPI(ds); // Send data
	ds = 0;

	// key_btn();
}

/************************************************************************************/
/**************************KEYPAD BUTTON CONNECTING FUNCTION*************************/
/************************************************************************************/
void key_btn()
{
	key_scr = 1;
	Set_btn_focus(); // Set Button/Controll Focus / Appropriate Color to indicate Selected
	btn_flag = false;
}

//***********************************************************************************************
void Set_btn_focus() // Set Button / Controll Focus / Appropriate Color to indicate Selected
{
	int btn_pos;
	int Submnu;
	char buffer[16];

	if (menu_v < 16) // if(Dgs_sub_mnu == 0)
	{
		for (i = 1; i < 10; i = i + 2)
		{
			gtk_widget_set_name(btn_dv[i], "btnv1-entry");
		} // De Slect All Menu Buttons

		if (btn_idx > 4)
		{
			btn_idx = 4;
		} // Set Focus to Appropriate Button
		btn_pos = (btn_idx * 2) + 1;

		gtk_widget_set_can_focus(GTK_WIDGET(btn_dv[btn_pos]), true);
		gtk_widget_grab_focus(GTK_WIDGET(btn_dv[btn_pos]));
		gtk_widget_set_name(btn_dv[btn_pos], "btnv1_1-entry");
	}
	if (menu_v > 16) // If Sub Menu is active/Display
	{
		if (menu_v > 16 && menu_v < 20) // DGS MENU
		{
			Submnu = menu_v - 17;
		}
		if (menu_v > 19 && menu_v < 23) // WELD PROF MENU
		{
			Submnu = menu_v - 20;
		}
		if (menu_v > 22 && menu_v < 26)
		{
			Submnu = menu_v - 23;
		}
		if (menu_v > 25 && menu_v < 29)
		{
			Submnu = menu_v - 26;
		}
		if (menu_v > 28 && menu_v < 32)
		{
			Submnu = menu_v - 29;
		}
		if (menu_v > 31 && menu_v < 35)
		{
			Submnu = menu_v - 32;
		}

		for (i = 1; i < 24; i = i + 2)
		{
			gtk_widget_set_name(dgs_btn[i], "btnv1-entry");
			gtk_widget_set_can_focus(GTK_WIDGET(dgs_btn[i]), true);
			gtk_widget_grab_focus(GTK_WIDGET(dgs_btn[i]));
		} // DeSlect All DGS Frame Buttons Buttons
		for (i = 1; i < 10; i = i + 2)
		{
			gtk_widget_set_name(btn_dv[i], "btnv1-entry");
		} // De Slect All Menu Buttons

		if (btn_idx > 3)
		{
			btn_idx = 3;
		}
		btn_pos = (btn_idx * 2) + (Submnu * 8) + 1;

		gtk_widget_set_can_focus(GTK_WIDGET(dgs_btn[btn_pos]), true);
		gtk_widget_grab_focus(GTK_WIDGET(dgs_btn[btn_pos]));

		gtk_widget_set_name(dgs_btn[btn_pos], "btnv1_1-entry");

		if (frame_type_num == 4)
		{
			sprintf(buffer, "color%03d", val_ary[COLOR_1_PERA]);
			gtk_widget_set_name(dgs_btn[19], buffer);
			sprintf(buffer, "color%03d", val_ary[COLOR_2_PERA]);
			gtk_widget_set_name(dgs_btn[21], buffer);
			sprintf(buffer, "color%03d", val_ary[COLOR_3_PERA]);
			gtk_widget_set_name(dgs_btn[23], buffer);
		}
	}
}

//************************************************************************************************

void OntString(int k_tnt)  // PRINT CHARACTERS IN NOTE DETAIL 
{
	if (chr_pos < 0)
	{
		chr_pos = 39;
	}
	if (chr_pos > 39)
	{
		chr_pos = 0;
	} // GO TO THE NEXT TEXT BOX THROUGH CURSOR MOVEMENT
	if (chr_pos > 40)
	{
		chr_pos = 0;
	} // GO TO THE NEXT TEXT BOX THROUGH CURSOR MOVEMENT

	/*ASCII CODES USED
		--SPACE  : 32
		--NUMBERS 0 to 9 : 48 to 57
		--CHARACTERS A to Z : 65 to 90*/

	ary_idx = (ln_no * 40) + chr_pos;
	as_c = Note_data[ary_idx];

	as_c = as_c + k_tnt;

	/*if (as_c < 1) { as_c = 1; }
	if (as_c > 127) { as_c = 127; }*/

	if (as_c < 32)
	{
		as_c = 90;
	}				// IF ASCII VALUE LESS THAN SPACE CHARACTER THEN GO TO Z CHAR

	if (as_c > 90)
	{
		as_c = 32;
	} // IF ASCII VALUE GREATER THAN Z THEN GO TO SPACE CHAR

	Note_data[ary_idx] = as_c;
	i = ln_no * 40;
	for (k = 0; k < 40; k++)
	{
		stringbox[k] = Note_data[i++];
	}

	gchar *ret = g_locale_to_utf8(stringbox, 40, NULL, NULL, NULL); // CONVERT TO UTF8 STRING
	gtk_entry_set_text(GTK_ENTRY(text_h[ln_no]), ret);

	for (j = 0; j <= temp_count; j++) // for (j = 0; j < 10; j++) // for (j = 0; j < temp_count; j++) // temp_count = 9;
	{
		gtk_editable_set_position(GTK_EDITABLE(text_h[j]), chr_pos);
		gtk_entry_grab_focus_without_selecting(GTK_ENTRY(text_h[j]));
		gtk_widget_set_can_focus(GTK_WIDGET(text_h[j]), false);
	}
}

static gboolean on_draw_event(GtkWidget *widget, cairo_t *cr, gpointer user_data)
{
	do_drawing(cr);
	return false;
}

static void do_drawing(cairo_t *cr)
{
	cairo_set_source_rgb(cr, 0.1, 0, 0);

	cairo_move_to(cr, 1, 1);
	cairo_line_to(cr, 1023, 1);

	cairo_set_line_width(cr, 10);
	cairo_stroke(cr);
}

/*************************************************************/
/***************** CREATE COLOR GRADIENT PART ****************/
void create_color_gradient_data(void)
{
	int i, j;
	int c_red = 255, c_green = 255, c_blue = 255;

	j = 0;
	for (i = 1; i < 30; i++) // 0 to 30
	{
		c_red = c_red - 8.5f;
		c_red = (gint)c_red;
		if (c_red > 255)
			c_red = 255;
		else if (c_red < 0)
			c_red = 0;

		c_green = c_green - 8.5f;
		c_green = (gint)c_green;
		if (c_green > 255)
			c_green = 255;
		else if (c_green < 0)
			c_green = 0;

		clr_rgb[j].r = c_red;
		clr_rgb[j].g = c_green;
		clr_rgb[j].b = c_blue;

		color_gradient_arr[j++] = (c_blue << 16) + (c_green << 8) + (c_red);
	}
	for (i = 30; i < 38; i++) // 30 to 38
	{
		c_green = c_green + 31.8f;
		c_green = (gint)c_green;
		if (c_green > 255)
			c_green = 255;
		else if (c_green < 0)
			c_green = 0;

		clr_rgb[j].r = c_red;
		clr_rgb[j].g = c_green;
		clr_rgb[j].b = c_blue;

		color_gradient_arr[j++] = (c_blue << 16) + (c_green << 8) + (c_red);
	}
	for (i = 38; i < 46; i++) // 38 to 46
	{
		c_blue = c_blue - 31.8f;
		c_blue = (gint)c_blue;
		if (c_blue > 255)
			c_blue = 255;
		else if (c_blue < 0)
			c_blue = 0;

		clr_rgb[j].r = c_red;
		clr_rgb[j].g = c_green;
		clr_rgb[j].b = c_blue;

		color_gradient_arr[j++] = (c_blue << 16) + (c_green << 8) + (c_red);
	}
	for (i = 46; i < 70; i++) // 46 to 70
	{
		c_red = c_red + 10.6f;
		c_red = (gint)c_red;
		if (c_red > 255)
			c_red = 255;
		else if (c_red < 0)
			c_red = 0;

		clr_rgb[j].r = c_red;
		clr_rgb[j].g = c_green;
		clr_rgb[j].b = c_blue;

		color_gradient_arr[j++] = (c_blue << 16) + (c_green << 8) + (c_red);
	}
	for (i = 70; i < 100; i++) // 70 to 100
	{
		c_green = c_green - 8.5f;
		c_green = (gint)c_green;
		if (c_green > 255)
			c_green = 255;
		else if (c_green < 0)
			c_green = 0;

		clr_rgb[j].r = c_red;
		clr_rgb[j].g = c_green;
		clr_rgb[j].b = c_blue;

		color_gradient_arr[j++] = (c_blue << 16) + (c_green << 8) + (c_red);
	}
	for (i = 100; i < 104; i++) // 100 to 104
	{
		c_green = c_green - 8.5f;
		c_green = (gint)c_green;
		if (c_green > 255)
			c_green = 255;
		else if (c_green < 0)
			c_green = 0;

		clr_rgb[j].r = c_red;
		clr_rgb[j].g = c_green;
		clr_rgb[j].b = c_blue;

		color_gradient_arr[j++] = (c_blue << 16) + (c_green << 8) + (c_red);
	}
	for (i = 104; i < 120; i++)
	{
		clr_rgb[j].r = 255;
		clr_rgb[j].g = 255;
		clr_rgb[j].b = 255;
		color_gradient_arr[j++] = 255;
	}
}

/*************************************************************/
/***************** CREATE COLOR GRADIENT PART ****************/
void create_color_gradient_tfd_data(void)
{
	int i, cdat;

	for (i = 0; i < 100; i++) // 0 to 30
	{
		cdat = (i * 255) / 100;
		color_gradient_tfd_arr[i] = (cdat << 16) + (cdat << 8) + (cdat);
		// g_print("%d = %d : %d, %d, %d\n", i, color_gradient_tfd_arr[i] , (cdat << 16), (cdat << 8), (cdat));
	}
}

/*************************************************************/
/************ MAIN WINDOW WIDGETS ARRANGEMENT PART************/
/************************************************************/
int main(int argc, char **argv)
{
	void clean_up(void);

	GtkApplication *app;
	gint status;
	
	app = gtk_application_new("org.gtk.myVisulizationApplication", G_APPLICATION_FLAGS_NONE);
	g_signal_connect(app, "activate", G_CALLBACK(activate), NULL);
	status = g_application_run(G_APPLICATION(app), argc, argv);

	ogl_uninitialization(signal_id);
	clean_up();
	g_object_unref(app);
	return status;
}

void Close_StScreen()
{
	g_source_remove(st_scrn_time_id);
	st_scrn_time_id = 0;
	gtk_widget_destroy(GTK_WIDGET(window_home));
	Init_all(); // Init/Start Main Application

	//Set_default_val(); // During Power Up set values of all perameters to default value
	
	//path_h = "Pwr1off.set";
	//if(access(path_h, F_OK) != -1) // During Power Up Read values of all perameters
	//{
	//	pwron_readvalues();
	//}
	//else
	{
		Refresh_Allpera_val_f(); // Refresh all peravalue by calling each function. It is used when Data recall from Memoery
	}
	Menu_f(0);
	menu_v = 0;
	printf("App Started \n\n");
}

//**************************************************************************************************
void activate(GtkApplication *app, gpointer user_data)
{
	// Set s/w clock time from h/w clock
	// system("hwclock -s");

	int fixSzie = 0;
	window = gtk_application_window_new(app);
	if (fixSzie == 1)
	{
    	gtk_window_set_default_size(GTK_WINDOW(window), 1024, 600); // Set window size
	}
	else
	{
		gtk_window_set_default_size(GTK_WINDOW(window), -1, -1);
		gtk_window_fullscreen(GTK_WINDOW(window));
		gtk_window_set_decorated(GTK_WINDOW(window), false); // Set false to remove topmost taskbar
	}

	/*******************OPENGL WINDOW DISPLAY**************************/
	/******************************************************************/
		
	gtk_widget_realize(window);
	gdk_window = gtk_widget_get_window(GTK_WIDGET(window));
	if (!GDK_IS_WAYLAND_WINDOW(gdk_window))
		printf("Can't GDK_IS_WAYLAND_WINDOW.\n");

	gdk_display = gdk_window_get_display(gdk_window);

	cssProvider = gtk_css_provider_new();
	css_clr_grd_Provider = gtk_css_provider_new();
	gtk_css_provider_load_from_path(GTK_CSS_PROVIDER(css_clr_grd_Provider), "color_grd_css.css", NULL);
	gtk_style_context_add_provider_for_screen(gdk_screen_get_default(), GTK_STYLE_PROVIDER(css_clr_grd_Provider), GTK_STYLE_PROVIDER_PRIORITY_USER);

	create_color_gradient_data();	  // Color Gradient For Color Coding
	create_color_gradient_tfd_data(); // Color Gradient For TOFD

	Set_default_val(); // During Power Up set values of all perameters to default value

	///*****SET VALUE THE DRAW FOR DRAWING OBJECTS, PROFILER AND RAYS ******/
	///*********************************************************************/
	//// Shape values initialize
	init_shape_value();

	//// Profiler values initialize
	initialize_profiler_data();
	init_profiler_value();
	copy_profiler_data();

	// Rays values initialize
	initialize_ray_data();
	init_rays_value();
	copy_rays_data();

	init_bsc_data();
	set_zero_data();

	bsc_height = (height_sh / 2) - (h_ruler_height);
	splite_frame_height = frame_height;

	pwron_readvalues();

	/*********SET VALUE OF THE REFERENCE FOR GAIN VALUE************/
	/**************************************************************/

	// gain_ref = val_ary[9];

	// sprintf(gstr_1, "%d", gain_ref);
	// sprintf(gstr_2, "%s", "\n  REF  ");

	// if (gain_ref > 0 && gain_ref < 100)
	// {
	// 	gstr_3[0] = gstr_1[0];
	// 	gstr_3[1] = dot[0];
	// 	gstr_3[2] = gstr_1[1];
	// }
	// if (gain_ref >= 100 && gain_ref < 1000)
	// {
	// 	gstr_3[0] = gstr_1[0];
	// 	gstr_3[1] = gstr_1[1];
	// 	gstr_3[2] = dot[0];
	// 	gstr_3[3] = gstr_1[2];
	// }
	// strcat(gstr_2, gstr_3);

	/****************************/
	/*CREATING MAIN VERTICAL BOX*/
	/****************************/
	avbox = gtk_box_new(GTK_ORIENTATION_VERTICAL, 0);

	/***********************************************/
	/*CREATING HORIZONTAL FIRST BOX FOR NOTIFICATION IMAGES*/
	/***********************************************/
	ahbox1 = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
	gtk_box_pack_start(GTK_BOX(avbox), ahbox1, false, false, 0);
	space51 = gtk_label_new("       ");
	gtk_widget_set_name(space51, "space51-label");
	gtk_widget_set_size_request(space51, 540, 40); // 550
	gtk_box_pack_start(GTK_BOX(ahbox1), space51, false, false, 0);

	/******************************************************************************/
	/***************SET FIRST LAYER OF NOTIFICATION IMG****************************/

	v2box = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
	/*gtk_box_pack_start(GTK_BOX(ahbox1), v2box, false, false, 0);*/

	int img_wt = image_w;
	// IMAGE OF DUAL, SINGLE, DAC, DGS, AWS ,REJECT, BATTERY etc. shown in frame over here
	for (i = 0; i < 7; i++) // for (i = 0; i < 6; i++)
	{
		if (i == 6)
		{
			img_wt = img_wt + 20;
		}
		nframe[i] = gtk_frame_new(NULL);
		gtk_frame_set_shadow_type(GTK_FRAME(nframe[i]), GTK_SHADOW_NONE); // GTK_SHADOW_IN);  //img_wtbat
		gtk_widget_set_size_request(nframe[i], img_wt, image_h);
		//n_pximage[i] = gdk_pixbuf_new_from_file_at_scale(imagename[i], img_wt, image_h, false, NULL);
		n_image[i] = gtk_image_new_from_pixbuf(n_pximage[i]);
		gtk_widget_set_size_request(GTK_WIDGET(n_image[i]), img_wt, image_h);
		gtk_container_add(GTK_CONTAINER(nframe[i]), n_image[i]);
		gtk_box_pack_start(GTK_BOX(v2box), nframe[i], false, false, 0);
	}

	Batt_Perc = gtk_label_new("     "); //Clock_lab = gtk_label_new("11:36 Dt:05/02/2023");
	//gtk_widget_set_name(Batt_Perc, "BattPer-entry");
	gtk_widget_set_halign(GTK_WIDGET(Batt_Perc), GTK_ALIGN_START);
	gtk_label_set_max_width_chars(GTK_LABEL(Batt_Perc), 25);
	gtk_label_set_ellipsize(GTK_LABEL(Batt_Perc), PANGO_ELLIPSIZE_END);
	gtk_container_add(GTK_CONTAINER(v2box), Batt_Perc);

	/*****************************************************************************************/
	/************************LAYER OF BSCAN PAUSE AND PLAY AND USB IMG************************/
	/*****************************************************************************************/

	nframe[8] = gtk_frame_new(NULL);
	gtk_frame_set_shadow_type(GTK_FRAME(nframe[8]), GTK_SHADOW_NONE); // GTK_SHADOW_IN);
	gtk_widget_set_size_request(nframe[8], image_clk, image_h);
	Pause_lab = gtk_label_new("     ");
	gtk_widget_set_halign(GTK_WIDGET(Pause_lab), GTK_ALIGN_START);
	gtk_label_set_max_width_chars(GTK_LABEL(Pause_lab), 25);
	gtk_label_set_ellipsize(GTK_LABEL(Pause_lab), PANGO_ELLIPSIZE_END);
	gtk_widget_set_name(Pause_lab, "Pause-entry");
	gtk_container_add(GTK_CONTAINER(nframe[8]), Pause_lab);
	gtk_box_pack_start(GTK_BOX(ahbox1), nframe[8], false, false, 0); // PAUSE OR PLAY FOR BSCAN RECORD

	n_sdcrdfrm = gtk_frame_new(NULL);
	gtk_frame_set_shadow_type(GTK_FRAME(n_sdcrdfrm), GTK_SHADOW_NONE); // GTK_SHADOW_IN);
	gtk_widget_set_size_request(n_sdcrdfrm, image_w, 35); // SD_Card.PNG

	n_pximage[11] = gdk_pixbuf_new_from_file_at_scale("Images/Images/sd.png", image_w, 35, false, NULL);
	n_image[11] = gtk_image_new_from_pixbuf(n_pximage[11]);
	gtk_widget_set_size_request(GTK_WIDGET(n_image[11]), image_w, 35);
	gtk_container_add(GTK_CONTAINER(n_sdcrdfrm), n_image[11]);

	nframe[9] = gtk_frame_new(NULL);
	gtk_frame_set_shadow_type(GTK_FRAME(nframe[9]), GTK_SHADOW_NONE); // GTK_SHADOW_IN);
	gtk_widget_set_size_request(nframe[9], image_w + 18, 24);

	n_pximage[8] = gdk_pixbuf_new_from_file_at_scale("Images/Images/usb_size_1.png", image_w + 15, 22, false, NULL);
	n_image[8] = gtk_image_new_from_pixbuf(n_pximage[8]);
	gtk_widget_set_size_request(GTK_WIDGET(n_image[8]), image_w + 15, 22);
	gtk_container_add(GTK_CONTAINER(nframe[9]), n_image[8]);

	gtk_box_pack_start(GTK_BOX(ahbox1), n_sdcrdfrm, false, false, 5);
	gtk_box_pack_start(GTK_BOX(ahbox1), nframe[9], false, false, 5); // USB attached logo
	gtk_box_pack_start(GTK_BOX(ahbox1), v2box, false, false, 0); // Notification Images and Battery Image

	/**********************************************************/
	/****CREATING HORIZONTAL BOX FOR FRAME AND DATA BUTTONS****/
	/**********************************************************/
	ahbox3 = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
	gtk_box_pack_start(GTK_BOX(avbox), ahbox3, false, false, 1);

	/*CREATE THE FRAME FOR DRAWING AREA*/
	frame = gtk_frame_new(NULL);
	overlay = gtk_overlay_new();
	//gtk_frame_set_shadow_type(GTK_FRAME(frame), GTK_SHADOW_IN);
	gtk_widget_set_size_request(frame, frame_width, frame_height);

	/**********************************************************/
	/***********************OPENGL PART************************/
	/**********************************************************/

	egl_wayland_initialization(gdk_window, frame_width, frame_height);
	ogl_render(frame_width, frame_height);

	/**********************************************************/
	/*********************SPLIT WINDOW PART********************/
	/**********************************************************/

	frame_s1 = gtk_frame_new(NULL);
	gtk_widget_set_size_request(frame_s1, width_sh, (height_sh / 2));

	// Bscan
	dest_pixbuf = gdk_pixbuf_new(GDK_COLORSPACE_RGB, false, 8, width_sh, bsc_height);
	gdk_pixbuf_fill(dest_pixbuf, 0x000000FF);
	plot_bscan_data = gtk_image_new_from_pixbuf(dest_pixbuf);

	bscan_data_grid = gtk_event_box_new();
    gtk_widget_set_size_request(bscan_data_grid, width_sh, bsc_height);
	gtk_container_add(GTK_CONTAINER(bscan_data_grid), plot_bscan_data);

	// register callback function to os for get mouse co-ordinates
	g_signal_connect(bscan_data_grid, "motion-notify-event", G_CALLBACK(get_mouse_coordinates), NULL); // Get Mouse position X,Y
	gtk_widget_set_events(bscan_data_grid, GDK_POINTER_MOTION_MASK);

	src_pixbuf = gdk_pixbuf_new(GDK_COLORSPACE_RGB, false, 8, width_sh * 2, bsc_height);
	gdk_pixbuf_fill(src_pixbuf, 0x000000FF);

	pixbuf_base_address = gdk_pixbuf_get_pixels(dest_pixbuf);
	rgb_count = gdk_pixbuf_get_n_channels(dest_pixbuf);
	rowstride = gdk_pixbuf_get_rowstride(dest_pixbuf);

	// Bscan rular
	surface_rular = cairo_image_surface_create(CAIRO_FORMAT_RGB24, width_sh, h_ruler_height);
	cr_rular = cairo_create(surface_rular);
	surface_rular_image = gtk_image_new_from_surface(surface_rular);
	surface_rular_update();

	frm_box = gtk_box_new(GTK_ORIENTATION_VERTICAL, 0);
	gtk_box_pack_start(GTK_BOX(frm_box), bscan_data_grid, false, false, 0);
	gtk_box_pack_start(GTK_BOX(frm_box), surface_rular_image, false, false, 0);
	gtk_container_add(GTK_CONTAINER(frame_s1), frm_box);

	frame_s2 = gtk_frame_new(NULL);
	gtk_widget_set_size_request(frame_s2, width_sh, (height_sh / 2));

	surface_clr = cairo_image_surface_create(CAIRO_FORMAT_RGB24, width_sh, (height_sh / 2));
	cr_clr = cairo_create(surface_clr);
	surface_clr_image = gtk_image_new_from_surface(surface_clr);
	draw_thick_log();

	gtk_container_add(GTK_CONTAINER(frame_s2), surface_clr_image);

	splite_box_1 = gtk_box_new(GTK_ORIENTATION_VERTICAL, 0);
	splite_box_2 = gtk_box_new(GTK_ORIENTATION_VERTICAL, 0);
	gtk_box_pack_start(GTK_BOX(splite_box_1), frame_s1, false, false, 0);
	gtk_box_pack_start(GTK_BOX(splite_box_2), frame_s2, false, false, 0);

	/****************************************************************/
	/***************CREATE THE DATA BTN AREA*************************/
	/****************************************************************/

	f2_box = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);

	Main_lyout = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);

	/*Develop button and give the size of the button*/
	for (i = 0; i < 24; i++)
	{
		dgs_btn[i] = gtk_button_new();
		gtk_widget_set_size_request(dgs_btn[i], btn_width, btn_height);
	}

	V1_lyout = gtk_box_new(GTK_ORIENTATION_VERTICAL, 0);
	gtk_box_pack_start(GTK_BOX(Main_lyout), V1_lyout, false, false, 1);

	for (i = 0, j = 180; i < 8, j < 188; i++, j++)
	{
		gtk_box_pack_start(GTK_BOX(V1_lyout), dgs_btn[i], false, false, 0);
		dgslabel[i] = gtk_label_new(all_btnval[j]);
		gtk_container_add(GTK_CONTAINER(dgs_btn[i]), dgslabel[i]);
		gtk_widget_set_name(dgs_btn[i], btndv_css[i]);
	}

	V2_lyout = gtk_box_new(GTK_ORIENTATION_VERTICAL, 0);
	gtk_box_pack_start(GTK_BOX(Main_lyout), V2_lyout, false, false, 1);

	for (i = 8, j = 190, k = 0; i < 16; i++, j++, k++) //for (i = 8, j = 190, k = 0; i < 16, j < 198, k < 8; i++, j++, k++)
	{
		gtk_box_pack_start(GTK_BOX(V2_lyout), dgs_btn[i], false, false, 0);
		dgslabel[i] = gtk_label_new(all_btnval[j]);
		gtk_container_add(GTK_CONTAINER(dgs_btn[i]), dgslabel[i]);
		gtk_widget_set_name(dgs_btn[i], btndv_css[k]);
	}

	V3_lyout = gtk_box_new(GTK_ORIENTATION_VERTICAL, 0);
	gtk_box_pack_start(GTK_BOX(Main_lyout), V3_lyout, false, false, 1);

	for (i = 16, j = 202, k = 0; i < 24; i++, j++, k++) // for (i = 17, j = 202, k = 0; i < 24, j < 208, k < 8; i++, j++, k++)
	{
		gtk_box_pack_start(GTK_BOX(V3_lyout), dgs_btn[i], false, false, 0);
		dgslabel[i] = gtk_label_new(all_btnval[j]);
		gtk_container_add(GTK_CONTAINER(dgs_btn[i]), dgslabel[i]);
		gtk_widget_set_name(dgs_btn[i], btndv_css[k]);
	}

	for (k = 0; k < 16; k = k + 2)
	{
		gtk_widget_set_halign(GTK_WIDGET(dgslabel[k]), GTK_ALIGN_START);
	}

	for (i = 16; i < 24; i = i + 2)
	{
		gtk_widget_set_halign(GTK_WIDGET(dgslabel[i]), GTK_ALIGN_START);
	}

	prof_box = gtk_box_new(GTK_ORIENTATION_VERTICAL, 0);
	shape_profiler_rays_surface = cairo_image_surface_create(CAIRO_FORMAT_RGB24, profiler_drawing_area_width, profiler_drawing_area_height);
	shape_profiler_rays_cr = cairo_create(shape_profiler_rays_surface);
	shape_profiler_rays_image = gtk_image_new_from_surface(shape_profiler_rays_surface);
	gtk_box_pack_start(GTK_BOX(prof_box), shape_profiler_rays_image, false, false, 0);
	draw_function();

	gtk_box_pack_start(GTK_BOX(f2_box), prof_box, false, false, 0);	  //
	gtk_box_pack_start(GTK_BOX(f2_box), Main_lyout, false, false, 0); // DGS , WELD PROF BOXES 

	// gtk_box_pack_start(GTK_BOX(f2_box), Main_lyout, false, false, 325);  // Set Left postion of DGS Selection

	/**************************************************************************/
	/**********************NOTE TEXTBOX AREA CREATED***************************/
	/**************************************************************************/
	f3_box = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);

	ft_h = fopen("Note4.txt", "r");

	for (i = 0; i < 10; i++)
	{
		fgets(line[i], sizeof(line[i]), ft_h);
	}

	fclose(ft_h);

	///////////////////////////////////////////////////////////////

	txtbox = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 1);

	txtbox1 = gtk_box_new(GTK_ORIENTATION_VERTICAL, 0);
	gtk_box_pack_start(GTK_BOX(txtbox), txtbox1, false, false, 0);

	txtbox2 = gtk_box_new(GTK_ORIENTATION_VERTICAL, 0);
	gtk_box_pack_start(GTK_BOX(txtbox), txtbox2, false, false, 0);

	/**********************************/
	/**CREATE READ ONLY TEXT ENTRIES**/

	for (i = 5; i < 10; i++) // for (i = 14; i < 28; i++)
	{
		// FOR TEXT HEADING LABELS
		text_h[i] = gtk_entry_new();
		gtk_widget_set_size_request(text_h[i], texthd_width, 0);
		gtk_box_pack_start(GTK_BOX(txtbox1), text_h[i], false, false, 1);
	}

	for (i = 0; i < 5; i++) // for (i = 0; i < 14; i++)
	{
		// FOR TEXT DATA VALUES
		text_h[i] = gtk_entry_new();
		gtk_widget_set_size_request(text_h[i], txtdata_width, 0);

		gtk_widget_set_can_focus(GTK_WIDGET(text_h[i]), false);
		gtk_box_pack_start(GTK_BOX(txtbox2), text_h[i], false, false, 1);
		gtk_widget_add_events(text_h[i], GDK_KEY_PRESS_MASK);
		gtk_widget_set_name(text_h[i], "text-entry");
	}

	/////////////////READ HEADINGS TEXT FROM FILE/////////////////////

	for (i = 0; i < 5; i++) // for (i = 0; i < 14; i++)
	{
		gtk_entry_set_text(GTK_ENTRY(text_h[count]), heading_name[i]); // Display Heading of Note Data
		j = i * 40;
		for (k = 0; k < 40; k++)
		{
			stringbox[k] = Note_data[j++];
		}
		gchar *ret = g_locale_to_utf8(stringbox, 40, NULL, NULL, NULL); // CONVERT TO UTF8 STRING
		gtk_entry_set_text(GTK_ENTRY(text_h[temp_count]), ret);	// Display Data of Note Data //gtk_entry_set_text(GTK_ENTRY(text_h[ln_no]), ret); // gchar* ret =o_name[i];

		count = count + 1;	// TO COUNT THE NUMBER OF LINES FOR HEADING
		temp_count = temp_count + 1; // COUNT NUMBER OF DATA LINES
		imgline_count = imgline_count + 20;
		imgh_line1 = imgh_line1 + 20;
		if (temp_count > 4)
		{
			temp_count = 4;
		} // if (temp_count > 13) { temp_count = 14; }
	}

	for (i = 5; i < 10; i++)
	{
		gtk_widget_set_halign(GTK_WIDGET(text_h[i]), GTK_ALIGN_START);
		gtk_widget_set_name(text_h[i], "labeltext-entry");
	}

	gtk_box_pack_start(GTK_BOX(f3_box), txtbox, false, false, 5);

	/************************************************************/
	/***********OVERLAY FOR MULTIPLE BOXES DISPLAY **************/

	gtk_overlay_add_overlay(GTK_OVERLAY(overlay), splite_box_1);
	gtk_overlay_add_overlay(GTK_OVERLAY(overlay), splite_box_2);
	gtk_overlay_add_overlay(GTK_OVERLAY(overlay), f2_box); // f2_box for DGS selection
	gtk_overlay_add_overlay(GTK_OVERLAY(overlay), f3_box); // f3 Box for Note Data

	/**************************************************************/
	/**************************************************************/
	gtk_container_add(GTK_CONTAINER(frame), overlay);

	v_ruler_surface = cairo_image_surface_create(CAIRO_FORMAT_RGB24, ruler_Height_width, frame_height);
	v_ruler_cr = cairo_create(v_ruler_surface);
	v_ruler_img = gtk_image_new_from_surface(v_ruler_surface);
	vertical_ruler();

	h_ruler_surface = cairo_image_surface_create(CAIRO_FORMAT_RGB24, frame_width + ruler_Height_width + 1, ruler_Height_width);
	h_ruler_cr = cairo_create(h_ruler_surface);
	h_ruler_img = gtk_image_new_from_surface(h_ruler_surface);
	horizontal_ruler();

	h_box = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
	gtk_container_add(GTK_CONTAINER(h_box), v_ruler_img);
	gtk_container_add(GTK_CONTAINER(h_box), frame);

	v_box = gtk_box_new(GTK_ORIENTATION_VERTICAL, 0);
	gtk_container_add(GTK_CONTAINER(v_box), h_box);
	gtk_container_add(GTK_CONTAINER(v_box), h_ruler_img);

	gtk_box_pack_start(GTK_BOX(ahbox3), v_box, false, false, 1); // gtk_box_pack_start(GTK_BOX(ahbox3), frame, false, false, 1);

	/***************************************************************************************************/
	/*************************SET THE LEFT KEYS AROUND DATA BTNS****************************************/
	/***************************************************************************************************/
	int iwd = 20;
	lfbox = gtk_box_new(GTK_ORIENTATION_VERTICAL, 0);
	gtk_box_pack_start(GTK_BOX(ahbox3), lfbox, false, false, 1);

	GtkWidget* space1 = gtk_label_new("");
	gtk_widget_set_size_request(space1, 0, databtn_hght);
	gtk_box_pack_start(GTK_BOX(lfbox), space1, false, false, 0);

	btn_dv[20] = gtk_button_new();
	label_dv[10] = gtk_label_new("◄");
	gtk_container_add(GTK_CONTAINER(btn_dv[20]), label_dv[10]);
	gtk_box_pack_start(GTK_BOX(lfbox), btn_dv[20], false, false, 0);
	gtk_widget_set_size_request(btn_dv[20], iwd, databtn_hght);
	gtk_widget_set_name(btn_dv[20], btndv_css[8]);

	GtkWidget* space2 = gtk_label_new("");
	gtk_widget_set_size_request(space2, 0, databtn_hght);
	gtk_box_pack_start(GTK_BOX(lfbox), space2, false, false, 0);

	btn_dv[11] = gtk_button_new();
	label_dv[11] = gtk_label_new("◄");
	gtk_container_add(GTK_CONTAINER(btn_dv[11]), label_dv[11]);
	gtk_box_pack_start(GTK_BOX(lfbox), btn_dv[11], false, false, 0);
	gtk_widget_set_size_request(btn_dv[11], iwd, databtn_hght);
	gtk_widget_set_name(btn_dv[11], btndv_css[8]);

	GtkWidget* space3 = gtk_label_new("");
	gtk_widget_set_size_request(space3, 0, databtn_hght);
	gtk_box_pack_start(GTK_BOX(lfbox), space3, false, false, 0);

	btn_dv[12] = gtk_button_new();
	label_dv[12] = gtk_label_new("◄");
	gtk_container_add(GTK_CONTAINER(btn_dv[12]), label_dv[12]);
	gtk_box_pack_start(GTK_BOX(lfbox), btn_dv[12], false, false, 0);
	gtk_widget_set_size_request(btn_dv[12], iwd, databtn_hght);
	gtk_widget_set_name(btn_dv[12], btndv_css[8]);

	GtkWidget* space4 = gtk_label_new("");
	gtk_widget_set_size_request(space4, 0, databtn_hght);
	gtk_box_pack_start(GTK_BOX(lfbox), space4, false, false, 0);

	btn_dv[13] = gtk_button_new();
	label_dv[13] = gtk_label_new("◄");
	gtk_container_add(GTK_CONTAINER(btn_dv[13]), label_dv[13]);
	gtk_box_pack_start(GTK_BOX(lfbox), btn_dv[13], false, false, 0);
	gtk_widget_set_size_request(btn_dv[13], iwd, databtn_hght);
	gtk_widget_set_name(btn_dv[13], btndv_css[8]);

	GtkWidget* space5 = gtk_label_new("");
	gtk_widget_set_size_request(space5, 0, databtn8_hght); // Gain btn height required
	gtk_box_pack_start(GTK_BOX(lfbox), space5, false, false, 0);

	btn_dv[14] = gtk_button_new();
	label_dv[14] = gtk_label_new("◄");
	gtk_container_add(GTK_CONTAINER(btn_dv[14]), label_dv[14]);
	gtk_box_pack_start(GTK_BOX(lfbox), btn_dv[14], false, false, 0);
	gtk_widget_set_size_request(btn_dv[14], iwd, databtn_hght);
	gtk_widget_set_name(btn_dv[14], btndv_css[8]);

	gtk_widget_set_halign(GTK_WIDGET(lfbox), GTK_ALIGN_START);

	hbox = gtk_box_new(GTK_ORIENTATION_VERTICAL, 0);
	gtk_box_pack_start(GTK_BOX(ahbox3), hbox, false, false, 1);

	/****************************************************************************/
	/**********************SET THE DATA VALUE AND HEADING************************/
	for (i = 0; i < 7; i = i + 2)
	{
		btn_dv[i] = gtk_button_new();
		label_dv[i] = gtk_label_new(all_btnval[i]);
		gtk_label_set_max_width_chars(GTK_LABEL(label_dv[i]), 11);			  // Sets the desired maximum width in characters of label   to restrict the size of control even caption text is big
		gtk_label_set_ellipsize(GTK_LABEL(label_dv[i]), PANGO_ELLIPSIZE_END); // The text will be ellipsized if there is not enough space to render the entire string.
		gtk_container_add(GTK_CONTAINER(btn_dv[i]), label_dv[i]);
		gtk_widget_set_size_request(btn_dv[i], databtn_width, databtn_hght);
		gtk_widget_get_style_context(btn_dv[i]);
		gtk_widget_set_name(btn_dv[i], btndv_css[i]); // "btnd1-entry"
	}
	
	for (i = 1; i < 8; i = i + 2)
	{
		btn_dv[i] = gtk_button_new();
		label_dv[i] = gtk_label_new(all_btnval[i]);
		gtk_label_set_max_width_chars(GTK_LABEL(label_dv[i]), 11);			  // Sets the desired maximum width in characters of label   to restrict the size of control even caption text is big
		gtk_label_set_ellipsize(GTK_LABEL(label_dv[i]), PANGO_ELLIPSIZE_END); // The text will be ellipsized if there is not enough space to render the entire string.
		gtk_container_add(GTK_CONTAINER(btn_dv[i]), label_dv[i]);
		gtk_widget_set_size_request(btn_dv[i], databtn_width, databtn_hght);
		gtk_widget_get_style_context(btn_dv[i]);
		gtk_widget_set_name(btn_dv[i], btndv_css[i]); // "btnd1-entry"
	}

	for (i = 0; i < 8; i++)
	{
		gtk_box_pack_start(GTK_BOX(hbox), btn_dv[i], false, false, 0);
	}

	/**************************************************************************/
	/*************HIGHLIGHT THE FIRST BUTTON OF DATA VALUE*********************/
	/**************************************************************************/

	gtk_widget_set_can_focus(GTK_WIDGET(btn_dv[1]), true);
	gtk_widget_grab_focus(GTK_WIDGET(btn_dv[1]));
	gtk_widget_set_name(btn_dv[1], "btnv1_1-entry");

	/*************************BUTTON 8 DATA HEADING************************/
	btn_dv[8] = gtk_button_new();
	strcpy(Gain_glbl, all_btnval[8]);
	strcat(all_btnval[8], gstr_2);
	label_dv[8] = gtk_label_new(all_btnval[8]);
	gtk_label_set_max_width_chars(GTK_LABEL(label_dv[8]), 11);			  
	gtk_label_set_ellipsize(GTK_LABEL(label_dv[8]), PANGO_ELLIPSIZE_END); 
	gtk_box_pack_start(GTK_BOX(hbox), btn_dv[8], false, false, 0);
	gtk_container_add(GTK_CONTAINER(btn_dv[8]), label_dv[8]);
	gtk_widget_set_size_request(btn_dv[8], databtn_width, databtn8_hght);
	gtk_widget_set_name(btn_dv[8], btndv_css[8]);
	gtk_widget_set_halign(GTK_WIDGET(label_dv[8]), GTK_ALIGN_START);

	/**************************BUTTON 9 DATA VALUE*************************/
	btn_dv[9] = gtk_button_new();
	label_dv[9] = gtk_label_new(all_btnval[9]);
	gtk_label_set_max_width_chars(GTK_LABEL(label_dv[9]), 0);			  
	gtk_label_set_ellipsize(GTK_LABEL(label_dv[9]), PANGO_ELLIPSIZE_END);
	gtk_box_pack_start(GTK_BOX(hbox), btn_dv[9], false, false, 0);
	gtk_container_add(GTK_CONTAINER(btn_dv[9]), label_dv[9]);
	gtk_widget_set_size_request(btn_dv[9], databtn_width, button_height);
	gtk_widget_get_style_context(btn_dv[9]);
	gtk_widget_set_name(btn_dv[9], btndv_css[9]);

	btn_dv[10] = gtk_button_new();
	label_dv[10] = gtk_label_new(menu_lbl[0]);
	gtk_label_set_max_width_chars(GTK_LABEL(label_dv[10]), 7);			   
	gtk_label_set_ellipsize(GTK_LABEL(label_dv[10]), PANGO_ELLIPSIZE_END); 
	gtk_box_pack_start(GTK_BOX(hbox), btn_dv[10], false, false, 0);
	gtk_container_add(GTK_CONTAINER(btn_dv[10]), label_dv[10]);
	gtk_widget_set_size_request(btn_dv[10], databtn_width, button_height);
	gtk_widget_get_style_context(btn_dv[10]);
	gtk_widget_set_name(btn_dv[10], "btndmenu-entry");

	for (i = 0, j = 1; i < 8, j < 8; i = i + 2, j = j + 2)
	{
		gtk_widget_set_halign(GTK_WIDGET(label_dv[i]), GTK_ALIGN_START);
		gtk_widget_set_halign(GTK_WIDGET(label_dv[j]), GTK_ALIGN_CENTER);
	}

	gtk_widget_set_halign(GTK_WIDGET(hbox), GTK_ALIGN_START);

	/***************************************************************************************************/
    /*************************SET THE RIGHT KEYS AROUND DATA BTNS***************************************/
    /***************************************************************************************************/
	rgbox = gtk_box_new(GTK_ORIENTATION_VERTICAL, 0);
	gtk_box_pack_start(GTK_BOX(ahbox3), rgbox, false, false, 1);

	GtkWidget* space6 = gtk_label_new("");
	gtk_widget_set_size_request(space6, 5, databtn_hght);
	gtk_box_pack_start(GTK_BOX(rgbox), space6, false, false, 0);

	btn_dv[15] = gtk_button_new();
	label_dv[15] = gtk_label_new("►");
	gtk_container_add(GTK_CONTAINER(btn_dv[15]), label_dv[15]);
	gtk_box_pack_start(GTK_BOX(rgbox), btn_dv[15], false, false, 0);
	gtk_widget_set_size_request(btn_dv[15], 5, databtn_hght);
	gtk_widget_set_name(btn_dv[15], btndv_css[8]);

	GtkWidget* space7 = gtk_label_new("");
	gtk_widget_set_size_request(space7, 5, databtn_hght);
	gtk_box_pack_start(GTK_BOX(rgbox), space7, false, false, 0);

	btn_dv[16] = gtk_button_new();
	label_dv[16] = gtk_label_new("►");
	gtk_container_add(GTK_CONTAINER(btn_dv[16]), label_dv[16]);
	gtk_box_pack_start(GTK_BOX(rgbox), btn_dv[16], false, false, 0);
	gtk_widget_set_size_request(btn_dv[16], 5, databtn_hght);
	gtk_widget_set_name(btn_dv[16], btndv_css[8]);

	GtkWidget* space8 = gtk_label_new("");
	gtk_widget_set_size_request(space8, 5, databtn_hght);
	gtk_box_pack_start(GTK_BOX(rgbox), space8, false, false, 0);

	btn_dv[17] = gtk_button_new();
	label_dv[17] = gtk_label_new("►");
	gtk_container_add(GTK_CONTAINER(btn_dv[17]), label_dv[17]);
	gtk_box_pack_start(GTK_BOX(rgbox), btn_dv[17], false, false, 0);
	gtk_widget_set_size_request(btn_dv[17], 5, databtn_hght);
	gtk_widget_set_name(btn_dv[17], btndv_css[8]);

	GtkWidget* space9 = gtk_label_new("");
	gtk_widget_set_size_request(space9, 5, databtn_hght);
	gtk_box_pack_start(GTK_BOX(rgbox), space9, false, false, 0);

	btn_dv[18] = gtk_button_new();
	label_dv[18] = gtk_label_new("►");
	gtk_container_add(GTK_CONTAINER(btn_dv[18]), label_dv[18]);
	gtk_box_pack_start(GTK_BOX(rgbox), btn_dv[18], false, false, 0);
	gtk_widget_set_size_request(btn_dv[18], 5, databtn_hght);
	gtk_widget_set_name(btn_dv[18], btndv_css[8]);

	GtkWidget* space10 = gtk_label_new("");
	gtk_widget_set_size_request(space10, 5, databtn8_hght);
	gtk_box_pack_start(GTK_BOX(rgbox), space10, false, false, 0);

	btn_dv[19] = gtk_button_new();
	label_dv[19] = gtk_label_new("►");
	gtk_container_add(GTK_CONTAINER(btn_dv[19]), label_dv[19]);
	gtk_box_pack_start(GTK_BOX(rgbox), btn_dv[19], false, false, 0);
	gtk_widget_set_size_request(btn_dv[19], 5, databtn_hght);
	gtk_widget_set_name(btn_dv[19], btndv_css[8]);

	gtk_widget_set_halign(GTK_WIDGET(rgbox), GTK_ALIGN_START);

	/****************************************************************************/
	/**********************SET THE SCROLLBAR*************************************/
	/****************************************************************************/

	vbox = gtk_box_new(GTK_ORIENTATION_VERTICAL, 1);
	gtk_box_pack_start(GTK_BOX(ahbox3), vbox, false, false, 1);

	adj = gtk_adjustment_new(
		0.0,	   // initial value
		0.0,	   // minimum value
		1000000.0, // maximum value10000000.0 /10000000.0
		1.0,	   // step increment
		1.0,	   // page increment
		0.0);	   // page size

	scrollbar = gtk_scrollbar_new(GTK_ORIENTATION_VERTICAL, adj);
	gtk_box_pack_start(GTK_BOX(vbox), scrollbar, false, false, 1);
	gtk_widget_set_size_request(scrollbar, scrollbar_w, scrollbar_h);
	gtk_widget_set_halign(GTK_WIDGET(vbox), GTK_ALIGN_END); // scr_bckgrnd
	gtk_widget_set_name(scrollbar, "scr_bckgrnd");

	/******************************************************************************************************************************/
	/*********************CREATING HORIZONTAL FOURTH BOX FOR FRAME BTM BUTTONS FOR ERROR MSG AND VALUES****************************/
	/*****************************************************************************************************************************/

	ahbox4 = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
	gtk_box_pack_start(GTK_BOX(avbox), ahbox4, false, false, 0);
	gtk_box_set_spacing(GTK_BOX(ahbox4), 0);

	b_bframe = gtk_frame_new(NULL); // Message Button Box
	gtk_frame_set_shadow_type(GTK_FRAME(b_bframe), GTK_SHADOW_NONE);
	gtk_widget_set_size_request(b_bframe, btm_btnfrm, button_height);
	n_overlay = gtk_overlay_new();
	b_btnbox = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
	sb_btnbox = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);

	/******************************************************************************************************************/
	/*********************************SET THE SECOND LAST ROW OF BUTTON************************************************/
	/******************************************************************************************************************/

	for (i = 0; i < 4; i++)
	{
		top_btn[i] = gtk_button_new();
		t_label[i] = gtk_label_new(top_ary[i]);
		gtk_widget_set_size_request(top_btn[i], tsbtn_width, btntop_height);
		gtk_label_set_max_width_chars(GTK_LABEL(t_label[i]), 12);			 
		gtk_label_set_ellipsize(GTK_LABEL(t_label[i]), PANGO_ELLIPSIZE_END); 
		gtk_widget_set_halign(GTK_WIDGET(t_label[i]), GTK_ALIGN_END);		 // GTK_ALIGN_START
		gtk_widget_set_valign(GTK_WIDGET(t_label[i]), GTK_ALIGN_END);		 // GTK_ALIGN_START

		gtk_container_add(GTK_CONTAINER(top_btn[i]), t_label[i]);
		gtk_widget_set_name(top_btn[i], tbtn_css[i]);
	}

	// top_btn[3] = gtk_button_new();
	// t_label[3] = gtk_label_new(top_ary[3]);
	// gtk_widget_set_size_request(top_btn[3], tsbtn4_width, btntop_height);
	// gtk_label_set_max_width_chars(GTK_LABEL(t_label[3]), 10); //Sets the desired maximum width in characters of label
	// gtk_label_set_ellipsize(GTK_LABEL(t_label[3]), PANGO_ELLIPSIZE_END); // The text will be ellipsized if there is not enough space to render the entire string.
	// gtk_widget_set_halign(GTK_WIDGET(t_label[3]), GTK_ALIGN_START);
	// gtk_widget_set_valign(GTK_WIDGET(t_label[3]), GTK_ALIGN_START);

	// gtk_container_add(GTK_CONTAINER(top_btn[3]), t_label[3]);
	// gtk_widget_set_name(top_btn[3], tbtn_css[3]);

	for (i = 0; i < 4; i++)
	{
		gtk_box_pack_start(GTK_BOX(b_btnbox), top_btn[i], false, false, 0);
	}
	// gtk_box_pack_start(GTK_BOX(b_btnbox), top_btn[3], false, false, 0);


	/******************************************************************************************************************************/
	/******************************TO DISPLAY ERROR MESSAGES INSTEAD OF BUTTONS****************************************************/
	/******************************************************************************************************************************/

	b_errorbox = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
	btn_err = gtk_button_new();  // DISPLAY WARNING MESSAGE BUTTON 
	gtk_widget_set_size_request(btn_err, btm_btnfrm, button_height);
	err_label = gtk_label_new(" DISPLAY WARNING MESSAGE ");
	gtk_container_add(GTK_CONTAINER(btn_err), err_label);
	gtk_widget_set_name(btn_err, "err_msg"); // gtk_widget_set_name(btn_err, "err_msg");
	/*gtk_box_pack_start(GTK_BOX(b_errorbox), err_label, false, false, 0);*/
	gtk_box_pack_start(GTK_BOX(b_errorbox), btn_err, false, false, 0);

	gtk_overlay_add_overlay(GTK_OVERLAY(n_overlay), b_btnbox); //SECOND LAST LAYER OF BUTTON on OVERLAY
	gtk_overlay_add_overlay(GTK_OVERLAY(n_overlay), b_errorbox); // ERROR BUTTON on Overlay
	gtk_container_add(GTK_CONTAINER(b_bframe), n_overlay); // ADD overlay to frame

	gtk_box_pack_start(GTK_BOX(ahbox4), b_bframe, false, false, 1);
	// gtk_box_set_spacing(GTK_BOX(b_btnbox), 2);

	v1box = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
	gtk_box_pack_start(GTK_BOX(ahbox4), v1box, false, false, 2);
	// gtk_box_set_spacing(GTK_BOX(v1box), 0);


	/****************************************************************************************************/
	/*******************************STP Key BUTTON OF 1 and 10 ******************************************/
	/****************************************************************************************************/
	b_btn[6] = gtk_button_new(); // b_btn[6] : Stp Coarse btn
	b_label[6] = gtk_label_new(btn_scr[1]);
	gtk_container_add(GTK_CONTAINER(b_btn[6]), b_label[6]);
	gtk_label_set_max_width_chars(GTK_LABEL(b_label[6]), 8); // Sets the desired maximum width in characters of label
	gtk_label_set_ellipsize(GTK_LABEL(b_label[6]), PANGO_ELLIPSIZE_END); // The text will be ellipsized if there is not enough space to render the entire string.
	gtk_widget_set_halign(GTK_WIDGET(b_label[6]), GTK_ALIGN_CENTER);
	gtk_box_pack_start(GTK_BOX(v1box), b_btn[6], false, false, 1);
	gtk_widget_set_size_request(b_btn[6], v_button_width + 5, v_button_height);
	gtk_widget_set_name(b_btn[6], bbtn_css[6]);


	/*********************************************************************************/
	/***********************SET THE PREVIOUS MENU BUTTON******************************/
	/*********************************************************************************/
	btn_prv = gtk_button_new();
	label14 = gtk_label_new("<<");
	gtk_container_add(GTK_CONTAINER(btn_prv), label14);
	gtk_label_set_max_width_chars(GTK_LABEL(label14), 3);			  
	gtk_label_set_ellipsize(GTK_LABEL(label14), PANGO_ELLIPSIZE_END); 
	gtk_widget_set_halign(GTK_WIDGET(label14), GTK_ALIGN_CENTER);
	gtk_widget_set_size_request(btn_prv, btnw_prvnxt, btnh_prvnxt);
	gtk_box_pack_start(GTK_BOX(v1box), btn_prv, false, false, 0);
	// gtk_box_pack_start(GTK_BOX(ahbox4), btn_prv, false, false, 4);
	gtk_widget_set_name(btn_prv, "btnprv-entry");


	/********************************************************************************/
	/************************SET THE NEXT MENU BUTTON********************************/
	/********************************************************************************/
	btn_next = gtk_button_new();
	label15 = gtk_label_new(">>");
	gtk_container_add(GTK_CONTAINER(btn_next), label15);
	gtk_label_set_max_width_chars(GTK_LABEL(label15), 3);			  
	gtk_label_set_ellipsize(GTK_LABEL(label15), PANGO_ELLIPSIZE_END); 
	gtk_widget_set_halign(GTK_WIDGET(label15), GTK_ALIGN_CENTER);
	gtk_widget_set_size_request(btn_next, btnw_prvnxt, btnh_prvnxt);
	gtk_widget_set_name(btn_next, "btnnxt-entry");
	gtk_box_pack_end(GTK_BOX(v1box), btn_next, false, false, 0);

	v4box = gtk_box_new(GTK_ORIENTATION_VERTICAL, 0);
	gtk_box_pack_start(GTK_BOX(ahbox4), v4box, false, false, 0);


	/****************************************************************************/
	/************************SET THE KEYPAD BUTTON*******************************/
	/****************************************************************************/
	bbtnkey = gtk_button_new();
	label13 = gtk_label_new("Key");
	gtk_container_add(GTK_CONTAINER(bbtnkey), label13);
	gtk_label_set_max_width_chars(GTK_LABEL(label13), 3);			 
	gtk_label_set_ellipsize(GTK_LABEL(label13), PANGO_ELLIPSIZE_END); 
	gtk_widget_set_halign(GTK_WIDGET(label13), GTK_ALIGN_CENTER);
	gtk_widget_set_size_request(bbtnkey, v_button_width, v_button_height);
	gtk_box_pack_start(GTK_BOX(v4box), bbtnkey, false, false, 0);
	gtk_widget_set_name(bbtnkey, "bbtnkey-entry");

	ahbox5 = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
	gtk_box_pack_start(GTK_BOX(avbox), ahbox5, false, false, 0);
	gtk_box_set_spacing(GTK_BOX(ahbox5), 0);


	/*************************************************************************************************************************/
	/****************************************BOTTOM MOST ROW OF BUTTON AND CLOCK**********************************************/
	/*************************************************************************************************************************/
	for (i = 0; i < 3; i++)
	{
		s_btn[i] = gtk_button_new();
		s_label[i] = gtk_label_new(scnd_ary[i]);
		gtk_widget_set_size_request(s_btn[i], tsbtn_width, button_height);
		gtk_label_set_max_width_chars(GTK_LABEL(s_label[i]), 12);	//Sets the desired maximum width in characters of label
		gtk_label_set_ellipsize(GTK_LABEL(s_label[i]), PANGO_ELLIPSIZE_END); //The text will be ellipsized if there is not enough space to render the entire string.
		gtk_widget_set_halign(GTK_WIDGET(s_label[i]), GTK_ALIGN_END);
		gtk_widget_set_valign(GTK_WIDGET(s_label[i]), GTK_ALIGN_END); // GTK_ALIGN_START
		gtk_container_add(GTK_CONTAINER(s_btn[i]), s_label[i]);
		gtk_widget_set_name(s_btn[i], sbtn_css[i]);
		gtk_box_pack_start(GTK_BOX(sb_btnbox), s_btn[i], false, false, 0);
	}

	s_btn[3] = gtk_button_new();
	s_label[3] = gtk_label_new(scnd_ary[3]);
	gtk_widget_set_size_request(s_btn[3], tsbtn4_width, button_height);
	gtk_label_set_max_width_chars(GTK_LABEL(s_label[3]), 10); //Sets the desired maximum width in characters of label
	gtk_label_set_ellipsize(GTK_LABEL(s_label[3]), PANGO_ELLIPSIZE_END); //The text will be ellipsized if there is not enough space to render the entire string.
	gtk_widget_set_halign(GTK_WIDGET(s_label[3]), GTK_ALIGN_END);
	gtk_widget_set_valign(GTK_WIDGET(s_label[3]), GTK_ALIGN_END); // GTK_ALIGN_START
	gtk_container_add(GTK_CONTAINER(s_btn[3]), s_label[3]);
	gtk_widget_set_name(s_btn[3], sbtn_css[3]);
	gtk_box_pack_start(GTK_BOX(sb_btnbox), s_btn[3], false, false, 0);

	s_btn[4] = gtk_button_new();
	s_label[4] = gtk_label_new("--");
	gtk_widget_set_size_request(s_btn[4], 135, button_height);
	gtk_label_set_max_width_chars(GTK_LABEL(s_label[4]), 20); //Sets the desired maximum width in characters of label
	gtk_label_set_ellipsize(GTK_LABEL(s_label[4]), PANGO_ELLIPSIZE_END); //The text will be ellipsized if there is not enough space to render the entire string.
	gtk_widget_set_halign(GTK_WIDGET(s_label[4]), GTK_ALIGN_START);
	gtk_widget_set_valign(GTK_WIDGET(s_label[4]), GTK_ALIGN_START); // GTK_ALIGN_START
	gtk_container_add(GTK_CONTAINER(s_btn[4]), s_label[4]);
	gtk_widget_set_name(s_btn[4], sbtn_css[4]);
	gtk_box_pack_start(GTK_BOX(sb_btnbox), s_btn[4], false, false, 0);

	gtk_box_pack_start(GTK_BOX(ahbox5), sb_btnbox, false, false, 0); //SECOND LAYER OF BOTTOM BUTTONS

	/*********************************************************************************/
	/*************************** CLOCK DATE AND TIME *********************************/
	/*********************************************************************************/
	nframe[7] = gtk_frame_new(NULL);
	n_overlay = gtk_overlay_new();
	gtk_frame_set_shadow_type(GTK_FRAME(nframe[7]), GTK_SHADOW_NONE); // GTK_SHADOW_IN);
	gtk_widget_set_size_request(nframe[7], image_clk, image_h);

	Clock_lab = gtk_label_new(" "); //Clock_lab = gtk_label_new("11:36 Dt:05/02/2023");
	gtk_widget_set_halign(GTK_WIDGET(Clock_lab), GTK_ALIGN_START);
	gtk_label_set_max_width_chars(GTK_LABEL(Clock_lab), 25);
	gtk_label_set_ellipsize(GTK_LABEL(Clock_lab), PANGO_ELLIPSIZE_END);
	gtk_container_add(GTK_CONTAINER(nframe[7]), Clock_lab);

	gtk_box_pack_start(GTK_BOX(ahbox5), nframe[7], false, false, 2);


	/******************************************************************************/
	/************CONNECT THE WIDGETS WITH THEIR PARTICULAR FUNCTIONS***************/
	/******************************************************************************/
	g_signal_connect(window, "destroy", G_CALLBACK(gtk_main_quit), NULL); //Delete_PopUp()

	g_signal_connect(top_btn[0], "clicked", G_CALLBACK(Delete_PopUp), NULL);

	g_signal_connect(btn_dv[1], "clicked", G_CALLBACK(OnBtn_press), NULL); // button-press-event  clicked
	g_signal_connect(btn_dv[3], "clicked", G_CALLBACK(OnBtn_press), NULL); // button-press-event
	g_signal_connect(btn_dv[5], "clicked", G_CALLBACK(OnBtn_press), NULL); // button-press-event
	g_signal_connect(btn_dv[7], "clicked", G_CALLBACK(OnBtn_press), NULL); // button-press-event
	g_signal_connect(btn_dv[9], "clicked", G_CALLBACK(OnBtn_press), NULL); // button-press-event

	g_signal_connect(btn_dv[20], "clicked", G_CALLBACK(lftBtn_valchng), NULL); // For left traverse key
	g_signal_connect(btn_dv[11], "clicked", G_CALLBACK(lftBtn_valchng), NULL); // For left traverse key
	g_signal_connect(btn_dv[12], "clicked", G_CALLBACK(lftBtn_valchng), NULL); // For left traverse key
	g_signal_connect(btn_dv[13], "clicked", G_CALLBACK(lftBtn_valchng), NULL); // For left traverse key
	g_signal_connect(btn_dv[14], "clicked", G_CALLBACK(lftBtn_valchng), NULL); // For left traverse key
	
	for (i = 15; i < 20; i++)
	{
		g_signal_connect(btn_dv[i], "clicked", G_CALLBACK(rghtBtn_valchng), NULL); // For Right traverse key
	}

	g_signal_connect(btn_prv, "clicked", G_CALLBACK(PrvBtnClick), NULL);
	g_signal_connect(btn_next, "clicked", G_CALLBACK(NxtBtnClick), NULL);
	g_signal_connect(bbtnkey, "clicked", G_CALLBACK(keypad_btn), NULL);
	g_signal_connect(adj, "value-changed", G_CALLBACK(OnScroll), NULL);
	g_signal_connect(window, "key_press_event", G_CALLBACK(my_keypress_val), NULL);
	g_signal_connect(b_btn[6], "clicked", G_CALLBACK(stp_coarse), NULL);
	g_signal_connect(dgs_btn[17], "clicked", G_CALLBACK(OnBtn_press), NULL); // Exit From Frame Menu      Dgs_exit_f), NULL);

	for (i = 1; i < 24; i = i + 2)
	{
		g_signal_connect(dgs_btn[i], "clicked", G_CALLBACK(OnBtn_press), NULL);
	}

	Creat_bk_img(Measure_v1, 1); // Create Image for Measurement Display Button
	Creat_bk_img(Measure_v2, 2); // Create Image for Measurement Display Button
	Colour_Theme_Apply(0);

	gtk_container_add(GTK_CONTAINER(window), avbox);
	gtk_widget_show_all(window);

	gtk_widget_hide(f2_box); // HIDE THE EXTRA DATA BTN
	gtk_widget_hide(f3_box); // HIDE THE TEXTBOX FRAME
	gtk_widget_hide(b_errorbox);

	Start_up_Scr();
	gtk_widget_show_all(window_home);

	gtk_widget_hide(splite_box_1);
	gtk_widget_hide(splite_box_2);
	//gtk_widget_hide(nframe[7]); 
	//gtk_widget_hide(nframe[8]);
	//gtk_widget_show(nframe[9]);

	gtk_main();
	// pwron_readvalues();
	// return(0);
}

void clean_up(void)
{
	close_bsc_file();

	if (shape_profiler_rays_cr)
	{
		cairo_destroy(shape_profiler_rays_cr);
		shape_profiler_rays_cr = NULL;
	}
	if (shape_profiler_rays_surface)
	{
		cairo_surface_destroy(shape_profiler_rays_surface);
		shape_profiler_rays_surface = NULL;
	}
	if (h_ruler_cr)
	{
		cairo_destroy(h_ruler_cr);
		h_ruler_cr = NULL;
	}
	if (h_ruler_surface)
	{
		cairo_surface_destroy(h_ruler_surface);
		h_ruler_surface = NULL;
	}
	if (v_ruler_cr)
	{
		cairo_destroy(v_ruler_cr);
		v_ruler_cr = NULL;
	}
	if (v_ruler_surface)
	{
		cairo_surface_destroy(v_ruler_surface);
		v_ruler_surface = NULL;
	}
}

//*************************************************************************************************************
void Start_up_Scr()
{
	GdkPixbuf *image_st;
	GtkWidget *image_stgt, *Labbox, *Labbox1, *Labbox2, *Labbox3;
	int stw, sth;
	stw = 1024;
	sth = 600;

	// Start Up Screen crated and Display
	window_home = gtk_window_new(GTK_WINDOW_POPUP); // gtk_application_window_new(app);
	// gtk_window_set_resizable(GTK_WINDOW(window), false); // Sets whether the user can resize a window
	// gtk_window_set_default_size(GTK_WINDOW(window), window_width, window_height); // Set window size
	gtk_window_set_default_size(GTK_WINDOW(window_home), 1024, 600); // gtk_window_set_default_size(GTK_WINDOW(window_home), -1, -1);
	gtk_window_fullscreen(GTK_WINDOW(window_home));
	// gtk_window_set_decorated(GTK_WINDOW(window_home), false); // Set false to remove topmost taskbar
	// g_signal_connect(window, "delete-event", G_CALLBACK (delete_event), NULL);
	// g_signal_connect(window, "destroy", G_CALLBACK (gtk_main_quit), NULL);
	gtk_window_set_transient_for(GTK_WINDOW(window_home), GTK_WINDOW(window));

	// image_st = gdk_pixbuf_new_from_file_at_scale("Images/Images/St_Scrn.png", stw, sth, false, NULL);  //stscreen-entry
	gtk_widget_set_name(window_home, "stscreen-entry");

	Labbox = gtk_box_new(GTK_ORIENTATION_VERTICAL, 0);
	GtkWidget *label = NULL;
	GtkWidget *labe2 = NULL;
	GtkWidget *labe3 = NULL;
	GtkWidget *labed = NULL;

	labed = gtk_label_new("        ");
	gtk_widget_set_halign(GTK_WIDGET(labed), GTK_ALIGN_CENTER);
	gtk_box_pack_start(GTK_BOX(Labbox), labed, false, false, 100 + 10);

	// Labbox1 = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
	label = gtk_label_new("MODSCAN 100");
	gtk_widget_set_halign(GTK_WIDGET(label), GTK_ALIGN_CENTER);
	gtk_box_pack_start(GTK_BOX(Labbox), label, false, false, 10);
	gtk_widget_set_name(label, "stclabel-entry");

	// Labbox2 = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
	labe2 = gtk_label_new("SR NO:15-04-2024");
	gtk_widget_set_halign(GTK_WIDGET(labe2), GTK_ALIGN_CENTER);
	gtk_box_pack_start(GTK_BOX(Labbox), labe2, false, false, 10);
	gtk_widget_set_name(labe2, "stclabe2-entry");

	// Labbox3 = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
	labe3 = gtk_label_new("VER:01.00.00");
	gtk_widget_set_halign(GTK_WIDGET(labe3), GTK_ALIGN_CENTER);
	gtk_box_pack_start(GTK_BOX(Labbox), labe3, false, false, 10);
	gtk_widget_set_name(labe3, "stclabe3-entry");

	gtk_container_add(GTK_CONTAINER(window_home), Labbox);

	guint scrtm = 2000;
	st_scrn_time_id = g_timeout_add((guint)scrtm, (GSourceFunc)Close_StScreen, NULL); // (gpointer)gdk_display);
}


/*********************************************************************************************************************************/
void Delete_PopUp() // Pop up window of Confirmation for Deleting the files(Not Used)
{
	GdkPixbuf* image_st;
	GtkWidget* image_stgt, * Labbox, * Labbox1, * Labbox2, * Labbox3;
	GtkWidget* btn_yes, * btn_no;
	int stw, sth;
	stw = 1024;
	sth = 600;

	// Delete popup created
	window_del = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	gtk_window_set_default_size(GTK_WINDOW(window_del), 100, 175); 
	gtk_window_set_decorated(GTK_WINDOW(window_del), true); // Set false to remove topmost taskbar
	gtk_window_set_transient_for(GTK_WINDOW(window_del), GTK_WINDOW(window));

	Labbox = gtk_box_new(GTK_ORIENTATION_VERTICAL, 0);
	GtkWidget* label = NULL;
	GtkWidget* labe2 = NULL;
	GtkWidget* labe3 = NULL;
	GtkWidget* labed = NULL;

	labed = gtk_label_new("        ");
	gtk_widget_set_halign(GTK_WIDGET(labed), GTK_ALIGN_CENTER);
	gtk_box_pack_start(GTK_BOX(Labbox), labed, false, false, 5);

	label = gtk_label_new("DO YOU WANT TO DELETE THE FILE");
	gtk_widget_set_halign(GTK_WIDGET(label), GTK_ALIGN_CENTER);
	gtk_box_pack_start(GTK_BOX(Labbox), label, false, false, 10);
	gtk_widget_set_name(label, "delpop-entry");

	btn_yes = gtk_button_new_with_label("Yes");
	gtk_widget_set_size_request(btn_yes, 25, 25);
	gtk_container_add(GTK_CONTAINER(Labbox), btn_yes);

	btn_no = gtk_button_new_with_label("No");
	gtk_widget_set_size_request(btn_yes, 25, 25);
	gtk_container_add(GTK_CONTAINER(Labbox), btn_no);

	// Labbox2 = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
	//labe2 = gtk_label_new("SR NO:24-01-2024");
	//gtk_widget_set_halign(GTK_WIDGET(labe2), GTK_ALIGN_CENTER);
	//gtk_box_pack_start(GTK_BOX(Labbox), labe2, false, false, 10);
	//gtk_widget_set_name(labe2, "stclabe2-entry");

	//// Labbox3 = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
	//labe3 = gtk_label_new("VER:01.00.00");
	//gtk_widget_set_halign(GTK_WIDGET(labe3), GTK_ALIGN_CENTER);
	//gtk_box_pack_start(GTK_BOX(Labbox), labe3, false, false, 10);
	//gtk_widget_set_name(labe3, "stclabe3-entry");

	gtk_container_add(GTK_CONTAINER(window_del), Labbox);

	g_signal_connect(btn_yes, "clicked", G_CALLBACK(Del_Yes), NULL);
	g_signal_connect(btn_no, "clicked", G_CALLBACK(Del_No), NULL);
	
	gtk_widget_show_all(window_del);

	//guint scrtm = 2000;
	//st_scrn_time_id = g_timeout_add((guint)scrtm, (GSourceFunc)Close_StScreen, NULL);
}


/*********************************************************************************************************************************/
void Del_Yes()
{
	remove(path_h);
	dsp_msg(42);
	//MEMNO_f(0);
	gtk_widget_destroy(GTK_WIDGET(window_del));
}
void Del_No()
{
	gtk_widget_destroy(GTK_WIDGET(window_del));
}

//****************NOT IN USE BELOW FUNCTION***************************************************************
void Start_up_Scr_safe()
{
	GdkPixbuf *image_st;
	GtkWidget *image_stgt;
	int stw, sth;
	stw = 1024;
	sth = 600;

	// Start Up Screen crated and Display
	window_home = gtk_window_new(GTK_WINDOW_POPUP); // gtk_application_window_new(app);
	// gtk_window_set_resizable(GTK_WINDOW(window), false); // Sets whether the user can resize a window
	// gtk_window_set_default_size(GTK_WINDOW(window), window_width, window_height); // Set window size
	gtk_window_set_default_size(GTK_WINDOW(window_home), 1024, 600); // gtk_window_set_default_size(GTK_WINDOW(window_home), -1, -1);
	gtk_window_fullscreen(GTK_WINDOW(window_home));
	// gtk_window_set_decorated(GTK_WINDOW(window_home), false); // Set false to remove topmost taskbar
	gtk_window_set_transient_for(GTK_WINDOW(window_home), GTK_WINDOW(window));

	image_st = gdk_pixbuf_new_from_file_at_scale("Images/Images/St_Scrn.png", stw, sth, false, NULL);
	image_stgt = gtk_image_new_from_pixbuf(image_st);
	gtk_container_add(GTK_CONTAINER(window_home), image_stgt);

	guint scrtm = 5000;
	st_scrn_time_id = g_timeout_add((guint)scrtm, (GSourceFunc)Close_StScreen, NULL); // (gpointer)gdk_display);
}

//*************************************************************************************************************
void Close_Window()
{
	close(fd_SPI);

	if (signal_id)
	{
		g_source_remove(signal_id);
		signal_id = 0;
	}
	gtk_widget_destroy(GTK_WIDGET(window));
}

/*********************************************************************************************************************************/
void Colour_Theme_Apply(int thmeno) // Color theme of Screen
{
	if (thmeno == 0)
	{
		gtk_css_provider_load_from_path(GTK_CSS_PROVIDER(cssProvider), "gray.css", NULL);
	}
	if (thmeno == 1)
	{
		gtk_css_provider_load_from_path(GTK_CSS_PROVIDER(cssProvider), "blue.css", NULL);
	}
	if (thmeno == 2)  // (NOT USING)
	{
		gtk_css_provider_load_from_path(GTK_CSS_PROVIDER(cssProvider), "orange.css", NULL);
	}

	gtk_style_context_add_provider_for_screen(gdk_screen_get_default(), GTK_STYLE_PROVIDER(cssProvider), GTK_STYLE_PROVIDER_PRIORITY_USER);

}

void stp_coarse() // Stp Button value in GUI of 1 or 10.
{
	/*if (btn_idx == 4)
	{
		GainVal_chng(1);
	}*/
	//else
	if (step_coarseflag == true)
	{
		char val_stp[5] = "10";
		Key_stp = 10;
		btnstep_val = 1;
		strcpy(btn_scr[1], val_stp);
		gtk_label_set_label(GTK_LABEL(b_label[6]), btn_scr[1]);
		gtk_widget_set_halign(GTK_WIDGET(b_label[6]), GTK_ALIGN_START);
		step_coarseflag = false;
	}
	else if (step_coarseflag == false)
	{
		char val_stp[5] = "1";
		Key_stp = 1;
		btnstep_val = 0;
		strcpy(btn_scr[1], val_stp);
		gtk_label_set_label(GTK_LABEL(b_label[6]), btn_scr[1]);
		gtk_widget_set_halign(GTK_WIDGET(b_label[6]), GTK_ALIGN_CENTER);
		step_coarseflag = true;
	}
}

void DetectSDCard()
{
	FILE* f = popen("mount | grep /media/mmcblk1p1", "r");

	if (NULL != f)
	{
		/* test if something has been output by the command */
		if (EOF == fgetc(f))
		{
			//gtk_widget_hide(n_sdcrdfrm); 
			gtk_widget_hide(n_image[11]);
			sdcrd_val = 0;
			//puts("\n/dev/sda1 is NOT mounted");
		}
		else
		{
			// gtk_widget_show(n_sdcrdfrm);  
			gtk_widget_show(n_image[11]);
			strcpy(sdcard_path, "/media/mmcblk1p1/");
			sdcrd_val = 1;
			//puts("\n/dev/sda1 is mounted");
		}

		/* close the command file */
		pclose(f);
	}
	return;
}

void DetectUsb()
{
	FILE* f = popen("mount | grep /media/sda", "r");

	if (NULL != f)
	{
		/* test if something has been output by the command */
		if (EOF == fgetc(f))
		{
			//gtk_widget_hide(nframe[9]);
			gtk_widget_hide(n_image[8]);
			usb_val = 0;
			//puts("\n/dev/sda1 is NOT mounted");
		}
		else
		{
			//gtk_widget_show(nframe[9]);
			gtk_widget_show(n_image[8]);
			strcpy(pendrv_path, "/media/sda/");
			usb_val = 1;
			//puts("\n/dev/sda1 is mounted");
		}

		/* close the command file */
		pclose(f);
	}
	return;
}

void MountUSB(const char *filename)
{
	char path[256];

	fpCpy = fopen("/dev/sda", "r");
	if (fpCpy != NULL)
	{
		strcpy(path, "cp -r /usr/share/wslprog/");
		strcat(path, filename);
		strcat(path, " /media/sda1/");
		system(path);
		// Close device
		fclose(fpCpy);
		fpCpy = NULL;
		dsp_msg(25);
	}
	else
	{
		dsp_msg(28);
	}
}

void UmountUSB(void)
{
	system("umount /media/sda1");
	dsp_msg(49);
}

//void DetectUsb()  //Detect the usb
//{
//	FILE* f;
//	if (f = popen("mount | grep /media/sda", "r"))
//	{
//		if (NULL != f)
//		{
//			if (EOF == fgetc(f))
//			{
//				//gtk_widget_hide(nframe[9]);
//				gtk_widget_hide(n_image[8]);
//				usb_val = 0;
//			}
//			else
//			{
//				//gtk_widget_show(nframe[9]);
//				gtk_widget_show(n_image[8]);
//				strcpy(pendrv_path, "/media/sda/");
//				usb_val = 1;
//			}
//			pclose(f); /* close the command file */
//		}
//	}
//	else if (f = popen("mount | grep /media/sda1", "r"))
//	{
//		if (NULL != f)
//		{
//			if (EOF == fgetc(f))
//			{
//				//gtk_widget_hide(nframe[9]);
//				gtk_widget_hide(n_image[8]);
//				usb_val = 0;
//			}
//			else
//			{
//				//gtk_widget_show(nframe[9]);
//				gtk_widget_show(n_image[8]);
//				strcpy(pendrv_path, "/media/sda1/");
//				usb_val = 1;
//			}
//			pclose(f); 	/* close the command file */
//		}
//	}
//	else if (f = popen("mount | grep /media/sdb", "r"))
//	{
//		if (NULL != f)
//		{
//			if (EOF == fgetc(f))
//			{
//				//gtk_widget_hide(nframe[9]);
//				gtk_widget_hide(n_image[8]);
//				usb_val = 0;
//			}
//			else
//			{
//				//gtk_widget_show(nframe[9]);
//				gtk_widget_show(n_image[8]);
//				strcpy(pendrv_path, "/media/sdb/");
//				usb_val = 1;
//			}
//			pclose(f); /* close the command file */
//		}
//	}
//	else if (f = popen("mount | grep /media/sdb1", "r"))
//	{
//		if (NULL != f)
//		{
//			if (EOF == fgetc(f))
//			{
//				//gtk_widget_hide(nframe[9]);
//				gtk_widget_hide(n_image[8]);
//				usb_val = 0;
//			}
//			else
//			{
//				//gtk_widget_show(nframe[9]);
//				gtk_widget_show(n_image[8]);
//				strcpy(pendrv_path, "/media/sdb1/");
//				usb_val = 1;
//			}
//			pclose(f); /* close the command file */
//		}
//	}
//	return;
//}

//void DetectUsb()  //Detect the usb
//{
//	//Copy_All();
//	FILE* f;
//	//if (f = popen("mount | grep /home/rnd1/temp1", "r")) //fopen(path_h, "r");
//	if (f = fopen("/home/rnd1/temp1", "r"))
//	{
//		if (NULL != f)
//		{
//			/* test if something has been output by the command */
//			//if (EOF == fgetc(f))
//			if (feof(f))
//			{
//				gtk_widget_hide(nframe[9]);
//				usb_val = 0;
//				//puts("\n/dev/sda1 is NOT mounted");
//			}
//			else
//			{
//				gtk_widget_show(nframe[9]);
//				strcpy(pendrv_path, "/home/rnd1/temp1");
//				//pendrv_path
//				usb_val = 1;
//				//puts("\n/dev/sda1 is mounted");
//			}
//			/* close the command file */
//			//pclose(f);
//			fclose(f);
//		}
//	}
//	//else if (f = popen("mount | grep /home/rnd1/temp2", "r")) // else if (f = fopen("Cal", "r"))
//	else if (f = fopen("/home/rnd1/temp2", "r"))
//	{
//		if (NULL != f)
//		{
//			/* test if something has been output by the command */
//			//if (EOF == fgetc(f))
//			if (feof(f))
//			{
//				gtk_widget_hide(nframe[9]);
//				usb_val = 0;
//				//puts("\n/dev/sda1 is NOT mounted");
//			}
//			else
//			{
//				gtk_widget_show(nframe[9]);
//				strcpy(pendrv_path, "/home/rnd1/temp2");
//				usb_val = 1;
//				//puts("\n/dev/sda1 is mounted");
//			}
//			/* close the command file */
//			//pclose(f);
//			fclose(f);
//		}
//	}
//	return;
//}


void Reset_DGSDAC() // To Reset the DAC and DGS after reading from file
{
	int key_v = 0;
	dgs_fromfile = 0;
	reset_value = 1;
	Set_default_val();

	Dac_f(key_v);
	STARTa_f(key_v);
	Point_f(key_v);
	press_f(key_v);

	Size_Eval_Select_f(key_v); // MENU 12

	Size_Eval_f(key_v);	 // MENU 4   // To be review
	Size_Eval_f1(key_v); // To be review
	Size_Eval_f2(key_v); // To be review
	Size_Eval_f3(key_v); // To be review
}


/****************************************************************************/
/***********************SET THE BOTTOM BUTTON'S******************************/
	/*for (i = 0; i < 5; i++)
	{
		b_btn[i] = gtk_button_new();
		b_label[i] = gtk_label_new(b_ary[i]);
		gtk_container_add(GTK_CONTAINER(b_btn[i]), b_label[i]);
		gtk_label_set_max_width_chars(GTK_LABEL(b_label[i]), 8);
		gtk_label_set_ellipsize(GTK_LABEL(b_label[i]), PANGO_ELLIPSIZE_END);
		gtk_widget_set_halign(GTK_WIDGET(b_label[i]), GTK_ALIGN_CENTER);
		gtk_widget_set_size_request(b_btn[i], button_width, button_height);
		gtk_widget_set_name(b_btn[i], bbtn_css[i]);
	}*/