#include <include/include/gpiod.h>
#include "include/include/OpenGL.h"
#include "include/include/shp_prf.h"

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "include/include/thick_log.h"

// key_scr == 0 :- Get the value from scrollbar
// key_scr == 1 :- Get the value from button keypad
// key_scr == 2 :- Get the value from touch keypad

// #include "include/include/gpiod.h"
//--------
/*MENU 0*/
//--------
// #define ARRAY_SIZE(a) (sizeof(a) / sizeof((a)[0]))
// #define ARRAY_SIZEL(a) (sizeof(a) / sizeof((a)[0]))
#define ARRAY_SIZE(a) (sizeof(a) / sizeof((a)[0]))

char Memext[15][10] = {"asc", "cal", "tfd", "csc", "thk", "bsc", "6", "7", "8", "9", "rep"};
int Mem_no[10] = {10, 20, 30, 40, 50, 60, 70, 80, 90, 100};

int bt1, bt2, bt3, bt4, amp;
double Val_f;
unsigned char Ctrreg0 = 0x01; //
unsigned char ENCRST_reg = 0x0;
unsigned char Ctr_reg1;

uint8_t tx_cmd[4096] = {
	// uint8_t tx_cmd[512] = {
	0xA5,
	0xAA,
	0xFF,
	0xFF,
	0xFF,
	0xFF,
	0xAA,
	0x00,
	0x00,
	0x00,
	0x00,
	0x95,
	0xAA,
	0xAA,
	0xFF,
	0xFF,
	0xFF,
	0xFF,
	0xAA,
	0xFF,
	0xAA,
	0xFF,
	0xFF,
	0xFF,
	0xAA,
	0xFF,
	0xFF,
	0xAA,
	0xFF,
	0xFF,
	0xDE,
	0xAD,
	0xBE,
	0xEF,
	0xBA,
	0xAA,
	0x00,
	0x0D,
};

uint8_t rx_cmd[4096] = {
	0,
};

// extern struct OGLData ogl;
// int Tx_nod=16;
extern uint8_t tx_cmd[];
extern bool Color_update;
extern int Batt_val;
extern gboolean time_frame_flag;

char Dsp_Str[15];
int Key_stp = 1;
int Key_Scn_code = 0;
int tx_bufidx;

extern int asc_cur_pos;
extern int thk_dim_type;
extern GLubyte row_y[256];
int bsc_flg = 0;
extern FILE *bsc_fp;

// static
void Send_SPI(int tx_nofd); // void Send_SPI();
void Gain_set(int chanlc, int Gainc, int freqc);
void Dav_out(int chanlc, int Dacno, int Vdata);
void Cal_Range_tbl_all(int Rangc, int Veloc);
void Set_dly_all(int zero_c, int dly_rc, int Velo);
void Write_data(int regAddr, unsigned char wData);
unsigned char Read_data(int regAddr);
void COLOR_f(int key_t);
void COLOR_Theme_f(int key_t);
void Cal_Gate(); // Cal Gate related Peramatere
void Cal_Tval();
void Cal_vertices(); // Calculate Verteces for Filled/Envelop/Dynmaic etc

void DAC_Copy_for_Disp(int crvno); // Copy DAC points data for the Display

int Avg = 1, Maxv = 1;

int Gate_Adjust(int key_t, int gstad);								// Adjust Gate Start Value
void toarry(long value, int A_pos, int pre, int dot_p, char *unit); /* Decimal Point Position */

double zoom_val = 1.0;
double zoom_ratio = 1.0;

void vertical_ruler(void);
void horizontal_ruler(void);
double zoom_in_out_function(int val);

/***********************************************************************************/
/*********************************ZERO FUNCTION*************************************/
/***********************************************************************************/
void Zero_f(int key_t)
{
	char *unitd[] = {" us "}; // Displays 00.00 99.99 , 100.0 to 199.9
	char *dec_num[10];
	char buffer[40];
	float tmpzero_val = 0.0;

	zero_val = val_ary[ZERO_PERA];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
		gtk_adjustment_set_lower(adj, 0);
		gtk_adjustment_set_upper(adj, 19999);
		// gtk_adjustment_set_value(adj, zero_val);
	}

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from machine button keypad
		zero_val = zero_val + (key_t * Key_stp);

	//**********KEY_SCR = 2*********************
	if (key_scr == 2) // Get the value from touch keypad  The value will be 2.65 then we need to multiply it by 100 to get 265
	{
		tmpzero_val = key_array[ZERO_PERA];
		zero_val = tmpzero_val * 100;
	}

	if (zero_val < 200)
		zero_val = 200;
	else if (zero_val > 19999)
		zero_val = 19999;

	val_ary[ZERO_PERA] = zero_val;

	toarry(zero_val-200, 0, 0, 2, unitd[0]); //   (long value, int A_pos, int pre,int dot_p, char *unit), char *dstr;    /* Decimal Point Position */
	/*sprintf(buffer, "%d", zero_val);
	gtk_label_set_label(GTK_LABEL(t_label[0]), buffer);*/
	pos = (ZERO_PERA * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10; // strcpy(all_btnval[pos + 1],dec_num[0]);

	Set_dly_all(zero_val, Delay_rv, Mtlvel_val); // Set/Send Value  to FPGA  one count means one sample so here 0.02 us
}

/***********************************************************************************/
/*********************************RANGE FUNCTION************************************/
/***********************************************************************************/
void Range_f(int key_t)
{
	char *unitm[] = {" mm"}, *uniti[] = {" in"}; // tmp   Posi Array index of Range  its 3 for Range Value
	char buffer[40];
	int ndgt, posi;
	long temp = 1, rstp;
	float temprng_val = 0.0;

	gchar dec_num[10];

	if (Unit_v == INCH) // If unit is INCH
	{
		gtk_adjustment_set_lower(adj, 100);
		gtk_adjustment_set_upper(adj, 3100); // gtk_adjustment_set_upper(adj, 100000);
	}
	else // If Unit is MM
	{
		gtk_adjustment_set_lower(adj, 250);
		gtk_adjustment_set_upper(adj, 11800); // gtk_adjustment_set_upper(adj, 100000);
	}
	Range_v = val_ary[RANGE_PERA];

	if (Unit_v == MM) // For Unit as MM
	{
		//********** KEY_SCR = 0 *********************
		if (key_scr == 0) // Get the value from scrollbar
		{
			Range_v = scr_val;
			temp = scr_val;
			if (scr_val < 1000)
			{
				Range_v = scr_val;
			}
			else if (scr_val < 1900)
			{
				temp = (scr_val - 1000);
				Range_v = 1000 + (10 * temp);
			}
			else if (scr_val < 100899)
			{
				temp = (scr_val - 1900);
				Range_v = 10000 + (100 * temp);
			}
		}

		//********** KEY_SCR = 1 *********************

		if (key_scr == 1) // Get the value from button keypad
		{
			rstp = 1;
			if (key_t == 1) // If increment then follow below
			{
				if (Range_v >= 1000 && Range_v < 10000)
				{
					rstp = 10;
				}
				if (Range_v >= 10000)
				{
					rstp = 100;
					if (Key_stp == 10)
						temp = 1;
				} // Coarse Step of  50.00 mm
				if (Range_v >= 100000 && Key_stp == 10) //   > 1000.00 mm
				{
					temp = 5;
				} // Coarse step of 500.00 mm

				// g_print("key_t == 1 : %d\n", Range_v);
			}
			else
			{
				if (Range_v > 1000 && Range_v <= 10000)
				{
					rstp = 10;
				}
				if (Range_v > 10000)
				{
					rstp = 100;
					if (Key_stp == 10)
						temp = 1;
				} // Coarse Step of 50 mm
				if (Range_v > 100000 && Key_stp == 10) //   > 1000.00 mm
				{
					temp = 5;
				} // 10*50*100 =  500.00 Step of 500mm
				// g_print("key_t == -1 : %d\n", Range_v);
			}
			temp = temp * Key_stp;
			temp = key_t * temp * rstp;
			Range_v = Range_v + temp;
			//g_print("key_t == 0 : %d\n", Range_v);
		}

		//********** KEY_SCR = 2 *********************

		if (key_scr == 2) // Get the value from touch keypad
		{
			temprng_val = key_array[RANGE_PERA];

			if (Range_v > 1000 && Range_v <= 10000)
			{
				rstp = 10;
			}
			if (Range_v > 10000)
			{
				rstp = 100;
				if (Key_stp == 10)
					temp = 1;
			} // Coarse Step of  50.00 mm
			if (Range_v > 100000 && Key_stp == 10) //   > 1000.00 mm
			{
				temp = 5;
			}

			Range_v = temprng_val * 100; //+(temp * rstp);
		}

		if (Range_v > MAX_RangeMM) // Max Range Limit
			Range_v = MAX_RangeMM; //
		if (Range_v < MIN_Range)   // 2.50 Minimum Range Limit
			Range_v = MIN_Range;

		val_ary[RANGE_PERA] = Range_v;
		//
		ndgt = 0;
		if (Range_v >= 1000 && Range_v < 10000) // When Range is higher then 100 mm then Fraction of range to be round of
		{
			ndgt = Range_v % 10;
			Range_v = Range_v - ndgt;
			ndgt = 1;
		}
		if (Range_v >= 10000)
		{
			ndgt = Range_v % 100;
			Range_v = Range_v - ndgt;
			ndgt = 2;
		}
		toarry(Range_v, posi, ndgt, 2, unitm[0]);
	}
	else if (Unit_v == INCH) // If unit is selected to Inch
	{
		//********** KEY_SCR = 0 *********************
		if (key_scr == 0) // If Scroll Bar is changed
		{
			temp = scr_val;
			if (scr_val < 1001)
			{
				Range_v = scr_val;
			}
			else if (scr_val < 1901)
			{
				temp = (scr_val - 1000);
				Range_v = 1000 + (10 * temp);
			}
			else if (scr_val < 2801)
			{
				temp = (scr_val - 1900);
				Range_v = 10000 + (100 * temp);
			}
			else
			{
				temp = (scr_val - 2800);
				Range_v = 100000 + (1000 * temp);
			}
		} // If Scroll bar is changed

		//********** KEY_SCR = 1 *********************

		if (key_scr == 1) // If key is pressed
		{
			Range_v = val_ary[RANGE_PERA];
			rstp = 1;
			if (key_t == 1 || key_t == -1) // If increment then follow below
			{
				if (Range_v > 1000 && Range_v < 10000)
				{
					rstp = 10;
				}
				else if (Range_v >= 10000 && Range_v < 100000)
				{
					rstp = 100;
				}
				else if (Range_v >= 100000)
				{
					rstp = 1000;
				}
			}

			temp = Key_stp;
			temp = key_t * temp * rstp;
			Range_v = Range_v + temp;
		}

		//********** KEY_SCR = 2 *********************

		if (key_scr == 2)
		{
			temprng_val = key_array[RANGE_PERA];
			Range_v = temprng_val * 1000;
		}
		if (Range_v > MAX_RangeINCH)
		{
			Range_v = MAX_RangeINCH;
		} //  0.100  to  390.000
		if (Range_v < 100)
		{
			Range_v = 100;
		} //   Display 0.100  to 390.0
		val_ary[RANGE_PERA] = Range_v;
		// When Range is higher then Fraction of range to be round of
		ndgt = 0;
		if (Range_v >= 1000 && Range_v < 10000)
		{
			ndgt = 1;
			rstp = Range_v % 10;
			Range_v = Range_v - rstp;
		}
		if (Range_v >= 10000 && Range_v < 100000)
		{
			ndgt = 2;
			rstp = Range_v % 100;
			Range_v = Range_v - rstp;
		}
		if (Range_v >= 100000)
		{
			ndgt = 3;
			rstp = Range_v % 1000;
			Range_v = Range_v - rstp;
		}
		val_ary[RANGE_PERA] = Range_v;
		toarry(Range_v, posi, ndgt, 3, uniti[0]);
	}

	/*sprintf(buffer, "%d", Range_v);
	gtk_label_set_label(GTK_LABEL(t_label[0]), buffer);*/

	pos = (RANGE_PERA * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10; // strcpy(all_btnval[pos + 3], dec_num);

	Cal_Range_tbl_all(Range_v, Mtlvel_val); // Calculate and send data to FPGA
	PRF_Cal();
	if (val_ary[BEAM_PROF_PERA] == 2)
	{
		Beam_Profile_Cal_f();
	} // Calculate Near Field Value and Angle

	ColorLeg_refresh(); // Recalculate and Refresh Color Leg On Screen
	horizontal_ruler();
	vertical_ruler();
	gl_clear_color_background_data(width_sh, height_sh);
}

/************************************************************************************/
/*******************************VEL_f FUNCTION********************************/
/************************************************************************************/

void Velo_f(int key_t) // Velocity Function
{
	char *unitm[] = {"M/S "}, *uniti[] = {"    "};

	if (Unit_v == INCH) // If unit is INCH
	{
		gtk_adjustment_set_lower(adj, 400);	 // If unit is inch
		gtk_adjustment_set_upper(adj, 6000); // gtk_adjustment_set_upper(adj, 100000);
	}
	else // If Unit is MM
	{
		gtk_adjustment_set_lower(adj, 1000);
		gtk_adjustment_set_upper(adj, 16000); // gtk_adjustment_set_upper(adj, 100000);
	}

	Mtlvel_val = val_ary[VELO_PERA];

	//**********KEY_SCR = 1*********************

	if (key_scr == 1) // Get the value from button keypad
	{
		if (Unit_v == MM) // When Unit is MM selected
		{
			if (key_t == 1) // If Step is pressed then scroll through Predefine steps
			{
				if (Key_stp == 10)
				{
					if (Mtlvel_val < 1450)
					{
						Mtlvel_val = 1450;
					}
					else if (Mtlvel_val < 1600)
					{
						Mtlvel_val = 1600;
					}
					else if (Mtlvel_val < 2000)
					{
						Mtlvel_val = 2000;
					}
					else if (Mtlvel_val < 2730)
					{
						Mtlvel_val = 2730;
					}
					else if (Mtlvel_val < 3000)
					{
						Mtlvel_val = 3000;
					}
					else if (Mtlvel_val < 3130)
					{
						Mtlvel_val = 3130;
					}
					else if (Mtlvel_val < 3250)
					{
						Mtlvel_val = 3250;
					}
					else if (Mtlvel_val < 4000)
					{
						Mtlvel_val = 4000;
					}
					else if (Mtlvel_val < 5000)
					{
						Mtlvel_val = 5000;
					}
					else if (Mtlvel_val < 5920)
					{
						Mtlvel_val = 5920;
					}
					else if (Mtlvel_val < 6000)
					{
						Mtlvel_val = 6000;
					}
					else if (Mtlvel_val < 6320)
					{
						Mtlvel_val = 6320;
					}
					else if (Mtlvel_val < 7000)
					{
						Mtlvel_val = 7000;
					}
					else if (Mtlvel_val >= 7000)
					{
						Mtlvel_val = Mtlvel_val + 1000;
						if (Mtlvel_val > 16000)
						{
							Mtlvel_val = 16000;
						}
						if (Mtlvel_val > 15000 && Mtlvel_val < 16000)
						{
							Mtlvel_val = 15000;
						}
						if (Mtlvel_val > 14000 && Mtlvel_val < 15000)
						{
							Mtlvel_val = 14000;
						}
						if (Mtlvel_val > 13000 && Mtlvel_val < 14000)
						{
							Mtlvel_val = 13000;
						}
						if (Mtlvel_val > 12000 && Mtlvel_val < 13000)
						{
							Mtlvel_val = 12000;
						}
						if (Mtlvel_val > 11000 && Mtlvel_val < 12000)
						{
							Mtlvel_val = 11000;
						}
						if (Mtlvel_val > 10000 && Mtlvel_val < 11000)
						{
							Mtlvel_val = 10000;
						}
						if (Mtlvel_val > 9000 && Mtlvel_val < 10000)
						{
							Mtlvel_val = 9000;
						}
						if (Mtlvel_val > 8000 && Mtlvel_val < 9000)
						{
							Mtlvel_val = 8000;
						}
					}
				}
				else // If Step key is not pressed
				{
					Mtlvel_val = Mtlvel_val + 1;
				}
			}
			if (key_t == -1)
			{
				if (Key_stp == 10) // Hot is pressed then scroll through predefined steps
				{
					Mtlvel_val = Mtlvel_val - 1;
					if (Mtlvel_val < 1451)
					{
						Mtlvel_val = 1000;
					}
					else if (Mtlvel_val < 1601)
					{
						Mtlvel_val = 1450;
					}
					else if (Mtlvel_val < 2001)
					{
						Mtlvel_val = 1600;
					}
					else if (Mtlvel_val < 2731)
					{
						Mtlvel_val = 2000;
					}
					else if (Mtlvel_val < 3001)
					{
						Mtlvel_val = 2730;
					}
					else if (Mtlvel_val < 3131)
					{
						Mtlvel_val = 3000;
					}
					else if (Mtlvel_val < 3251)
					{
						Mtlvel_val = 3130;
					}
					else if (Mtlvel_val < 4001)
					{
						Mtlvel_val = 3250;
					}
					else if (Mtlvel_val < 5001)
					{
						Mtlvel_val = 4000;
					}
					else if (Mtlvel_val < 5921)
					{
						Mtlvel_val = 5000;
					}
					else if (Mtlvel_val < 6001)
					{
						Mtlvel_val = 5920;
					}
					else if (Mtlvel_val < 6321)
					{
						Mtlvel_val = 6000;
					}
					else if (Mtlvel_val < 7001)
					{
						Mtlvel_val = 6320;
					}
					else if (Mtlvel_val < 8001)
					{
						Mtlvel_val = 7000;
					}
					else if (Mtlvel_val < 9001)
					{
						Mtlvel_val = 8000;
					}
					else if (Mtlvel_val < 10001)
					{
						Mtlvel_val = 9000;
					}
					else if (Mtlvel_val < 11001)
					{
						Mtlvel_val = 10000;
					}
					else if (Mtlvel_val < 12001)
					{
						Mtlvel_val = 11000;
					}
					else if (Mtlvel_val < 13001)
					{
						Mtlvel_val = 12000;
					}
					else if (Mtlvel_val < 14001)
					{
						Mtlvel_val = 13000;
					}
					else if (Mtlvel_val < 15001)
					{
						Mtlvel_val = 14000;
					}
					else if (Mtlvel_val < 16001)
					{
						Mtlvel_val = 15000;
					}
					else
					{
					}
				} // Key_stp  over
				else // If Down key is pressed and Step key is not pressed
				{
					Mtlvel_val = Mtlvel_val + key_t;
				}
			}
		}
		if (Unit_v == INCH) // If Unit is Inch
		{
			if (key_t == 1)
			{
				if (Key_stp == 10)
				{
					if (Mtlvel_val < 571)
					{
						Mtlvel_val = 571;
					}
					else if (Mtlvel_val < 630)
					{
						Mtlvel_val = 630;
					}
					else if (Mtlvel_val < 1000)
					{
						Mtlvel_val = 1000;
					}
					else if (Mtlvel_val < 1080)
					{
						Mtlvel_val = 1080;
					}
					else if (Mtlvel_val < 1230)
					{
						Mtlvel_val = 1230;
					}
					else if (Mtlvel_val < 1320)
					{
						Mtlvel_val = 1320;
					}
					else if (Mtlvel_val < 1500)
					{
						Mtlvel_val = 1500;
					}
					else if (Mtlvel_val < 2000)
					{
						Mtlvel_val = 2000;
					}
					else if (Mtlvel_val < 2330)
					{
						Mtlvel_val = 2330;
					}
					else if (Mtlvel_val < 2490)
					{
						Mtlvel_val = 2490;
					}
					else if (Mtlvel_val < 2500)
					{
						Mtlvel_val = 2500;
					}
					else if (Mtlvel_val < 3000)
					{
						Mtlvel_val = 3000;
					}
					else if (Mtlvel_val >= 3000)
					{
						Mtlvel_val = Mtlvel_val + 500;
						if (Mtlvel_val >= 3000 && Mtlvel_val < 3500)
						{
							Mtlvel_val = 3500;
						}
						if (Mtlvel_val > 3500 && Mtlvel_val < 4000)
						{
							Mtlvel_val = 3500;
						}
						if (Mtlvel_val > 4000 && Mtlvel_val < 4500)
						{
							Mtlvel_val = 4000;
						}
						if (Mtlvel_val > 4500 && Mtlvel_val < 5000)
						{
							Mtlvel_val = 4500;
						}
						if (Mtlvel_val > 5000 && Mtlvel_val < 5500)
						{
							Mtlvel_val = 5000;
						}
						if (Mtlvel_val > 5500 && Mtlvel_val < 6000)
						{
							Mtlvel_val = 5500;
						}
						if (Mtlvel_val > 6000)
						{
							Mtlvel_val = 6000;
						}
					}
				}
				else // If Key_stp=1
				{
					Mtlvel_val = Mtlvel_val + key_t;
				}
			}
			if (key_t == -1) // Down Key is pressed
			{
				if (Key_stp == 10)
				{
					if (Mtlvel_val < 572)
					{
						Mtlvel_val = 400;
					}
					else if (Mtlvel_val < 631)
					{
						Mtlvel_val = 571;
					}
					else if (Mtlvel_val < 1001)
					{
						Mtlvel_val = 630;
					}
					else if (Mtlvel_val < 1081)
					{
						Mtlvel_val = 1000;
					}
					else if (Mtlvel_val < 1231)
					{
						Mtlvel_val = 1080;
					}
					else if (Mtlvel_val < 1321)
					{
						Mtlvel_val = 1230;
					}
					else if (Mtlvel_val < 1501)
					{
						Mtlvel_val = 1320;
					}
					else if (Mtlvel_val < 2001)
					{
						Mtlvel_val = 1500;
					}
					else if (Mtlvel_val < 2331)
					{
						Mtlvel_val = 2000;
					}
					else if (Mtlvel_val < 2491)
					{
						Mtlvel_val = 2330;
					}
					else if (Mtlvel_val < 2501)
					{
						Mtlvel_val = 2490;
					}
					else if (Mtlvel_val < 3001)
					{
						Mtlvel_val = 2500;
					}
					else if (Mtlvel_val < 3501)
					{
						Mtlvel_val = 3000;
					}
					else if (Mtlvel_val < 4001)
					{
						Mtlvel_val = 3500;
					}
					else if (Mtlvel_val < 4501)
					{
						Mtlvel_val = 4000;
					}
					else if (Mtlvel_val < 5001)
					{
						Mtlvel_val = 4500;
					}
					else if (Mtlvel_val < 5501)
					{
						Mtlvel_val = 5000;
					}
					else if (Mtlvel_val < 6000)
					{
						Mtlvel_val = 5500;
					}
					else
					{
						Mtlvel_val = Mtlvel_val - 1000;
					}
				}
				else
				{
					Mtlvel_val = Mtlvel_val + key_t;
				}
			}
		}
	} // key_scr == 1  over

	//**********KEY_SCR = 0*********************  Scroll Bar is changed
	if (key_scr == 0) // Get the value from scrollbar
	{
		Mtlvel_val = scr_val;
	}

	if (Unit_v == MM)
	{
		if (Mtlvel_val < 1000)
		{
			Mtlvel_val = 1000;
		}
		if (Mtlvel_val > 16000)
		{
			Mtlvel_val = 16000;
		}
		val_ary[VELO_PERA] = Mtlvel_val;
		toarry((long)Mtlvel_val, pos, 0, 0, unitm[0]);
	}
	else if (Unit_v == INCH)
	{
		if (Mtlvel_val < 400)
		{
			Mtlvel_val = 400;
		}
		if (Mtlvel_val > 6000)
		{
			Mtlvel_val = 6000;
		}
		val_ary[VELO_PERA] = Mtlvel_val;
		toarry((long)Mtlvel_val, pos, 0, 1, uniti[0]);
	}

	pos = (VELO_PERA * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
	Cal_Range_tbl_all(Range_v, Mtlvel_val); // Calculate and send data to FPGA

	if (val_ary[BEAM_PROF_PERA] == 2)
	{
		Beam_Profile_Cal_f();
	} // Calculate Near Field Value and Angle
	gl_clear_color_background_data(width_sh, height_sh);
	PRF_Cal();
}

/***********************************************************************************/
/**********************************DELAY FUNCTION***********************************/
/***********************************************************************************/
void Delay_f(int key_t)
{
	char *unitm[] = {" mm"}, *uniti[] = {" in"};
	char buffer[40];
	float tmpDelay_rv = 0.0;
	gchar dec_num[8];
	int astp = 1, temp;
	int ndgt = 0, posi = 0;

	if (Unit_v == INCH) // If unit is INCH
	{
		gtk_adjustment_set_lower(adj, 0); // If unit is inch
		gtk_adjustment_set_upper(adj, 2100); // gtk_adjustment_set_upper(adj, 100000);
	}
	else // If Unit is MM
	{
		gtk_adjustment_set_lower(adj, 0);
		gtk_adjustment_set_upper(adj, 1920); // gtk_adjustment_set_upper(adj, 100000);
	}

	Delay_rv = val_ary[DELAY_PERA];

	//**********KEY_SCR = 0*********************

	if (key_scr == 0) // Get the value from scrollbar
	{
		if (Unit_v == MM) // If Unit is MM Delay_rv=scr_val;
		{
			Delay_rv = scr_val;
			temp = scr_val;
			if (scr_val < 1000)
			{
				Delay_rv = scr_val;
			}
			else if (scr_val < 1900)
			{
				temp = (scr_val - 1000);
				Delay_rv = 1000 + (10 * temp);
			}
			else if (scr_val < 100899)
			{
				temp = (scr_val - 1900);
				Delay_rv = 10000 + (100 * temp);
			}
		}
		if (Unit_v == INCH) // If Unit is MM Delay_rv=scr_val;
		{
			Delay_rv = scr_val;
			temp = scr_val;
			if (scr_val < 1000)
			{
				Delay_rv = scr_val;
			}
			else if (scr_val < 1900)
			{
				temp = (scr_val - 1000);
				Delay_rv = 1000 + (10 * temp);
			}
			else if (scr_val < 100899)
			{
				temp = (scr_val - 1900);
				Delay_rv = 10000 + (100 * temp);
			}
		}
	}

	//**********KEY_SCR = 1*********************

	if (key_scr == 1) // Get the value from button keypad
	{
		if (Unit_v == MM) // If Unit is MM
		{
			if (key_t == 1)
			{
				if (Delay_rv >= 1000)
				{
					astp = 10;
				}
				if (Delay_rv >= 10000 && Delay_rv < 100000)
				{
					astp = 100;
				}
				if (Delay_rv >= 100000)
				{
					astp = 1000;
				}
			}
			else
			{
				if (Delay_rv > 1000)
				{
					astp = 10;
				}
				if (Delay_rv > 10000 && Delay_rv <= 100000)
				{
					astp = 100;
				}
				if (Delay_rv > 100000)
				{
					astp = 1000;
				}
			}
			Delay_rv = Delay_rv + (key_t * astp * Key_stp); //  -10.00 mm to      2000mm
		}

		if (Unit_v == INCH) // If Unit is MM
		{
			if (key_t == 1)
			{
				if (Delay_rv >= 1000)
				{
					astp = 10;
				}
				if (Delay_rv >= 10000 && Delay_rv < 100000)
				{
					astp = 100;
				}
				if (Delay_rv >= 100000)
				{
					astp = 1000;
				}
			}
			else
			{
				if (Delay_rv > 1000)
				{
					astp = 10;
				}
				if (Delay_rv > 10000 && Delay_rv <= 100000)
				{
					astp = 100;
				}
				if (Delay_rv > 100000)
				{
					astp = 1000;
				}
			}
			Delay_rv = Delay_rv + (key_t * astp * Key_stp); //  -0.300  to 40.000  Inche
		}
	}

	//********** KEY_SCR = 2 *********************

	if (key_scr == 2) // Get the value from touch keypad
	{
		if (Unit_v == MM)
		{
			tmpDelay_rv = key_array[DELAY_PERA];
			if (tmpDelay_rv >= 1000)
			{
				astp = 10;
			}
			if (tmpDelay_rv >= 10000 && tmpDelay_rv < 100000)
			{
				astp = 100;
			}
			if (tmpDelay_rv >= 100000)
			{
				astp = 1000;
			}

			if (tmpDelay_rv < 1000)
			{
				Delay_rv = tmpDelay_rv * astp * 100;
			}
			else
			{
				Delay_rv = tmpDelay_rv * astp * 10;
			}

			if (Delay_rv > 500000)
			{
				Delay_rv = 500000;
			}
			if (Delay_rv >= 1000 && Delay_rv < 10000)
			{
				ndgt = Delay_rv % 10;
				Delay_rv = Delay_rv - ndgt;
				ndgt = 1;
			} // When Value is higher then 10 mm then Fraction to be round of
			if (Delay_rv < 0)
			{
				Delay_rv = 0;
			}
			if (Delay_rv >= 10000)
			{
				ndgt = Delay_rv % 100;
				Delay_rv = Delay_rv - ndgt;
				ndgt = 2;
			}
			toarry(Delay_rv, posi, ndgt, 2, unitm[0]); //   (long value, int A_pos, int pre,int dot_p, char *unit), char *dstr;    /* Decimal Point Position */
			val_ary[DELAY_PERA] = Delay_rv;
		}

		if (Unit_v == INCH)
		{
			tmpDelay_rv = key_array[DELAY_PERA];

			if (tmpDelay_rv >= 1000)
			{
				astp = 10;
			}
			if (tmpDelay_rv >= 10000 && tmpDelay_rv < 100000)
			{
				astp = 100;
			}
			if (tmpDelay_rv >= 100000)
			{
				astp = 1000;
			}

			Delay_rv = tmpDelay_rv * astp * 1000;

			if (Delay_rv < -1000)
			{
				Delay_rv = -1000;
			}
			if (Delay_rv > 30000)
			{
				Delay_rv = 30000;
			}

			if (Delay_rv >= 1000 && Delay_rv < 10000)
			{
				ndgt = Delay_rv % 10;
				Delay_rv = Delay_rv - ndgt;
				ndgt = 1;
			} // When Value is higher then Fraction of value to be round of
			if(Delay_rv < 0) 
			{
				Delay_rv = 0;
			}
			if (Delay_rv >= 10000)
			{
				ndgt = Delay_rv % 100;
				Delay_rv = Delay_rv - ndgt;
				ndgt = 2;
			}
			toarry(Delay_rv, posi, ndgt, 3, uniti[0]);
			val_ary[DELAY_PERA] = Delay_rv;
		}
	}

	pos = m_val * 10;
	ndgt = 0;
	if (Unit_v == INCH)
	{
		if (Delay_rv < 0)
		{
			Delay_rv = 0;
		}
		if (Delay_rv > 30000)
		{
			Delay_rv = 30000;
		}
		if (Delay_rv >= 1000 && Delay_rv < 10000)
		{
			ndgt = Delay_rv % 10;
			Delay_rv = Delay_rv - ndgt;
			ndgt = 1;
		} // When Value is higher then Fraction of value to be round of
		if (Delay_rv >= 10000)
		{
			ndgt = Delay_rv % 100;
			Delay_rv = Delay_rv - ndgt;
			ndgt = 2;
		}
		toarry(Delay_rv, posi, ndgt, 3, uniti[0]);
		val_ary[DELAY_PERA] = Delay_rv; //
	}
	else
	{
		if (Delay_rv < 0) // Minimum = -50 mm
		{
			Delay_rv = 0;
		}
		// if (Delay_rv > 12000)
		// {
		// 	Delay_rv = 12000;
		// }  // Removed as Delay wanted till 5000
		if (Delay_rv > 500000) // Maximum till 5000 mm
		{
			Delay_rv = 500000;
		}
		if (Delay_rv >= 1000 && Delay_rv < 10000)
		{
			ndgt = Delay_rv % 10;
			Delay_rv = Delay_rv - ndgt;
			ndgt = 1;
		} // When Value is higher then 10 mm then Fraction to be round of
		if (Delay_rv >= 10000)
		{
			ndgt = Delay_rv % 100;
			Delay_rv = Delay_rv - ndgt;
			ndgt = 2;
		}
		toarry(Delay_rv, posi, ndgt, 2, unitm[0]);
		val_ary[DELAY_PERA] = Delay_rv;
	}

	pos = (DELAY_PERA * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str); // pos=pos % 10;
	/*sprintf(buffer, " %d", Delay_rv);
	gtk_label_set_label(GTK_LABEL(t_label[0]), buffer);*/

	Set_dly_all(zero_val, Delay_rv, Mtlvel_val); //   Set_dly_all();   // Set/Send Value  to FPGA

	if (val_ary[BEAM_PROF_PERA] == 2)
	{
		Beam_Profile_Cal_f(); // Calculate Near Field Value and Angle
	}
	ColorLeg_refresh(); // Recalculate and Refresh Color Leg On Screen
	horizontal_ruler();
	vertical_ruler();
	gl_clear_color_background_data(width_sh, height_sh);
}

/***********************************************************************************/
/***********************************************************************************/
void Cal_Range_tbl_all(int Rangc, int Veloc) // Calculates Range compress factor...
{											 // long int temp; //temp     //   st= 10 us for 250 samples when 1 to 1 means 0000ffff is seted
	long int st, td, data;					 //   required time to display  td= (2*range)/velocity
	unsigned char utemp;					 //,Ch_vh,Ch_vl;    // required factor =  (st*0xffff) / td
	int i, j;
	int ds;

	//   Ch_vh=0x00; //Ch_vl=0x00;
	//   tx_bufidx=0;
	//   utemp=0x15;  //0x15|Ch_vl;    // 15 Write Address where data to be written  0x15 cccca aaaaa (C for channel A means Pera address)
	// Write_data(r_addR1, utemp);  // LSB of address to be write in R1
	//   utemp=0x00;   //0x00|Ch_vh;
	// Write_data(r_addR2, utemp);  // MSB of address to be write in R2
	//          //**** Write one by one byte LSB first in same Reg 1 write address increments auto in FPGA
	// to improove calculation accuracy divide in last by velocity
	td = Veloc / Rangc;
	if (td < 4)
	{
		// In Range Expansion values gets change so recalcute it
		// for (i=0;i<256;i++){j=i*ASCAN_WIDTH; pntArray_dsp[i].x=j/250; } //     2.6*(i+5);

		td = 4 * Rangc; // td=2*Rangc;    // to get time in us = Range in mm * 1000   / velo met/sec
		st = Veloc * 0xffff;
		st = st / td; // required compress factor

		Ctrreg0 = Ctrreg0 & 0xDF;
		ds = 0;
		tx_cmd[ds++] = 0x1B;
		tx_cmd[ds++] = 0x080;
		tx_cmd[ds++] = Ctrreg0;
		tx_cmd[ds++] = 0x1B; // 1B 80 11 1B   Command for Interpolation OFF .
							 // Range_Expand=false;
	}
	else // Interpolation to be activate
	{
		if (td < 16) //

			td = 16 * Rangc; // td=2*Rangc;    // to get time in us = Range in mm * 1000   / velo met/sec
		st = Veloc * 0xffff;
		st = st / td;
		ds = 0;
		Ctrreg0 = Ctrreg0 & 0xDF;
		Ctrreg0 = Ctrreg0 | 0x20;
		tx_cmd[ds++] = 0x1B;
		tx_cmd[ds++] = 0x080;
		tx_cmd[ds++] = Ctrreg0;
		tx_cmd[ds++] = 0x1B; // 1B 80 31 1B   Command for Interpolation ON. // 1B 80 11 1B   Command for Interpolation OFF .
		if (st > 0xffff)
		{
			st = 0xffff;
			//  Range_Expand=true;    // If Range Expand is required then true else its false
		}
	}

	Send_SPI(ds); // Send data

	tx_bufidx = 0;
	utemp = 0x15;				// 0x15|Ch_vl; // 15 Write Address where data to be written  0x15 cccca aaaaa (C for channel A means Pera address)
	Write_data(r_addR1, utemp); // LSB of address to be write in R1
	utemp = 0x00;				// 0x00|Ch_vh;
	Write_data(r_addR2, utemp); // MSB of address to be write in R2

	data = st;
	utemp = (uint8_t)data;		// CMP by 4 1B41151B1B42001B1B43001B1B43401B
	Write_data(r_addR3, utemp); // LSB 0 byte Register R1
	data = st >> 8;
	utemp = (uint8_t)data;		//
	Write_data(r_addR3, utemp); // LSB 1 byte Register R1
	data = st >> 16;
	utemp = (uint8_t)data;
	Write_data(r_addR3, utemp); // LSB 2 byte Register R1
	data = st >> 24;
	utemp = (uint8_t)data;
	Write_data(r_addR3, utemp); // MSB byte Register R1
	Send_SPI(tx_bufidx);

	// Prf_f(0);   // Refresh PRF value based on Range/Velocity Value
}

//******************************************************************************************
void Set_dly_all(int zero_c, int dly_rc, int velo) // calculate and set Sampling delay on base of Probe zero + Delay
{
	long int sm_dly, zerl; //  one count means one sample sample freq is 50Mhz so here 0.02 us per count
	unsigned char utemp, Ch_vl, Ch_vh;
	int data;
	long int Charge_Wcnt, Tx_Cnt, Tx_Dlycnt, ldata;

	sm_dly = dly_rc;
	ldata = velo; // Convert from range to Time t=Dly*1000*2/Velo  * Samp/us  50
	sm_dly = (sm_dly * 1000) / ldata;
	zerl = zero_c;
	zerl = zerl / 2;		// 1 count means
	sm_dly = zerl + sm_dly ; // dly_rc;
	tx_bufidx = 0;

	Ch_vh = 0x00;
	Ch_vl = 0x00;
	// ******When DATA written to FPGA last byte gets corrupted so send data in address sequence
	//******* Write Charge Width Cnt   Value to FPGA
	utemp = 0x09 | Ch_vl;		// 09 Write Address where data to be written  0x09 cccca aaaaa (C for channel A means Pera address)
	Write_data(r_addR1, utemp); // LSB of address to be write in R1
	utemp = 0x00 | Ch_vh;
	Write_data(r_addR2, utemp); // MSB of address to be write in R2
								//**** Write one by one byte LSB first in same Reg 1 write address increments auto in FPGA
	Charge_Wcnt = 0x0032;		// Default value 0x32
	data = Charge_Wcnt;
	utemp = (uint8_t)data;
	Write_data(r_addR3, utemp); // LSB 0 byte Register R1
	data = Charge_Wcnt >> 8;
	utemp = (uint8_t)data;
	Write_data(r_addR3, utemp); // MSB  byte Register R1

	//******* Write Tx Cnt   Value to FPGA
	utemp = 0x0B | Ch_vl;		// 0bWrite Address where data to be written  0x0B cccca aaaaa (C for channel A means Pera address)
	Write_data(r_addR1, utemp); // LSB of address to be write in R1
	utemp = 0x00 | Ch_vh;
	Write_data(r_addR2, utemp); // MSB of address to be write in R2
								//**** Write one by one byte LSB first in same Reg 1 write address increments auto in FPGA
	Tx_Dlycnt = 0x083+0x180;			// 0x3c   check tx value and fix it

	// Tx_Cnt=Tx_Dlycnt+0x0D ;   // Controls Tx pulse width
	// Tx_Cnt=Tx_Dlycnt+0x0C ;  // Default value  0x3F
	Tx_Cnt = Tx_Dlycnt + 0x08; // Default value  0x3F
	// Tx_Cnt=Tx_Dlycnt+0x20 ;  // Default value  0x3F
	data = Tx_Cnt;
	utemp = (uint8_t)data;
	Write_data(r_addR3, utemp); // LSB 0 byte Register R1
	data = Tx_Cnt >> 8;
	utemp = (uint8_t)data;
	Write_data(r_addR3, utemp); // MSB  byte Register R1

	//******* Write Tx Delay Cnt  Value to FPGA
	utemp = 0x0D | Ch_vl;		// 0dWrite Address where data to be written  0x0B cccca aaaaa (C for channel A means Pera address)
	Write_data(r_addR1, utemp); // LSB of address to be write in R1
	utemp = 0x00 | Ch_vh;
	Write_data(r_addR2, utemp); // MSB of address to be write in R2
								//**** Write one by one byte LSB first in same Reg 1 write address increments auto in FPGA
								// Tx_Dlycnt=0x003C;  // Default value //03C
	data = Tx_Dlycnt;
	utemp = (uint8_t)data;
	Write_data(r_addR3, utemp); // LSB 0 byte Register R1
	data = Tx_Dlycnt >> 8;
	utemp = (uint8_t)data;
	Write_data(r_addR3, utemp); // MSB  byte Register R1

	//*****  Write Delay Value to FPGA
	utemp = 0x0F | Ch_vl;		// 0f Write Address where data to be written  0x0F cccca aaaaa (C for channel A means Pera address)
	Write_data(r_addR1, utemp); // LSB of address to be write in R1
	utemp = 0x00 | Ch_vh;
	Write_data(r_addR2, utemp); // MSB of address to be write in R2
								//**** Write one by one byte LSB first in same Reg 1 write address increments auto in FPGA
	data = sm_dly;
	utemp = (uint8_t)data;
	Write_data(r_addR3, utemp); // LSB 0 byte Register R1
	data = sm_dly >> 8;
	utemp = (uint8_t)data;
	Write_data(r_addR3, utemp); // LSB 1 byte Register R1
	data = sm_dly >> 16;
	utemp = (uint8_t)data;
	Write_data(r_addR3, utemp); // LSB 2 byte Register R1
	data = sm_dly >> 24;
	utemp = (uint8_t)data;
	Write_data(r_addR3, utemp); // MSB byte Register R1
	Send_SPI(tx_bufidx);
}

//***********************************************************************************************
void toarry(long value, int A_pos, int pre, int dot_p, char *unit) /* Decimal Point Position */
{
	int i, dp;		 // Value to be display, Display posi of Array, No of digit after decimal point ,Decimal point position
	int m0 = 48, m1; // Unit to be appened to Value
	// LPSTR A_data;       // ="12345678";
	char buf[] = "          ";

	for (i = 0; i < 4; i++) // Clear Data Field
	{
		buf[i] = 32;
	}
	// buf[i++]=(uint8_t)*unit++; buf[i++]=(uint8_t)*unit++; buf[i++]=(uint8_t)*unit++;   // Append Unit Data
	dp = 0;
	if (value < 0)
	{
		value = -value;
		buf[dp++] = '-';
	}
	m1 = 48;
ckm6:
	if (value >= 1000000)
	{
		value = value - 1000000;
		m1++;
		goto ckm6;
	}
	if (m1 != 48 || dot_p == 6)
		buf[dp++] = m1; // m0 !=48 means leading Blank

	m0 = 48;
ckm5:
	if (value >= 100000)
	{
		value = value - 100000;
		m0++;
		goto ckm5;
	}
	if (m0 != 48 || dot_p == 5 || m1 != 48)
	{
		buf[dp++] = m0;
		m0 = 49;
	} // m0 !=48 means leading Blank

	if (pre == 5)
		goto prelmt;
	if (dot_p == 5) // If dot_p=4 then put Decimal point
		buf[dp++] = '.';

	m1 = 48;

ckm4:
	if (value >= 10000)
	{
		value = value - 10000;
		m1++;
		goto ckm4;
	}
	if (m1 != 48 || dot_p == 4 || m0 != 48)
	{
		buf[dp++] = m1;
		m0 = 32;
	} // m0 value other then 48 means no leading Blank
	if (pre == 4)
		goto prelmt;
	if (dot_p == 4) // If dot_p=4 then put Decimal point
		buf[dp++] = '.';
	m1 = 48;
ckm3:
	if (value >= 1000)
	{
		value = value - 1000;
		m1++;
		goto ckm3;
	}
	if (m0 != 48 || m1 != 48 || dot_p == 3)
	{
		buf[dp++] = m1;
		m0 = 32;
	}
	if (pre == 3)
		goto prelmt;
	if (dot_p == 3)
		buf[dp++] = '.'; // if dot_p= 3 then put decimal point
	m1 = 48;
ckm2:
	if (value >= 100)
	{
		value = value - 100;
		m1++;
		goto ckm2;
	}
	if (m0 != 48 || m1 != 48 || dot_p == 2) // leading no digit then put 0
	{
		buf[dp++] = m1;
		m0 = 32;
	}
	m0 = 48;
ckm1:
	if (value >= 10)
	{
		value = value - 10;
		m0++;
		goto ckm1;
	}
	if (pre == 2)
		goto prelmt;
	if (dot_p == 2) // If dot_p=2 then put decimal point
		buf[dp++] = '.';
	buf[dp++] = m0;
	if (pre == 1)
		goto prelmt;
	if (dot_p == 1) // If dot_p=1 then  put decimal point
		buf[dp++] = '.';
	m0 = 48 + value;
	buf[dp++] = m0;
prelmt:;

	buf[dp++] = (uint8_t)*unit++;
	buf[dp++] = (uint8_t)*unit++;
	buf[dp] = (uint8_t)*unit++; // Append Unit Data

	for (i = 0; i < 9; i++) // Clear Array and put NULL at end of array
	{
		Dsp_Str[i] = ' ';
	}
	Dsp_Str[9] = 0; // put NULL at end of array

	int dst = 8;
	for (i = dp; i > -1; i--)
	{
		Dsp_Str[dst--] = buf[i];
	}
}

//***********************************************************************************
void Write_data(int regAddr, unsigned char wData)
{
	unsigned char Adr;
	Adr = regAddr;
	tx_cmd[tx_bufidx++] = 0x1B;
	tx_cmd[tx_bufidx++] = Adr;
	tx_cmd[tx_bufidx++] = wData;
	tx_cmd[tx_bufidx++] = 0x1B;
}

/***********************************************************************************/
/*********************GAIN VAL TYPE CHANGE .1 .5 1 2 6 14***************************/
/***********************************************************************************/
void GainVal_chng(int key_t)
{
	pos = 0 * 10;
	char gvsum[30];

	if (key_t == 1)
	{
		if (Gn_stp == 1)
		{
			Gn_stp = 5;
		}
		else if (Gn_stp == 5)
		{
			Gn_stp = 10;
		}
		else if (Gn_stp == 10)
		{
			Gn_stp = 20;
		}
		else if (Gn_stp == 20)
		{
			Gn_stp = 60;
		}
		else if (Gn_stp == 60)
		{
			Gn_stp = 120;
		}
		else if (Gn_stp == 120)
		{
			Gn_stp = 140;
		}
		else if (Gn_stp == 140)
		{
			Gn_stp = 1;
		}
		else
		{
			Gn_stp = 10;
		}
	}
	if (key_t == -1)
	{
		if (Gn_stp == 140)
		{
			Gn_stp = 120;
		}
		else if (Gn_stp == 120)
		{
			Gn_stp = 60;
		}
		else if (Gn_stp == 60)
		{
			Gn_stp = 20;
		}
		else if (Gn_stp == 20)
		{
			Gn_stp = 10;
		}
		else if (Gn_stp == 10)
		{
			Gn_stp = 5;
		}
		else if (Gn_stp == 5)
		{
			Gn_stp = 1;
		}
		else if (Gn_stp == 1)
		{
			Gn_stp = 140;
		}
		else
		{
			Gn_stp = 10;
		}
	}

	// Display on LCD / Referesh in App pera  array
	if (Gn_stp == 5)
	{
		strcpy(gvsum, "GAIN .5");
	}
	else if (Gn_stp == 10)
	{
		strcpy(gvsum, "GAIN  1");
	}
	else if (Gn_stp == 20)
	{
		strcpy(gvsum, "GAIN  2");
	}
	else if (Gn_stp == 60)
	{
		strcpy(gvsum, "GAIN  6");
	}
	else if (Gn_stp == 120)
	{
		strcpy(gvsum, "GAIN 12");
	}
	else if (Gn_stp == 140)
	{
		strcpy(gvsum, "GAIN 14");
	}
	else
	{
		strcpy(gvsum, "GAIN .1");
	}

	strcpy(Gain_glbl, gvsum);
	strcat(gvsum, gstr_2);
	strcpy(all_btnval[pos + 8], gvsum);

	gtk_widget_set_name(btn_dv[8], btndv_css[8]);
}

/***********************************************************************************/
/*********************************GAIN VALUE CHANGE MENU 0**************************/
/***********************************************************************************/

void Gain_f(int key_t)
{
	int i, d, p, s;
	float tmpgain_val = 0.0;
	gchar dec_num[8];
	char buffer[50];

	if (Key_stp == 10)
	{
		GainVal_chng(key_t);
		return;
	} // If Step is pressed then changein Gain Step value

	Gain_v = val_ary[GAIN_PERA];
	gtk_adjustment_set_lower(adj, 10);
	gtk_adjustment_set_upper(adj, 1000);

	//********** KEY_SCR = 0 *********************
	if (key_scr == 0) // Get the value from scrollbar
	{
	}

	//********** KEY_SCR = 1 *********************

	if (key_scr == 1) // Get the value from button keypad
	{
		Gain_v = val_ary[GAIN_PERA];
		Gain_v = Gain_v + (key_t * Gn_stp); // gtk_adjustment_set_value(adj, Gain_v);   // if we enable this then it would call scroll move event so this fuction would get call twice so suitable solution to be implement
	} // Display Gain Value in Menu

	//********** KEY_SCR = 2 *********************
	if (key_scr == 2) // Get the value from touch keypad
	{
		if (tmpgain_val < 10)
		{
			tmpgain_val = 10;
		}
		if (tmpgain_val > 1000)
		{
			tmpgain_val = 1000;
		}
		// tmpgain_val = key_array[GAIN_PERA];
		tmpgain_val = key_array[(menu_v * 5) + btn_idx];
		Gain_v = tmpgain_val * 10;
	}
	if (Gain_v < 10)
	{
		Gain_v = 10;
	}
	if (Gain_v > 1000)
	{
		Gain_v = 1000;
	}
	val_ary[GAIN_PERA] = Gain_v;

	sprintf(snum, "%d", Gain_v);
	p = strlen(snum);
	if (p == 1)
	{
		dec_num[0] = ' ';
		dec_num[1] = ' ';
		dec_num[2] = '0';
		dec_num[3] = '.';
		dec_num[4] = snum[0];
		dec_num[5] = 'd';
		dec_num[6] = 'B';
		dec_num[7] = 0;
	}
	else if (p == 2)
	{
		dec_num[0] = ' ';
		dec_num[1] = ' ';
		dec_num[2] = snum[0];
		dec_num[3] = '.';
		dec_num[4] = snum[1];
		dec_num[5] = 'd';
		dec_num[6] = 'B';
		dec_num[7] = 0;
	}
	else if (p == 3)
	{
		dec_num[0] = ' ';
		dec_num[1] = snum[0];
		dec_num[2] = snum[1];
		dec_num[3] = '.';
		dec_num[4] = snum[2];
		dec_num[5] = 'd';
		dec_num[6] = 'B';
		dec_num[7] = 0;
	}
	else if (p == 4)
	{
		dec_num[0] = snum[0];
		dec_num[1] = snum[1];
		dec_num[2] = snum[2];
		dec_num[3] = '.';
		dec_num[4] = snum[3];
		dec_num[5] = 'd';
		dec_num[6] = 'B';
		dec_num[7] = 0;
	}
	else
	{
		dec_num[0] = snum[0];
		dec_num[1] = snum[1];
		dec_num[2] = snum[2];
		dec_num[3] = snum[3];
		dec_num[4] = snum[4];
		dec_num[5] = 'd';
		dec_num[6] = 'B';
		dec_num[7] = 0;
	}

	pos = (GAIN_PERA * 2) + 1;
	strcpy(all_btnval[pos], dec_num);
	pos = pos % 10;

	Gain_set(0, Gain_v, 0);
	Dgs_gain = (Gain_v + 180) - Dgs_gn; // Used when DGS is ON and Gain change then DGS curve height gets calculated on this basis
}

void Gain_set(int chanlc, int Gainc, int freqc)
{
	int VG1off, VG2off;
	int VGN1, VGN2, GStep;
	int Gn_offl, Gn_off2, Gn_off3;
	int Gn1_off_v = 0, Gn2_off_v = 0, Gn3_off_v = 0;
	int long templ;
	unsigned char Ch_vh, Ch_vl;

	if (Evaluate_val == 0 && (Dac_v == 2 || Dac_v == 3)) // IF DAC is ON or TCG ON then add DAC _tl correction
	{
		Gainc = Gainc + Dac_tlg_v;
	}

	if (Evaluate_val == 2 && (Dgs_onoff_v == 3)) // IF DGS is ON then add DGS _TL correction
	{
		Gainc = Gainc + Tl_corr_v;
	}

	if (Gainc > 1000)
	{
		Gainc = 1000;
	}

	// Gainc=Gainc+20+Add_Gain_v;    //add extra 4 dB   Now 10 db Reduced with compare to 60+60 addition now 40 is added so it is 10 dB reduced with compare to previous

	VG1off = 510;			  // 580 +110                   //   Minimum o/p volatge required 0.1 V
	VG2off = 510 + 219 + 400; //   580+110;

	if (Gainc <= 315) // 310    41dB    //  20dB/V selected  Vout= (3* Code)/4096
	{
		templ = Gainc;
		templ = templ * (4096 + 0); //+275        // 300 Code= (dB *4096) /(20*3)
		templ = templ / 600;
		VGN1 = templ;
		VGN2 = 0;
		GStep = 1;
	}
	else if (Gainc <= 630) // 73 db
	{
		templ = Gainc - 315;		// 310
		templ = templ * (4096 + 0); //  275  // Code= (dB *4096) /(20*3)
		templ = templ / 600;
		VGN1 = templ; //  +100              // 280  Step 1 Off set
		Gn_offl = (Gn1_off_v * 4096) / 600;
		VG1off = 510 + Gn_offl;
		VGN2 = 0;
		GStep = 2;
	}
	else if (Gainc <= 800) // 80 dB
	{
		templ = Gainc - 475;		// templ=Gains-480;      // comes to 16 db
		templ = templ * (4096 + 0); // 275             // 300 Code= (dB *4096) /(20*3)
		templ = templ / 600;
		VGN1 = templ + 0; // 240-20;     // 240-20
		Gn_off2 = (Gn2_off_v * 4096) / 600;
		VG1off = 510 + Gn_off2;
		// VG1off=510-0;
		VGN2 = 0;
		GStep = 3;
	}
	else if (Gainc <= 1200)
	{
		// VGN1=3091-200;  // 2185+240;
		VGN1 = 2218; // 2587
		templ = Gainc - 800;
		templ = templ * (4096 + 0); // 275             // 300 Code= (dB *4096) /(20*3)
		templ = templ / 600;
		VGN2 = templ;
		Gn_off3 = (Gn3_off_v * 4096) / 600;
		VG1off = 510 + Gn_off3;
		GStep = 3;
	}

	///************ Send Data to DAC  1
	VGN1 = VGN1 + VG1off;
	if (VGN1 > 4000)
		VGN1 = 4000;
	Dav_out(chanlc, 1, VGN1);

	VGN2 = VGN2 + VG2off; //*** Send Data to DAC  1
	TCG_offGn = VGN2;	  // Holds calculated DAC value of DAC 2 used in TCG calculation
	Dav_out(chanlc, 2, VGN2);

	int ds = 0; // Fill data for Gain Step Selection  // 1B 412B 1B  1B 4200 1B  1B 43XX 1B    // Default data 7x
	tx_cmd[ds++] = 0x1B;
	tx_cmd[ds++] = 0x41;
	tx_cmd[ds++] = 0x2B;
	tx_cmd[ds++] = 0x1B;
	tx_cmd[ds++] = 0x1B;
	tx_cmd[ds++] = 0x42;
	tx_cmd[ds++] = 0x00;
	tx_cmd[ds++] = 0x1B;
	tx_cmd[ds++] = 0x1B;
	tx_cmd[ds++] = 0x43;
	tx_cmd[ds++] = 0xA0;
	tx_cmd[ds++] = 0x1B;

	if (GStep == 1) // Upper nibble used for gain step GSTP4,GSTP3,GSTP2,GSTP1,  xxxx
	{
		tx_cmd[10] = 0xA0;
	}
	if (GStep == 2)
	{
		tx_cmd[10] = 0xD0;
	}
	if (GStep == 3)
	{
		tx_cmd[10] = 0x70;
	}
	Send_SPI(ds); // Send data
}

void Dav_out(int chanlc, int Dacno, int Vdata)
{
	int temp;
	unsigned char wData, Ch_vh, Ch_vl;
	int regAddrL;

	switch (Dacno)
	{
	case 1:
		regAddrL = 0x001; // regAddr=r_addDAC1;
		break;
	case 2:
		regAddrL = 0x003; // regAddr=r_addDAC2;
		break;
	case 3:
		regAddrL = 0x005; // regAddr=r_addDAC3;
		break;
	case 4:
		regAddrL = 0x007; // regAddr=r_addDAC4;
		break;
	}

	int ds = 0;
	tx_cmd[ds++] = 0x1B;
	tx_cmd[ds++] = 0x41;
	tx_cmd[ds++] = regAddrL;
	tx_cmd[ds++] = 0x1B;
	tx_cmd[ds++] = 0x1B;
	tx_cmd[ds++] = 0x42;
	tx_cmd[ds++] = 0x00;
	tx_cmd[ds++] = 0x1B;

	temp = Vdata & 0xFF;
	wData = (unsigned char)temp;
	tx_cmd[ds++] = 0x1B;
	tx_cmd[ds++] = 0x43;
	tx_cmd[ds++] = wData;
	tx_cmd[ds++] = 0x1B;

	temp = Vdata & 0x00FF00;
	temp = temp >> 8;
	wData = (unsigned char)temp;
	tx_cmd[ds++] = 0x1B;
	tx_cmd[ds++] = 0x43;
	tx_cmd[ds++] = wData;
	tx_cmd[ds++] = 0x1B;
	
	Send_SPI(ds); // Send data
}

//---------
/* MENU 1 */
//---------

/***********************************************************************************/
/*********************************GATE A FUNCTION***********************************/
/***********************************************************************************/

void Gatea_f(int key_t)
{
	Gate1_v = val_ary[GATE1_PERA];
	int temp = 0;

	//**********KEY_SCR = 0*********************

	if (key_scr == 0) // Get the value from scrollbar
	{
		gtk_adjustment_set_lower(adj, 0.0);
		gtk_adjustment_set_upper(adj, 8.0);
		gtk_adjustment_set_step_increment(adj, 6.0);
		// gtk_adjustment_set_page_size(adj, 2.0);
		// gtk_adjustment_set_page_increment(adj, 2.0);
	}

	//**********KEY_SCR = 1*********************

	if (key_scr == 1) // Get the value from button keypad
		Gate1_v = Gate1_v + key_t;

	if (Gate1_v < 0)
		Gate1_v = 8;
	else if (Gate1_v > 8)
		Gate1_v = 0;
	val_ary[GATE1_PERA] = Gate1_v;

	if (Gate1_v == 0)
	{
		strcpy(Pera_str, "OFF     ");

		if (gac == 0)
		{
			gas = val_ary[GSTA1_PERA];
			gae = val_ary[GEND1_PERA];
		}
		else if (gac == 1)
		{
			val_ary[GSTA1_PERA] = gas;
			val_ary[GEND1_PERA] = gae;
			gac = 0;
		}
		
		Cal_Range_tbl_all(Range_v, Mtlvel_val);
		Set_dly_all(zero_val, Delay_rv, Mtlvel_val);
		horizontal_ruler();
		
	}
	else if (Gate1_v == 1)
	{
		strcpy(Pera_str, "PLOGIC  ");
	}
	else if (Gate1_v == 2)
	{
		strcpy(Pera_str, "NLOGIC  ");
	}
	else if (Gate1_v == 3)
	{
		strcpy(Pera_str, "CRV M   ");
	}
	else if (Gate1_v == 4)
	{
		strcpy(Pera_str, "CRV -1  ");
	}
	else if (Gate1_v == 5)
	{
		strcpy(Pera_str, "CRV -2  ");
	}
	else if (Gate1_v == 6)
	{
		strcpy(Pera_str, "CRV +1  ");
	}
	else if (Gate1_v == 7)
	{
		strcpy(Pera_str, "CRV +2  ");

		if (gac == 0)
		{
			gas = val_ary[GSTA1_PERA];
			gae = val_ary[GEND1_PERA];
		}
		else if (gac == 1)
		{
			val_ary[GSTA1_PERA] = gas;
			val_ary[GEND1_PERA] = gae;
			gac = 0;
		}
		
		Cal_Range_tbl_all(Range_v, Mtlvel_val);
		Set_dly_all(zero_val, Delay_rv, Mtlvel_val);
		horizontal_ruler();
	}
	else if (Gate1_v == 8)
	{
		strcpy(Pera_str, "EXPAND  ");
		
		gac = 1;
		val_ary[GSTA1_PERA] = 0;
		val_ary[GEND1_PERA] = 1000;
		val_ary[GEND1_PERA] = val_ary[RANGE_PERA];

        temp = gae - gas;  
		if (temp < 0)
			temp = val_ary[RANGE_PERA];
			// temp = 1000;

		Cal_Range_tbl_all(temp * 10, Mtlvel_val);
		Set_dly_all(zero_val, gas * 10, Mtlvel_val);
		horizontal_ruler();
	}

	if (Dac_v > 0 || Dgs_onoff_v == 2 || Dgs_onoff_v == 3) // DAC is DRAW or ON
	{
		dac_gen(&dac_pnt[0], &dac_cv[0], Gain_v, Range_v, Delay_rv); // If Dac ON then Draw DAC Curve
	}

	pos = (GATE1_PERA * 2) + 1;
	strcpy(all_btnval[pos], Pera_str);
	pos = pos % 10;

	gl_clear_color_background_data(width_sh, height_sh);
	gate_display();

	Cal_Gate();
}

/***********************************************************************************/
/*********************************START A FUNCTION**********************************/
/***********************************************************************************/

void STARTa_f(int key_t)
{
	int gstad;
	float tmpstrta_val = 0.0, new_val;

	gtk_adjustment_set_lower(adj, 0);
	gtk_adjustment_set_upper(adj, 1000000);
	
	/***********************Key scr == 1 ****************************/

	if (key_scr == 1) // Get the value from button keypad
	{
		Gstart1_v = val_ary[GSTA1_PERA];
		val_ary[GSTA1_PERA] = Gate_Adjust(key_t, Gstart1_v); // Adjust Gate Start Value
		Gstart1_v = val_ary[GSTA1_PERA];
		gstep = Gstart1_v;
		key_scr = 5;

		pos = (GSTA1_PERA * 2) + 1;
		strcpy(all_btnval[pos], Dsp_Str);
		strcpy(gasDisp, Dsp_Str);
		strcpy(all_btnval[(CURSOR_PERA * 2) + 1], Dsp_Str);
		pos = pos % 10;										 // COPY THE VALUE TO MENU 4 START
		strcpy(all_btnval[(STRT_GA_PERA * 2) + 1], Dsp_Str); // For Auto Cal
	}

	/***********************Key scr == 2 ****************************/
	if (key_scr == 2) // Get the value from touch keypad
	{
		prev_sval = Gstart1_v;

		if (tmpstrta_val < 0)
		{
			tmpstrta_val = 0;
		}
		else if (tmpstrta_val > 1000000)
		{
			tmpstrta_val = 1000000;
		}

		tmpstrta_val = key_array[(menu_v * 5) + btn_idx];

		if (Unit_v == MM)
		{
			Gstart1_v = tmpstrta_val * 10;
		}
		else
		{
			Gstart1_v = tmpstrta_val * 100;
		}

		new_val = Gstart1_v;
		val_ary[GSTA1_PERA] = Gstart1_v;
		Gstart1_v = val_ary[GSTA1_PERA];

		val_ary[GSTA1_PERA] = Gate_Adjust(key_t, Gstart1_v); // Adjust Gate Start Value
		Gstart1_v = val_ary[GSTA1_PERA];

		int next_val = new_val - prev_sval;
		key_t = next_val;
		key_scr = 5;

		pos = (GSTA1_PERA * 2) + 1;
		strcpy(all_btnval[pos], Dsp_Str);
		strcpy(gasDisp, Dsp_Str);
		strcpy(all_btnval[(CURSOR_PERA * 2) + 1], Dsp_Str);
		pos = pos % 10;										 // COPY THE VALUE TO MENU 4 START
		strcpy(all_btnval[(STRT_GA_PERA * 2) + 1], Dsp_Str); // For Auto Cal
	}

	if (Gate1_v == 8)
		horizontal_ruler();

	if (val_ary[GATE1_PERA] > 0)
	{
		gl_clear_color_background_data(width_sh, Asc_Height);
		gate_display();
	}

	Cal_Gate();
	ENDa_f(key_t);
}

/***********************************************************************************/
/*******************************END A FUNCTION**************************************/
/***********************************************************************************/

void ENDa_f(int key_t)
{
	char buffer[20];

	float tmpenda_val = 0.0;
	float new_val;
	int gstad;

	if (val_ary[GEND1_PERA] > 1000000)
		val_ary[GEND1_PERA] = 1000000;

	/***********************Key scr == 0 ****************************/
	if (key_scr == 0) // Get the value from scrollbar
	{
		gtk_adjustment_set_lower(adj, 0);
		gtk_adjustment_set_upper(adj, 1000000);
		Gend1_v = val_ary[GEND1_PERA];
		val_ary[GEND1_PERA] = Gate_Adjust(key_t, Gend1_v); // Adjust Gate Start Value
		if (Gend1_v > 1000000)
			Gend1_v = 1000000;
		Gend1_v = val_ary[GEND1_PERA];
	}

	/***********************Key scr == 1 ****************************/
	if (key_scr == 1) // Get the value from button keypad
	{
		Gend1_v = val_ary[GEND1_PERA];
		val_ary[GEND1_PERA] = Gate_Adjust(key_t, Gend1_v); // Adjust Gate Start Value
		if (Gend1_v > 1000000)								   // 1000000
			Gend1_v = 1000000;
		Gend1_v = val_ary[GEND1_PERA];
	}

	/***********************Key scr == 2 ****************************/

	if (key_scr == 2) // Get the value from touch keypad
	{
		tmpenda_val = key_array[GEND1_PERA];

		if (tmpenda_val < 0)
			tmpenda_val = 0;
		else if (tmpenda_val > 1000000)
			tmpenda_val = 1000000;

		if (Unit_v == MM)
			Gend1_v = tmpenda_val * 10;
		else
			Gend1_v = tmpenda_val * 100;

		val_ary[GEND1_PERA] = Gate_Adjust(key_t, Gend1_v); // Adjust Gate Start Value
		if (Gend1_v > 1000000)
			Gend1_v = 1000000;
		Gend1_v = val_ary[GEND1_PERA];
	}

	if (key_scr == 5) // For End to move with Start values
	{
		Gend1_v = val_ary[GEND1_PERA];
		if (Gend1_v > 1000000)
			Gend1_v = 1000000;

		val_ary[GEND1_PERA] = Gate_Adjust(key_t, Gend1_v); // Adjust Gate Start Value
		
		if (val_ary[GEND1_PERA] > 1000000)
			val_ary[GEND1_PERA] = 1000000;
		Gend1_v = val_ary[GEND1_PERA];
	}

	pos = (GEND1_PERA * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	strcpy(gaeDisp, Dsp_Str);
	pos = pos % 10;

	if ( val_ary[GSTA1_PERA] >= val_ary[GEND1_PERA])
		val_ary[GEND1_PERA] = val_ary[GSTA1_PERA] + 1;

	if (Gate1_v == 8)
		horizontal_ruler();

	if (val_ary[GATE1_PERA] > 0)
	{
		gl_clear_color_background_data(width_sh, Asc_Height);
		gate_display();
	}
	Cal_Gate();
}

/***********************************************************************************/
/*********************************LEVEL A FUNCTION**********************************/
/***********************************************************************************/

void LEVELa_f(int key_t)
{
	level1_v = val_ary[GTHE1_PERA];

	//**********KEY_SCR = 0*********************

	if (key_scr == 0) // Get the value from scrollbar
	{
		gtk_adjustment_set_lower(adj, 0);
		gtk_adjustment_set_upper(adj, 100);
		// level1_v = scr_val;
	}

	//**********KEY_SCR = 1*********************

	if (key_scr == 1) //  Get the value from button keypad
	{
		level1_v = level1_v + (key_t * Key_stp);
	}

	if (Rectify_v == 3) // RF Mode
	{
		if (level1_v < -100)
		{
			level1_v = -100;
		}
		if (level1_v > 100)
		{
			level1_v = 100;
		}
	}
	else // Non RF Mode
	{
		if (level1_v < 0)
		{
			level1_v = 0;
		}
		if (level1_v > 100)
		{
			level1_v = 100;
		}
	}

	val_ary[GTHE1_PERA] = level1_v;

	sprintf(Dsp_Str, "%d %%", level1_v);
	pos = (GTHE1_PERA * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;

	if (val_ary[GATE1_PERA] > 0)
	{
		gl_clear_color_background_data(width_sh, height_sh);
		// gate_display();
	}
	// Cal_Gate();
}

/************************************************************************************/
/*********************************GATE B FUNCTION************************************/
/************************************************************************************/

void GATEb_f(int key_t)
{
	gchar dec_num[10];
	Gate2_v = val_ary[GATE2_PERA];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
		// Gate2_v = scr_val;
		gtk_adjustment_set_lower(adj, 0);
		gtk_adjustment_set_upper(adj, 3);
		gtk_adjustment_set_step_increment(adj, 5.0);
	}

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) //  Get the value from button keypad
		Gate2_v = Gate2_v + key_t;

	if (Gate2_v < 0)
		Gate2_v = 3;
	else if (Gate2_v > 3)
		Gate2_v = 0;
	val_ary[GATE2_PERA] = Gate2_v;

	if (Gate2_v == 0)
	{
		strcpy(Dsp_Str, "OFF     ");
	}
	else if (Gate2_v == 1)
	{
		strcpy(Dsp_Str, "PLOGIC  ");
	}
	else if (Gate2_v == 2)
	{
		strcpy(Dsp_Str, "NLOGIC  ");
	}
	else if (Gate2_v == 3)
	{
		strcpy(Dsp_Str, "AUTO A  ");
	}

	pos = (GATE2_PERA * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;

	if (val_ary[GATE2_PERA] > 0)
	{
		gl_clear_color_background_data(width_sh, height_sh);
		gate_display();
	}
	else
		gl_clear_color_background_data(width_sh, height_sh);
}

/***********************************************************************************/
/***********************************START B FUNCTION********************************/
/***********************************************************************************/

void STARTb_f(int key_t)
{
	float tmpstrtb_val = 0.0;
	char buffer[40];
	float new_val;

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
		gtk_adjustment_set_lower(adj, 0);
		gtk_adjustment_set_upper(adj, 1000000);
	}

	/***********************Key scr == 1 ****************************/
	if (key_scr == 1) // Get the value from button keypad
	{
		prev_sval = val_ary[GSTA2_PERA];
		Gstart2_v = val_ary[GSTA2_PERA];
		val_ary[GSTA2_PERA] = Gate_Adjust(key_t, Gstart2_v); // Adjust Gate Start Value

		pos = (GSTA2_PERA * 2) + 1;
		strcpy(all_btnval[pos], Dsp_Str);
		pos = pos % 10;

		if (val_ary[GATE2_PERA] > 0) //  //if (val_ary[GATE2_PERA] == 1)
		{
			gl_clear_color_background_data(width_sh, height_sh);
			gate_display();
		}
		Cal_Gate();
		
		gstep = Gstart2_v;
		key_scr = 5;
	}

	if (key_scr == 2) // Get the value from touch keypad
	{
		if (tmpstrtb_val < 0)
		{
			tmpstrtb_val = 0;
		}
		if (tmpstrtb_val > 1000000)
		{
			tmpstrtb_val = 1000000;
		}

		tmpstrtb_val = key_array[GSTA2_PERA];
		if (Unit_v == MM)
		{
			Gstart2_v = tmpstrtb_val * 10;
		}
		else
		{
			Gstart2_v = tmpstrtb_val * 100;
		}

		new_val = Gstart2_v;
		val_ary[GSTA2_PERA] = Gstart2_v;
		Gstart2_v = val_ary[GSTA2_PERA];

		val_ary[GSTA2_PERA] = Gate_Adjust(key_t, Gstart2_v); // Adjust Gate Start Value

		pos = (GSTA2_PERA * 2) + 1;
		strcpy(all_btnval[pos], Dsp_Str);

		if (val_ary[GSTA2_PERA] > 0) // val_ary[(m_val * 5) + 0] == 1)
		{
			gl_clear_color_background_data(width_sh, height_sh);
			gate_display();
		}
		Cal_Gate();
		int next_val = new_val - prev_sval;
		key_t = next_val;
		key_scr = 5;
	}

	ENDb_f(key_t);
}

/***********************************************************************************/
/************************************END B FUNCTION*********************************/
/***********************************************************************************/

void ENDb_f(int key_t)
{
	float tmpendb_val = 0.0;
	float new_val;
	char buffer[40];
	int gstad;

	/***********************Key scr == 0 ****************************/
	if (key_scr == 0) // Get the value from scrollbar
	{
		gtk_adjustment_set_lower(adj, 0);
		gtk_adjustment_set_upper(adj, 1000000);
	}

	/***********************Key scr == 1 ****************************/
	if (key_scr == 1) // Get the value from button keypad
	{
		Gend2_v = val_ary[GEND2_PERA];
		val_ary[GEND2_PERA] = Gate_Adjust(key_t, Gend2_v); // Adjust Gate Start Value
		Gend2_v = val_ary[GEND2_PERA];
		if (val_ary[GEND2_PERA] > 1000000)
		{
			val_ary[GEND2_PERA] = 1000000;
		}

		if ( val_ary[GSTA2_PERA] >= val_ary[GEND2_PERA])
			val_ary[GEND2_PERA] = val_ary[GSTA2_PERA] + 1;

		pos = (GEND2_PERA * 2) + 1;
		strcpy(all_btnval[pos], Dsp_Str);
		pos = pos % 10;

		if (val_ary[GATE2_PERA] > 0)
		{
			gl_clear_color_background_data(width_sh, height_sh);
			gate_display();
		}
		Cal_Gate();
	}

	/***********************Key scr == 2 ****************************/
	if (key_scr == 2) // Get the value from touch keypad
	{
		if (tmpendb_val < 0)
		{
			tmpendb_val = 0;
		}
		if (tmpendb_val > 1000000)
		{
			tmpendb_val = 1000000;
		}

		tmpendb_val = key_array[GEND2_PERA];

		if (Unit_v == MM)
		{
			Gend2_v = tmpendb_val * 10;
		}
		else
		{
			Gend2_v = tmpendb_val * 100;
		}

		val_ary[GEND2_PERA] = Gate_Adjust(key_t, Gend2_v); // Adjust Gate Start Value

		if ( val_ary[GSTA2_PERA] >= val_ary[GEND2_PERA])
			val_ary[GEND2_PERA] = val_ary[GSTA2_PERA] + 1;

		Gend2_v = val_ary[GEND2_PERA];
		pos = (GEND2_PERA * 2) + 1;
		strcpy(all_btnval[pos], Dsp_Str);
		pos = pos % 10;

		if (val_ary[GATE2_PERA] > 0)
		{
			gl_clear_color_background_data(width_sh, height_sh);
		}
		Cal_Gate();
	}

	/***********************Key scr == 5 ****************************/
	if (key_scr == 5) // For End to move with Start values
	{
		Gend2_v = val_ary[GEND2_PERA];
		val_ary[GEND2_PERA] = Gate_Adjust(key_t, Gend2_v); // Adjust Gate Start Value

		if ( val_ary[GSTA2_PERA] >= val_ary[GEND2_PERA])
			val_ary[GEND2_PERA] = val_ary[GSTA2_PERA] + 1;

		pos = (GEND2_PERA * 2) + 1;
		strcpy(all_btnval[pos], Dsp_Str);
		pos = pos % 10;

		if (val_ary[GATE2_PERA] > 0)
		{
			gl_clear_color_background_data(width_sh, height_sh);
			gate_display();
		}
		Cal_Gate();
	}

	if (val_ary[GEND2_PERA] > 1000000)
	{
		val_ary[GEND2_PERA] = 1000000;
	}
}

/***********************************************************************************/
/************************************LEVEL B FUNCTION*******************************/
/***********************************************************************************/

void LEVELb_f(int key_t)
{
	level2_v = val_ary[GTHE2_PERA];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
		gtk_adjustment_set_lower(adj, 0);
		gtk_adjustment_set_upper(adj, 100);
		// level2_v = scr_val;
	}

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
	{
		level2_v = level2_v + (key_t * Key_stp);
	}

	if (level2_v < 0)
	{
		level2_v = 0;
	}
	if (level2_v > 100)
	{
		level2_v = 100;
	}
	val_ary[GTHE2_PERA] = level2_v;

	sprintf(Dsp_Str, "%d %%", level2_v);
	pos = (GTHE2_PERA * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;

	if (val_ary[GATE2_PERA] > 0)
	{
		gl_clear_color_background_data(width_sh, height_sh);
	}
}

/************************************************************************************/
void Cal_Gate() // Cal Gate related Peramatere
{
	int Gst1, Gend1, Gthe1, Gst2, Gend2, Gthe2, Vel_v, Rng_v, Delay_rv;
	int St_val, End_val;
	int templ, data;
	unsigned char utemp;

	Gst1 = val_ary[GSTA1_PERA];
	Gend1 = val_ary[GEND1_PERA];
	Gthe1 = val_ary[GTHE1_PERA];
	Vel_v = val_ary[VELO_PERA];
	Rng_v = val_ary[RANGE_PERA];
	Delay_rv = val_ary[DELAY_PERA];

	// Cal GST/Gend for all channel used for measurement so send data to FPGA
	templ = Delay_rv / 10;
	templ = 0;
	St_val = Gst1; //-(Delay_rv/10); //
	St_val = St_val - templ;
	if (St_val > (Rng_v / 10))
	{
		St_val = Rng_v / 10;
	}
	St_val = (St_val * 10000) / Vel_v; // Time in sample =((d/10) * 2*1000 for vel *25 for sample freq) /v  but d is 0.00 and
									   // FPGA_gst1=St_val;  // Sample fre to be 25Mhz

	tx_bufidx = 0;
	data = St_val;
	utemp = (uint8_t)data;
	Write_data(DATA1_Adr, utemp); // LSB 0 byte Register R1
	data = St_val >> 8;
	utemp = (uint8_t)data;
	Write_data(DATA2_Adr, utemp); // LSB 1 byte Register R1
	data = St_val >> 16;
	utemp = (uint8_t)data;
	Write_data(Gsta1_WAdr, utemp); // LSB 2 byte Register R1

	End_val = Gend1 - (Delay_rv / 10);
	if (End_val > (Rng_v / 10))
	{
		End_val = Rng_v / 10;
	}
	End_val = (End_val * 10000) / Vel_v; // Time in sample =((d/10) * 2*1000 for vel *25 for sample freq) /v  but d is 0.00 and

	// FPGA_gend1=End_val;
	//  Sample fre to be 25Mhz
	data = End_val;
	utemp = (uint8_t)data;
	Write_data(DATA1_Adr, utemp); // LSB 0 byte Register R1
	data = End_val >> 8;
	utemp = (uint8_t)data;
	Write_data(DATA2_Adr, utemp); // LSB 1 byte Register R1
	data = End_val >> 16;
	utemp = (uint8_t)data;
	Write_data(Gend1_WAdr, utemp); // LSB 2 byte Register R1

	data = Gthe1;

	utemp = (uint8_t)data;

	Write_data(Gthe1_WAdr, utemp); // LSB 0 byte Register R1

	Send_SPI(tx_bufidx); // Send data to FPGA

	//**********   Send Data to FPGA for Gate 2

	Gst1 = val_ary[GSTA2_PERA];
	Gend1 = val_ary[GEND2_PERA];
	Gthe1 = val_ary[GTHE2_PERA];
	Vel_v = val_ary[VELO_PERA];
	Rng_v = val_ary[RANGE_PERA];
	Delay_rv = val_ary[DELAY_PERA];

	// Cal GST/Gend for all channel used for measurement so send data to FPGA
	templ = Delay_rv / 10;
	templ = 0;
	St_val = Gst1; //-(Delay_rv/10); //
	St_val = St_val - templ;
	if (St_val > (Rng_v / 10))
	{
		St_val = Rng_v / 10;
	}
	St_val = (St_val * 10000) / Vel_v; // Time in sample =((d/10) * 2 * 1000 for vel * 25 for sample freq) /v  but d is 0.00 and
									   // FPGA_gst1=St_val;   // Sample fre to be 25Mhz

	tx_bufidx = 0;
	data = St_val;
	utemp = (uint8_t)data;
	Write_data(DATA1_Adr, utemp); // LSB 0 byte Register R1
	data = St_val >> 8;
	utemp = (uint8_t)data;
	Write_data(DATA2_Adr, utemp); // LSB 1 byte Register R1
	data = St_val >> 16;
	utemp = (uint8_t)data;
	Write_data(Gsta2_WAdr, utemp); // LSB 2 byte Register R1

	End_val = Gend1 - (Delay_rv / 10);
	if (End_val > (Rng_v / 10))
	{
		End_val = Rng_v / 10;
	}
	End_val = (End_val * 10000) / Vel_v; // Time in sample =((d/10) * 2*1000 for vel *25 for sample freq) /v  but d is 0.00 and

	// FPGA_gend1=End_val;
	//  Sample fre to be 25Mhz
	data = End_val;
	utemp = (uint8_t)data;
	Write_data(DATA1_Adr, utemp); // LSB 0 byte Register R1
	data = End_val >> 8;
	utemp = (uint8_t)data;
	Write_data(DATA2_Adr, utemp); // LSB 1 byte Register R1
	data = End_val >> 16;
	utemp = (uint8_t)data;
	Write_data(Gend2_WAdr, utemp); // LSB 2 byte Register R1

	data = Gthe1;

	utemp = (uint8_t)data;

	Write_data(Gthe2_WAdr, utemp); // LSB 0 byte Register R1

	Send_SPI(tx_bufidx); // Send data to FPGA
	Cal_Gate_Crss_val();
}

void Cal_Gate_Crss_val() // Get the signal gate cross value for beep sound and led light
{
	int Gst1, Gend1, Gthe1, Gst2, Gend2, Gthe2, Vel_v, Rng_v, Delay_rv;
	char buffer[40], buffer1[41];

	Gst1 = val_ary[GSTA1_PERA];
	Gend1 = val_ary[GEND1_PERA];
	Gst2 = val_ary[GSTA2_PERA];
	Gend2 = val_ary[GEND2_PERA];
	Gthe1 = val_ary[GTHE1_PERA];
	Vel_v = val_ary[VELO_PERA];
	Rng_v = val_ary[RANGE_PERA];
	Delay_rv = val_ary[DELAY_PERA];

	// Calculations for GATE A
	Gatecrs_strt1 = (Gst1 * 2500) / Rng_v; //(for ascan from 0 to 250) // Gate 1 cross start value
	Gatecrs_end1 = (Gend1 * 2500) / Rng_v; // Gate 1 cross end value

	if (Gatecrs_strt1 < 0)
		Gatecrs_strt1 = 0;
	else if (Gatecrs_strt1 > 250)
		Gatecrs_strt1 = 250;

	if (Gatecrs_end1 < 0)
		Gatecrs_end1 = 0;
	else if (Gatecrs_end1 > 250)
		Gatecrs_end1 = 250;

	// Calculations for GATE B
	Gatecrs_strt2 = (Gst2 * 2500) / Rng_v; //(for ascan from 0 to 250) // Gate 2 cross start value
	Gatecrs_end2 = (Gend2 * 2500) / Rng_v; // Gate 2 cross end value

	if (Gatecrs_strt2 < 0)
		Gatecrs_strt2 = 0;
	else if (Gatecrs_strt2 > 250)
		Gatecrs_strt2 = 250;

	if (Gatecrs_end2 < 0)
		Gatecrs_end2 = 0;
	else if (Gatecrs_end2 > 250)
		Gatecrs_end2 = 250;
}

//---------
/*MENU 3*/
//---------

/************************************************************************************/
/**********************************MEMORY FUNCTION***********************************/
/************************************************************************************/

void MEMORY_f(int key_t)
{
	gtk_adjustment_set_lower(adj, 0);
	gtk_adjustment_set_upper(adj, 10);

	memory_val = val_ary[MEM_PERA];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
		memory_val = scr_val;

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
		memory_val = memory_val + key_t;

	if (memory_val < 0)
		memory_val = 2;
	else if (memory_val > 2)
		memory_val = 0;

	val_ary[MEM_PERA] = memory_val;

	if (memory_val == 0)
		strcpy(Dsp_Str, "A-SCAN  ");    // A-SCAN
	if (memory_val == 1)
		strcpy(Dsp_Str, "SET-UP  ");	// SET-UP
	if (memory_val == 2)
		strcpy(Dsp_Str, "REPORT  ");	// REPORT

	pos = (MEM_PERA * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;

	MEMNO_f(0);
}

/***********************************************************************************/
/**********************************MEM NO FUNCTION**********************************/
/***********************************************************************************/

void MEMNO_f(int key_t)
{
	gtk_adjustment_set_lower(adj, 0);
	gtk_adjustment_set_upper(adj, 500);

	memory_val = val_ary[MEM_PERA];
	// memno_val = Mem_no[memory_val];

	//**********KEY_SCR = 0******************************
	if (key_scr == 0) // Get the value from scrollbar
	{
		memno_val = scr_val;
		gtk_adjustment_set_lower(adj, 0);
		gtk_adjustment_set_upper(adj, 500);
	}

	//**********KEY_SCR = 1*******************************
	if (key_scr == 1) //  Get the value from button keypad
		memno_val = memno_val + (Key_stp * key_t);

	Mem_no[memory_val] = memno_val;
	val_ary[MEM_NO_PERA] = memno_val;

	if (Mem_no[0] < 1)
	{
		Mem_no[0] = 1;
	}
	if (Mem_no[0] > 500)
	{
		Mem_no[0] = 500;
	} // Check Set up Mem no limits
	if (Mem_no[1] < 1)
	{
		Mem_no[1] = 1;
	}
	if (Mem_no[1] > 500)
	{
		Mem_no[1] = 500;
	} // Check Ascan Mem no limits
	if (Mem_no[2] < 1)
	{
		Mem_no[2] = 1;
	}
	if (Mem_no[2] > 500)
	{
		Mem_no[2] = 500;
	} // Check REPORT Mem no limits
	if (Mem_no[3] < 1)
	{
		Mem_no[3] = 1;
	}
	if (Mem_no[3] > 500)
	{
		Mem_no[3] = 500;
	} // Check Color Bscan Mem no limits
	if (Mem_no[4] < 1)
	{
		Mem_no[4] = 1;
	}
	if (Mem_no[4] > 500)
	{
		Mem_no[4] = 500;
	} // Check Thickness Mem no limits
	if (Mem_no[5] < 1)
	{
		Mem_no[5] = 1;
	}
	if (Mem_no[5] > 500)
	{
		Mem_no[5] = 500;
	} // Check TOFD Mem no limits
	if (Mem_no[6] < 1)
	{
		Mem_no[6] = 1;
	}
	if (Mem_no[6] > 500)
	{
		Mem_no[6] = 500;
	} // Check C Scan Mem no limits     etc

	memno_val = Mem_no[memory_val];
	// If File exists then Dislay File Number with Astric

	Create_Directory();
	if (memory_val == 0)
	{
		sprintf(filen, "Ascan/%s%04d", Memext[memory_val], memno_val); // Generate appropriate file name
		path_h = strcat(filen, ".asc");
	}
	else if (memory_val == 1)
	{
		sprintf(filen, "Cal/%s%04d", Memext[memory_val], memno_val); // Generate appropriate file name
		path_h = strcat(filen, ".set");
	}
	else if (memory_val == 2)
	{
		sprintf(filen, "Report/%s%04d", Memext[10], memno_val); // Generate appropriate file name
		path_h = strcat(filen, ".pdf");
		// path_report = strcat(filen, ".pdf");
	}

	if (access(path_h, F_OK) == 0)
		sprintf(Dsp_Str, "%02d*", memno_val); // If File exists then Dislay File Number with Astric
	else
	{
		// if (memory_val == 0 && Mem_no[0] == 0)
		// 	sprintf(Dsp_Str, "SD CARD");
		// else if (memory_val == 0 && Mem_no[0] == -1)
		// 	sprintf(Dsp_Str, "USB DISK");
		// else
			sprintf(Dsp_Str, "%02d", memno_val);
	}

	pos = (MEM_NO_PERA * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
	pos1 = 3 * 10;
	strcpy(all_btnval[pos1 + 7], "ENTER>");
}

/***********************************************************************************/
/*********************************ACTION FUNCTION***********************************/
/***********************************************************************************/

void ACTION_f(int key_t)
{
	gtk_adjustment_set_lower(adj, 0);
	gtk_adjustment_set_upper(adj, 10);

	Mem_act = val_ary[MEM_ACT_PERA];

	//**********KEY_SCR = 0*********************

	if (key_scr == 0) // Get the value from scrollbar
	{
		// Mem_act = val_ary[MEM_ACT_PERA];
	}

	//**********KEY_SCR = 1*********************

	if (key_scr == 1 && Key_stp == 1) //  Get the value from button keypad
		Mem_act = Mem_act + (Key_stp * key_t);

	if (Key_stp == 1)
	{
		if (Mem_act < 0)
			Mem_act = 7;
		else if (Mem_act > 7)
			Mem_act = 0;
	}

	val_ary[MEM_ACT_PERA] = Mem_act;

	if (Mem_act == 0)
		strcpy(Dsp_Str, "RECALL  "); 
	else if (Mem_act == 1)
		strcpy(Dsp_Str, "SAVE    "); 
	else if (Mem_act == 2)
		strcpy(Dsp_Str, "DETAIL ");
	else if (Mem_act == 3)
		strcpy(Dsp_Str, "DELETE  ");
	else if (Mem_act == 4)
		strcpy(Dsp_Str, "DELETE ALL");
	else if (Mem_act == 5)
		strcpy(Dsp_Str, "COPY ");
	else if (Mem_act == 6)
		strcpy(Dsp_Str, "COPY ALL");
	else if (Mem_act == 7)
		strcpy(Dsp_Str, "EJECT");

	pos = (MEM_ACT_PERA * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
}

/************************************************************************************/
/***********************************NOTE FUNCTION************************************/
/************************************************************************************/

int delete()
{
	if (memory_val == 0)
		return system("rm ./Ascan/*");
	else if (memory_val == 1)
		return system("rm ./Cal/*");
	else if (memory_val == 2)
		return system("rm ./Report/*");
}

void Mem_Note_f(int key_t)
{
	char buffer[40];
	gtk_adjustment_set_lower(adj, 0);
	gtk_adjustment_set_upper(adj, 5);

	m_val = 3;
	pos = m_val * 10;
	note_val = val_ary[MEM_NOTE_PERA];

	//**********KEY_SCR = 0*********************

	if (key_scr == 0) // Get the value from scrollbar
	{
		// note_val = val_ary[MEM_NOTE_PERA];
	}

	//**********KEY_SCR = 1*********************

	if (key_scr == 1) // Get the value from button keypad
	{
		if (key_t == -1 && note_dsp == 0)
		{
			Note_Display(key_t); // Display Note
		}
		else if (key_t == 1 && note_dsp == 1)
		{
			Note_Display(key_t); // Exit From NOTE Edit Mode
		}
		else if (key_t == 1 && note_dsp == 0) // perform Memory Action as per selection in the Action
		{
			// forfile_dgs = 1;
			if (Mem_act == 0)
			{
				Reset_DGSDAC(); // (REQUIRED)
				if (access(path_h, F_OK) != -1)
				{
					if (memory_val == 0)
					{
						recall_read = 1;
						h_read();
						gtk_label_set_label(GTK_LABEL(space51), "FREEZ");
					}
					else if (memory_val == 1)
					{
						recall_read = 0;
						set_read();
					}
					dsp_msg(38);
				}
				else
				{
					dsp_msg(39);
				}
			}
			else if (Mem_act == 1)
			{
				FILE *file;
				if (DGS_ReadFile == true)
				{
					dgs_fromfile = 1;
				}
				else
				{
					dgs_fromfile = 0;
				}
				if (file = fopen(path_h, "r"))
				{
					if (Key_stp == 10)
					{
						if (memory_val == 0)
						{
							h_write();
						}
						else if (memory_val == 1)
						{
							set_write();
						}
						else if (memory_val == 2)
						{
							CreateAscan_Pdfreport();
						}
						dsp_msg(40);
						MEMNO_f(0);
					}
					else
					{
						dsp_msg(21);
						return;
					}
				}
				else
				{
					if (memory_val == 0)
					{
						h_write();
					}
					else if (memory_val == 1)
					{
						set_write();
					}
					else if (memory_val == 2)
					{
						CreateAscan_Pdfreport();
					}
					dsp_msg(40);
					MEMNO_f(0);
				}
			}
			else if (Mem_act == 2)
			{
				if (access(path_h, F_OK) != -1)
				{
					h_detail();
					dsp_msg(41);
				}
			}
			else if (Mem_act == 3)
			{
				if (Key_stp == 10)
				{
					remove(path_h);
					MEMNO_f(0);

					dsp_msg(42);
				}
				else
				{
					dsp_msg(27);
					return;
				}
			}
			else if (Mem_act == 4)
			{
				if (access(path_h, F_OK) != -1)
				{
					if (Key_stp == 10)
					{
						delete();
						MEMNO_f(0);
						
						dsp_msg(43);
					}
					else
					{
						dsp_msg(23);
					}
				}
			}
			else if (Mem_act == 5)
			{
				if (access(path_h, F_OK) == 0)
				{
					/*	
					DetectUsb();	// To detect the pendrive and obtain its path
					DetectSDCard(); // To detect sd card and obtain its path
					*/
					MountUSB(path_h);
					dsp_msg(25);
				}
				else
				{
					dsp_msg(24);
				}
			}
			else if (Mem_act == 6)
			{
				if (access(path_h, F_OK) == 0)
				{
					if (Key_stp == 10)
					{
						if (memory_val == 0)
							MountUSB("Ascan");
						else if (memory_val == 1)
							MountUSB("Cal");
						else if (memory_val == 2)
							MountUSB("Report");

						dsp_msg(44);
					}
					else
					{
						dsp_msg(26); // Warning enter stp key and enter key together to copy all files
					}
				}
			}
			else if (Mem_act == 7)
			{
				UmountUSB();

				rw_flag = -1;
				Dac_Bscan_flag = true;
				opengl_update = true;
				gtk_label_set_label(GTK_LABEL(space51), "     ");
			}
		}
	}
}

//**************************************************************************************************
//**************************************************************************************************
// Detail of Note Details frame
void Note_Display(int key_t)
{
	// m_val = 3; // For EDIT A,S for character scrolling, Page up/Page DN for Cursur Move, W for Line Change
	if (menu_v == 3)
	{
		menu_v = 3;
		m_val = 3;
		pos = menu_v * 10;
	}

	if (menu_v == 13)
	{
		menu_v = 13;
		m_val = 13;
		pos = menu_v * 10;
	}
	if (key_t < 0) // If key_t = -1 then display Note
	{
		note_dsp = 1; // Indicates Note is Display
		key_scr = 1;
		Asc_Dsp = 0; // No Ascan Update
		partial_uninitialize();

		gtk_widget_show(f3_box); // Show the widget
		if (dgs_fromfile == 1)
		{
			gtk_widget_hide(f2_box); // When reading from pwroff file the dgs selection box also shows therefore this code is necessary
		}

		strcpy(all_btnval[pos + 2], "LINE   ");
		strcpy(all_btnval[pos + 3], "UP/DN  ");
		strcpy(all_btnval[pos + 4], "CURSOR ");
		strcpy(all_btnval[pos + 5], "MOVE   ");
		strcpy(all_btnval[pos + 6], "EXIT   ");
		strcpy(all_btnval[0 + 8], "CHAR   "); // all_btnval[0 + 8]
		strcpy(all_btnval[0 + 9], "SCROLL ");
	}

	if (key_t > 0) // If key_t= 1 then Hide Note data  / Exit From Note EDIT Menu
	{
		if (menu_v == 3) // NOTE DETAIL IN MENU 3 IN ASCAN DETAIL
		{
			key_scr = 1;
			note_dsp = 0; // Indicates Note is Hidden
			Asc_Dsp = 1;  // Display/  Ascan Update

			// partial_uninitialize();
			recreate_surface(width_sh, height_sh, ogl_x_position, ogl_y_position);
			// ogl_render(width_sh, height_sh);
			gl_clear_color_background_data(width_sh, height_sh);

			gtk_widget_hide(f3_box); // Hide the widget

			strcpy(all_btnval[pos + 2], "MEM NO ");
			gtk_label_set_label(GTK_LABEL(label_dv[2]), all_btnval[pos + 2]);
			strcpy(all_btnval[pos + 4], "ACTION ");
			gtk_label_set_label(GTK_LABEL(label_dv[4]), all_btnval[pos + 4]);
			strcpy(all_btnval[pos + 6], "<NOTE  ");
			gtk_label_set_label(GTK_LABEL(label_dv[6]), all_btnval[pos + 6]);
			strcpy(all_btnval[8], Gain_glbl);
			strcat(all_btnval[8], gstr_2);
			gtk_label_set_label(GTK_LABEL(label_dv[8]), all_btnval[8]);

			MEMNO_f(0);
			ACTION_f(0);
			Gain_f(0);
		}

		if (menu_v == 13) // NOTE IN MENU 13
		{
			key_scr = 1;
			note_dsp = 0; // Indicates Note is Hidden
			Asc_Dsp = 1;  // Display/  Ascan Update

			// partial_uninitialize();
			recreate_surface(width_sh, height_sh, ogl_x_position, ogl_y_position);
			// ogl_render(width_sh, height_sh);
			gl_clear_color_background_data(width_sh, height_sh);
			pos = 130;
			gtk_widget_hide(f3_box); // Hide the widget

			strcpy(all_btnval[pos + 2], "MEM NO");
			gtk_label_set_label(GTK_LABEL(label_dv[2]), all_btnval[pos + 2]);
			strcpy(all_btnval[pos + 4], "ACTION ");
			gtk_label_set_label(GTK_LABEL(label_dv[4]), all_btnval[pos + 4]);
			strcpy(all_btnval[pos + 6], "<<ENTER");
			gtk_label_set_label(GTK_LABEL(label_dv[6]), all_btnval[pos + 6]);
			strcpy(all_btnval[8], Gain_glbl);
			strcat(all_btnval[8], gstr_2);
			gtk_label_set_label(GTK_LABEL(label_dv[8]), all_btnval[8]);

			Record_No_f(0);
			Bs_Action_Select_f(0);
			Gain_f(0);
		}
	}
}

// For changing the traversing the text boxes in Note Detail
/************************************************************************************/
void Note_ln_f(int key_t)
{
	ln_no = ln_no + key_t; // For traversing textbox directly
	if (ln_no > temp_count)
	{
		ln_no = 0;
	}
	if (ln_no < 0)
	{
		ln_no = temp_count;
	}
	gtk_widget_set_can_focus(GTK_WIDGET(text_h[ln_no]), true);
	gtk_widget_grab_focus(GTK_WIDGET(text_h[ln_no]));
	// chr_pos = 0;
	OntString(0);
}

// For changing the position of the cursor in Note Detail
/************************************************************************************/

void Note_Cur_pos_f(int key_t) // Set Cursor Position in the
{
	chr_pos = chr_pos + key_t;
	if (chr_pos > 39)
	{
		chr_pos = 0;
		Note_ln_f(1);
	}

	if (chr_pos < 0)
	{
		chr_pos = 39;
		Note_ln_f(-1);
	}

	gtk_widget_set_can_focus(GTK_WIDGET(text_h[ln_no]), true);
	OntString(0);
}

// To scroll through the characters in Note Detail
/************************************************************************************/
void Note_Char_Scroll_f(int key_t)
{
	gtk_widget_set_can_focus(GTK_WIDGET(text_h[ln_no]), true);
	OntString(key_t);
}

/************************************************************************************/
/***********************************SIZE EVAL FUNCTION*******************************/
/************************************************************************************/
void Size_Eval_f(int key_t)
{
	gtk_adjustment_set_lower(adj, 0);
	gtk_adjustment_set_upper(adj, 5);

	if (key_t == 0 && reset_value == 1) // While Unfreezing after file read function in Memory
	{
		Dac_f(0);
		AWS_f(0);
		DGS_f(0);
		reset_value = 0;
	}
	if (Evaluate_val == 0)
	{
		Dac_f(key_t);
	}
	else if (Evaluate_val == 1)
	{
		AWS_f(key_t);
	}
	else if (Evaluate_val == 2)
	{
		DGS_f(key_t);
	}
	else
	{
	}
}

/************************************************************************************/
/*********************************SIZE EVAL f1 FUNCTION******************************/
/************************************************************************************/
void Size_Eval_f1(int key_t)
{
	pos = DAC_PERA * 2;
	// gatea_flag == true;
	if (Evaluate_val == 0 && Dac_v == 4) // If TCG Edit is selected
	{
		TCG_pnt_f(key_t);
	}
	else if (Evaluate_val == 0 || Evaluate_val == 1) // DAC or AWS
	{
		STARTa_f(key_t);
		pos = DAC_PERA * 2;
		strcpy(all_btnval[pos + 2], "START A");
		strcpy(all_btnval[pos + 3], all_btnval[13]);
	}
	else if (Evaluate_val == 2) // DGS is selected
	{
		STARTa_f(key_t);
		pos = DAC_PERA * 2;
		strcpy(all_btnval[pos + 2], "START A");
		strcpy(all_btnval[pos + 3], all_btnval[13]);
	}
	else
	{
	}
}

/************************************************************************************/
/*********************************SIZE EVAL f2 FUNCTION******************************/
/************************************************************************************/
void Size_Eval_f2(int key_t)
{
	if (Evaluate_val == 0)
	{
		if (Dac_v == 4)
		{
			TCG_pnt_gn(key_t);
		}
		else
		{
			press_f(key_t); // PRESS FUNCTION(DAC CRV DB INCREASE FUNCTION ALSO PRESENT)
		}
	}
	else if (Evaluate_val == 1)
	{
		Aws_Ref_f(key_t);
	}
	else if (Evaluate_val == 2)
	{
		if (Dgs_onoff_v == 2)
		{
			DGS_Ref_f(key_t); // DGS Ref FUNCTION
		}
		else if (Dgs_onoff_v == 3)
		{
			DgsCrv_db(key_t); // TO GET DGS CURVE DB INCREASE FUNCTION
		}
		else
		{
			DGS_Ref_f(key_t); // DGS Ref FUNCTION
		}
	}
}

/************************************************************************************/
/*********************************SIZE EVAL f3 FUNCTION******************************/
/************************************************************************************/
void Size_Eval_f3(int key_t)
{
	if (Evaluate_val == 0)
	{
		Point_f(key_t); // press_f(key_t);
	}
	else if (Evaluate_val == 1)
	{

	} // Aws_Ref_f(key_t);
	else if (Evaluate_val == 2 && Dgs_onoff_v == 3)
	{
		Tl_Corr_f(key_t);
	}
	else
	{
	}
}

/************************************************************************************/
/****************************************DAC PERA********************************/
/************************************************************************************/
void Dac_f(int key_t)
{
	gtk_adjustment_set_lower(adj, 0);
	gtk_adjustment_set_upper(adj, 5);

	pos = DAC_PERA * 2;

	Dac_v = val_ary[DAC_PERA];
	DGS_ReadFile = false;

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
		Dac_v = val_ary[DAC_PERA];

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
		Dac_v = Dac_v + key_t;

	gdac_flag = false;
	if (Dac_v < 0)
		Dac_v = 4;
	if (Dac_v > 4)
		Dac_v = 0;
	val_ary[DAC_PERA] = Dac_v;

	if (Dac_v == 0)
	{
		strcpy(all_btnval[pos], "DAC(D) ");
		strcpy(all_btnval[pos + 1], "OFF     ");
		strcpy(all_btnval[pos + 2], "START A");
		STARTa_f(0); // OFF
		Gain_f(0);

		val_ary[POINT_PERA] = 0;
		val_ary[PRESS_PERA] = 0;

		for (i = 0; i < 255; i++)
		{
			pntArray_DACM[i].x = 0;
			pntArray_DACM[i].y = 0;			

			pntArray_DAC1P[i].x = 0;
			pntArray_DAC1P[i].y = 0;	

			pntArray_DAC2P[i].x = 0;
			pntArray_DAC2P[i].y = 0;	

			pntArray_DAC1N[i].x = 0;
			pntArray_DAC1N[i].y = 0;	

			pntArray_DAC2N[i].x = 0;
			pntArray_DAC2N[i].y = 0;	
		}
	
		if (key_t != 0 && Tcg_edit == 1)
		{
			val_ary[GATE2_PERA] = gate2_Sv;
			val_ary[GSTA2_PERA] = Gstart2_Sv;
			val_ary[GEND2_PERA] = Gend2_Sv;
			val_ary[GTHE2_PERA] = level2_Sv;
			Tcg_edit = 0;
		}

		if (Bsc_Dsp == false) // This condition used here due to segmentation fault and multiple calls to opengl
		{
			opengl_update = true;

			partial_uninitialize();
			recreate_surface(width_sh, height_sh, ogl_x_position, ogl_y_position);
		}
		TCG_Activate_Deactivate(false);
	}
	else if (Dac_v == 1)
	{
		strcpy(all_btnval[pos + 1], "DRAW    ");
		gdac_flag = true;
		if (key_t != 0)
		{
			point_v = 0;
			Dac_tlg_v = 0;
			Dac_crv_dB = 0;
		} // DRAW
		TCG_Activate_Deactivate(false);
	}
	else if (Dac_v == 2)
	{
		strcpy(all_btnval[pos], "DAC(D) ");
		strcpy(all_btnval[pos + 1], "ON      ");
		gdac_flag = true; // ON
		TCG_Activate_Deactivate(false);
		dgs_fromfile = 0;
	}
	else if (Dac_v == 3)
	{
		strcpy(all_btnval[pos], "TCG  ");
		strcpy(all_btnval[pos + 1], "   ON ");
		gdac_flag = true;
		strcpy(all_btnval[pos + 2], "START A");
		STARTa_f(0);

		TCG_Cal(&dac_pnt[0], &dac_cv[0], Gain_v, Range_v, Delay_rv);
		TCG_Activate_Deactivate(true); // dac_v=dac;
		if (key_t != 0 && Tcg_edit == 1)
		{
			val_ary[GATE2_PERA] = gate2_Sv;
			val_ary[GSTA2_PERA] = Gstart2_Sv;
			val_ary[GEND2_PERA] = Gend2_Sv;
			val_ary[GTHE2_PERA] = level2_Sv;
			Tcg_edit = 0;
		}
	} // TCG ON
	else if (Dac_v == 4)
	{
		strcpy(all_btnval[pos], "TCG ON  ");
		strcpy(all_btnval[pos + 1], "EDIT    ");
		gdac_flag = true; // TCG Edit
		if (key_t != 0)
		{
			gate2_Sv = val_ary[GATE2_PERA];
			Gstart2_Sv = val_ary[GSTA2_PERA];
			Gend2_Sv = val_ary[GEND2_PERA];
			level2_Sv = val_ary[GTHE2_PERA];
			Tcg_edit = 1;
		}

		val_ary[GATE2_PERA] = 1;
		dac_gen(&dac_pnt[0], &dac_cv[0], Gain_v, Range_v, Delay_rv); // If Dac ON then Draw DAC Curve
	
		TCG_pnt_f(0); // Draw Gate for the Selected Point and Display on LCD
		TCG_Cal(&dac_pnt[0], &dac_cv[0], Gain_v, Range_v, Delay_rv);
		TCG_Activate_Deactivate(true); // dac_v=dac;
	}

	Point_f(0); // When DAC State Change then Point to be also refresh
	press_f(0); //
	if (Dac_v == 3)
	{
		Draw_notificimg(SZEVAL_S, 3);
	} // TCG is ON  Symbol type,Postion
	else
	{
		Draw_notificimg(SZEVAL_S, Evaluate_val);
	} // Symbol type,Postion

	dac_gen(&dac_pnt[0], &dac_cv[0], Gain_v, Range_v, Delay_rv); // If Dac ON then Draw DAC Curve
	gl_clear_color_background_data(width_sh, height_sh);
}

///************************************************************************************************
//*************************************************************************************************
void TCG_Cal(int *dac_pntt, int *dac_p, int ref_g, long Range, long dly_r)
{
	int TCG_data[300];				  // Hold calculated TCG gain value
	int *pnt, *cv, crv_gain, Temp_gn; //  FPGA takes about 830ns to load new DAC value so if time is more then its ok
	int range;						  //      else we have to reduce/compress DAC data in the TCG table to match the requirement
	int Rang_d;						  //
	range = Range;					  //
	cv = dac_p;

	/* Make sure During DAC plot to be store X pos with taking care of
	   Delay Value.. for eg if Delay is already applied then add equi value of
	   of Delay to X pos record  for ex if Ran=100 and Delay=20applied
	   Id First Point at 20 % so Pixpos=50 and Delay=30mm pix=75 X to be
	   store as  50+75=125   */
	// // Clear all data of Ascan area for to erase old DAc curve
	// // Draw GRID  GATE

	double x1, x2, y1, y2, temp, y1_old, y1_new;
	double p1, dy, dx, xof;
	long int /*st,*/ end, data; // required time to display td= (2*range)/velocity
	unsigned char utemp;		// required factor =  (st*0xffff) / td
	long templ;
	int i, t;
	int j, k = 0;
	int p = 0;
	int *jp;
	int *dac_pt;
	int Min_gn = 1000;
	// int Rang_d;
	int dac_ptmp[300];

	int check[250];

	POINT pntArray_DAC[255]; // Holds data of DAC Curve 12 points per Channel

	long tmpc; //,temp;	//x_dly
	long Range_l, DacpntL;
	dac_pt = &dac_ptmp[0];
	Screen_w = 250;
	Range_l = Range;

	// dac_pntt=&DGS_pnt[0];  //  &DGS_pnt[0];
	Rang_d = Range_dac;		 // 10000;
	for (i = 0; i < 80; i++) /* Clear array */
	{
		dac_ptmp[i] = 0;
	}

	jp = dac_p;
	Min_gn = 1000; // Find Minimum Gain value
	for (i = 0; i < 10; i++)
	{
		t = *(dac_pntt + (2 * i) + 1);
		if (t > 0 & Min_gn > t)
		{
			Min_gn = t;
		}
	}
	crv_gain = ref_g; //  crv_gain holds current gain
	ref_g = Min_gn;	  //  ref_g holds minimum gain and with refrance to that ( Gain-ref_g) gain to be add in TCG

	y1_old = 1400;
	for (i = 0; i < 32; i++) // earlier its 10 point    /* 32 requires for DGS Curve  Maximum 10 points */
	{
		tmpc = (dly_r * 5) / 2;
		tmpc = Rang_d;
		DacpntL = *dac_pntt++; //   DGS_pnt[p++];  //*dac_pntt++; //
		tmpc = tmpc * DacpntL;
		DacpntL = (dly_r);
		DacpntL = DacpntL * 250; /* Cal X1 Pos for current Range */
		tmpc = tmpc - DacpntL;
		tmpc = (tmpc) / Range_l;

		if (tmpc > 12000) /* more then 100  times then exit */
			tmpc = 12000;
		if (tmpc < -12000)
			tmpc = -12000;
		x1 = (int)tmpc;

		*dac_pt++ = (int)(x1); /* Store temp DAC Point array */

		y1 = *dac_pntt++; //  DGS_pnt[p++];  //  *dac_pntt++;
		if (y1 == 0)
			goto extdcl1;
		y1 = y1 - ref_g; // ref_g is current Gain Value
		// y1=GaintoEH(y1);  /* Get %height from dB value */

		if (y1 > 1300)
			y1 = 1300;
		*dac_pt++ = (int)(y1);

		tmpc = Rang_d;
		DacpntL = *dac_pntt; // DGS_pnt[p];  //*dac_pntt;   //
		tmpc = tmpc * DacpntL;
		DacpntL = dly_r;
		DacpntL = DacpntL * 250; /* Cal X1 Pos for current Range */
		tmpc = tmpc - DacpntL;
		tmpc = (tmpc) / Range_l;

		if (tmpc > 12000)
			tmpc = 12000;
		if (tmpc < -12000)
			tmpc = -12000;
		x2 = (int)tmpc;
		t = x2 - x1;
		if (x1 > x2) // Last point to be like that X1>X2 so it will get exit
			goto extdcl1;
		if (x1 > 400) // 250             // If first point is out of screen then calculation not require.
			goto extdcl1;

		// if (t>75)  //Insert three more points  /* Makes smooth Curve */
		{
			y2 = *(dac_pntt + 1); //  DGS_pnt[p+1];   //  *(dac_pntt+1);
			if (y2 == 0)
				goto extdcl1;
			{
				t = x1 + (x2 - x1) / 4;
				*dac_pt++ = (int)(t); // t=(x2+x1)/2;  *dac_pt++=(int)(t);      /* Store new added  position */
				y2 = y2 - ref_g;	  // y2=GaintoEH(y2);

				if (y2 > 1300)
					y2 = 1300;
				t = y2 - y1; // If Diff is >25 then apply formula else not
				if (t > 10)	 // If Rising curve
				{
					t = y1 + (((y2 - y1) * 35) / 100);
					*dac_pt++ = (int)(t);
					y1_new = (int)(t); // t=(12*(y1+y2))/25; *dac_pt++=(int)(t);     /*  Controls Smooth /average factor */
					t = x1 + ((x2 - x1) * 2) / 4;
					*dac_pt++ = (int)(t);
					t = y1 + (((y2 - y1) * 63) / 100);
					*dac_pt++ = (int)(t); // 65
					t = x1 + ((x2 - x1) * 3) / 4;
					*dac_pt++ = (int)(t);
					t = y1 + (((y2 - y1) * 83) / 100);
					*dac_pt++ = (int)(t); // 85
				} /*  Store Amp of calculated Value   */
				else // If Falling curve
				{
					if (y1_old<y1 & y1> y2)
					{
						t = y1 - (((y1 - y2) * 20) / 100);
						*dac_pt++ = (int)(t);
						y1_new = (int)(t);
						t = x1 + ((x2 - x1) * 2) / 4;
						*dac_pt++ = (int)(t);
						t = y1 - (((y1 - y2) * 55) / 100);
						*dac_pt++ = (int)(t);
					}
					else
					{
						t = y1 - (((y1 - y2) * 35) / 100);
						*dac_pt++ = (int)(t);
						y1_new = (int)(t);
						t = x1 + ((x2 - x1) * 2) / 4;
						*dac_pt++ = (int)(t);
						t = y1 - (((y1 - y2) * 63) / 100);
						*dac_pt++ = (int)(t);
					}
					t = x1 + ((x2 - x1) * 3) / 4;
					*dac_pt++ = (int)(t);
					t = y1 - (((y1 - y2) * 83) / 100);
					*dac_pt++ = (int)(t); // 85
				} /*  Store Amp of calculated Value   */
			}
		}
		y1_old = y1_new; // Used to check peak of DAC curve
	} // For loop end

extdcl1:
	dac_pt = &dac_ptmp[0];
	for (i = 0; i < 250; i++)
	{
		check[i] = *dac_pt++;
	}

	dac_p = jp;

	dac_pt = &dac_ptmp[0];
	x1 = *dac_pt++; /* First point   */
	y1 = *dac_pt++;
	x2 = *dac_pt++; /* Get Next point */
	y2 = *dac_pt++;

	if (x1 > 0) // Intially upto X1 value fill with zero
	{
		for (i = 0; i < x1; i++)
		{
			*dac_p++ = 0;
		}
	}
	else if (x1 < 0)
	{
	nextrd:
		if (x2 < 0)
		{
			x1 = x2;		//*dac_pt++; /* First point   */
			y1 = y2;		//*dac_pt++;
			x2 = *dac_pt++; /* Get Next point */
			y2 = *dac_pt++;
		}
		if (x2 < 0)
		{
			goto nextrd;
		}
	}

	for (i = x1; i < Screen_w + 6; i++) /* Need to generate curve for 250 pix */
	{
		if (x1 > x2) // (x1>=x2) But it creates problem in DGS so changed to X1 > X2
		{
			*dac_p++ = 0;
		}
		else
		{
			if (i >= x1 && i < x2)
			{ // if (y1<201 || y2<201)
				{
					if (i > 0) //{*(dac_p++)=(y1+(((y2-y1)*(x1-i))/(x2-x1)));}
					{
						dy = y1 - y2;
						dx = x2 - x1;
						xof = x1 - i;
						p1 = ((dy * xof) / dx);
						*(dac_p++) = (y1 + p1);
					}
				}
				// else
				//  { *dac_p++=201; }
			}
			else if (i == x1 && i == x2) /* if equal to x2 (next) point then read next point */
			{
				x1 = x2, y1 = y2;
				x2 = *dac_pt++;
				y2 = *dac_pt++;
				if (y2 > y1)
				{
					*(dac_p++) = y2;
				}
				else
				{
					*(dac_p++) = y1;
				}
			}
			else if (i == x2) /* if equal to x2 (next) point then read next point */
			{
				x1 = x2, y1 = y2;
				x2 = *dac_pt++;
				y2 = *dac_pt++;
				*(dac_p++) = y1;
			}
			else if (x2 < i)
			{
				x1 = x2, y1 = y2;
				x2 = *dac_pt++;
				y2 = *dac_pt++; /**(dac_p--);*/
				if (y2 > y1)
				{
					*(dac_p++) = y2;
				}
				else
				{
					*(dac_p++) = y1;
				}
				if (x2 < i)
				{
					x1 = x2, y1 = y2;
					x2 = *dac_pt++;
					y2 = *dac_pt++;
					*(dac_p--);
					if (y2 > y1)
					{
						*(dac_p++) = y2;
					}
					else
					{
						*(dac_p++) = y1;
					}
				}
				if (x2 < i)
				{
					x1 = x2, y1 = y2;
					x2 = *dac_pt++;
					y2 = *dac_pt++;
					*(dac_p--);
					if (y2 > y1)
					{
						*(dac_p++) = y2;
					}
					else
					{
						*(dac_p++) = y1;
					}
				}
				if (x2 < i)
				{
					x1 = x2, y1 = y2;
					x2 = *dac_pt++;
					y2 = *dac_pt++;
					*(dac_p--);
					if (y2 > y1)
					{
						*(dac_p++) = y2;
					}
					else
					{
						*(dac_p++) = y1;
					}
				}
				if (x2 < i)
				{
					x1 = x2, y1 = y2;
					x2 = *dac_pt++;
					y2 = *dac_pt++;
					*(dac_p--);
					if (y2 > y1)
					{
						*(dac_p++) = y2;
					}
					else
					{
						*(dac_p++) = y1;
					}
				}
				if (x2 < i)
				{
					x1 = x2, y1 = y2;
					x2 = *dac_pt++;
					y2 = *dac_pt++;
					*(dac_p--);
					if (y2 > y1)
					{
						*(dac_p++) = y2;
					}
					else
					{
						*(dac_p++) = y1;
					}
				}
				if (x2 < i)
				{
					x1 = x2, y1 = y2;
					x2 = *dac_pt++;
					y2 = *dac_pt++;
					*(dac_p--);
					if (y2 > y1)
					{
						*(dac_p++) = y2;
					}
					else
					{
						*(dac_p++) = y1;
					}
				}
				if (x2 < i)
				{
					x1 = x2, y1 = y2;
					x2 = *dac_pt++;
					y2 = *dac_pt++;
					*(dac_p--);
					if (y2 > y1)
					{
						*(dac_p++) = y2;
					}
					else
					{
						*(dac_p++) = y1;
					}
				}
				if (x2 < i)
				{
					x1 = x2, y1 = y2;
					x2 = *dac_pt++;
					y2 = *dac_pt++;
					*(dac_p--);
					if (y2 > y1)
					{
						*(dac_p++) = y2;
					}
					else
					{
						*(dac_p++) = y1;
					}
				}
				if (x2 < i)
				{
					x1 = x2, y1 = y2;
					x2 = *dac_pt++;
					y2 = *dac_pt++;
					*(dac_p--);
					if (y2 > y1)
					{
						*(dac_p++) = y2;
					}
					else
					{
						*(dac_p++) = y1;
					}
				}
				if (x2 < i)
				{
					x1 = x2, y1 = y2;
					x2 = *dac_pt++;
					y2 = *dac_pt++;
					*(dac_p--);
					if (y2 > y1)
					{
						*(dac_p++) = y2;
					}
					else
					{
						*(dac_p++) = y1;
					}
				}
			}
			else
				*dac_p++ = (int)(0);
		}
	}

	dac_p = jp; // Load Starting pointer address of array
	for (i = 0; i < 250; i++)
	{
		check[i] = *dac_p++;
	}

	/* Plot DAC Curve */
	dac_p = jp; // Load Starting pointer address of array

	// if (dac_v==3)  // IF TCG is ON
	{
		y2 = 0;
		dac_npnt = 0;				   // If TCG is on then Draw Stright Curve
		for (i = 0; i < Screen_w; i++) // 250
		{
			y1 = *dac_p++; // y1=*dac_p++;
			if (y1 > 0)
			{
				if (y2 == 0)
				{
					y1 = (ref_g) - (crv_gain); //=ref_g
					y1 = GaintoEH(y1);		   /* Get %height from dB value */
					y2 = y1;				   // y2 holds first non zero data
					if (y2 > 199)
						y2 = 199;
					y2 = Asc_Height - ((Asc_Height * y2) / 200);
				}
				pntArray_DAC[dac_npnt].y = y2; // 2; //temp;
				pntArray_DAC[dac_npnt].x = (Asc_Width * i) / 250;
				dac_npnt++; // Also keep how many DAC point to be draw during Polyline
			}
		}
	}

	// *************** Send to FPGA for TCG ***********************
	//****  TCG Address Reset *************************************
	// ENCRST_reg=ENCRST_reg|0x02;
	int ds = 0;
	ENCRST_reg = ENCRST_reg & 0xFB; //  1111 1011
	ENCRST_reg = ENCRST_reg | 0x04;
	tx_cmd[ds++] = 0x1B;
	tx_cmd[ds++] = r_addENCRST;
	tx_cmd[ds++] = ENCRST_reg;
	tx_cmd[ds++] = 0x1B;			// 1B 56 04 1B    Address Reset
	ENCRST_reg = ENCRST_reg & 0xFB; //  1111 1011
	tx_cmd[ds++] = 0x1B;
	tx_cmd[ds++] = r_addENCRST;
	tx_cmd[ds++] = ENCRST_reg;
	tx_cmd[ds++] = 0x1B; // 1B 56 00 1B    Address Clear
	Send_SPI(ds);		 // Send data

	for (i = 0; i <= 256; i++)
	{
		dac_ptmp[i] = check[i];
	}

	i = 0;

	for (i = 0; i < 45; i++)		// 2024-07-24
	{
		dac_ptmp[250 + i] = dac_ptmp[20];
	}

	k = 0;
	tx_bufidx = 0;
	for (i = 0; i <= 256 + 40; i++)
	{
		templ = dac_ptmp[i];
		if (templ < 0)
		{
			templ = 0;
		}
		templ = templ * (4096 + 0); // 275  // 300 Code= (dB *4096) /(20*3)
		templ = templ / 600;		// templ=templ/600;
		end = templ + TCG_offGn;	// Holds calculated DAC value of DAC 2 used in TCG calculation //VG2off;
		if (end > 4095)
		{
			end = 4095;
		} // Sample fre to be 25Mhz
		data = end;
		utemp = (uint8_t)data;
		Write_data(DATA1_Adr, utemp); // LSB 0 byte Register R1
		data = end >> 8;
		utemp = (uint8_t)data;
		Write_data(0x89, utemp); // LSB 1 byte Register R1  //Write_data(DATA2_Adr, utemp);  // LSB 1 byte Register R1
	}
	
	Send_SPI(tx_bufidx);
	tx_bufidx = 0;

	for (i = 0; i <= 500; i++)
	{
		templ = dac_ptmp[10];
		if (templ < 0)
		{
			templ = 0;
		}
		templ = templ * (4096 + 0); // 275  // 300 Code= (dB *4096) /(20*3)
		templ = templ / 600;		// templ=templ/600;
		end = templ + TCG_offGn;	// Holds calculated DAC value of DAC 2 used in TCG calculation //VG2off;
		if (end > 4095)
		{
			end = 4095;
		} // Sample fre to be 25Mhz
		data = end;
		utemp = (uint8_t)data;
		Write_data(DATA1_Adr, utemp); // LSB 0 byte Register R1
		data = end >> 8;
		utemp = (uint8_t)data;
		Write_data(0x89, utemp); // LSB 1 byte Register R1  //Write_data(DATA2_Adr, utemp);  // LSB 1 byte Register R1
	}

	Send_SPI(tx_bufidx);

	// Full curve data is also required when Dac Curve trigger is used
	for (i = 0; i < 255; i++)
	{
		pntArray_DACM[i].y = pntArray_DAC[i].y;
		pntArray_DACM[i].x = pntArray_DAC[i].x;
	}
}

/************************************************************************************/
/************************************************************************************/
void Send_Tcg_Data()
{
	int Cnt, Lsb, Msb;
	unsigned char wDatam, wDatal;
	int ds = 0; // //Fill data for TCG

	ENCRST_reg = ENCRST_reg & 0xFB; //  1111 1011
	ENCRST_reg = ENCRST_reg | 0x04;
	tx_cmd[ds++] = 0x1B;
	tx_cmd[ds++] = r_addENCRST;
	tx_cmd[ds++] = ENCRST_reg;
	tx_cmd[ds++] = 0x1B;			// 1B 56 04 1B    Address Reset
	ENCRST_reg = ENCRST_reg & 0xFB; // 1111 1011
	tx_cmd[ds++] = 0x1B;
	tx_cmd[ds++] = r_addENCRST;
	tx_cmd[ds++] = ENCRST_reg;
	tx_cmd[ds++] = 0x1B; // 1B 56 00 1B    Address Clear

	for (Cnt = 0; Cnt < 256; Cnt++)
	{
		Lsb = Cnt * 4;
		wDatal = (unsigned char)Lsb;
		Msb = Cnt * 4;
		Msb = Msb >> 8;
		Msb = Msb & 0x0FF;
		wDatam = (unsigned char)Msb;
		tx_cmd[ds++] = 0x1B;
		tx_cmd[ds++] = 0x44;
		tx_cmd[ds++] = wDatal;
		tx_cmd[ds++] = 0x1B; // 1B 44 LL 1B    LSB Data of DAC
		tx_cmd[ds++] = 0x1B;
		tx_cmd[ds++] = 0x89;
		tx_cmd[ds++] = wDatam;
		tx_cmd[ds++] = 0x1B; // 1B 89 MM 1B    MSB Data of DAC
	}
	Send_SPI(ds);

	// Send data
	// tx_cmd[ds++]=0x1B;   tx_cmd[ds++]=0x56; tx_cmd[ds++]=0x02;  tx_cmd[ds++]=0x1B;     // 1B 56 02 1B     Enable TCG
	// tx_cmd[ds++]=0x1B;   tx_cmd[ds++]=0x56; tx_cmd[ds++]=0x00;  tx_cmd[ds++]=0x1B;     // 1B 56 00 1B     Disable TCG
}

void OpenFile(void)
{
	remove("TestFile.txt");

	fpTemp = fopen("TestFile.txt", "w");
	if (fpTemp == NULL)
		g_print("Failed to open TestFile.txt file...\n");
}

void WriteDataIntoFile(int i,  int gain)
{
	if (i == 0)
		fprintf(fpTemp, "\n");

	fprintf(fpTemp, "%d     %d\n", i, gain);

	if (i == 299)
		fprintf(fpTemp, "\n\n");
}

void CloseFile(void)
{
	if (fpTemp)
	{
		fclose (fpTemp);
		fpTemp = NULL;
		g_print("Closed TestFile.txt file successfully...\n");
	}
}

//***********************************************************************************
//***********************************************************************************
void TCG_pnt_f(int keyupdn) // Select approprite DAC point and adjust Gain of it
{
	double Pnt_strt, RangD;
	int H_db, point;
	char *unit[] = {"   "};

	Tcg_pnt_v = Tcg_pnt_v + keyupdn;

	if (Tcg_pnt_v < 0)
	{
		Tcg_pnt_v = 0;
	}
	if (Tcg_pnt_v > 10)
	{
		Tcg_pnt_v = 10;
	}
	Pnt_strt = dac_pnt[(Tcg_pnt_v * 2)];

	if (Pnt_strt == 0)
	{
		Tcg_pnt_v = 0;
	}

	toarry(Tcg_pnt_v + 1, pos, 0, 0, unit[0]);
	pos = (CURSOR_PERA * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	strcpy(Dsp_Str, "POINT  ");
	strcpy(all_btnval[pos - 1], Dsp_Str);
	strcpy(all_btnval[pos + 3], "        ");
	strcpy(all_btnval[pos + 4], "        ");
	// allpera[DSTART_POSI-1]="POINT  ";
	RangD = val_ary[RANGE_PERA];
	RangD = RangD / 10;
	Gend2_v = RangD; // Set Gate Width

	Pnt_strt = dac_pnt[(Tcg_pnt_v * 2)]; // Dac Point is recorded in terms of 250 pix position with Range so
	point = (int)Pnt_strt;				 // In calculation DAC Range and Current Range so Gate position to be Proper

	// RangD=Range_v/10;
	// Pnt_strt=(Pnt_strt*RangD)/250;  // Range_dac

	Pnt_strt = (Pnt_strt * Range_dac) / 250; // Now ptr in terms of mm
	Gstart2_v = Pnt_strt / 10;				 //-(Gend2_v/2);  // level2_v=50;

	val_ary[GSTA2_PERA] = Gstart2_v;
	val_ary[GEND2_PERA] = Gend2_v;
	val_ary[GTHE2_PERA] = 50;

	gl_clear_color_background_data(width_sh, height_sh);
	TCG_pnt_gn(0);
	// Cal_gate();
}

///***********************************************************************************
///***********************************************************************************
void TCG_pnt_gn(int keyupdn) //  DAC point Gain set
{
	int H_db, point;
	char *unit[] = {" dB"};
	int Tcg_gn;
	pos = (PRESS_PERA * 2) + 1;
	Tcg_gn = dac_pnt[(Tcg_pnt_v * 2) + 1];
	Tcg_gn = Tcg_gn + keyupdn;

	if (Tcg_gn < 0)
	{
		Tcg_gn = 0;
	}
	if (Tcg_gn > 1000)
	{
		Tcg_gn = 1000;
	}
	dac_pnt[(Tcg_pnt_v * 2) + 1] = Tcg_gn;
	toarry(Tcg_gn, pos, 0, 1, unit[0]);
	strcpy(all_btnval[pos], Dsp_Str);
	strcpy(Dsp_Str, "TCG GN ");
	strcpy(all_btnval[pos - 1], Dsp_Str);
	// allpera[PRESS_POSI-1]="TCG GN ";
    
	TCG_Activate_Deactivate(false);
	dac_gen(&dac_pnt[0], &dac_cv[0], Gain_v, Range_v, Delay_rv); // If Dac ON/TCG ON then Draw DAC Curve
	TCG_Cal(&dac_pnt[0], &dac_cv[0], Gain_v, Range_v, Delay_rv);
	TCG_Activate_Deactivate(true); 
}
  
//*************************************************************************************************
//************************************ Activate Deactivate TCG Function   *************************
//*************************************************************************************************
void TCG_Activate_Deactivate(bool tcg_onoff)
{
	int ds = 0;

	ENCRST_reg = ENCRST_reg & 0xFD;

	if (tcg_onoff == 1) // Enable TCG
	{
		ENCRST_reg = ENCRST_reg | 0x02;
		tx_cmd[ds++] = 0x1B;
		tx_cmd[ds++] = r_addENCRST;
		tx_cmd[ds++] = ENCRST_reg;
		tx_cmd[ds++] = 0x1B; // 1B 56 02 1B     Enable TCG
		Send_SPI(ds);		 // Send data
	}
	else // Disable TCG
	{
		tx_cmd[ds++] = 0x1B;
		tx_cmd[ds++] = r_addENCRST;
		tx_cmd[ds++] = ENCRST_reg;
		tx_cmd[ds++] = 0x1B; // 1B 56 00 1B     Disable TCG
		Send_SPI(ds);		 // Send data
		Gain_f(0);
	}
	Gain_f(0);
}

/************************************************************************************/
/****************************************AWS FUNC************************************/
/************************************************************************************/
void AWS_f(int key_t)
{
	char buffer[40];
	double tempd;
	Aws_onoff_v = val_ary[DAC_PERA];

	//**********KEY_SCR = 0*********************

	if (key_scr == 0) // Get the value from scrollbar
	{
		gtk_adjustment_set_lower(adj, 0);
		gtk_adjustment_set_upper(adj, 2);
		// Aws_onoff_v = val_ary[DAC_PERA];
	}

	//**********KEY_SCR = 1*********************

	if (key_scr == 1) // Get the value from button keypad
	{
		Aws_onoff_v = Aws_onoff_v + key_t;
	}

	if (Aws_onoff_v < 0)
	{
		Aws_onoff_v = 2;
	}
	if (Aws_onoff_v > 2)
	{
		Aws_onoff_v = 0;
	}

	val_ary[DAC_PERA] = Aws_onoff_v;

	Draw_notificimg(SZEVAL_S, Evaluate_val);

	pos = DAC_PERA * 2;
	if (Aws_onoff_v == 0)
	{
		strcpy(all_btnval[pos + 1], "OFF    ");
		// Gain_f(0);
	}
	if (Aws_onoff_v == 1)
	{
		strcpy(all_btnval[pos + 1], "SET    ");
	}
	if (Aws_onoff_v == 2)
	{
		strcpy(all_btnval[pos + 1], "MEASURE");
		// Measure_f(0);
	}
	strcpy(all_btnval[pos + 0], "AWS    ");
	strcpy(all_btnval[pos + 4], "SET-REF");
	strcpy(all_btnval[pos + 6], "       ");
	strcpy(all_btnval[pos + 7], "       ");
	Aws_Ref_f(0); // Refresh SET-REF status

	if (Aws_onoff_v == 0) // After set-ref is turned on reference value is shown instead of gain. To remove ref value after aws is off we need to call below function
	{
		Gain_f(0);
	}
}

/************************************************************************************/
/****************************************DGS FUNC************************************/
/************************************************************************************/
void DGS_f(int key_t)
{
	gtk_adjustment_set_lower(adj, 0);
	gtk_adjustment_set_upper(adj, 5);

	pos = DAC_PERA * 2;
	Dgs_onoff_v = val_ary[DAC_PERA];
	gdac_flag = false;

	DGS_ReadFile = true;

	//**********KEY_SCR = 0*********************

	if (key_scr == 0) // Get the value from scrollbar
	{
		// Dgs_onoff_v = val_ary[DAC_PERA];
	}

	//**********KEY_SCR = 1*********************

	if (key_scr == 1) // Get the value from button keypad
	{
		Dgs_onoff_v = Dgs_onoff_v + key_t;
	}
	// Refresh Display Perametere
	if (Dgs_onoff_v < 0)
	{
		Dgs_onoff_v = 0;
	}
	if (Dgs_onoff_v > 3)
	{
		Dgs_onoff_v = 0;
	}
	val_ary[DAC_PERA] = Dgs_onoff_v;

	Draw_notificimg(SZEVAL_S, Evaluate_val);

	if (Dgs_onoff_v == 0)
	{
		val_ary[PRESS_PERA] = 0;
		strcpy(all_btnval[pos + 1], "OFF    ");
		gdac_flag = false;
		Asc_Dsp = 1;
		DGS_Ref_f(0);
		if (recall_read == 1)
			opengl_update = false;
		else
			opengl_update = true;

		if (Bsc_Dsp == false) // This condition used here due to segmentation fault and multiple calls to opengl
		{
			partial_uninitialize();
			recreate_surface(width_sh, height_sh, ogl_x_position, ogl_y_position);
			gl_clear_color_background_data(width_sh, height_sh);
		}
	}
	else if (Dgs_onoff_v == 1)
	{
		strcpy(all_btnval[pos + 1], "SELECT ");
		Asc_Dsp = 0;
		gtk_label_set_label(GTK_LABEL(label_dv[1]), all_btnval[pos + 1]);
		gtk_widget_set_can_focus(GTK_WIDGET(dgs_btn[16]), true);
		gtk_widget_grab_focus(GTK_WIDGET(dgs_btn[16]));
		partial_uninitialize();
		Menu_pre = menu_v;
		menu_v = 19;
		Sub_st_menu = menu_v - 2; // Store Current value of Menu for restore // DGS Setting Menu
		Dsp_dgs_selection(0);	  //  MENU 16 1
		Scal_f(0);
		DGS_Ref_f(0);
	}
	else if (Dgs_onoff_v == 2)
	{
		Asc_Dsp = 1;
		strcpy(all_btnval[pos + 1], "REF REC");
		strcpy(all_btnval[pos + 4], "DGS REF");
		gdac_flag = true;
		TCG_Activate_Deactivate(false);
		DGS_Ref_f(0);
		partial_uninitialize();
		recreate_surface(width_sh, height_sh, ogl_x_position, ogl_y_position);
		dac_gen(&dac_pnt[0], &dac_cv[0], Gain_v, Range_v, Delay_rv); // If Dac ON then Draw DAC Curve
	}
	else if (Dgs_onoff_v == 3)
	{
		gdac_flag = true;
		strcpy(all_btnval[pos + 1], "ON     ");
		strcpy(all_btnval[pos + 4], "DGS dB");
		DGS_on_f(key_t);
		DgsCrv_db(0);												 // Rahul Nair for Multiple DGS dB increase function
		dac_gen(&dac_pnt[0], &dac_cv[0], Gain_v, Range_v, Delay_rv); // If Dac ON then Draw DAC Curve
	}
}

/************************************************************************************/
/****************************************SCAL FUNC***********************************/
/************************************************************************************/
void Scal_f(int key_t)
{
	char Prb_name[10];
	long tempL;
	gtk_adjustment_set_lower(adj, 0);
	gtk_adjustment_set_upper(adj, 18);

	Scal_v = val_ary[SCALE_POS_PERA];

	//**********KEY_SCR = 0*********************

	if (key_scr == 0) // Get the value from scrollbar
	{
	}

	//**********KEY_SCR = 1*********************

	if (key_scr == 1) //  Get the value from button keypad
	{
		Scal_v = Scal_v + (key_t * Key_stp);
	}

	if (Scal_v < 0)
	{
		Scal_v = 0;
	}
	if (Scal_v > 18)
	{
		Scal_v = 18;
	}

	val_ary[SCALE_POS_PERA] = Scal_v;

	if (Scal_v == 0)
	{
		D_efect_vC = 150;
		// Dly_vel_vC = 1000;
		Dly_vel_vC = val_ary[DELVEL_PERA];
		Prb_freq_vC = 25; // This Value to be set in Set_Default_pera_value
		strcpy(Dsp_Str, "0      ");
		strcpy(Prb_name, "CUSTOM ");
		Prb_freq_v = Prb_freq_vC;
		D_efect_v = D_efect_vC;
		Dly_vel_v = Dly_vel_vC;
		Near_FD = 9216000;
		// NFLT = ( F * E_dia *E_dia * 5 )/2   Actual NF= NFLT/Velo
	}

	if (Scal_v == 1)
	{
		strcpy(Dsp_Str, "1      ");
		strcpy(Prb_name, "M1SN   ");
		Prb_freq_v = 100;
		D_efect_v = 232;
		Dly_vel_v = 2500;
		Near_FD = 13456000;
	}

	if (Scal_v == 2)
	{
		strcpy(Dsp_Str, "2      ");
		strcpy(Prb_name, "M2SN   ");
		Prb_freq_v = 200;
		D_efect_v = 231;
		Dly_vel_v = 2500;
		Near_FD = 26680500;
	}

	if (Scal_v == 3)
	{
		strcpy(Dsp_Str, "3      ");
		strcpy(Prb_name, "M4SN   ");
		Prb_freq_v = 400;
		D_efect_v = 228;
		Dly_vel_v = 2500;
		Near_FD = 51984000;
	}

	if (Scal_v == 4)
	{
		strcpy(Dsp_Str, "4      ");
		strcpy(Prb_name, "MM2SN  ");
		Prb_freq_v = 200;
		D_efect_v = 97;
		Dly_vel_v = 2500;
		Near_FD = 4704500;
	}

	if (Scal_v == 5)
	{
		strcpy(Dsp_Str, "5       ");
		strcpy(Prb_name, "MM4SN  ");
		Prb_freq_v = 400;
		D_efect_v = 96;
		Dly_vel_v = 2500;
		Near_FD = 9216000;
	}

	if (Scal_v == 6)
	{
		strcpy(Dsp_Str, "6      ");
		strcpy(Prb_name, "MM5SN  ");
		Prb_freq_v = 500;
		D_efect_v = 96;
		Dly_vel_v = 2500;
		Near_FD = 11520000;
	}

	if (Scal_v == 7)
	{
		strcpy(Dsp_Str, "7      ");
		strcpy(Prb_name, "MBW45-2");
		Prb_freq_v = 200;
		D_efect_v = 98;
		Dly_vel_v = 2730;
		Near_FD = 4802000;
	}

	if (Scal_v == 8)
	{
		strcpy(Dsp_Str, "8      ");
		strcpy(Prb_name, "MBW60-2");
		Prb_freq_v = 200;
		D_efect_v = 98;
		Dly_vel_v = 2730;
		Near_FD = 4802000;
	}

	if (Scal_v == 9)
	{
		strcpy(Dsp_Str, "9      ");
		strcpy(Prb_name, "MBW70-2");
		Prb_freq_v = 200;
		D_efect_v = 98;
		Dly_vel_v = 2730;
		Near_FD = 4802000;
	}

	if (Scal_v == 10)
	{
		strcpy(Dsp_Str, "10     ");
		strcpy(Prb_name, "MBW45-4");
		Prb_freq_v = 400;
		D_efect_v = 98;
		Dly_vel_v = 2730;
		Near_FD = 9604000;
	}

	if (Scal_v == 11)
	{
		strcpy(Dsp_Str, "11     ");
		strcpy(Prb_name, "MBW60-4");
		Prb_freq_v = 400;
		D_efect_v = 98;
		Dly_vel_v = 2730;
		Near_FD = 9604000;
	}

	if (Scal_v == 12)
	{
		strcpy(Dsp_Str, "12     ");
		strcpy(Prb_name, "MBW70-4");
		Prb_freq_v = 400;
		D_efect_v = 98;
		Dly_vel_v = 2730;
		Near_FD = 9604000;
	}

	if (Scal_v == 13)
	{
		strcpy(Dsp_Str, "13     ");
		strcpy(Prb_name, "BW45-1 ");
		Prb_freq_v = 100;
		D_efect_v = 242;
		Dly_vel_v = 2730;
		Near_FD = 14641000;
	}

	if (Scal_v == 14)
	{
		strcpy(Dsp_Str, "14     ");
		strcpy(Prb_name, "BW60-1 ");
		Prb_freq_v = 100;
		D_efect_v = 242;
		Dly_vel_v = 2730;
		Near_FD = 14641000;
	}

	if (Scal_v == 15)
	{
		strcpy(Dsp_Str, "15     ");
		strcpy(Prb_name, "BW70-1 ");
		Prb_freq_v = 100;
		D_efect_v = 242;
		Dly_vel_v = 2730;
		Near_FD = 14641000;
	}

	if (Scal_v == 16)
	{
		strcpy(Dsp_Str, "16     ");
		strcpy(Prb_name, "BW45-2 ");
		Prb_freq_v = 200;
		D_efect_v = 242;
		Dly_vel_v = 2730;
		Near_FD = 29282000;
	}

	if (Scal_v == 17)
	{
		strcpy(Dsp_Str, "17     ");
		strcpy(Prb_name, "BW60-2 ");
		Prb_freq_v = 200;
		D_efect_v = 242;
		Dly_vel_v = 2730;
		Near_FD = 29282000;
	}

	if (Scal_v == 18)
	{
		strcpy(Dsp_Str, "18      ");
		strcpy(Prb_name, "BW70-2 ");
		Prb_freq_v = 200;
		D_efect_v = 242;
		Dly_vel_v = 2730;
		Near_FD = 29282000;
	}

	// if (Scal_v == 19)  // Scal_v == 19 ADDED FOR TESTING PURPOSE ONLY. THIS Scal_v == 19 PART IS IRRELEVANT
	/*{
		strcpy(Dsp_Str, "19     ");
		strcpy(Prb_name, "M19SN  ");
		Prb_freq_v = 200;
		D_efect_v = 232;
		Dly_vel_v = 2500;
		Near_FD = 29282000;
	}*/

	if (Unit_v == INCH)
	{
		tempL = Near_FD / 127; // Convert to Inch   100*100/(254/254)
		tempL = tempL * 2500;
		Near_FD = tempL / 127;

		tempL = D_efect_v;
		tempL = (tempL * 500) / 127; // Convert to Inch
		D_efect_v = tempL;

		tempL = Dly_vel_v;
		tempL = (tempL * 50) / 127; // Convert to Inch
		Dly_vel_v = tempL;
	}

	pos = (SCALE_POS_PERA * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	strcpy(all_btnval[pos + 2], Prb_name);

	gtk_label_set_label(GTK_LABEL(dgslabel[1]), Dsp_Str);
	gtk_label_set_label(GTK_LABEL(dgslabel[3]), Prb_name);

	Prb_freq_f(0);
	D_efect_f(0);
	Del_Vel_f(0);
	Dgs_crv_f(0);
	Ref_size_f(0);

	if (Error_msg == true)
	{
		gtk_widget_hide(b_errorbox);
		gtk_widget_show(b_btnbox);
		Error_msg = false;
	} // Don't display Error message
}

/************************************************************************************/
/****************************************Defect FUNC*********************************/
/************************************************************************************/
void D_efect_f(int key_t)
{
	char *unitm[] = {" mm"}, *uniti[] = {" in"};
	int ndgt = 1;
	float tempdefct_rv = 0.0;

	gtk_adjustment_set_lower(adj, 0);
	gtk_adjustment_set_upper(adj, 100);

	D_efect_vC = val_ary[D_EFECT_PERA];

	//**********KEY_SCR = 0*********************
	if (Scal_v == 0) // If Custom then key value is ok else make it to zero so only valy get update in display
	{
		//********** KEY_SCR = 0 *********************
		if (key_scr == 0) // Get the value from scrollbar
		{
			// D_efect_vC = val_ary[D_EFECT_PERA];
			if (Unit_v == INCH)
			{
				D_efect_vC = D_efect_vC + (key_t * Key_stp);
				if (D_efect_vC > 1200)
				{
					D_efect_vC = 1200;
				}
				if (D_efect_vC < 200)
				{
					D_efect_vC = 200;
				}
				val_ary[D_EFECT_PERA] = D_efect_vC;

				D_efect_v = D_efect_vC;
			}
			else // UNit is mm
			{
				D_efect_vC = D_efect_vC + (key_t * Key_stp);
				if (D_efect_vC > 300)
				{
					D_efect_vC = 300;
				}
				if (D_efect_vC < 50)
				{
					D_efect_vC = 50;
				}
				val_ary[D_EFECT_PERA] = D_efect_vC;
				D_efect_v = D_efect_vC;
			}
		}
	}

	if (Scal_v == 0) // If Custom Scale then Allow to vary Defect else make it to zero so only value get update in display
	{
		//**********KEY_SCR = 1*********************

		if (key_scr == 1) // Get the value from button keypad
		{
			// D_efect_vC = val_ary[D_EFECT_PERA];
			if (Unit_v == INCH)
			{
				D_efect_vC = D_efect_vC + (key_t * Key_stp);
				if (D_efect_vC > 1200)
				{
					D_efect_vC = 1200;
				}
				if (D_efect_vC < 200)
				{
					D_efect_vC = 200;
				}
				val_ary[D_EFECT_PERA] = D_efect_vC;
				D_efect_v = D_efect_vC;
			}
			else // Unit is mm
			{
				D_efect_vC = D_efect_vC + (key_t * Key_stp);
				if (D_efect_vC > 300)
				{
					D_efect_vC = 300;
				}
				if (D_efect_vC < 50)
				{
					D_efect_vC = 50;
				}
				val_ary[D_EFECT_PERA] = D_efect_vC;
				D_efect_v = D_efect_vC;
			}
		}

		//********** KEY_SCR = 2 *********************

		if (key_scr == 2) // Get the value from touch keypad
		{
			if (Unit_v == MM)
			{
				tempdefct_rv = key_array[D_EFECT_PERA];
				D_efect_vC = tempdefct_rv * 10;

				if (D_efect_vC > 300)
				{
					D_efect_vC = 300;
				}
				if (D_efect_vC < 50)
				{
					D_efect_vC = 50;
				}
				val_ary[D_EFECT_PERA] = D_efect_vC;
				D_efect_v = D_efect_vC;
			}
			else
			{
				tempdefct_rv = key_array[D_EFECT_PERA];

				D_efect_vC = tempdefct_rv * 1000;

				if (D_efect_vC > 1200)
				{
					D_efect_vC = 1200;
				}
				if (D_efect_vC < 200)
				{
					D_efect_vC = 200;
				}
				val_ary[D_EFECT_PERA] = D_efect_vC;
				D_efect_v = D_efect_vC;
			}
		}
	}

	pos = (D_EFECT_PERA * 2) + 1;
	// pos=181;
	if (Unit_v == INCH)
	{
		toarry(D_efect_v, pos, 0, 3, uniti[0]);
	}
	else
	{
		toarry(D_efect_v, pos, 0, 1, unitm[0]);
	}

	pos = (D_EFECT_PERA * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	gtk_label_set_label(GTK_LABEL(dgslabel[9]), Dsp_Str);
}

/***********************************************************************************/
/***********************************************************************************/
void Frame_menu_exit_f(int key_t) // Exit From Frame Menu
{
	if (key_t == 1 || key_t == -1)
	{
		gtk_widget_hide(f2_box); // Frame Menu Exit
	}

	gtk_widget_set_can_focus(GTK_WIDGET(btn_dv[1]), true);
	gtk_widget_grab_focus(GTK_WIDGET(btn_dv[1]));
	gtk_widget_set_name(btn_dv[1], "btnv1_1-entry");

	if (menu_v == 28) // Beam Profile Menu then set focus button 2
	{
		btn_idx = 1;
		Beam_Prof_f(key_t);
	} // BEAM_PROF_PERA
	else if (menu_v == 31)
	{
		btn_idx = 3;
	}
	else if (menu_v == 34)
	{
		btn_idx = 3;
	}
	else
	{
		btn_idx = 0;
	}

	menu_v = Menu_pre;
	Set_btn_focus(); // Set Button/Controll Focus /Appropriate Color to indicate Selected
}

/***********************************************************************************/
/**********************************DGS EXIT FUNCTION*******************************/
/***********************************************************************************/
void Dgs_exit_f(int key_t)
{
	int gst_p;
	long int temp;

	if (key_t != 0)
	{
		temp = Ref_size_v << 8; // Plot Curve as per Reference
		temp = temp / D_efect_v;
		gst_p = temp;	  // 0x33 for 0.5 Ratio
		Get_Dgs_f(gst_p); // As per Ratio Get DGS Curve points from LKT
		Dgs_gain = 180;	  // Draw DGS Curve at 80% FSH

		Dgs_onoff_v = 2;
		val_ary[DAC_PERA] = Dgs_onoff_v;
		DGS_f(0); // Directly display DGS Ref Record and to DIspaly Ref curve
	}
}

/***********************************************************************************/
/******************************Dsp_dgs_selection FUNCTION***************************/
/***********************************************************************************/
void Dsp_dgs_selection(int Frame_type) //   Key A,S change Colums, Arroy Up/DN key for Row Selection, //
{
	int Scr_idx;

	if (Frame_type == 0) // DGS SET Configuration Frame
	{
		pos = SCALE_POS_PERA * 2;
		Scr_idx = pos;
		for (i = 0; i < 24; i++)
		{
			if (i == 8 || i == 16)
			{
				Scr_idx = Scr_idx + 2;
			}
			gtk_label_set_label(GTK_LABEL(dgslabel[i]), all_btnval[Scr_idx++]);
		}
		refresh_weld_profiler_area();
		gtk_widget_show(f2_box);
	}
	else if (Frame_type == 1) // WELD Profile Configuration Frame
	{
		pos = (WELD_TYPE_PERA * 2);
		Scr_idx = pos;
		for (i = 0; i < 24; i++)
		{
			if (i == 8 || i == 16)
			{
				Scr_idx = Scr_idx + 2;
			}
			gtk_label_set_label(GTK_LABEL(dgslabel[i]), all_btnval[Scr_idx++]);
		}
		gtk_widget_show(f2_box);
	}
	else if (Frame_type == 2) // Test Object Configuration Frame
	{
		pos = (OBJ_SHAPE_PERA * 2);
		Scr_idx = pos;
		for (i = 0; i < 24; i++)
		{
			if (i == 8 || i == 16)
			{
				Scr_idx = Scr_idx + 2;
			}
			gtk_label_set_label(GTK_LABEL(dgslabel[i]), all_btnval[Scr_idx++]);
		}
		gtk_widget_show(f2_box);
	}
	else if (Frame_type == 3) // Beam Profile
	{
		pos = (BEAM_PrbDia_PERA * 2);
		Scr_idx = pos;
		for (i = 0; i < 24; i++)
		{
			if (i == 8 || i == 16)
			{
				Scr_idx = Scr_idx + 2;
			}
			gtk_label_set_label(GTK_LABEL(dgslabel[i]), all_btnval[Scr_idx++]);
		}
		gtk_widget_show(f2_box);
	}
	else if (Frame_type == 4) // Thickness File Type
	{
		pos = (THKFILE_TYPE_PERA * 2);
		Scr_idx = pos;
		for (i = 0; i < 24; i++)
		{
			if (i == 8 || i == 16)
			{
				Scr_idx = Scr_idx + 2;
			}
			gtk_label_set_label(GTK_LABEL(dgslabel[i]), all_btnval[Scr_idx++]);
		}
		refresh_weld_profiler_area();
		gtk_widget_show(f2_box);
		frame_type_num = Frame_type;
	}
	else if (Frame_type == 5) // Thickness Color
	{
		pos = (COLOR_METHOD_PERA * 2);
		Scr_idx = pos;
		for (i = 0; i < 24; i++)
		{
			if (i == 8 || i == 16)
			{
				Scr_idx = Scr_idx + 2;
			}
			gtk_label_set_label(GTK_LABEL(dgslabel[i]), all_btnval[Scr_idx++]);
		}
		refresh_weld_profiler_area();
		gtk_widget_show(f2_box);
	}
	Set_btn_focus(); // Set Focus to Appropriate button after changing value of Menu
}

void refresh_weld_profiler_area(void)
{
	cairo_set_source_rgb(shape_profiler_rays_cr, 0.52, 0.80, 0.97);
	cairo_paint(shape_profiler_rays_cr);
	shape_profiler_rays_image = gtk_image_new_from_surface(shape_profiler_rays_surface);
}

/***********************************************************************************/
/**********************************DGS CRV FUNCTION*********************************/
/***********************************************************************************/
void Dgs_crv_f(int key_t)
{
	char *unitm[] = {" mm"}, *uniti[] = {" in"};
	int tempL;
	float tempdgs_curv = 0.0;
	// gchar dec_num[8];
	pos = (DGS_CRV_PERA * 2) + 1;
	tempL = D_efect_v * 5;
	tempL = tempL / 100;

	// gtk_adjustment_set_lower(adj, tempL);
	// gtk_adjustment_set_upper(adj, D_efect_v);
	Dgs_crvs_v = val_ary[DGS_CRV_PERA];

	if (key_scr == 0) // Get the value from scrollbar
	{
		Dgs_crvs_v = val_ary[DGS_CRV_PERA];
	}

	if (key_scr == 1) // Get the value from button keypad
	{
		Dgs_crvs_v = Dgs_crvs_v + (key_t * Key_stp);
	}

	if (key_scr == 2) // Get the value from touch keypad
	{
		tempdgs_curv = key_array[DGS_CRV_PERA];
		if (Unit_v == MM)
		{
			Dgs_crvs_v = tempdgs_curv * 10;
		}
		else
		{
			Dgs_crvs_v = tempdgs_curv * 1000;
		}
	}

	if (Dgs_crvs_v < tempL)
	{
		Dgs_crvs_v = tempL;
		dsp_msg(5);
	}
	if (Dgs_crvs_v > D_efect_v) // Maximum is same as Defect
	{
		Dgs_crvs_v = D_efect_v;
		dsp_msg(5);
	}
	val_ary[DGS_CRV_PERA] = Dgs_crvs_v;

	if (Unit_v == MM)
	{
		toarry(Dgs_crvs_v, pos, 0, 1, unitm[0]);
	}
	else
	{
		toarry(Dgs_crvs_v, pos, 0, 3, uniti[0]);
	} // Display in Inch Formatt

	strcpy(all_btnval[pos], Dsp_Str);
	gtk_label_set_label(GTK_LABEL(dgslabel[11]), Dsp_Str);
}

/***********************************************************************************/
/**********************************ATT REF FUNCTION*********************************/
/***********************************************************************************/
void Att_ref_f(int key_t)
{
	char *unit[] = {"dB "};
	float tempatt_ref = 0.0;

	gtk_adjustment_set_lower(adj, 0);
	gtk_adjustment_set_upper(adj, 1000);

	Att_ref_v = val_ary[ATT_REF_PERA];

	//**********KEY_SCR = 0*********************

	if (key_scr == 0) // Get the value from scrollbar
	{
		Att_ref_v = val_ary[ATT_REF_PERA];
	}

	//**********KEY_SCR = 1*********************

	if (Dgs_ref_v != 0)
	{
		dsp_msg(6);
	}
	else
	{
		if (key_scr == 1) // Get the value from button keypad
		{
			Att_ref_v = Att_ref_v + (key_t * Key_stp);
		}

		else if (key_scr == 2) // Get the value from touch keypad
		{
			tempatt_ref = key_array[ATT_REF_PERA];
			Att_ref_v = tempatt_ref * 10;
		}
	}

	val_ary[ATT_REF_PERA] = Att_ref_v;
	// Refresh On Display
	pos = (ATT_REF_PERA * 2) + 1;
	if (Att_ref_v > 1100)
	{
		Att_ref_v = 0;
	}
	if (Att_ref_v > 1000)
	{
		Att_ref_v = 1000;
	}
	toarry(Att_ref_v, pos, 0, 1, unit[0]);
	strcpy(all_btnval[pos], Dsp_Str);
	gtk_label_set_label(GTK_LABEL(dgslabel[19]), Dsp_Str);
}

/***********************************************************************************/
/*************************************PRESS FUNCTION********************************/
/***********************************************************************************/
void press_f(int key_t)
{
	int ech_pos, pnt, posi;
	char *dsp;
	char *unit[] = {" dB"};
	pos = (PRESS_PERA * 2) + 1;
	char buffer[40];

	Dac_crv_dB = val_ary[PRESS_PERA];
	if (Dac_v == 1 || Dac_v == 0) // If DAC==Draw or OFF
	{
		strcpy(all_btnval[pos - 1], "PRESS "); // ENTER
		strcpy(all_btnval[pos], "  ENTER");	   // ENTER

		if (key_t != 0 && Dac_v == 1) // Key Press and DAC in Draw Mode then Register Echo signal
		{
			Range_dac = Range_v;
			ech_pos = Find_peak_posi();
			pnt = point_v * 2;
			dac_pnt[pnt] = ech_pos;
			Ech_amp = 2 * Ech_amp;
			if (Ech_amp > 200)
			{
				Ech_amp = 200;
			}
			if (Ech_amp < 3)
			{
				Ech_amp = 3;
			}

			Ech_amp = 200 - Ech_amp;
			Ech_amp = ehtodb[Ech_amp]; // Get Required db to Bring Echo at 80% Height in DB
			Ech_amp = Ech_amp + Gain_v;

			dac_pnt[pnt + 1] = Ech_amp; // Store Echo posi and Height
			dac_pnt[pnt + 2] = 0;		// Clear Extra Points
			dac_pnt[pnt + 3] = 0;		// Clear Extra Points

			Point_f(1);			   // Increment Point value and display on LCD  Position is 35 for Point value
			Gain_v = Ech_amp - 20; // Set Echo height to 80%
			val_ary[GAIN_PERA] = Gain_v;
			Gain_f(0);													 // Change and Refresh Gain Value
			dac_gen(&dac_pnt[0], &dac_cv[0], Gain_v, Range_v, Delay_rv); // If Dac ON then Draw DAC Curve
		}
	}
	else if ((Evaluate_val == 0 && Dac_v == 2) || (Evaluate_val == 0 && Dac_v == 3)) // If DAC == ON  or TCG is ON then Adjust/set Dac curve DB perametere
	{
		Dac_crv_dB = Dac_crv_dB + (key_t * Gn_stp);
		if (Dac_crv_dB < 0)
		{
			Dac_crv_dB = 0;
		}
		/*if (Dac_crv_dB > 70)
		{
			Dac_crv_dB = 70;
		}*/
		if (Dac_crv_dB > 120)
		{
			Dac_crv_dB = 120;
		}
		val_ary[PRESS_PERA] = Dac_crv_dB;
		toarry(Dac_crv_dB, pos, 0, 1, unit[0]); // strcpy(all_btnval[pos], Dsp_Str);  pos=pos % 10;
		/*if (Dac_crv_dB == 70)
		{
			sprintf(Dsp_Str, "CRV6/14");
		}*/
		//** Special 6/14 DAC dB Curve allpera[pos] = "CRV6/14";
		strcpy(all_btnval[pos], Dsp_Str);
		sprintf(Dsp_Str, "DAC dB ");
		strcpy(all_btnval[pos - 1], Dsp_Str);
		dac_gen(&dac_pnt[0], &dac_cv[0], Gain_v, Range_v, Delay_rv); // If Dac ON then Draw DAC Curve
		gl_clear_color_background_data(width_sh, height_sh);
	}
}

/*******************************************************************************************************************/
/*************************************************DGS CURVE DB******************************************************/
/*******************************************************************************************************************/
void DgsCrv_db(int key_t)
{
	char *unit[] = {" dB"};
	pos = (PRESS_PERA * 2) + 1;

	Dac_crv_dB = val_ary[PRESS_PERA];

	Dac_crv_dB = Dac_crv_dB + (key_t * Gn_stp);

	if (Dac_crv_dB < 0)
		Dac_crv_dB = 0;
	else if (Dac_crv_dB > 120)
		Dac_crv_dB = 120;

	val_ary[PRESS_PERA] = Dac_crv_dB;

	toarry(Dac_crv_dB, pos, 0, 1, unit[0]);

	strcpy(all_btnval[pos], Dsp_Str);
	sprintf(Dsp_Str, "DGS dB ");
	strcpy(all_btnval[pos - 1], Dsp_Str);
	dac_gen(&dac_pnt[0], &dac_cv[0], Gain_v, Range_v, Delay_rv); // If Dac ON then Draw DAC Curve
	gl_clear_color_background_data(width_sh, height_sh);
}

//****************************************************************************
///***************************************************************************
///***************************************************************************
int Find_peak_posi() //// Find Peak value and Position
{
	int i, sta, end, x, y, ech;
	int temp;
	int rnge;

	rnge = Range_v;

	temp = (Gstart1_v * 2500) / rnge;
	sta = temp;

	temp = Gend1_v; // +Gstart1_v;
	temp = (temp * 2500) / rnge;

	end = temp;
	Screen_w = 250;
	if (end > Screen_w) // Change to Screen Width
		end = Screen_w;

	x = 0;
	y = 0;
	for (i = sta; i < end; i++)
	{
		ech = All_Ascan_data[i]; // AscanD_data[i];
		if (ech > y)
		{
			x = i;
			y = ech;
		}
	}
	Ech_amp = y;
	return x;
} // Find Peak value and Position

//***************************************************************************
//*********************  Generate Calculate DAC Curve   *********************
//***************************************************************************

void dac_gen(int *dacT_pnt, int *dac_p, int ref_g, long Range, long dly_r)
{
	int *pnt, *cv, crv_gain, Temp_gn;
	int range;
	int Rang_d;
	range = Range;
	cv = dac_p;
	crv_gain = ref_g; // For the DAC gain=ref_g is ok

	if ((Dac_v == 1 && point_v != 0) || Dac_v == 2 || Dac_v == 3 || Dac_v == 4 || Dgs_onoff_v == 2 || Dgs_onoff_v == 3) // * if dac is off then dont generate/plot DAC */
	{
		if (Dgs_onoff_v == 2 || Dgs_onoff_v == 3)
		{
			if (Dgs_onoff_v == 2)
				Dgs_gain = 180; // Draw DGS Curve at 80% FSH
	
			Copy_DGSpnt();
			pnt = &DGS_pnt[0];
			Range_dac = Range_v;
			Rang_d = range;
			crv_gain = Dgs_gain;
			ref_g = Dgs_gain;
		}
		else
		{
			pnt = &dac_pnt[0];
		}

		/* Make sure During DAC plot to be store X pos with taking care of
		   Delay Value.. for eg if Delay is already applied then add equi value of
		   of Delay to X pos record  for ex if Ran=100 and Delay=20applied
		   Id First Point at 20 % so Pixpos=50 and Delay=30mm pix=75 X to be
		   store as  50+75=125   */
		// Clear all data of Ascan area for to erase old DAc curve
		// Draw GRID  GATE

		Temp_gn = crv_gain;
		// Dac_crv_dB=0; // Calculate and Store for DAC curve Monitor Trigger Facility
		if (Dac_crv_dB != 0 && ((Dac_v == 2 || Dac_v == 3 || Dac_v == 4) || (Dgs_onoff_v == 3))) // If Dac CrvdB > 0 and DAC on then cal more curve  2024-07-18
		{
			/*DAC 1st Positive Curve*/
			////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			if (Dac_crv_dB == 70)
			{
				crv_gain = ref_g + 60;
			}
			else
			{
				crv_gain = ref_g + Dac_crv_dB;
			} // Special for 6/14 DAC db Curve
			dac_curve(pnt, cv, crv_gain, range, dly_r, RED); // DAC_+1 curve
			DAC_Copy_for_Disp(1);							 //** +Curve db 0 is main curve +DAC db Curve
			if (Gate1_v == CRV_1P)
			{
				Copy_dac_crv();
			}

			/*DAC 2nd Positive Curve*/
			///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			if (Dac_crv_dB == 70)
			{
				crv_gain = crv_gain + Dac_crv_dB + 20;
			}
			else
			{
				crv_gain = crv_gain + Dac_crv_dB;
			} // Special for 6/14 DAC db Curve
			dac_curve(pnt, cv, crv_gain, range, dly_r, RED); // DAC_+2 curve
			DAC_Copy_for_Disp(2);							 //** +2* Curve db is main curve + 2* DAC db Curve
			if (Gate1_v == CRV_2P)
			{
				Copy_dac_crv();
			}

			/*DAC 1st Negative Curve*/
			///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			if (Dac_crv_dB == 70)
			{
				crv_gain = ref_g - 60;
			}
			else
			{
				crv_gain = ref_g - Dac_crv_dB;
			} // Special for 6/14 DAC db Curve
			dac_curve(pnt, cv, crv_gain, range, dly_r, RED); // DAC_-1 curve
			DAC_Copy_for_Disp(3);							 //** -Curve db 0 is main curve -  DAC db Curve
			if (Gate1_v == CRV_1N)
			{
				Copy_dac_crv();
			}

			/*DAC 2nd Negative Curve*/
			////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			if (Dac_crv_dB == 70)
			{
				crv_gain = crv_gain - Dac_crv_dB - 20;
			}
			else
			{
				crv_gain = crv_gain - Dac_crv_dB;
			} // Special for 6/14 DAC db Curve
			dac_curve(pnt, cv, crv_gain, range, dly_r, RED); // DAC_-2 curve
			DAC_Copy_for_Disp(4);							 //** -2* Curve db is main curve - 2* DAC db Curve
			if (Gate1_v == CRV_2N)
			{
				Copy_dac_crv();
			}
		}

		crv_gain = Temp_gn;								 // Draw Main Curve Last so Curve value remain in dac_cv array and its used for ERS Measurement
		dac_curve(pnt, cv, crv_gain, range, dly_r, RED); // Curve Color
		if (Gate1_v == CRV_M)							 // Trigger By main Curve
		{
			Copy_dac_crv();
		}
		gl_clear_color_background_data(width_sh, height_sh); // Display On Screen
	}
}

//**********************************************************************************
//*********************** Copy DAC Curve for DAC  Trigger Function *****************
//**********************************************************************************
void Copy_dac_crv()
{
	int i;
	for (i = 0; i < 300; i++)
	{
		dac_trig[i] = dac_cv[i] / 2;
	}
}

//********************** Sub Dac Curve **** As per value of DAC Crv dB ********
//************** More smooth curve by inserting more additional cordinate when gap is more
//************************************************************************************
void dac_curve(int *dac_pntt, int *dac_p, int ref_g, long Range, long dly_r, int Crv_clr)
{
	double x1, x2, y1, y2, temp, y1_old, y1_new;
	double p1, dy, dx, xof;

	int i, t;
	int p = 0;
	int *jp;
	int *dac_pt;
	int Rang_d;
	int dac_ptmp[250];

	int check[250];

	POINT pntArray_DAC[255]; // Holds data of DAC Curve 12 points per Channel

	long tmpc;
	long Range_l, DacpntL;
	dac_pt = &dac_ptmp[0];
	Screen_w = 250;
	Range_l = Range;

	Rang_d = Range_dac;
	for (i = 0; i < 80; i++) /* Clear array */
		dac_ptmp[i] = 0;

	jp = dac_p;

	y1_old = 1400;

	for (i = 0; i < 32; i++) // earlier its 10 point    /* 32 requires for DGS Curve  Maximum 10 points */
	{
		tmpc = (dly_r * 5) / 2;
		tmpc = Rang_d;
		DacpntL = *dac_pntt++; // DGS_pnt[p++];  //*dac_pntt++; //
		tmpc = tmpc * DacpntL;
		DacpntL = (dly_r);
		DacpntL = DacpntL * 250; /* Cal X1 Pos for current Range */
		tmpc = tmpc - DacpntL;
		/* Cal X1 Pos for current Range */
		tmpc = (tmpc) / Range_l;
		// For Arjun calculate only for 250

		if (tmpc > 12000) /* more than 100 times then exit */
			tmpc = 12000;
		if (tmpc < -12000)
			tmpc = -12000;
		x1 = (int)tmpc;

		*dac_pt++ = (int)(x1); /* Store temp DAC Point array */

		y1 = *dac_pntt++; //  DGS_pnt[p++];  //  *dac_pntt++;
		if (y1 == 0)
			goto extdcl1;
		y1 = y1 - ref_g;   // ref_g is current Gain Value
		y1 = GaintoEH(y1); /* Get %height from dB value */
		// g_print("y1[%d] = %f \n", i, y1);
		if (y1 > 1300)
			y1 = 1300;
		*dac_pt++ = (int)(y1);

		tmpc = Rang_d;
		DacpntL = *dac_pntt; // DGS_pnt[p];  //*dac_pntt;   //
		tmpc = tmpc * DacpntL;
		DacpntL = dly_r;
		DacpntL = DacpntL * 250; /* Cal X1 Pos for current Range */
		tmpc = tmpc - DacpntL;
		tmpc = (tmpc) / Range_l;
		// tmpc=DacpntL;

		if (tmpc > 12000)
			tmpc = 12000;
		if (tmpc < -12000)
			tmpc = -12000;
		x2 = (int)tmpc;
		t = x2 - x1;
		if (x1 > x2) // Last point to be like that X1>X2 so it will get exit
			goto extdcl1;
		if (x1 > 400) // If first point is out of screen then calculation not require.
			goto extdcl1;

		// Insert three more points  /* Makes smooth Curve */
		{
			y2 = *(dac_pntt + 1); //  DGS_pnt[p+1];   //  *(dac_pntt+1);
			if (y2 == 0)
				goto extdcl1;
			{
				t = x1 + (x2 - x1) / 4;
				*dac_pt++ = (int)(t); //    t=(x2+x1)/2;  *dac_pt++=(int)(t);      /* Store new added  position */
				y2 = y2 - ref_g;
				y2 = GaintoEH(y2);

				if (y2 > 1300)
					y2 = 1300;
				t = y2 - y1; // If Diff is > 25 then apply formula else not
				if (t > 10)	 // If Rising curve
				{
					t = y1 + (((y2 - y1) * 35) / 100);
					*dac_pt++ = (int)(t);
					y1_new = (int)(t); // t=(12*(y1+y2))/25; *dac_pt++=(int)(t);  /*  Controls Smooth /average factor */
					t = x1 + ((x2 - x1) * 2) / 4;
					*dac_pt++ = (int)(t);
					t = y1 + (((y2 - y1) * 63) / 100);
					*dac_pt++ = (int)(t); // 65
					t = x1 + ((x2 - x1) * 3) / 4;
					*dac_pt++ = (int)(t);
					t = y1 + (((y2 - y1) * 83) / 100);
					*dac_pt++ = (int)(t); // 85
				} /*  Store Amp of calculated Value   */
				else // If Falling curve
				{
					if (y1_old<y1 & y1> y2)
					{
						t = y1 - (((y1 - y2) * 20) / 100);
						*dac_pt++ = (int)(t);
						y1_new = (int)(t);
						t = x1 + ((x2 - x1) * 2) / 4;
						*dac_pt++ = (int)(t);
						t = y1 - (((y1 - y2) * 55) / 100);
						*dac_pt++ = (int)(t);
					}
					else
					{
						t = y1 - (((y1 - y2) * 35) / 100);
						*dac_pt++ = (int)(t);
						y1_new = (int)(t);
						t = x1 + ((x2 - x1) * 2) / 4;
						*dac_pt++ = (int)(t);
						t = y1 - (((y1 - y2) * 63) / 100);
						*dac_pt++ = (int)(t);
					}
					t = x1 + ((x2 - x1) * 3) / 4;
					*dac_pt++ = (int)(t);
					t = y1 - (((y1 - y2) * 83) / 100);
					*dac_pt++ = (int)(t); // 85
				} /*  Store Amp of calculated Value  */
			}
		}
		y1_old = y1_new; // Used to check pean of DAC curve
	} // For loop end

extdcl1:
	dac_pt = &dac_ptmp[0];
	for (i = 0; i < 250; i++)
	{
		check[i] = *dac_pt++;
	}

	dac_p = jp;

	dac_pt = &dac_ptmp[0];
	x1 = *dac_pt++; /* First point   */
	y1 = *dac_pt++;
	x2 = *dac_pt++; /* Get Next point */
	y2 = *dac_pt++;

	if (x1 > 0) // Intially upto X1 value fill with zero
	{
		for (i = 0; i < x1; i++)
		{
			*dac_p++ = 0;
		}
	}
	else if (x1 < 0)
	{
	nextrd:
		if (x2 < 0)
		{
			x1 = x2;		//*dac_pt++; /* First point   */
			y1 = y2;		//*dac_pt++;
			x2 = *dac_pt++; /* Get Next point */
			y2 = *dac_pt++;
		}
		if (x2 < 0)
		{
			goto nextrd;
		}
	}

	for (i = x1; i < Screen_w + 6; i++) /* Need to generate curve for 250 pix */
	{
		if (x1 > x2) // (x1>=x2) But it creates problem in DGS so changed to X1 > X2
		{
			*dac_p++ = 0;
		}
		else
		{
			if (i >= x1 && i < x2)
			{
				if (y1 < 201 || y2 < 201)
				{
					if (i > 0)
					{
						dy = y1 - y2;
						dx = x2 - x1;
						xof = x1 - i;
						p1 = ((dy * xof) / dx);
						*(dac_p++) = (y1 + p1);
					}
				}
				else
				{
					*dac_p++ = 201;
				}
			}
			else if (i == x1 && i == x2) /* if equal to x2 (next) point then read next point */
			{
				x1 = x2, y1 = y2;
				x2 = *dac_pt++;
				y2 = *dac_pt++;
				if (y2 > y1)
				{
					*(dac_p++) = y2;
				}
				else
				{
					*(dac_p++) = y1;
				}
			}

			else if (i == x2) /* if equal to x2 (next) point then read next point */
			{
				x1 = x2, y1 = y2;
				x2 = *dac_pt++;
				y2 = *dac_pt++;
				*(dac_p++) = y1;
			}
			else if (x2 < i)
			{
				x1 = x2, y1 = y2;
				x2 = *dac_pt++;
				y2 = *dac_pt++;
				if (y2 > y1)
				{
					*(dac_p++) = y2;
				}
				else
				{
					*(dac_p++) = y1;
				}
				if (x2 < i)
				{
					x1 = x2, y1 = y2;
					x2 = *dac_pt++;
					y2 = *dac_pt++;
					*(dac_p--);
					if (y2 > y1)
					{
						*(dac_p++) = y2;
					}
					else
					{
						*(dac_p++) = y1;
					}
				}
				if (x2 < i)
				{
					x1 = x2, y1 = y2;
					x2 = *dac_pt++;
					y2 = *dac_pt++;
					*(dac_p--);
					if (y2 > y1)
					{
						*(dac_p++) = y2;
					}
					else
					{
						*(dac_p++) = y1;
					}
				}
				if (x2 < i)
				{
					x1 = x2, y1 = y2;
					x2 = *dac_pt++;
					y2 = *dac_pt++;
					*(dac_p--);
					if (y2 > y1)
					{
						*(dac_p++) = y2;
					}
					else
					{
						*(dac_p++) = y1;
					}
				}
				if (x2 < i)
				{
					x1 = x2, y1 = y2;
					x2 = *dac_pt++;
					y2 = *dac_pt++;
					*(dac_p--);
					if (y2 > y1)
					{
						*(dac_p++) = y2;
					}
					else
					{
						*(dac_p++) = y1;
					}
				}
				if (x2 < i)
				{
					x1 = x2, y1 = y2;
					x2 = *dac_pt++;
					y2 = *dac_pt++;
					*(dac_p--);
					if (y2 > y1)
					{
						*(dac_p++) = y2;
					}
					else
					{
						*(dac_p++) = y1;
					}
				}
				if (x2 < i)
				{
					x1 = x2, y1 = y2;
					x2 = *dac_pt++;
					y2 = *dac_pt++;
					*(dac_p--);
					if (y2 > y1)
					{
						*(dac_p++) = y2;
					}
					else
					{
						*(dac_p++) = y1;
					}
				}
				if (x2 < i)
				{
					x1 = x2, y1 = y2;
					x2 = *dac_pt++;
					y2 = *dac_pt++;
					*(dac_p--);
					if (y2 > y1)
					{
						*(dac_p++) = y2;
					}
					else
					{
						*(dac_p++) = y1;
					}
				}
				if (x2 < i)
				{
					x1 = x2, y1 = y2;
					x2 = *dac_pt++;
					y2 = *dac_pt++;
					*(dac_p--);
					if (y2 > y1)
					{
						*(dac_p++) = y2;
					}
					else
					{
						*(dac_p++) = y1;
					}
				}
				if (x2 < i)
				{
					x1 = x2, y1 = y2;
					x2 = *dac_pt++;
					y2 = *dac_pt++;
					*(dac_p--);
					if (y2 > y1)
					{
						*(dac_p++) = y2;
					}
					else
					{
						*(dac_p++) = y1;
					}
				}
				if (x2 < i)
				{
					x1 = x2, y1 = y2;
					x2 = *dac_pt++;
					y2 = *dac_pt++;
					*(dac_p--);
					if (y2 > y1)
					{
						*(dac_p++) = y2;
					}
					else
					{
						*(dac_p++) = y1;
					}
				}
			}
			else
				*dac_p++ = (int)(0);
		}
	}

	dac_p = jp; // Load Starting pointer address of array
	for (i = 0; i < 250; i++)
	{
		check[i] = *dac_p++;
	}

	/* Plot DAC Curve */
	dac_p = jp; // Load Starting pointer address of array

	if (Dac_v == 3 || Dac_v == 4) // IF TCG is ON or TCG EDIT
	{
		for (i = 0; i < 255; i++) // Clear Array Data
		{
			pntArray_DAC[i].y = -5;
			pntArray_DAC[i].x = 0;
		}
		y2 = 0;
		dac_npnt = 0; // If TCG is on then Draw Straight Curve
		for (i = 0; i < Screen_w; i++)
		{
			y1 = *dac_p++;

			// if(i>-1&& i<30){y1=20;}      
            // if(i>29 && i<40){y1=40;}
            // if(i>39 && i<50){y1=60;}
            // if(i>49 && i<60){y1=80;}
            // if(i>59 && i<70){y1=100;}
            // if(i>69 && i<80){y1=160;}
            // if(i>79 && i<90){y1=180;}
            // if(i>89 && i<100){y1=200;}
            // if(i>99 ){y1=200;}

			if (y1 > 0)
			{
				if (y2 == 0)
				{
					y2 = y1; // y2 holds first non zero data
					if (y2 > 200)
						y2 = 200;
					y2 = Asc_Height - ((Asc_Height * y2) / 200);
					// y2=132;
				}
				pntArray_DAC[dac_npnt].y = y2;
				pntArray_DAC[dac_npnt].x = i;
				dac_npnt++;					  // Also keep how many DAC point to be draw during Polyline
				pntArray_DAC[dac_npnt].y = -5; // Put next point zero so it indicates curve end
			}
		}
	}
	else // If TCG is off then Normal Curve
	{
		for (i = 0; i < 255; i++)
		{
			pntArray_DAC[i].y = -5;
			pntArray_DAC[i].x = 0;
		} // Clear Array Data
		dac_npnt = 0;
		for (i = 0; i < Screen_w; i++) // 250
		{
			y1 = *dac_p++;

			// if(i>-1&& i<30){y1=20;}      
            // if(i>29 && i<40){y1=40;}
            // if(i>39 && i<50){y1=60;}
            // if(i>49 && i<60){y1=80;}
            // if(i>59 && i<70){y1=100;}
            // if(i>69 && i<80){y1=160;}
            // if(i>79 && i<90){y1=180;}
            // if(i>89 && i<100){y1=200;}
            // if(i>99 ){y1=200;}

			if (y1 > 0) // (y1 >199 || y1<=0)
			{
				if (y1 > 200)
					y1 = 200; // (y1>199) y1=199;
				y1 = Asc_Height - ((Asc_Height * y1) / 200);
				pntArray_DAC[dac_npnt].y = y1;
				pntArray_DAC[dac_npnt].x = i;
				dac_npnt++; // Holds No of DAC point to be draw during Polyline
			}
		}
	}

	// dac_p=j;  // Load Starting pointer address of array
	// Full curve data is also required when Dac Curve trigger is used./
	for (i = 0; i < 255; i++)
	{
		pntArray_DACM[i].y = pntArray_DAC[i].y;
		pntArray_DACM[i].x = pntArray_DAC[i].x;
	}
}
//****************************************************************************
//****************************************************************************

void Copy_DGSpnt(void)
{
	int i, Nf_gain;
	long int temp, Nf_real;
	Nf_real = (Near_FD * 25) / Mtlvel_val; // Calculate Near Field Value
	Nf_gain = CDgs_dat[9];				   //  CDgs_Adat[9];   // Nf_gain=CDgs_dat[9];        // Get Gain value of NF
	Nf_gain = 200 - Nf_gain;

	for (i = 0; i < 32; i++) // Copy 32 points
	{
		temp = DGS_RP[i];
		temp = temp * Nf_real;
		temp = temp / Range_v; // Set Point position as per Current Range
							   // temp=temp*2;
		if (temp == 0)
			temp = 1;	 // If value is 0 then make to 1 otherwise Curve will be not ploted
		if (temp > 1500) //  (temp>500)
			temp = 0;
		DGS_pnt[(2 * i)] = temp;					   // Store Position in terms of Pixel  /
		DGS_pnt[(2 * i) + 1] = CDgs_Adat[i] + Nf_gain; // DGS_pnt[(2*i)+1]=CDgs_dat[i]+Nf_gain; //DGS_pnt holds Final Data of DGS Curve
	}
}

//******************************************************************************************
//****************  Convert Gain to height Used in Dynamic DAC Calculation *****************
//******************************************************************************************

int GaintoEH(int gain)
{
	int m = 1; /* Gain value ranging from -28.0 to +40.0 */
	if (gain > 400)
		gain = 400;
	else if (gain < -400)
		gain = -400;

	if (gain >= 0)
	{
	ckgr:
		if (gain > 59)
		{
			gain = gain - 60;
			m = m * 2;
			goto ckgr;
		}
		gain = dbtoeh[gain];
		gain = gain / (m);
	}

	else if (gain < 0)
	{
		gain = -gain;
	ckgrm:
		if (gain > 59)
		{
			gain = gain - 60;
			m = m * 2;
			goto ckgrm;
		}
		gain = 40000 / dbtoeh[gain];
		gain = m * gain;
	}
	return gain;
}

//**********************************************************************************
void DAC_Copy_for_Disp(int crvno) // Copy DAC points data for the Display ON LCD
{
	int i, temp, x1, y1;

	if (crvno == 1)
	{
		for (i = 0; i < 255; i++)
		{
			pntArray_DAC1P[i].y = pntArray_DACM[i].y;
			pntArray_DAC1P[i].x = pntArray_DACM[i].x;
		}
	}
	if (crvno == 2)
	{
		for (i = 0; i < 255; i++)
		{
			pntArray_DAC2P[i].y = pntArray_DACM[i].y;
			pntArray_DAC2P[i].x = pntArray_DACM[i].x;
		}
	}
	if (crvno == 3)
	{
		for (i = 0; i < 255; i++)
		{
			pntArray_DAC1N[i].y = pntArray_DACM[i].y;
			pntArray_DAC1N[i].x = pntArray_DACM[i].x;
		}
	}
	if (crvno == 4)
	{
		for (i = 0; i < 255; i++)
		{
			pntArray_DAC2N[i].y = pntArray_DACM[i].y;
			pntArray_DAC2N[i].x = pntArray_DACM[i].x;
		}
	}
}

/***********************************************************************************/
/*************************************AWS REF FUNCTION******************************/
/***********************************************************************************/

void Aws_Ref_f(int key_t)
{
	int H_db;
	int rnge, EampR;
	int Gst, Gend, Gme1, i;
	char gvsum[35];
	pos = PRESS_PERA * 2;
	Aws_ref_v = val_ary[PRESS_PERA];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
		// Aws_ref = val_ary[PRESS_PERA];
	}

	// Refresh on Screen
	if (key_t == 0) // Only Refresh REF Display status
	{
		if (Aws_ref_v == 1)
		{
			strcpy(all_btnval[pos + 1], "ON     ");
		} // ON
		else
		{
			strcpy(all_btnval[pos + 1], "OFF    ");
			return;
		} // OFF
	}
	else if (key_scr == 1) // Get the value from button keypad
	{
		if (Aws_onoff_v == 2)
		{
			return;
		} // If AWS measured ON then exit
		else if (Aws_onoff_v == 1) // If Aws_onoff SET then only allow to change SET-REF else referesh and exit
		{
			Aws_ref_v = Aws_ref_v + key_t;
			if (Aws_ref_v < 0)
			{
				Aws_ref_v = 1;
			}
			if (Aws_ref_v > 1)
			{
				Aws_ref_v = 0;
			}

			if (Aws_ref_v == 1 && key_t != 0) // If trun to REF ON then calculate and store Ref Gain value else not
			{
				strcpy(all_btnval[pos + 1], "ON     ");
				rnge = Range_v;
				Gst = Gstart1_v;
				Gend = Gend1_v;
				Gme1 = 0;
				EampR = 0; // Find Echo crossing in gateA and Max Amplitude of echo signal
				Gst = (Gst * 2500) / rnge;
				Gend = (Gend * 2500) / rnge;
				for (i = Gst; i < Gend; i++)
				{
					if (All_Ascan_data[i] > EampR)
					{
						EampR = All_Ascan_data[i];
						Gme1 = i;
					}
				}
				H_db = ehtodb[200 - (2 * EampR)]; // H_db=ehtodb[200-(2*Peak_G1)];    // Get Required db to Bring Echo at 80% Height in DB
				// Refg_v = Gain_v+(H_db-20);  IL_v=0; Af_v=0; Rt_v=0;
				Refg_v = Gain_v + (H_db - 60);
				IL_v = 0;
				Af_v = 0;
				Rt_v = 0;
				Refg_f(0);
			} // On then set Ref Gain Value
		}
	}

	/************************* Below code written by Rahul Nair **********************************************************/
	// Change Reference value and Display On the Gain button
	// val_ary[9] = Refg_v;
	// gain_ref = val_ary[9];
	// sprintf(gstr_1, "%d", gain_ref);
	// sprintf(gstr_2, "%s", "\n  REF  ");

	// if (gain_ref > 0 && gain_ref < 100)
	// {
	// 	gstr_3[0] = gstr_1[0];
	// 	gstr_3[1] = dot[0];
	// 	gstr_3[2] = gstr_1[1];
	// }
	// if (gain_ref >= 100 && gain_ref < 1000)
	// {
	// 	gstr_3[0] = gstr_1[0];
	// 	gstr_3[1] = gstr_1[1];
	// 	gstr_3[2] = dot[0];
	// 	gstr_3[3] = gstr_1[2];
	// }
	// strcpy(gvsum, Gain_glbl);
	// strcat(gstr_2, gstr_3);
	// strcat(gvsum, gstr_2);

	// pos = 0 * 10;
	// strcpy(all_btnval[pos + 8], gvsum);
}

//**********************************************************************************
void AWS_rat() // Calculate AWS Rating
{
	int temp; //,Af_v,IL_v; // ,Rating_v;
	int IL_lt, Af_lt, Rt_lt;
	long int temp_t;
	double tempd;

	if (Freez_v != FREEZ) // If normal running... When recall from Mem then it is not required to calculate
	{
		if (Unit_v == INCH)
		{
			if (G1_sp1 > 1000) // Snd_pth_vG1
			{
				temp_t = G1_sp1;
			} // Snd_pth_vG1
			else
			{
				temp_t = 1000;
			}
			temp_t = temp_t - 1000;
			Af_lt = 2 * temp_t;
			Af_lt = Af_lt / 100;
		} // When Init is MM
		else
		{
			if (G1_sp1 > 2540) // Snd_pth_vG1
			{
				temp_t = G1_sp1;
			} // Snd_pth_vG1
			else
			{
				temp_t = 2540;
			}
			temp_t = temp_t / 127;
			temp_t = temp_t - 20;
			Af_lt = temp_t;
		}

		tempd = Af_lt; // tempd=187; //Af_lt;

		temp = ehtodb[200 - (2 * G1_Amp1)]; // G1_Amp1 Peak_G1 Get Required db to Bring Echo at 80% Height in DB
											// IL_lt= Gain_v+(temp-20);  // Cal required db to bring echo at 80% height in db
		IL_lt = Gain_v + (temp - 60);		// Cal required db to bring echo at 50% height in db

		temp_t = IL_lt;
		temp_t = temp_t - Refg_v;
		Rt_lt = temp_t - Af_lt;
	}
	if (Freez_v != FREEZ)
	{
		IL_v = IL_lt;
		Af_v = Af_lt;
		Rt_v = Rt_lt;
	}
}

//**************************************************************************
//*********************  Reference GAIN  ***********************************
//**************************************************************************

void Refg_f(int key_v)
{
	// char buffer[10];
	double tempd;
	char *unit[] = {" dB"};

	if (Refg_v > 1100) // If Over Flaw then make it Zero
		Refg_v = 0;
	if (Refg_v > 999)
		Refg_v = 999;

	tempd = Refg_v;
	tempd = tempd / 10;
	sprintf(Dsp_Str, "REF%2.1f", tempd);

	
	g_print("1 : %s\n", Dsp_Str);
	strcpy(all_btnval[REF_GAIN], Dsp_Str);
}

/***********************************************************************************/
/************************************DGS REF FUNCTION*******************************/
/***********************************************************************************/

void DGS_Ref_f(int key_t)
{
	if (Dgs_onoff_v == 3) // If DGS is ON then dont allow to toggle or ON/OFF
	{
		if (key_t != 0)
		{
			dsp_msg(3);
			key_t = 0;
		}
	}

	if (key_t == 1 && Dgs_ref_v == 0) // DGS Ref is OFF then Turn ON
	{
		if (Dgs_onoff_v == 2) // If DGS is selected for Referance recording
		{
			Dgs_ref_v = 1;
			DGS_Ref_on_f();
		}
		else
		{
			dsp_msg(9);
		} // Turn on when DGS is for Referance recording
	}
	if (key_t == -1) // DGS Ref   Turn OFF
	{
		Dgs_ref_v = 0;
	}

	pos = (PRESS_PERA * 2) + 1;
	// During recall from Memory make sure to refresh directly
	if (Dgs_ref_v == 0)
	{
		strcpy(all_btnval[pos], "OFF    ");
	} // OFF
	if (Dgs_ref_v == 1)
	{
		strcpy(all_btnval[pos], "ON     ");
	} // ON
}

/***********************************************************************************/
/*********************************PRB FREQ FUNCTION*********************************/
/***********************************************************************************/

void Prb_freq_f(int key_t)
{
	char *unitfr[] = {"MHz"};
	float tmpprbfreq_val = 0.0;
	int temp;
	if (key_scr == 1) // Get the value from button keypad
	{
		if (Scal_v == 0)
		{
			Prb_freq_vC = val_ary[PRFFRE_POS_PERA];
			Prb_freq_vC = Prb_freq_vC + (key_t * 25 * Key_stp);
			if (Prb_freq_vC > 1000)
			{
				Prb_freq_vC = 1000;
			}
			if (Prb_freq_vC < 25)
			{
				Prb_freq_vC = 25;
			}

			val_ary[PRFFRE_POS_PERA] = Prb_freq_vC;
			Prb_freq_v = Prb_freq_vC;
			temp = D_efect_v;
			Near_FD = temp * temp * 5; // NFLT = ( F * E_dia *E_dia * 5 )/2    Actual NF= NFLT/Velo
			temp = Prb_freq_v;
			Near_FD = (temp * Near_FD) / 2; // Calculate Nf for custom Probe
		}
		else
		{
			if (key_t != 0)
			{
				dsp_msg(5);
			}
		}
	}
	if (key_scr == 2) // Get the value from touch keypad
	{
		if (Scal_v == 0)
		{
			tmpprbfreq_val = key_array[PRFFRE_POS_PERA];
			Prb_freq_vC = tmpprbfreq_val * 100; //+ (key_t * 25 * Key_stp);
			if (Prb_freq_vC > 1000)
			{
				Prb_freq_vC = 1000;
			}
			if (Prb_freq_vC < 25)
			{
				Prb_freq_vC = 25;
			}

			val_ary[PRFFRE_POS_PERA] = Prb_freq_vC;
			Prb_freq_v = Prb_freq_vC;
			temp = D_efect_v;
			Near_FD = temp * temp * 5; // NFLT = ( F * E_dia *E_dia * 5 )/2    Actual NF= NFLT/Velo
			temp = Prb_freq_v;
			Near_FD = (temp * Near_FD) / 2; // Calculate Nf for custom Probe
		}
		else
		{
			dsp_msg(5);
		}
	}

	pos = (PRFFRE_POS_PERA * 2) + 1;
	toarry(Prb_freq_v, pos, 0, 2, unitfr[0]);

	strcpy(all_btnval[pos], Dsp_Str);
	gtk_label_set_label(GTK_LABEL(dgslabel[5]), Dsp_Str);
}

/***********************************************************************************/
/*************************************REF ECHO FUNCTION******************************/
/***********************************************************************************/
void Ref_echo_f(int key_t)
{
	Ref_echo_v = val_ary[REF_ECHO_PERA];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
	}

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
	{
		Ref_echo_v = Ref_echo_v + key_t;
	}

	if (Ref_echo_v < 0)
	{
		Ref_echo_v = 2;
	}
	if (Ref_echo_v > 2)
	{
		Ref_echo_v = 0;
	}
	val_ary[REF_ECHO_PERA] = Ref_echo_v;

	if (Ref_echo_v == 0)
	{
		strcpy(Dsp_Str, "BW     ");
	}
	if (Ref_echo_v == 1)
	{
		strcpy(Dsp_Str, "FBH    ");
	}
	if (Ref_echo_v == 2)
	{
		strcpy(Dsp_Str, "SDH    ");
	}

	pos = (REF_ECHO_PERA * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	gtk_label_set_label(GTK_LABEL(dgslabel[13]), Dsp_Str);
	Ref_size_f(0);
}

/***********************************************************************************/
/*************************************ATT OBG FUNCTION******************************/
/***********************************************************************************/
void Att_obg_f(int key_t)
{
	char *unit[] = {"dB "};
	float tempatt_obj = 0.0;
	Att_obg_v = val_ary[ATT_OBJ_PERA];

	gtk_adjustment_set_lower(adj, 0);
	gtk_adjustment_set_upper(adj, 1000);

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from button keypad
	{
		Att_obg_v = val_ary[ATT_OBJ_PERA];
	}
	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
	{
		Att_obg_v = Att_obg_v + (key_t * Key_stp);
	}

	if (key_scr == 2) // Get the value from touch keypad
	{
		tempatt_obj = key_array[ATT_OBJ_PERA];
		Att_obg_v = tempatt_obj * 10;
	}

	pos = (ATT_OBJ_PERA * 2) + 1;
	if (Att_obg_v > 1100)
	{
		Att_obg_v = 0;
	}
	if (Att_obg_v > 1000)
	{
		Att_obg_v = 1000;
	}
	val_ary[ATT_OBJ_PERA] = Att_obg_v;

	toarry(Att_obg_v, pos, 0, 1, unit[0]);

	strcpy(all_btnval[pos], Dsp_Str);
	gtk_label_set_label(GTK_LABEL(dgslabel[21]), Dsp_Str);
}

//******************************************************************************
//************************* Display Error or warning Message  ******************
//******************************************************************************

void dsp_msg(int msgno) // Display Error or warning Message
{
	char Wrnmessage[75];
	// int temp;
	switch (msgno)
	{
	case 0:
		sprintf(Wrnmessage, "Memory is empty");
		break;
	case 1:
		sprintf(Wrnmessage, "DAC is active");
		break;
	case 2:
		sprintf(Wrnmessage, "AWS is active");
		break;
	case 3:
		sprintf(Wrnmessage, "DGS is active");
		break;
	case 4:
		sprintf(Wrnmessage, "DGS is off");
		break;
	case 5:
		sprintf(Wrnmessage, "As per probe type");
		break;
	case 6:
		sprintf(Wrnmessage, "DGS-REF is ON");
		break;
	case 7:
		sprintf(Wrnmessage, "Memory not empty");
		break;
	case 8:
		sprintf(Wrnmessage, "SET-REF is ON");
		break;
	case 9:
		sprintf(Wrnmessage, "In DGS REF Mode gets turn ON");
		break;
	case 10:
		sprintf(Wrnmessage, "Turn off DAC, then cahnge evaluation mode");
		break;
	case 11:
		sprintf(Wrnmessage, "Turn off AWS, then cahnge evaluation mode");
		break;
	case 12:
		sprintf(Wrnmessage, "Turn off DGS, then cahnge evaluation mode");
		break;
	case 13:
		sprintf(Wrnmessage, "Echo position 1 registered");
		break;
	case 14:
		sprintf(Wrnmessage, "To register echo press step and para up key");
		break;
	case 15:
		sprintf(Wrnmessage, "Echo 1 position is not registerd");
		break;
	case 16:
		sprintf(Wrnmessage, "Echo 2 position is not registerd");
		break;
	case 17:
		sprintf(Wrnmessage, "AUTO CAL failed");
		break;
	case 18:
		sprintf(Wrnmessage, "AUTO CAL successful ");
		break;
	case 19:
		sprintf(Wrnmessage, "End of file reached");
		break;
	case 20:
		sprintf(Wrnmessage, "Reached at the beginning of the file");
		break;
	case 21:
		sprintf(Wrnmessage, "File exists, Press STP + ENTER KEY to overwrite");
		break;
	case 22:
		sprintf(Wrnmessage, "Are you sure you want to delete ? PRESS ENETER BELOW  ");
		break;
	case 23:
		sprintf(Wrnmessage, "Press STP + ENTER KEY to delete all files");
		break;
	case 24:
		sprintf(Wrnmessage, "Please check, if file exists");
		break;
	case 25:
		sprintf(Wrnmessage, "File copied successfully");
		break;
	case 26:
		sprintf(Wrnmessage, "Press STP + ENTER KEY to copy all files ");
		break;
	case 27:
		sprintf(Wrnmessage, "Press STP + ENTER KEY to delete files");
		break;
	case 28:
		sprintf(Wrnmessage, "Mount the USB properly");
		break;
	case 29:
		sprintf(Wrnmessage, "Unable to copy file. Mount USB pendrive properly");
		break;
	case 30:
		sprintf(Wrnmessage, "Started data recording.");
		break;
	case 31:
		sprintf(Wrnmessage, "Open file for read data.");
		break;
	case 32:
		sprintf(Wrnmessage, "Closed data file.");
		break;
	case 33:
		sprintf(Wrnmessage, "File is Already open.");
		break;
	case 34:
		sprintf(Wrnmessage, "PRF value is limited, due to current range/valocity setting");
		break;
	case 35:
		sprintf(Wrnmessage, "Change PRF Mode to Manual ");
		break;
	case 36:
		sprintf(Wrnmessage, "Power is high");
		break;
	case 37:
		sprintf(Wrnmessage, "power is low");
		break;
	case 38:
		sprintf(Wrnmessage, "File recalled successfully");
		break;
	case 39:
		sprintf(Wrnmessage, "File does not exist");
		break;
	case 40:
		sprintf(Wrnmessage, "File SAVED successfully");
		break;
	case 41:
		sprintf(Wrnmessage, "File detail loaded successfully");
		break;
	case 42:
		sprintf(Wrnmessage, "File deleted successfully");
		break;
	case 43:
		sprintf(Wrnmessage, "All file's deleted successfully");
		break;
	case 44:
		sprintf(Wrnmessage, "All file's copied successfully");
		break;
	case 45:
		sprintf(Wrnmessage, "Battery low, connect the charger"); 
		break;
	case 46:
		sprintf(Wrnmessage, "Battery full, remove the charger");  
		break;
	case 47:
		sprintf(Wrnmessage, "Saved last setup successfully");
		break;
	case 48:
		sprintf(Wrnmessage, "Failed to save last setup");
		break;
	case 49:
		sprintf(Wrnmessage, "USB device can be removed");
		break;
	case 50:
		sprintf(Wrnmessage, "Hi, I am test message %d.", testMsgNo);
		break;
	default:
		sprintf(Wrnmessage, "                        ");
		break;
	}

	Clk_ref = 15;

	Error_msg = true;
	gtk_label_set_label(GTK_LABEL(err_label), Wrnmessage);
	gtk_widget_show(b_errorbox);
	gtk_widget_hide(b_btnbox);
}

/************************************************************************************/
/************************************POINT DAC FUNCTION******************************/
/************************************************************************************/

void Point_f(int key_t)
{
	char *unit[] = {"dB "};
	gchar dec_num[9];

	pos = (POINT_PERA * 2);
	point_v = val_ary[POINT_PERA];

	//**********KEY_SCR = 0*********************

	if (key_scr == 0) // Get the value from scrollbar
	{
		point_v = val_ary[POINT_PERA];
	}

	//**********KEY_SCR = 1********************* // Get the value from button keypad

	if (key_scr == 1 && Dac_v == 1 || Dac_v == 0) // If DAC is OFF or DRAW mode then display and set Point
	{
		point_v = point_v + key_t;
	}
	else if (key_scr == 1 && Dac_v == 2 || Dac_v == 3) // IF DAC is ON or TCG is on then DAC Transfer Gain Dac_tlg_v set
	{
		Dac_tlg_v = Dac_tlg_v + (key_t * Gn_stp);
	}
	// Display Value on Screen

	if (point_v < 0)
	{
		point_v = 0;
	}
	if (point_v > 14)
	{
		point_v = 14;
	}
	val_ary[POINT_PERA] = point_v;

	if (Dac_tlg_v < -200)
	{
		Dac_tlg_v = -200;
	}
	if (Dac_tlg_v > 200)
	{
		Dac_tlg_v = 200;
	}

	if (Dac_v == 1 || Dac_v == 0) // IF DAC IS ON or OFF
	{
		strcpy(all_btnval[pos + 0], "POINT  ");
		sprintf(Dsp_Str, "%02d ", point_v + 1);
		strcpy(all_btnval[pos + 1], Dsp_Str);
	}
	else if (Dac_v == 2 || Dac_v == 3) // IF DAC is ON or TCG then Display "TL  "
	{
		strcpy(all_btnval[pos + 0], "TL     ");
		toarry(Dac_tlg_v, pos, 0, 1, unit[0]);
		strcpy(all_btnval[pos + 1], Dsp_Str);
	}
	Gain_set(0, Gain_v, 0); // For DAC this is must to call
}

/***********************************************************************************/
/*************************************Tl CORR FUNCTION******************************/
/***********************************************************************************/

void Tl_Corr_f(int key_t)
{
	char *unitm[] = {" dB"};
	// Tl_corr_v = val_ary[POINT_PERA];

	pos = (POINT_PERA * 2) + 1;

	//**********KEY_SCR = 0*********************

	if (key_scr == 0) // Get the value from scrollbar
	{
	}

	//**********KEY_SCR = 1*********************

	if (key_scr == 1) // Get the value from button keypad
	{
		Tl_corr_v = Tl_corr_v + (key_t * Gn_stp);
	}

	if (Tl_corr_v < -240)
	{
		Tl_corr_v = -240;
	} // If Over Flaw then make it Zero
	if (Tl_corr_v > 240)
	{
		Tl_corr_v = 240;
	}

	toarry(Tl_corr_v, pos, 0, 1, unitm[0]);
	strcpy(all_btnval[pos], Dsp_Str);
	Gain_f(0); // If DGS is ON then Apply TL correction effect
}

/***********************************************************************************/
/*************************************DEL VEL FUNCTION******************************/
/***********************************************************************************/

void Del_Vel_f(int key_t)
{
	char *unitm[] = {"M/S"}, *uniti[] = {"   "};
	pos = (DELVEL_PERA * 2) + 1; //

	if (Unit_v == INCH)
	{
		gtk_adjustment_set_lower(adj, 400);
		gtk_adjustment_set_upper(adj, 4000);
	}
	else
	{
		gtk_adjustment_set_lower(adj, 1000);
		gtk_adjustment_set_upper(adj, 10000);
	}

	Dly_vel_vC = val_ary[DELVEL_PERA]; // added

	//**********KEY_SCR = 0*********************

	if (key_scr == 0) // Get the value from scrollbar
	{
		if (Scal_v == 0) // If Custom Scale then Allow to vary Freq
		{
			Dly_vel_vC = scr_val;
			Dly_vel_v = Dly_vel_vC;
		}
	}

	//**********KEY_SCR = 1*********************

	if (key_scr == 1) // Get the value from button keypad
	{
		if (Scal_v == 0) // If Custom Scale then Allow to vary Freq
		{
			Dly_vel_vC = Dly_vel_vC + (key_t * Key_stp);
			if (Unit_v == INCH) // If unit is Inch
			{
				if (Dly_vel_vC < 400)
					Dly_vel_vC = 400;
				if (Dly_vel_vC > 4000)
					Dly_vel_vC = 4000;
			}
			else
			{
				if (Dly_vel_vC < 1000)
					Dly_vel_vC = 1000;
				if (Dly_vel_vC > 10000)
					Dly_vel_vC = 10000;
			}
			Dly_vel_v = Dly_vel_vC;
		}
		else //  Fix Velocity so issue warning Message
		{
			if (key_t != 0)
			{
				dsp_msg(5);
			}
		}
	}

	//********** KEY_SCR = 2 *********************

	if (key_scr == 2) // Get the value from touch keypad
	{
		if (Scal_v == 0) // If Custom Scale then Allow to vary Freq
		{
			Dly_vel_vC = Dly_vel_vC;
			if (Unit_v == INCH) // If unit is Inch
			{
				if (Dly_vel_vC < 400)
					Dly_vel_vC = 400;
				if (Dly_vel_vC > 4000)
					Dly_vel_vC = 4000;
			}
			else
			{
				if (Dly_vel_vC < 1000)
					Dly_vel_vC = 1000;
				if (Dly_vel_vC > 10000)
					Dly_vel_vC = 10000;
			}
			Dly_vel_v = Dly_vel_vC;
		}
		else //  Fix Velocity so issue warning Message
		{
			dsp_msg(5);
		}
	}
	val_ary[DELVEL_PERA] = Dly_vel_vC;

	// Display Value on Display
	if (Unit_v == INCH)
	{
		toarry(Dly_vel_v, pos, 0, 0, uniti[0]);
	} // toarry(Dly_vel_v,allpera[posi],0,0,uniti[0]); }  // Display in Inches
	else
	{
		toarry(Dly_vel_v, pos, 0, 0, unitm[0]);
	} //  toarry(Dly_vel_v,allpera[posi],0,0,unitm[0]);}

	strcpy(all_btnval[pos], Dsp_Str);
	gtk_label_set_label(GTK_LABEL(dgslabel[7]), Dsp_Str);
}

/***********************************************************************************/
/*************************************REF SIZE FUNCTION*****************************/
/***********************************************************************************/

void Ref_size_f(int key_t)
{
	char *unitm[] = {" mm"}, *uniti[] = {" in"}, *cp;
	long int tempL;

	tempL = D_efect_v * 5; // Minimum Dia= Defec * 0.05
	tempL = tempL / 100;

	pos = (REF_SIZ_PERA * 2) + 1;
	Ref_size_v = val_ary[REF_SIZ_PERA];

	if (Ref_echo_v == 0)
	{
		strcpy(all_btnval[pos], "-------");
		Ref_size_v = D_efect_v;
	}
	else
	{
		if (key_scr == 1) // Get the value from button keypad
		{
			Ref_size_v = Ref_size_v + (key_t * Key_stp);
		}
	}

	if (Ref_size_v < tempL) // Minimum Limit
	{
		Ref_size_v = tempL;
		dsp_msg(5);
	}
	if (Ref_size_v > D_efect_v)
	{
		Ref_size_v = D_efect_v;
		dsp_msg(5);
	}

	val_ary[REF_SIZ_PERA] = Ref_size_v;

	if (Unit_v == MM)
	{
		toarry(Ref_size_v, pos, 0, 1, unitm[0]);
	}
	else
	{
		toarry(Ref_size_v, pos, 0, 3, uniti[0]);
	}

	if (Ref_echo_v == 0)
	{
		strcpy(Dsp_Str, "-------");
		Ref_size_v = D_efect_v;
	}

	strcpy(all_btnval[pos], Dsp_Str);
	gtk_label_set_label(GTK_LABEL(dgslabel[15]), Dsp_Str);
}

/***********************************************************************************/
/*************************************AMP CORR FUNCTION*******************************/
/***********************************************************************************/

void Amp_corr_f(int key_t)
{
	char *unit[] = {"dB "};
	float tempamp_corr = 0.0;
	Amp_corr_v = val_ary[AMP_COR_PERA];

	gtk_adjustment_set_lower(adj, -1000);
	gtk_adjustment_set_upper(adj, 1000);

	//**********KEY_SCR = 0*********************

	if (key_scr == 0) // Get the value from scrollbar
	{
		Amp_corr_v = val_ary[AMP_COR_PERA];
	}

	//**********KEY_SCR = 1*********************

	if (key_scr == 1) // Get the value from button keypad
	{
		if (key_t != 0)
			if (Dgs_ref_v != 0)
			{
				dsp_msg(6);
			}
			else
			{
				Amp_corr_v = Amp_corr_v + (key_t * Key_stp);
			}
	}

	//********** KEY_SCR = 2 *********************

	if (key_scr == 2) // Get the value from touch keypad
	{
		if (Dgs_ref_v != 0)
		{
			dsp_msg(6);
		}
		else
		{
			tempamp_corr = key_array[AMP_COR_PERA];
			Amp_corr_v = tempamp_corr * 10;
		}
	}

	if (Amp_corr_v < -1000)
	{
		Amp_corr_v = -1000;
	}
	if (Amp_corr_v > 1000)
	{
		Amp_corr_v = 1000;
	}

	val_ary[AMP_COR_PERA] = Amp_corr_v;

	pos = (AMP_COR_PERA * 2) + 1;
	toarry(Amp_corr_v, pos, 0, 1, unit[0]);
	strcpy(all_btnval[pos], Dsp_Str);
	gtk_label_set_label(GTK_LABEL(dgslabel[23]), Dsp_Str);
}

//--------
/*MENU 5*/
//--------

/************************************************************************************/
/************************************DAMPING CONTROL*********************************/
/************************************************************************************/

void DAMP_f(int key_t)
{
	gchar wData;
	char buffer[40];
	Damp_val = val_ary[DAMP_PERA];

	//********** KEY_SCR = 0 *********************

	if (key_scr == 0) // Get the value from scrollbar
	{
		Damp_val = val_ary[DAMP_PERA];
	}

	//**********KEY_SCR = 1*********************

	if (key_scr == 1) // Get the value from button keypad
	{
		Damp_val = Damp_val + key_t;
	}

	if (Damp_val < 0)
	{
		Damp_val = 0;
	}
	if (Damp_val > 2)
	{
		Damp_val = 2;
	}

	val_ary[DAMP_PERA] = Damp_val;

	Ctr_reg1 = Ctr_reg1 & 0x0C3; // Clr both Bit  1100 0011 // xxxx BBxx    // xxxx bbxx // 0x0FC

	if (Damp_val == 0)
	{
		Ctr_reg1 = Ctr_reg1 | 0x28; // (Interchanged) 0010 1000
		strcpy(Dsp_Str, "50 ohm");
	}
	else if (Damp_val == 1)
	{
		Ctr_reg1 = Ctr_reg1 | 0x18; // (Interchanged) 0001 1000
		strcpy(Dsp_Str, "150 ohm");
	}
	else if (Damp_val == 2)
	{
		Ctr_reg1 = Ctr_reg1 | 0x24; // (Interchanged) 0010 0100
		strcpy(Dsp_Str, "500 ohm");
	}
	else
	{
		Ctr_reg1 = Ctr_reg1 | 0x28;
		strcpy(Dsp_Str, "50 ohm");
	}

	tx_bufidx = 0;
	if (Damp_val == 0)
	{
		tx_cmd[tx_bufidx++] = 0x1B;
		tx_cmd[tx_bufidx++] = 0x57; // 01010111
		tx_cmd[tx_bufidx++] = Ctr_reg1;
		tx_cmd[tx_bufidx++] = 0x1B;
	}
	else if (Damp_val == 1)
	{
		tx_cmd[tx_bufidx++] = 0x1B;
		tx_cmd[tx_bufidx++] = 0x57;
		tx_cmd[tx_bufidx++] = Ctr_reg1;
		tx_cmd[tx_bufidx++] = 0x1B;
	}
	else if (Damp_val == 2)
	{
		tx_cmd[tx_bufidx++] = 0x1B;
		tx_cmd[tx_bufidx++] = 0x57;
		tx_cmd[tx_bufidx++] = Ctr_reg1;
		tx_cmd[tx_bufidx++] = 0x1B;
	}
	else
	{
		tx_cmd[tx_bufidx++] = 0x1B;
		tx_cmd[tx_bufidx++] = 0x57;
		tx_cmd[tx_bufidx++] = Ctr_reg1;
		tx_cmd[tx_bufidx++] = 0x1B;
	}

	Send_SPI(tx_bufidx);

	if (key_t == 0)
	{
	}
	else
	{
		usleep(500000); // in microseconds (50 milliseconds = 500000 microseconds)
	}

	tx_bufidx = 0;
	Ctr_reg1 = Ctr_reg1 & 0x0C3; // Clr both Bit  xxxx BBxx // 0x0F3
	tx_cmd[tx_bufidx++] = 0x1B;
	tx_cmd[tx_bufidx++] = 0x57;
	tx_cmd[tx_bufidx++] = Ctr_reg1;
	tx_cmd[tx_bufidx++] = 0x1B;

	Send_SPI(tx_bufidx);

	pos = (DAMP_PERA * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
}

/************************************************************************************/
/***************************************MODE*****************************************/
/************************************************************************************/

void Mode_f(int key_t)
{
	char buffer[40];
	gchar wData;
	Mode_val = val_ary[MODE_PERA];

	//**********KEY_SCR = 0*********************

	if (key_scr == 0) // Get the value from scrollbar
	{
		Mode_val = val_ary[MODE_PERA];
	}

	//**********KEY_SCR = 1*********************

	if (key_scr == 1) // Get the value from button keypad
	{
		Mode_val = Mode_val + key_t;
	}

	if (Mode_val < 0)
	{
		Mode_val = 0;
	}
	if (Mode_val > 1)
	{
		Mode_val = 1;
	}

	val_ary[MODE_PERA] = Mode_val;

	Ctr_reg1 = Ctr_reg1 & 0xCC; // Clr both Bit   xxBB xxBB    1100 1100

	// 10 means off  01 means on
	if (Mode_val == 0)
	{
		Ctr_reg1 = Ctr_reg1 | 0x22;
		strcpy(Dsp_Str, "SINGLE ");
	}
	else if (Mode_val == 1)
	{
		Ctr_reg1 = Ctr_reg1 | 0x21;
		strcpy(Dsp_Str, "DUAL   ");
	}

	tx_bufidx = 0;
	tx_cmd[tx_bufidx++] = 0x1B;
	tx_cmd[tx_bufidx++] = 0x057;
	tx_cmd[tx_bufidx++] = Ctr_reg1;
	tx_cmd[tx_bufidx++] = 0x1B;
	Send_SPI(tx_bufidx);

	if (key_t == 0)
	{
	}
	else
	{
		usleep(500000); // in microseconds (50 milliseconds = 500000 microseconds)
	}

	Ctr_reg1 = Ctr_reg1 & 0xCC; //  Clr both Bit   xxBB xxBB    1100 1100

	tx_bufidx = 0;
	tx_cmd[tx_bufidx++] = 0x1B;
	tx_cmd[tx_bufidx++] = 0x057;
	tx_cmd[tx_bufidx++] = Ctr_reg1;
	tx_cmd[tx_bufidx++] = 0x1B;
	Send_SPI(tx_bufidx);

	Draw_notificimg(MODE_S, Mode_val); // Symbol type,Position                  // Draw Symbol and DIsplay on Screen

	pos = (MODE_PERA * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
}

/************************************************************************************/
/*********************************** PRF ********************************************/
/************************************************************************************/
// Refer to Prf_Cal Excel Document in the current folder.
void Prf_f(int key_t)
{
	char buffer[40], buffer1[40], buffer2[40];
	unsigned char utemp;
	int tempprf_v = 100;
	// int St_val;
	long int st, data, time, set_prf, St_val; //   required time to display  td= (2*range)/velocity
	Prf_v = val_ary[PRF_PERA];

	pos = (PRF_PERA * 2) + 1;

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
		// gtk_adjustment_set_lower(adj, 0);
		// gtk_adjustment_set_upper(adj, 3);
		// gtk_adjustment_set_step_increment(adj, 4.0);
	}

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) //  Get the value from button keypad
	{
		if (Prf_v < 3)
			Prf_v = Prf_v + key_t;
		else
			Prf_v = Prf_v + (key_t * 10); // IF REQUIRED IN STEP OF 10 UNCOMMENT HERE   // Prf_v = Prf_v + (key_t * 100); // IF PRF VALUE REQUIRED IN STEP OF 100 UNCOMMENT HERE
	}

	if (Prf_v < 0)
		Prf_v = 0;
	else if (Prf_v == 3)
		Prf_v = 10; // IF PRF VALUE REQUIRED IN STEP OF 10 UNCOMMENT HERE  // Prf_v = 100; // IF PRF VALUE REQUIRED IN STEP OF 100 UNCOMMENT HERE
	else if (Prf_v > 2000)
		Prf_v = 2000;

	val_ary[PRF_PERA] = Prf_v;

	if (Prf_v == 0) // LOW
	{
		strcpy(Dsp_Str, "AUTO-L ");
		strcpy(all_btnval[pos - 1], "PRF    ");
	}
	else if (Prf_v == 1) // MEDIUM
	{
		strcpy(Dsp_Str, "AUTO-M ");
		strcpy(all_btnval[pos - 1], "PRF    ");
	}
	else if (Prf_v == 2) // HIGH
	{
		strcpy(Dsp_Str, "AUTO-H ");
		strcpy(all_btnval[pos - 1], "PRF    ");
	}
	else if (Prf_v >= 3) // MANUAL
	{
		strcpy(all_btnval[pos - 1], "MANUAL ");
		sprintf(Dsp_Str, "%d Hz", Prf_v);
	}

	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
	PRF_Set();
}

void PRF_Set()
{
	char buffer[40], buffer1[40], buffer2[40], prf_buffer1[40];
	unsigned char utemp;
	long int data, St_val, Set_prf;

	if (Prf_v == 0) // AUTO-LOW
	{
		Set_prf = Prf_cal / 4;
	}
	else if (Prf_v == 1) // AUTO _MEDIUM
	{
		Set_prf = Prf_cal / 2;
	}
	else if (Prf_v == 2) // AUTO_HIGH
	{
		Set_prf = Prf_cal;
	}
	else if (Prf_v >= 3) // MANUAL
	{
		Set_prf = Prf_v;
		if (Set_prf > Prf_condval)
		{
			dsp_msg(34);
			Set_prf = Prf_condval;
			val_ary[PRF_PERA] = Prf_condval;
			pos = (PRF_PERA * 2) + 1;
			sprintf(prf_buffer1, "%d Hz", Prf_condval);
			strcpy(all_btnval[pos], prf_buffer1);
		}
	}

	St_val = (1000000 * 50) / Set_prf;

	tx_bufidx = 0;
	data = St_val;
	utemp = (uint8_t)data;
	Write_data(DATA1_Adr, utemp); // LSB 0 byte Register R1
	data = St_val >> 8;
	utemp = (uint8_t)data;
	Write_data(DATA2_Adr, utemp); // LSB 1 byte Register R1
	data = St_val >> 16;
	utemp = (uint8_t)data;
	Write_data(PRF_Adr, utemp); // LSB 2 byte Register R1

	Send_SPI(tx_bufidx);
}

void PRF_Cal()
{
	char buffer[40];
	double rngp, velop, timep, prft, fact;

	rngp = val_ary[RANGE_PERA];
	velop = val_ary[VELO_PERA];
	timep = rngp / velop;

	if (timep < 0.1689189) // LESS THAN 10 mm
	{
		prft = 2000;
	}

	if (timep >= 0.1689189 && timep < 0.8445946) // 10mm to 50mm
	{
		fact = timep / 0.1689189;
		fact = fact - 1;
		prft = 2000 - ((1000 * fact) / 4);
	}

	if (timep >= 0.8445946 && timep < 4.222973) // 50mm to 250mm
	{
		fact = timep / 0.8445946;
		fact = fact - 1;
		prft = 1000 - ((500 * fact) / 4);
	}

	if (timep >= 4.222973 && timep < 21.1148649) // 250mm to 1250mm
	{
		fact = timep / 4.222973;
		fact = fact - 1;
		prft = 500 - ((250 * fact) / 4);
	}

	if (timep >= 21.1148649 && timep < 105.5743243) // 1250mm to 6250mm
	{
		fact = timep / 21.1148649;
		fact = fact - 1;
		prft = 250 - ((125 * fact) / 4);
	}

	if (timep >= 105.5743243) // GREATER THAN 6250mm
	{
		fact = timep / 105.5743243;
		fact = fact - 1;
		prft = 125 - ((62.5 * fact) / 4);
	}

	Prf_cal = prft;
	Prf_condval = prft;

	if (Prf_condval > 3 && Prf_condval <= 10)
	{
		Prf_condval = 10;
	}
	for (i = 20; i <= 2000; i = i + 10) // CONDITIONS FOR PRF STEP INCREMENT BY 10. So if Prf_cal max value is 875 then make it 880 else the prf value will become 875 and then step increment will happen in the form of 875,865,855 etc.
	{
		if (Prf_condval > i && Prf_condval <= i + 10)
		{
			Prf_condval = i + 10;
		}
	}

	// if (Prf_condval > 3 && Prf_condval <= 100)		// IF PRF VALUE REQUIRED IN STEP OF 100 UNCOMMENT HERE
	//{
	//	Prf_condval = 100;
	// }
	// for (i = 200; i <= 2000; i = i + 100) // CONDITIONS FOR PRF STEP INCREMENT BY 10. So if Prf_cal max value is 875 then make it 880 else the prf value will become 875 and then step increment will happen in the form of 875,865,855 etc.
	//{
	//	if (Prf_condval > i && Prf_condval <= i + 100)
	//	{
	//		Prf_condval = i + 100;
	//	}
	// }

	PRF_Set();
}

void Txvolt_f(int key_t)
{
	int txvs;
	char buffer[40];
	txvolt_v = val_ary[TXVOLT_PERA];

	//********** KEY_SCR = 0 *********************
	if (key_scr == 0) // Get the value from scrollbar
	{
		gtk_adjustment_set_lower(adj, 0);
		gtk_adjustment_set_upper(adj, 4);
		// txvolt_v = val_ary[TXVOLT_PERA];
	}

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) //  Get the value from button keypad
		txvolt_v = txvolt_v + key_t;

	//**********KEY_SCR = 2*********************
	if (key_scr == 2) // Get the value from touch keypad
		txvolt_v = val_ary[TXVOLT_PERA];

	if (txvolt_v < 0)
		txvolt_v = 0; // Prf_m = 4;
	if (txvolt_v > 4)
		txvolt_v = 4;

	val_ary[TXVOLT_PERA] = txvolt_v;

	if (txvolt_v == 0)
	{
		txvs = 400;
		sprintf(Dsp_Str, "50 V ");
	}
	else if (txvolt_v == 1)
	{
		txvs = 1080;
		sprintf(Dsp_Str, "100 V ");
	}
	else if (txvolt_v == 2)
	{
		txvs = 1800;
		sprintf(Dsp_Str, "150 V ");
	}
	else if (txvolt_v == 3)
	{
		txvs = 2440;
		sprintf(Dsp_Str, "200 V ");
	}
	else if (txvolt_v == 4)
	{
		txvs = 3160;
		sprintf(Dsp_Str, "250 V ");
	}
	
	//  Vout    DAC Count value
	//	50		400
	//	100		1080
	//	150		1800
	//	200		2440
	//  250		3160
	
	pos = (TXVOLT_PERA * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	Dav_out(0, 3, txvs);
}

/************************************************************************************/
/**********************************REJECTION*****************************************/
/************************************************************************************/
void Reject_f(int key_t) // Rejection Value increased from 100 % to 125 %
{
	Reject_v = val_ary[REJECT_PERA];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
	}
	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
	{
		Reject_v = Reject_v + key_t;
	}

	if (Reject_v < 0)
	{
		Reject_v = 0;
	}
	if (Reject_v > 125)
	{
		Reject_v = 125;
	}

	val_ary[REJECT_PERA] = Reject_v;

	pos = (REJECT_PERA * 2) + 1;
	sprintf(Dsp_Str, "%d %%", Reject_v);
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;

	if (Reject_v == 0)
	{
		Draw_notificimg(REJECT_S, 0);
	} // Rejection ON Symbol type,Postion   Display Status/Symbol
	else
	{
		Draw_notificimg(REJECT_S, 1);
	} // Rejection OFF Symbol type,Postion   Display Status/Symbol
}

//*********************************************************************************************************************************
//******************************************************* Used to Set Averaging and Max value of Ascan Data in FPGA
//*********************************************************************************************************************************

void Max_Average_Set_f() // Used to Set Averaging and Max value of Ascan Data in FPGA
{
	unsigned char tmpc;
	int ds = 0;

	// Maxv=Reject_v;
	if (Maxv < 1)
	{
		Maxv = 1;
	}
	if (Maxv > 8)
	{
		Maxv = Maxv;
	}

	tx_cmd[ds++] = 0x1B;
	tx_cmd[ds++] = 0x082;
	tx_cmd[ds++] = Maxv;
	tx_cmd[ds++] = 0x1B; // 1B 82 xx 1B     To set Max ( Find maximum out of xx )  value 1 to 8
	Send_SPI(ds);		 // Send data

	// Avg=Brightness_v;
	if (Avg < 1)
	{
		Avg = 1;
	}
	if (Avg > 8)
	{
		Avg = 8;
	}

	ds = 0;
	tx_cmd[ds++] = 0x1B;
	tx_cmd[ds++] = 0x081;
	tx_cmd[ds++] = Avg;
	tx_cmd[ds++] = 0x1B; // 1B 81 xx 1B     To set Average of n data (Find average of xx )  value from 1 to 8

	Ctrreg0 = Ctrreg0 & 0xf0;
	Ctrreg0 = Ctrreg0 | Avg;
	tx_cmd[ds++] = 0x1B;
	tx_cmd[ds++] = 0x080;
	tx_cmd[ds++] = Ctrreg0;
	tx_cmd[ds++] = 0x1B; // 1B 80 Dx 1B     To set Average of n data (Find average of  x )  value from 1 to 8

	Send_SPI(ds); // Send data
}

/**************************************************************************************/
/*********************************** Freq Band ****************************************/
/**************************************************************************************/
void Freq_f(int key_t)
{
	Freq_v = val_ary[FREQ_PERA];

	//**********KEY_SCR = 0**************************
	if (key_scr == 0) // Get the value from scrollbar
	{
	}

	//**********KEY_SCR = 1******************************
	if (key_scr == 1) // Get the value from button keypad
	{
		Freq_v = Freq_v + key_t;
	}

	if (Freq_v < 0)
	{
		Freq_v = 0;
	}
	if (Freq_v > 6)
	{
		Freq_v = 6;
	}
	val_ary[FREQ_PERA] = Freq_v;

	if (Freq_v == 0)
	{
		strcpy(Dsp_Str, ".2-1.2MHZ");
	}
	else if (Freq_v == 1)
	{
		strcpy(Dsp_Str, "  .5-4MHZ");
	}
	else if (Freq_v == 2)
	{
		strcpy(Dsp_Str, "1.5-8.5MHZ");
	}
	else if (Freq_v == 3)
	{
		strcpy(Dsp_Str, "0.2-10MHZ");
	}
	else if (Freq_v == 4)
	{
		strcpy(Dsp_Str, "  5-15MHZ");
	}
	else if (Freq_v == 5)
	{
		strcpy(Dsp_Str, "2-21.5MHZ");
	}
	else if (Freq_v == 6)
	{
		strcpy(Dsp_Str, "  8-24MHZ");
	}
	else
	{
		Freq_v = 1;
		strcpy(Dsp_Str, "  .5-4MHZ");
	} //

	pos = (FREQ_PERA * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;

	Send_filt_Coef(); // Send Filter Coeficient to FPGA
}

//**************************************************************************************************************************
//**************************************************************************************************************************
void Send_filt_Coef() //   Send Filter Coeficient to FPGA
{
	int i, j, k;
	int lsb, msb, data, ds;
	int *Filter;
	unsigned char wData;

	if (Freq_v == 0)
	{
		Filter = &Filt_0p2to1p2[0];
	}
	else if (Freq_v == 1)
	{
		Filter = &Filt_0p5to4p0[0];
	}
	else if (Freq_v == 2)
	{
		Filter = &Filt_1p5to8p5[0];
	}
	else if (Freq_v == 3)
	{
		Filter = &Filt_0p2to10p0[0];
	}
	else if (Freq_v == 4)
	{
		Filter = &Filt_5p0to15p0[0];
	}
	else if (Freq_v == 5)
	{
		Filter = &Filt_2p0to21p5[0];
	}
	else if (Freq_v == 6)
	{
		Filter = &Filt_8p0to24p0[0];
	}
	else
	{
		Filter = &Filt_0p5to4p0[0];
		Freq_v = 1;
	}

	ds = 0;
	for (i = 0; i < 98; i++)
	{
		data = *Filter++; //  Filt_05to40[i];
		msb = data & 0x00FF00;
		msb = msb >> 8;
		wData = (unsigned char)data;
		tx_cmd[ds++] = 0x1B;
		tx_cmd[ds++] = msb;
		tx_cmd[ds++] = wData;
		tx_cmd[ds++] = 0x1B;
		Send_SPI(ds); // Send data
	}
	ds = 0;
}

/*************************************************************************************/
/*********************************** Freq Band ***************************************/
/*************************************************************************************/
void Rectify_f(int key_t)
{
	int tx_bufidx, ds;
	unsigned char cmd_r;

	Rectify_v = val_ary[RECTIFY_PERA];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) 	{	} // Get the value from scrollbar

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) //  Get the value from button keypad
		Rectify_v = Rectify_v + key_t;

	if (Rectify_v < 0)
		Rectify_v = 3;
	else if (Rectify_v > 3)
		Rectify_v = 0;
	
	val_ary[RECTIFY_PERA] = Rectify_v;

	if (Rectify_v == 0)
		strcpy(Dsp_Str, "FULL-W  ");
	else if (Rectify_v == 1)
		strcpy(Dsp_Str, "POS-HW  ");
	else if (Rectify_v == 2)
		strcpy(Dsp_Str, "NEG-HW  ");
	else if (Rectify_v == 3)
		strcpy(Dsp_Str, "RF      ");

	Ctrreg0 = Ctrreg0 & 0x3F;
	cmd_r = 0;
	
	if (Rectify_v == 1) 		// Pos HW
		cmd_r = 0x40;
	else if (Rectify_v == 2) 	// Neg HW
		cmd_r = 0x80;
	else if (Rectify_v == 3) 	// RF
		cmd_r = 0x00;
	else 						// Envelop
		cmd_r = 0xc0;

	Ctrreg0 = Ctrreg0 | cmd_r;
	tx_bufidx = 0;
	tx_cmd[tx_bufidx++] = 0x1B;
	tx_cmd[tx_bufidx++] = 0x80;
	tx_cmd[tx_bufidx++] = Ctrreg0;
	tx_cmd[tx_bufidx++] = 0x1B;

	Send_SPI(tx_bufidx); // Send data
	ds = 0;

	pos = (RECTIFY_PERA * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;

	LEVELa_f(0); // Threshold Level is different for RF and Non RF so call this to make value appropriate
	Cal_Gate();

	Menu_Refresh();
}

/***********************************************************************************/
/***********************************SMOOTH FUNCTION*********************************/
/***********************************************************************************/
void Smooth_f(int key_t)
{
	Smooth_v = val_ary[SMOOTH_PERA];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
	}

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
	{
		Smooth_v = Smooth_v + key_t;
	}

	if (Smooth_v < 0)
	{
		Smooth_v = 0;
	}
	if (Smooth_v > 3)
	{
		Smooth_v = 3;
	}
	val_ary[SMOOTH_PERA] = Smooth_v;

	if (Smooth_v == 0)
	{
		strcpy(Dsp_Str, "OFF    ");
	} // OFF
	if (Smooth_v == 1)
	{
		strcpy(Dsp_Str, "LOW    ");
	} // LOW
	if (Smooth_v == 2)
	{
		strcpy(Dsp_Str, "MEDIUM ");
	} // MEDIUM
	if (Smooth_v == 3)
	{
		strcpy(Dsp_Str, "HIGH   ");
	} // HIGH
	pos = (SMOOTH_PERA * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
}

//*******************************************************************************************************
//*******************************************************************************************************
void Grid_f(int key_v) // Draw Grid as per selection   GRID_PERA
{
	Grid_v = val_ary[GRID_PERA];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
	}

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
	{
		Grid_v = Grid_v + key_v;
	}

	if (key_scr == 2) // Get the value from touch keypad
	{
		Grid_v = val_ary[GRID_PERA] - 1;
		// Grid_v = Grid_v + 1;
	}
	if (Grid_v < 0)
	{
		Grid_v = 0;
	}
	if (Grid_v > 5)
	{
		Grid_v = 5;
	}

	val_ary[GRID_PERA] = Grid_v;

	sprintf(Dsp_Str, "  %d", Grid_v + 1);

	pos = (GRID_PERA * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;

	gl_clear_color_background_data(width_sh, height_sh);
}

//*******************************************************************************************************
void Color_Leg_f(int key_v)
{
	Color_Leg_v = val_ary[COL_LEG_PERA];

	//**********KEY_SCR = 0*********************

	if (key_scr == 0) // Get the value from scrollbar
	{
	}

	//**********KEY_SCR = 1*********************

	if (key_scr == 1) // Get the value from button keypad
	{
		Color_Leg_v = Color_Leg_v + key_v;
	}

	if (Color_Leg_v < 0)
	{
		Color_Leg_v = 0;
	}
	if (Color_Leg_v > 1)
	{
		Color_Leg_v = 1;
	}
	val_ary[COL_LEG_PERA] = Color_Leg_v;

	if (Color_Leg_v == 0)
	{
		strcpy(Dsp_Str, "OFF    ");
	} // OFF
	if (Color_Leg_v == 1)
	{
		strcpy(Dsp_Str, "ON     ");
	} // ON

	pos = (COL_LEG_PERA * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str); // pos=pos % 10;

	if (Color_Leg_v == 1)
	{
		ColorLeg_refresh(); // Recalculate and Refresh Color Leg On Screen
	}
	else
	{
		COLOR_f(0);
	}
}

//**********************************************************************************************
void Cal_ColorLeg() // Calculate value for Color LEG
{
	double pi;
	double Angr, Awidth, RngD, datad;
	int i, x, DlyD;

	pi = 3.141592653; //*** Calculate angle in Radian
	Angr = Angle_v;
	Angr = Angr / 10;
	Angr = (pi * Angr) / 180;
	Angr = cos(Angr); // sin(Angr);
					  // lstrt=ASCAN_LEFT+5;
	Awidth = Asc_Width;
	RngD = val_ary[RANGE_PERA];
	datad = val_ary[THICK_PERA];
	datad = datad * Awidth;
	Angr = Angr * RngD;
	Angr = datad / Angr;
	Clr_leg_width = Angr;
	Clr_leg_sta = Clr_leg_width; // Consider Dekay and subtract from this
}

/***********************************************************************************/
/***********************************************************************************/
void ColorLeg_refresh() // Recalculate and Refresh Color Leg On Screen
{
	int dst, Ast, Awidth, Asc_Widthl;
	if (Color_Leg_v == 1)
	{
		Cal_ColorLeg();
		Ast = (Clr_leg_sta * 250) / Asc_Width;
		Awidth = (Clr_leg_width * 250) / Asc_Width; // Calculate in terms of A-Scn Sample Length
		Color_update = true;
		dst = 0;
		Asc_Widthl = Asc_Width + 60;
		if (video_val == 1)
		{
			Ast = Ast * 3;
			Awidth = Awidth * 3;
			Asc_Widthl = Asc_Widthl * 3;
		}
		for (i = 0; i < Ast; i++)
		{
			if (dst > Asc_Widthl)
			{
				break;
			}
			ogl.vertices_color[dst++] = 1.0f;
			ogl.vertices_color[dst++] = 1.0f;
			ogl.vertices_color[dst++] = 0.0f;
		} // Color 1

		for (j = 0; j < 10; j++)
		{
			for (i = 0; i < Awidth; i++)
			{
				if (dst > Asc_Widthl)
				{
					break;
				}
				ogl.vertices_color[dst++] = 0.0f;
				ogl.vertices_color[dst++] = 0.70f;
				ogl.vertices_color[dst++] = 0.90f;
			} // Color 2

			for (i = 0; i < Awidth; i++)
			{
				if (dst > Asc_Widthl)
				{
					break;
				}
				ogl.vertices_color[dst++] = 1.0f;
				ogl.vertices_color[dst++] = 1.0f;
				ogl.vertices_color[dst++] = 0.0f;
			} // Color 1

			if (dst > Asc_Widthl)
			{
				break;
			}
		}
	}
}

/***********************************************************************************/
/***********************************VIDEO FUNCTION**********************************/
/***********************************************************************************/
void Video_f(int key_t)
{
	char video_range[3][15] = {"FILLED ", "DYNAMIC", "ENVELOP"};
	video_val = val_ary[VIDEO_PERA];

	//**********KEY_SCR = 0*********************

	if (key_scr == 0) // Get the value from scrollbar
	{
	}

	//**********KEY_SCR = 1*********************

	if (key_scr == 1) // Get the value from button keypad
	{
		video_val = video_val + key_t;
	}

	if (video_val < 0)
	{
		video_val = 0;
	}
	if (video_val > 2)
	{
		video_val = 2;
	}
	val_ary[VIDEO_PERA] = video_val;

	if (video_val == 1)
	{
		strcpy(Dsp_Str, "FILLED ");
	} // FILLED
	else if (video_val == 2)
	{
		strcpy(Dsp_Str, "DYNAMIC");
	} // DYNAMIC
	else
	{
		strcpy(Dsp_Str, "ENVELOP");
	} // ENVELOP

	pos = (VIDEO_PERA * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;

	if (video_val == 2 && key_t != 0) // If Key is press and Dynamic selected then clear Previous data
	{
		for (i = 0; i < 256; i++)
			Asc_Max[i] = 0;
	}
	Cal_vertices(); // Calculate Verteces for Filled/Envelop/Dynmaic etc
}

/***********************************************************************************/
/***********************************SETREF FUNCTION*********************************/
/***********************************************************************************/
void Setref_f(int key_t)
{
	setref_val = val_ary[SET_REF_PERA];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
	}

	//**********KEY_SCR = 1**********************
	if (key_scr == 1) // Get the value from button keypad
	{
		setref_val = setref_val + key_t;
	}

	if (setref_val < 0)
	{
		setref_val = 0;
	}
	if (setref_val > 1)
	{
		setref_val = 1;
	}
	val_ary[SET_REF_PERA] = setref_val;

	if (setref_val == 0)
	{
		strcpy(Dsp_Str, "OFF    ");
	} // OFF
	if (setref_val == 1)
	{
		strcpy(Dsp_Str, "ON     ");
		Ascan_peak_flag = true;
	} // ON

	pos = (SET_REF_PERA * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
}

/***********************************************************************************/
void SplitWindow(int Split_f)
{
	splite_win_flg = Split_f;
	Bsc_Dsp = false;

	if (splite_win_flg == 0)
	{
		if (temp_Asc_Height != 0)
			Asc_Height = temp_Asc_Height;

		splite_frame_height = frame_height;
		partial_uninitialize();
		recreate_surface(width_sh, height_sh, ogl_x_position, ogl_y_position);

		strcpy(all_btnval[RECORD_NO_PERA * 2], "MEM NO ");		 // strcpy(all_btnval[(RECORD_NO_PERA * 2) + 1]," RIGHT");
		strcpy(all_btnval[(RECORD_NO_PERA * 2) + 2], "ACTION "); // strcpy(all_btnval[(RECORD_NO_PERA*2)+3]," DOWN ");
		Record_No_f(0);
		Bs_Action_Select_f(0);

		gtk_widget_hide(splite_box_1);
		gtk_widget_hide(splite_box_2);
		temp_Asc_Height = 0;
	}
	else if (splite_win_flg == 1) // Draw Thickness based B-Scan // Color Coded Bscan // TOFD
	{
		gdk_pixbuf_fill(dest_pixbuf, 0x000000FF);
		gdk_pixbuf_fill(src_pixbuf, 0x000000FF);

		if (temp_Asc_Height == 0)
		{
			temp_Asc_Height = Asc_Height;
			Asc_Height = Asc_Height / 2;
			splite_frame_height = frame_height / 2;
		}
		// g_print("***%d %d %d\n", temp_Asc_Height, Asc_Height, height_sh / 2);
		partial_uninitialize();
		recreate_surface(width_sh, height_sh / 2, ogl_x_position, ogl_y_position);

		gtk_widget_show(splite_box_1);
		gtk_widget_hide(splite_box_2);
		Bsc_Dsp = true;
	}
	else if (splite_win_flg == 2)  // Thick Log
	{
		if (temp_Asc_Height == 0)
		{
			temp_Asc_Height = Asc_Height;
			Asc_Height = Asc_Height / 2;
			splite_frame_height = frame_height / 2;
		}

		partial_uninitialize();
		recreate_surface(width_sh, height_sh / 2, ogl_x_position, ogl_y_position);

		gtk_widget_show(splite_box_2);
		gtk_widget_hide(splite_box_1);
	}
}

/***********************************************************************************/
/*************************************COLOR FUNCTION********************************/
/***********************************************************************************/
void COLOR_Theme_f(int key_t)
{
	// pos = m_val * 10;
	Theme_color_val = val_ary[SCR_THEME_PERA];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
		Theme_color_val = val_ary[SCR_THEME_PERA];
	}

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
	{
		Theme_color_val = Theme_color_val + key_t;
	}

	if (Theme_color_val < 0)
	{
		Theme_color_val = 0;
	}
	if (Theme_color_val > 1)
	{
		Theme_color_val = 1;
	}
	val_ary[SCR_THEME_PERA] = Theme_color_val;

	Creat_bk_img(Measure_v1, 1); // Create Image for Measurement Display Button
	Creat_bk_img(Measure_v2, 2); // Create Image for Measurement Display Button

	if (Theme_color_val == 0)
	{
		strcpy(Dsp_Str, "THEME 1 ");
		Colour_Theme_Apply(0);
	} // BLUE.CSS
	if (Theme_color_val == 1)
	{
		strcpy(Dsp_Str, "THEME 2 ");
		Colour_Theme_Apply(1);
	} // GRAY.CSS
	if (Theme_color_val == 2)
	{
		strcpy(Dsp_Str, "THEME 3 "); // Not Used
		Colour_Theme_Apply(2);
	} // Orange.CSS

	pos = (SCR_THEME_PERA * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;

	Dac_f(0);			   // To chng the bckgrnd of the symbols this functions are called over here.
	Mode_f(0);			   // To chng the bckgrnd of the symbols this functions are called over here.
	Reject_f(0);		   // To chng the bckgrnd of the symbols this functions are called over here.
	Trig_f(0);			   // To chng the bckgrnd of the symbols this functions are called over here.
	Size_Eval_Select_f(0); // To chng the bckgrnd of the symbols this functions are called over here.
	Battery_Symbol(Batt_val, 0);
	CLOCK_f(0); // TO CHANGE THE TEXT COLOR OF CLOCK TIME AND DATE WHILE CHANGING THEMES
}

//****************************************************************************************************************
void COLOR_f(int key_t)
{
	Asc_Clr_val = val_ary[ACOLOR_PERA];
	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
		// Asc_Clr_val = val_ary[ACOLOR_PERA ];
	}
	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
	{
		Asc_Clr_val = Asc_Clr_val + key_t;
	}

	if (key_scr == 2) // Get the value from touch keypad
	{
		Asc_Clr_val = val_ary[ACOLOR_PERA] - 1;
	}

	if (Asc_Clr_val < 0)
	{
		Asc_Clr_val = 0;
	}
	if (Asc_Clr_val > 9)
	{
		Asc_Clr_val = 9;
	}
	val_ary[ACOLOR_PERA] = Asc_Clr_val;

	Color_update = true;
	for (i = 0; i < 1536; i++)
	{
		ogl.vertices_color[(i * 3) + 0] = Red[Asc_Clr_val];
		ogl.vertices_color[(i * 3) + 1] = Green[Asc_Clr_val];
		ogl.vertices_color[(i * 3) + 2] = Blue[Asc_Clr_val];
	}

	sprintf(Dsp_Str, "  %d", Asc_Clr_val + 1); // COLOR.CSS

	pos = (ACOLOR_PERA * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;

	gl_clear_color_background_data(width_sh, height_sh); // Update Color in Background
}

/***********************************************************************************/
/*************************************BRIGHTNESS FUNCTION********************************/
/***********************************************************************************/
void Brightness_f(int key_t)
{
	Brightness_v = val_ary[BRIGHT_PERA];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
	}
	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
	{
		Brightness_v = Brightness_v + key_t;
	}

	if (Brightness_v < 1)
	{
		Brightness_v = 1;
	}
	if (Brightness_v > 10)
	{
		Brightness_v = 10;
	}
	val_ary[BRIGHT_PERA] = Brightness_v;

	sprintf(Dsp_Str, "%d %%   ", (Brightness_v * 10));
	pos = (BRIGHT_PERA * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
	Brightness_value();
}

int Brightness_value() // Write Brightness value to file
{
	int fbrght;
	int value;
	char buffer[5];
	char buf[50];

	// Have in built values from 1 to 7. When Selecting 7 for brightness the screen completely turns dark hence 7 value is avoided below
	// cd /sys/class/backlight/backlight/brightness
	fbrght = open("/sys/class/backlight/backlight/brightness", O_WRONLY); // echo 1 > /sys/class/backlight/backlight/brightness

	if (Brightness_v == 1)
	{
		sprintf(buf, "%d", 6);
		write(fbrght, buf, strlen(buf));
	}
	else if (Brightness_v == 2)
	{
		sprintf(buf, "%d", 5);
		write(fbrght, buf, strlen(buf));
	}
	else if (Brightness_v == 3)
	{
		sprintf(buf, "%d", 5);
		write(fbrght, buf, strlen(buf));
	}
	else if (Brightness_v == 4)
	{
		sprintf(buf, "%d", 4);
		write(fbrght, buf, strlen(buf));
	}
	else if (Brightness_v == 5)
	{
		sprintf(buf, "%d", 4);
		write(fbrght, buf, strlen(buf));
	}
	else if (Brightness_v == 6)
	{
		sprintf(buf, "%d", 3);
		write(fbrght, buf, strlen(buf));
	}
	else if (Brightness_v == 7)
	{
		sprintf(buf, "%d", 3);
		write(fbrght, buf, strlen(buf));
	}
	else if (Brightness_v == 8)
	{
		sprintf(buf, "%d", 2);
		write(fbrght, buf, strlen(buf));
	}
	else if (Brightness_v == 9)
	{
		sprintf(buf, "%d", 2);
		write(fbrght, buf, strlen(buf));
	}
	else if (Brightness_v == 10)
	{
		sprintf(buf, "%d", 1);
		write(fbrght, buf, strlen(buf));
	}
	else
	{
		sprintf(buf, "%d", 4);
		write(fbrght, buf, strlen(buf));
	}
}

/*******************************************************************************************************************************/
/***********************************************POWER KEY CHECK FUNCTION********************************************************/
void MessageBox(const gchar *title, const char *msg)
{
	GtkDialogFlags flags = GTK_DIALOG_DESTROY_WITH_PARENT;
	// GtkDialogFlags flags = GTK_DIALOG_DESTROY_WITH_PARENT | GTK_DIALOG_MODAL;

	GtkWidget *dialog = gtk_message_dialog_new(NULL,  flags, GTK_MESSAGE_INFO, GTK_BUTTONS_CLOSE, "%s", title);

	gtk_message_dialog_format_secondary_text(GTK_MESSAGE_DIALOG (dialog), "%s", msg);

    gtk_dialog_run(GTK_DIALOG(dialog));

	gtk_widget_destroy (dialog);
}

void TurnOff_f()  // Intialise checking of Power Key
{
	char msg[64];

	char buffer[40];
	const char *chipname = "gpiochip2";
	int ret, ret1;
	const unsigned int line_num_PWR = 20; // POWER PIN NO 250 IN Schemetic

	if (Spi_open == false) // In Weston for checking when SPI is disable then below function to be also avoided else app will crash
		return;

	int er1 = 0, er2 = 0, er3 = 0;

	// Open GPIO chip
	chip = gpiod_chip_open_by_name(chipname);
	if (!chip)
	{
		g_print("Open chip failed\n");
		er1 = 1;
	}

	// Open GPIO lines
	PWR_KEY = gpiod_chip_get_line(chip, line_num_PWR);
	if (!PWR_KEY)
	{
		g_print("Get line failed\n");
		er2 = 1;
	}

	// Open lines for Input
	ret1 = gpiod_line_request_output(PWR_KEY, "PWR_KEY_TEST", 0);
	if (ret1 < 0)
	{
		g_print("Set line request failed\n");
		er3 = 1;
	}

	// Write Power key status
	gpiod_line_set_value(PWR_KEY, 1);
	
	gpiod_line_release(PWR_KEY);
	gpiod_chip_close(chip);
}

void PowerKey_ck()  // Intialise checking of Power Key
{
	char msg[64];

	char buffer[40];
	const char *chipname = "gpiochip0";
	int ret, ret1;
	const unsigned int line_num_PWR = 0; // POWER PIN NO 216 IN Schemetic

	if (Spi_open == false) // In Weston for checking when SPI is disable then below function to be also avoided else app will crash
		return;

	// Open GPIO chip
	chip = gpiod_chip_open_by_name(chipname); // gpio5.IO26 gpio-154 LCD_LR SODI pin 210 // chip1 = gpiod_chip_open_by_name(chipname1);  // gpio5.IO27 gpio-155 LCD_UD   SODI  pin 212 // chip1=                                 // gpio      SODI pin 216
	if (!chip)
	{
		g_print("Open chip failed\n");
	}

	// Open GPIO lines
	PWR_KEY = gpiod_chip_get_line(chip, line_num_PWR);
	if (!PWR_KEY)
	{
		g_print("Get line failed\n");
	}

	// Open lines for Input
	ret1 = gpiod_line_request_input(PWR_KEY, "PWR_KEY_TEST");
	if (ret1 < 0)
	{
		g_print("Set line request failed\n");
	}

	// Read Power key status
	ret = gpiod_line_get_value(PWR_KEY);
	if (ret == 0)
	{
		UmountUSB();
		pwroff_savesetup();
		// TurnOff_f();
	}
	else
	{
	}	

	gpiod_line_release(PWR_KEY);
	gpiod_chip_close(chip);
}

/***********************************************************************************/
/*********************************SCREEN ROTATE FUNCTION********************************/
/***********************************************************************************/
void Screen_rotate_f(int key_t)
{
	const char *chipname = "gpiochip4";

	const unsigned int line_num_LR = 26;
	const unsigned int line_num_UD = 27;

	struct gpiod_chip *chip;			//,*chip1;
	struct gpiod_line *LCD_LR, *LCD_UD; //  *lineRed,  // Red LED

	if (Spi_open == false) // In Weston for checking when SPI is disable then below function to be also avoided else app will crash
	{
		return;
	}

	// Open GPIO chip
	chip = gpiod_chip_open_by_name(chipname); //  gpio5.IO26 gpio-154 LCD_LR   SODI  pin 210 // chip1 = gpiod_chip_open_by_name(chipname1);  // gpio5.IO27 gpio-155 LCD_UD   SODI  pin 212
	if (!chip)
	{
		printf("Open chip failed\n");
	}

	// Open GPIO lines
	LCD_LR = gpiod_chip_get_line(chip, line_num_LR);
	LCD_UD = gpiod_chip_get_line(chip, line_num_UD);
	if (!LCD_LR)
	{
		printf("Get line failed\n");
	}

	gpiod_line_request_output(LCD_LR, "example", 0);
	gpiod_line_request_output(LCD_UD, "example", 0);

	Scr_Rot_V = val_ary[SCREEN_PERA];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) {	}

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) //  for key press
		Scr_Rot_V = Scr_Rot_V + key_t;

	if (Scr_Rot_V < 0)
		Scr_Rot_V = 0;
	if (Scr_Rot_V > 1)
		Scr_Rot_V = 1;
	val_ary[SCREEN_PERA] = Scr_Rot_V;

	if (Scr_Rot_V == 1)
	{
		strcpy(Dsp_Str, "LEFT   ");
		gpiod_line_set_value(LCD_LR, 1);
		gpiod_line_set_value(LCD_UD, 0);
	} // gpio_set_value(154, 0);  GPIO4 IO8 }   // gpio set 154; gpio clear 155 =GPIO1 io12  #include <include/include/gpiod.h>
	else
	{
		strcpy(Dsp_Str, "RIGHT  ");
		gpiod_line_set_value(LCD_LR, 0);
		gpiod_line_set_value(LCD_UD, 1);
	}

	gpiod_line_release(LCD_LR);
	gpiod_line_release(LCD_UD);
	gpiod_chip_close(chip);

	pos = (SCREEN_PERA * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
}

/************************************************************************************/
/**********************************X OFFSET****************************************/
/**********************************************************************************/

void X_OFFSET_f(int key_t) //
{
	char *unitm[] = {" mm"}, *uniti[] = {" in"};
	float tempxoff_val = 0.0;
	gchar dec_num[8];
	int astp = 1, temp;
	int ndgt = 0;

	if (Unit_v == INCH) // If unit is INCH
	{
		gtk_adjustment_set_lower(adj, 0);	 // If unit is inch
		gtk_adjustment_set_upper(adj, 2100); // gtk_adjustment_set_upper(adj, 100000);
	}
	else // If Unit is MM
	{
		gtk_adjustment_set_lower(adj, 0);
		gtk_adjustment_set_upper(adj, 1920); // gtk_adjustment_set_upper(adj, 100000);
	}

	X_offset_v = val_ary[XOFF_PERA];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
		if (Unit_v == MM) // If Unit is MM Delay_rv=scr_val;
		{
			X_offset_v = scr_val;
			temp = scr_val;
			if (scr_val < 1000)
			{
				X_offset_v = scr_val;
			}
			else if (scr_val < 1900)
			{
				temp = (scr_val - 1000);
				X_offset_v = 1000 + (10 * temp);
			}
			else if (scr_val < 100899)
			{
				temp = (scr_val - 1900);
				X_offset_v = 10000 + (100 * temp);
			}
		}
		if (Unit_v == INCH) // If Unit is MM X_offset_v=scr_val;
		{
			X_offset_v = scr_val;
			temp = scr_val;
			if (scr_val < 1000)
			{
				X_offset_v = scr_val;
			}
			else if (scr_val < 1900)
			{
				temp = (scr_val - 1000);
				X_offset_v = 1000 + (10 * temp);
			}
			else if (scr_val < 100899)
			{
				temp = (scr_val - 1900);
				X_offset_v = 10000 + (100 * temp);
			}
		}
	}

	//**********KEY_SCR = 1*********************

	if (key_scr == 1) // Get the value from button keypad
	{
		if (Unit_v == MM) // If Unit is MM
		{
			if (key_t == 1)
			{
				if (X_offset_v >= 1000)
				{
					astp = 10;
				}
				if (X_offset_v >= 10000 && X_offset_v < 100000)
				{
					astp = 100;
				}
				if (X_offset_v >= 100000)
				{
					astp = 1000;
				}
			}
			else
			{
				if (X_offset_v > 1000)
				{
					astp = 10;
				}
				if (X_offset_v > 10000 && X_offset_v <= 100000)
				{
					astp = 100;
				}
				if (X_offset_v > 100000)
				{
					astp = 1000;
				}
			}
			X_offset_v = X_offset_v + (key_t * astp * Key_stp); //  -10.00 mm to      2000mm
		} //  if (Unit_v == MM)  over

		if (Unit_v == INCH) // If Unit is MM
		{
			if (key_t == 1)
			{
				if (X_offset_v >= 1000)
				{
					astp = 10;
				}
				if (X_offset_v >= 10000 && X_offset_v < 100000)
				{
					astp = 100;
				}
				if (X_offset_v >= 100000)
				{
					astp = 1000;
				}
			}
			else
			{
				if (X_offset_v > 1000)
				{
					astp = 10;
				}
				if (X_offset_v > 10000 && X_offset_v <= 100000)
				{
					astp = 100;
				}
				if (X_offset_v > 100000)
				{
					astp = 1000;
				}
			}
			X_offset_v = X_offset_v + (key_t * astp * Key_stp);
		}
	} // Key Press over

	//**********KEY_SCR = 2*********************
	if (key_scr == 2) // Get the value from touch keypad
	{
		tempxoff_val = key_array[XOFF_PERA];

		if (Unit_v == MM)
		{
			X_offset_v = tempxoff_val * 100;
		}
		if (Unit_v == INCH)
		{
			X_offset_v = tempxoff_val * 1000;
		}
	}

	pos = (XOFF_PERA * 2) + 1;
	ndgt = 0;
	if (Unit_v == INCH)
	{
		if (X_offset_v < 0)
		{
			X_offset_v = 0;
		}
		if (X_offset_v > 2000)
		{
			X_offset_v = 2000;
		}
		if (X_offset_v >= 1000 && X_offset_v < 10000)
		{
			ndgt = X_offset_v % 10;
			X_offset_v = X_offset_v - ndgt;
			ndgt = 1;
		} // When Value is higher then Fraction of value to be round of
		if (X_offset_v >= 10000)
		{
			ndgt = X_offset_v % 100;
			X_offset_v = X_offset_v - ndgt;
			ndgt = 2;
		}
		toarry(X_offset_v, pos, ndgt, 3, uniti[0]);
		val_ary[XOFF_PERA] = X_offset_v;
	}
	else
	{
		if (X_offset_v < 0)
		{
			X_offset_v = 0;
		}
		if (X_offset_v > 5000)
		{
			X_offset_v = 5000;
		}
		if (X_offset_v >= 1000 && X_offset_v < 10000)
		{
			ndgt = X_offset_v % 10;
			X_offset_v = X_offset_v - ndgt;
			ndgt = 1;
		} // When Value is higher then 10 mm then Fraction to be round of
		if (X_offset_v >= 10000)
		{
			ndgt = X_offset_v % 100;
			X_offset_v = X_offset_v - ndgt;
			ndgt = 2;
		}
		toarry(X_offset_v, pos, ndgt, 2, unitm[0]);
		val_ary[XOFF_PERA] = X_offset_v;
	}

	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
}
/***********************************************************************************/
/***********************************ANGLE OF PROBE**********************************/
/***********************************************************************************/

void ANGLE_f(int key_t)
{
	char *unit[] = {"DEG"};
	char buffer[30];
	float tmpangle_val = 0.0;
	Angle_v = val_ary[ANGLE_PERA];

	gtk_adjustment_set_lower(adj, 0);
	gtk_adjustment_set_upper(adj, 900);

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
	}

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
	{
		Angle_v = Angle_v + key_t;
	}

	//**********KEY_SCR = 2*********************
	if (key_scr == 2) // Get the value from touch keypad
	{
		if (tmpangle_val < 0)
		{
			tmpangle_val = 0;
		}
		if (tmpangle_val > 900)
		{
			tmpangle_val = 900;
		}
		tmpangle_val = key_array[ANGLE_PERA];
		Angle_v = tmpangle_val * 10;
	}

	if (Angle_v < 0)
	{
		Angle_v = 0;
	}
	if (Angle_v > 900)
	{
		Angle_v = 900;
	}
	val_ary[ANGLE_PERA] = Angle_v;

	pos = (ANGLE_PERA * 2) + 1;
	toarry(Angle_v, pos, 0, 1, unit[0]); // decimal point after 1 digit

	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
	ColorLeg_refresh(); // Recalculate and Refresh Color Leg On Screen
}

/***********************************************************************************/
/*******************************Thickness of Material*******************************/
/***********************************************************************************/

void THICK_f(int key_t)
{
	char *unitm[] = {" mm"}, *uniti[] = {" in"};
	char buffer[30];
	float tmpthck1_rv = 0.0;
	int astp = 1, temp;
	int ndgt = 0;

	Thick_v = val_ary[THICK_PERA];

	if (Unit_v == INCH) // If unit is INCH
	{
		gtk_adjustment_set_lower(adj, 0);	 // If unit is inch
		gtk_adjustment_set_upper(adj, 2100); //  gtk_adjustment_set_upper(adj, 2100);
	}
	else // If Unit is MM
	{
		gtk_adjustment_set_lower(adj, 0);
		gtk_adjustment_set_upper(adj, 1920); //  gtk_adjustment_set_upper(adj, 1920);
	}

	Thick_v = val_ary[THICK_PERA];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
		if (Unit_v == MM) // If Unit is MM Thick_v=scr_val;
		{
			Thick_v = scr_val;
			temp = scr_val;
			if (scr_val < 1000)
			{
				Thick_v = scr_val;
			}
			else if (scr_val < 1900)
			{
				temp = (scr_val - 1000);
				Thick_v = 1000 + (10 * temp);
			}
			else if (scr_val < 100899)
			{
				temp = (scr_val - 1900);
				Thick_v = 10000 + (100 * temp);
			}
		}
		if (Unit_v == INCH) // If Unit is MM Thick_v=scr_val;
		{
			Thick_v = scr_val;
			temp = scr_val;
			if (scr_val < 1000)
			{
				Thick_v = scr_val;
			}
			else if (scr_val < 1900)
			{
				temp = (scr_val - 1000);
				Thick_v = 1000 + (10 * temp);
			}
			else if (scr_val < 100899)
			{
				temp = (scr_val - 1900);
				Thick_v = 10000 + (100 * temp);
			}
		}
	}

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
	{
		if (Unit_v == MM) // If Unit is MM
		{
			if (key_t == 1)
			{
				if (Thick_v >= 1000)
				{
					astp = 10;
				}
				if (Thick_v >= 10000 && Thick_v < 100000)
				{
					astp = 100;
				}
				if (Thick_v >= 100000)
				{
					astp = 1000;
				}
			}
			else
			{
				if (Thick_v > 1000)
				{
					astp = 10;
				}
				if (Thick_v > 10000 && Thick_v <= 100000)
				{
					astp = 100;
				}
				if (Thick_v > 100000)
				{
					astp = 1000;
				}
			}
			Thick_v = Thick_v + (key_t * astp * Key_stp);
		} //  if (Unit_v == MM)  over

		if (Unit_v == INCH) // If Unit is MM
		{
			if (key_t == 1)
			{
				if (Thick_v >= 1000)
				{
					astp = 10;
				}
				if (Thick_v >= 10000 && Thick_v < 100000)
				{
					astp = 100;
				}
				if (Thick_v >= 100000)
				{
					astp = 1000;
				}
			}
			else
			{
				if (Thick_v > 1000)
				{
					astp = 10;
				}
				if (Thick_v > 10000 && Thick_v <= 100000)
				{
					astp = 100;
				}
				if (Thick_v > 100000)
				{
					astp = 1000;
				}
			}
			Thick_v = Thick_v + (key_t * astp * Key_stp);
		}
	}

	//**********KEY_SCR = 2*********************
	if (key_scr == 2) // Get the value from touch keypad
	{
		if (Unit_v == MM) // If Unit is MM
		{
			tmpthck1_rv = key_array[THICK_PERA];
			if (Thick_v >= 1000)
			{
				astp = 10;
			}
			if (Thick_v >= 10000 && Thick_v < 100000)
			{
				astp = 100;
			}
			if (Thick_v >= 100000)
			{
				astp = 1000;
			}

			if (tmpthck1_rv < 1000)
			{
				Thick_v = tmpthck1_rv * astp * 100;
			}
			else
			{
				Thick_v = tmpthck1_rv * astp * 10;
			}
			val_ary[THICK_PERA] = Thick_v;
		} //  if (Unit_v == MM)  over

		if (Unit_v == INCH) // If Unit is MM
		{
			tmpthck1_rv = key_array[THICK_PERA];

			if (Thick_v >= 1000)
			{
				astp = 10;
			}
			if (Thick_v >= 10000 && Thick_v < 100000)
			{
				astp = 100;
			}
			if (Thick_v >= 100000)
			{
				astp = 1000;
			}

			// if (tmpthck1_rv < 1000)
			{
				Thick_v = tmpthck1_rv * astp * 1000;
			}
			val_ary[THICK_PERA] = Thick_v;
		}
	}

	pos = (THICK_PERA * 2) + 1;
	ndgt = 0;
	if (Unit_v == INCH)
	{
		if (Thick_v < 0)
			Thick_v = 0;
		else if (Thick_v > 400000)
			Thick_v = 400000;  // Check Max limit

		if (Thick_v >= 1000 && Thick_v < 400000)
		{
			ndgt = Thick_v % 10;
			Thick_v = Thick_v - ndgt;
			ndgt = 1;
		} // When Value is higher then Fraction of value to be round of
		else if (Thick_v >= 400000)
		{
			ndgt = Thick_v % 100;
			Thick_v = Thick_v - ndgt;
			ndgt = 2;
		}

		toarry(Thick_v, pos, ndgt, 3, uniti[0]);
		val_ary[THICK_PERA] = Thick_v;
	}
	else
	{
		if (Thick_v < 0)
			Thick_v = 0;
		else if (Thick_v > 1000000)
			Thick_v = 1000000; // Check Max limit

		if (Thick_v >= 1000 && Thick_v < 1000000)
		{
			ndgt = Thick_v % 10;
			Thick_v = Thick_v - ndgt;
			ndgt = 1;
		} // When Value is higher then 10 mm then Fraction to be round of
		else if (Thick_v >= 1000000)
		{
			ndgt = Thick_v % 100;
			Thick_v = Thick_v - ndgt;
			ndgt = 2;
		}

		toarry(Thick_v, pos, ndgt, 2, unitm[0]);
		val_ary[THICK_PERA] = Thick_v;
	}

	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
	ColorLeg_refresh(); // Recalculate and Refresh Color Leg On Screen // Menu_Refresh();
}

/************************************************************************************/
/******************************Trigger Point Selection*******************************/
/************************************************************************************/
void Trig_f(int key_t)
{
	gchar wData;

	trig_val = val_ary[TRIG_PERA];
	//**********KEY_SCR = 0*********************
	if (key_scr == 0) { } // Get the value from scrollbar

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
		trig_val = trig_val + key_t;

	if (trig_val < 0)
		trig_val = 0;
	else if (trig_val > 1)
		trig_val = 1;

	val_ary[TRIG_PERA] = trig_val;

	if (trig_val == 0)
		strcpy(Dsp_Str, "FLANK  "); 	// FLANK
	else if (trig_val == 1)
		strcpy(Dsp_Str, "PEAK   ");		// PEAK
	else if (trig_val == 2)
		strcpy(Dsp_Str, "ZERO CRS ");	// PEAK
	else if (trig_val == 3)
		strcpy(Dsp_Str, "J CROSS ");	// PEAK

	pos = (TRIG_PERA * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;

	Draw_notificimg(TRIG_S, trig_val); // Symbol type,Postion
}

/***********************************************************************************/
/************************************HORN FUNCTION**********************************/
/***********************************************************************************/

void HORN_f(int key_t)
{
	void D_op_s_test(int make_b);
	horn_val = val_ary[HORN_PERA];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) { }// Get the value from scrollbar

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
	{
		horn_val = horn_val + key_t;
	}

	if (horn_val < 0)
	{
		horn_val = 0;
	}
	if (horn_val > 1)
	{
		horn_val = 1;
	}
	val_ary[HORN_PERA] = horn_val;

	if (horn_val == 0)
	{
		strcpy(Dsp_Str, "OFF    ");
	} // OFF
	if (horn_val == 1)
	{
		strcpy(Dsp_Str, "ON     ");
	} // ON

	pos = (HORN_PERA * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;

	D_op_s_test(horn_val);
}

void D_op_s_test(int make_b)
{
	// int make_b = 0;
	int ds = 0; // Fill data for Gain Step Selection  // 1B 412B 1B  1B 4200 1B  1B 43XX 1B    // Default data 7x
	tx_cmd[ds++] = 0x1B;
	tx_cmd[ds++] = 0x41;
	tx_cmd[ds++] = 0x2F;
	tx_cmd[ds++] = 0x1B;

	tx_cmd[ds++] = 0x1B;
	tx_cmd[ds++] = 0x42;
	tx_cmd[ds++] = 0x00;
	tx_cmd[ds++] = 0x1B;

	tx_cmd[ds++] = 0x1B;
	tx_cmd[ds++] = 0x43;
	tx_cmd[ds++] = 0xA0;
	tx_cmd[ds++] = 0x1B;

	if (make_b == 1) // Upper nibble used for gain step GSTP4, GSTP3, GSTP2, GSTP1, xxxx
	{
		tx_cmd[10] = 0xFF;
	}
	if (make_b == 0)
	{
		tx_cmd[10] = 0x00;
	}

	Send_SPI(ds); // Send data
}

/*****************************************************************************************/
/*******************************DATE & TIME CLOCK FUNCTION********************************/
/*****************************************************************************************/
void set_system_time(void)
{
	gchar tbuffer[64];

	// Below 4 commands are used to set hardware clock time
	sprintf(tbuffer, "timedatectl set-ntp false");
	system(tbuffer);
	sprintf(tbuffer, "timedatectl set-time \"%d-%02d-%02d %02d:%02d:%02d\"", new_year, new_month, new_day, new_hour, new_minute, new_second);
	system(tbuffer);
	// Set s/w clock time from h/w clock
	system("hwclock -s");

	// timedatectl set-ntp false
	// timedatectl set-time "2015-01-31 11:13:54"
	// hwclock -s
	// ref link : https://developer.toradex.com/software/linux-resources/linux-features/real-time-clock-rtc-linux/
}

void CLOCK_f(int key_t)
{
	/*PANGO FONT TO DISPLAY CLOCK TIME*/
	PangoAttrList *attrlist;
	PangoAttribute *attr;
	PangoFontDescription *df;

	attrlist = pango_attr_list_new();

	// First, let's set up the base attributes.
	df = pango_font_description_new();
	pango_font_description_set_family(df, "Arial Rounded MT"); // FONT TYPE
	pango_font_description_set_size(df, 11 * PANGO_SCALE);	   // FONT SIZE
	pango_font_description_set_weight(df, PANGO_WEIGHT_BOLD);  // FONT WEIGHT
	// You can also use pango_font_description_new_from_string() and pass in a string like "Arial Rounded MT Bold (whatever fontsize is)".
	// But here's where things change:
	attr = pango_attr_font_desc_new(df);
	// This is not documented, but pango_attr_font_desc_new() makes a copy of df, so let's release ours:
	pango_font_description_free(df);
	pango_attr_list_insert(attrlist, attr);

	clock_val = val_ary[CLOCK_PERA];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) { } // Get the value from scrollbar

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
		clock_val = clock_val + key_t;

	if (clock_val < 0)
		clock_val = 4;
	else if (clock_val > 4)
		clock_val = 0;

	val_ary[CLOCK_PERA] = clock_val;

	if (clock_val == 0) // OFF
	{
		strcpy(Dsp_Str, "OFF    ");
		gtk_widget_hide(nframe[7]);

	} 
	else if (clock_val == 1) // ON
	{
		{   
			// HORN
			strcpy(Dsp_Str, "HORN");
			pos = (HORN_PERA * 2) + 0;
			strcpy(all_btnval[pos], Dsp_Str);
			pos = pos % 10;

			if (val_ary[HORN_PERA] == 0)
				strcpy(Dsp_Str, "OFF");
			else
				strcpy(Dsp_Str, "ON");

			pos = (HORN_PERA * 2) + 1;
			strcpy(all_btnval[pos], Dsp_Str);
			pos = pos % 10;
		}

		{
			// BEEP
			strcpy(Dsp_Str, "BEEP");
			pos = (BEEP_PERA * 2) + 0;
			strcpy(all_btnval[pos], Dsp_Str);
			pos = pos % 10;

			if (val_ary[BEEP_PERA] == 0)
				strcpy(Dsp_Str, "OFF");
			else
				strcpy(Dsp_Str, "ON");

			pos = (BEEP_PERA * 2) + 1;
			strcpy(all_btnval[pos], Dsp_Str);
			pos = pos % 10;
		}

		{
			// UNIT
			strcpy(Dsp_Str, "UNIT");
			pos = (UNIT_PERA * 2) + 0;
			strcpy(all_btnval[pos], Dsp_Str);
			pos = pos % 10;

			if (val_ary[UNIT_PERA] == 0)
				strcpy(Dsp_Str, "MM");
			else
				strcpy(Dsp_Str, "INCH");

			pos = (UNIT_PERA * 2) + 1;
			strcpy(all_btnval[pos], Dsp_Str);
			pos = pos % 10;
		}

		strcpy(Dsp_Str, "ON     ");
		gtk_widget_show(nframe[7]);
	} 
	else if (clock_val == 2) // Change Date
	{
		{   
			// HORN
			strcpy(Dsp_Str, "DATE");
			pos = (HORN_PERA * 2) + 0;
			strcpy(all_btnval[pos], Dsp_Str);
			pos = pos % 10;

			sprintf(Dsp_Str, "%d", new_day);
			pos = (HORN_PERA * 2) + 1;
			strcpy(all_btnval[pos], Dsp_Str);
			pos = pos % 10;
		}

		{
			// BEEP
			strcpy(Dsp_Str, "MONTH");
			pos = (BEEP_PERA * 2) + 0;
			strcpy(all_btnval[pos], Dsp_Str);
			pos = pos % 10;

			sprintf(Dsp_Str, "%d", new_month);
			pos = (BEEP_PERA * 2) + 1;
			strcpy(all_btnval[pos], Dsp_Str);
			pos = pos % 10;
		}

		{
			// UNIT
			strcpy(Dsp_Str, "YEAR");
			pos = (UNIT_PERA * 2) + 0;
			strcpy(all_btnval[pos], Dsp_Str);
			pos = pos % 10;

			sprintf(Dsp_Str, "%d", new_year);
			pos = (UNIT_PERA * 2) + 1;
			strcpy(all_btnval[pos], Dsp_Str);
			pos = pos % 10;
		}

		strcpy(Dsp_Str, "CNG DATE");
	}
	else if (clock_val == 3) // Change Time
	{
		{   
			// HORN
			strcpy(Dsp_Str, "HOUR");
			pos = (HORN_PERA * 2) + 0;
			strcpy(all_btnval[pos], Dsp_Str);
			pos = pos % 10;

			sprintf(Dsp_Str, "%d", new_hour);
			pos = (HORN_PERA * 2) + 1;
			strcpy(all_btnval[pos], Dsp_Str);
			pos = pos % 10;
		}

		{
			// BEEP
			strcpy(Dsp_Str, "MINUTE");
			pos = (BEEP_PERA * 2) + 0;
			strcpy(all_btnval[pos], Dsp_Str);
			pos = pos % 10;

			sprintf(Dsp_Str, "%d", new_minute);
			pos = (BEEP_PERA * 2) + 1;
			strcpy(all_btnval[pos], Dsp_Str);
			pos = pos % 10;
		}

		{
			// UNIT
			strcpy(Dsp_Str, "UNIT");
			pos = (UNIT_PERA * 2) + 0;
			strcpy(all_btnval[pos], Dsp_Str);
			pos = pos % 10;

			if (val_ary[UNIT_PERA] == 0)
				strcpy(Dsp_Str, "MM");
			else
				strcpy(Dsp_Str, "INCH");

			pos = (UNIT_PERA * 2) + 1;
			strcpy(all_btnval[pos], Dsp_Str);
			pos = pos % 10;
		}

		strcpy(Dsp_Str, "CNG TIME");
	}
	else  if (clock_val == 4) // ON
	{
		strcpy(Dsp_Str, "SET DT");
		set_system_time();
	}

	sprintf(Tmstr, "Time:%02d:%02d\nDt:%02d/%02d/%d", (char)tm.tm_hour, (char)tm.tm_min, (char)tm.tm_mday, (char)tm.tm_mon + 1, (char)tm.tm_year + 1900);
	gtk_label_set_label(GTK_LABEL(Clock_lab), Tmstr);

	// And finally, give the GtkLabel our attribute list.
	gtk_label_set_attributes(GTK_LABEL(Clock_lab), attrlist);
	if (Theme_color_val == 0)
	{
		gtk_widget_set_name(Clock_lab, "clockg-color");
	}
	else if (Theme_color_val == 1)
	{
		gtk_widget_set_name(Clock_lab, "clockb-color");
	}
	
	pos = (CLOCK_PERA * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
}

void New_Date_f(int key_t)
{
	if (key_scr == 1) // Get the value from button keypad
		new_day = new_day + key_t;

	if (new_day < 1)
		new_day = 31;
	else if (new_day > 31)
		new_day = 1;

	strcpy(Dsp_Str, "DATE");
	pos = (HORN_PERA * 2) + 0;
	strcpy(all_btnval[pos], Dsp_Str);

	sprintf(Dsp_Str, "%d", new_day);
	pos = (HORN_PERA * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
}

void New_Month_f(int key_t)
{
	if (key_scr == 1) // Get the value from button keypad
		new_month = new_month + key_t;

	if (new_month < 1)
		new_month = 12;
	else if (new_month > 12)
		new_month = 1;

	strcpy(Dsp_Str, "MONTH");
	pos = (BEEP_PERA * 2) + 0;
	strcpy(all_btnval[pos], Dsp_Str);

	sprintf(Dsp_Str, "%d", new_month);
	pos = (BEEP_PERA * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
}

void New_Year_f(int key_t)
{
	if (key_scr == 1) // Get the value from button keypad
		new_year = new_year + key_t;

	if (new_year < 1900)
		new_year = 1900;
	else if (new_year > 4000)
		new_year = 4000;

	strcpy(Dsp_Str, "YEAR");
	pos = (UNIT_PERA * 2) + 0;
	strcpy(all_btnval[pos], Dsp_Str);

	sprintf(Dsp_Str, "%d", new_year);
	pos = (UNIT_PERA * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);	
	pos = pos % 10;
}

void New_Houre_f(int key_t)
{
	if (key_scr == 1) // Get the value from button keypad
		new_hour = new_hour + key_t;

	if (new_hour < 0)
		new_hour = 0;
	else if (new_hour > 23)
		new_hour = 0;

	strcpy(Dsp_Str, "HOUR");
	pos = (HORN_PERA * 2) + 0;
	strcpy(all_btnval[pos], Dsp_Str);

	sprintf(Dsp_Str, "%d", new_hour);
	pos = (HORN_PERA * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
}

void New_Minute_f(int key_t)
{
	if (key_scr == 1) // Get the value from button keypad
		new_minute = new_minute + key_t;

	if (new_minute < 0)
		new_minute = 0;
	else if (new_minute > 59)
		new_minute = 0;

	strcpy(Dsp_Str, "MINUTE");
	pos = (HORN_PERA * 2) + 0;
	strcpy(all_btnval[pos], Dsp_Str);

	sprintf(Dsp_Str, "%d", new_minute);
	pos = (BEEP_PERA * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
}

/***********************************************************************************/
/***********************************BEEP FUNCTION***********************************/
/***********************************************************************************/

void BEEP_f(int key_t)
{
	int ds = 0;
	beep_val = val_ary[BEEP_PERA];
	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
	}
	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
	{
		beep_val = beep_val + key_t;
	}

	if (beep_val < 0)
	{
		beep_val = 0;
	}
	if (beep_val > 1)
	{
		beep_val = 1;
	}

	val_ary[BEEP_PERA] = beep_val;

	if (beep_val == 0)
	{
		strcpy(Dsp_Str, "OFF    ");
	} // OFF
	if (beep_val == 1)
	{
		strcpy(Dsp_Str, "ON     ");
	} // ON

	ds = 0;

	pos = (BEEP_PERA * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;

	Key_Beep();
}

//*******************************************************************************
//*******************************************************************************
void Key_Beep() // Beep / Horn
{
	unsigned char wData;
	tx_bufidx = 0;
	wData = ENCRST_reg | 0x020; // Set Buzzer bit
	Write_data(r_addENCRST, wData);
	wData = ENCRST_reg & 0x0DF; // ClearBuzzer bit
	Write_data(r_addENCRST, wData);
	Send_SPI(tx_bufidx);
}

/***********************************************************************************/
/*************************************UNIT FUNCTION*********************************/
/***********************************************************************************/
void Unit_f(int key_t) // (MM or INCH)
{
	gtk_adjustment_set_lower(adj, 0); // If unit is inch
	gtk_adjustment_set_upper(adj, 1); // gtk_adjustment_set_upper(adj, 100000);

	Unit_v = val_ary[UNIT_PERA];

	//**********KEY_SCR = 0*********************

	if (key_scr == 0) { /* Unit_v = scr_val; */ }

	//**********KEY_SCR = 1*********************

	if (key_scr == 1) //  for key press
		Unit_v = Unit_v + key_t;

	if (Unit_v < 0)
		Unit_v = 1;
	else if (Unit_v > 1)
		Unit_v = 0;

	val_ary[UNIT_PERA] = Unit_v;

	pos = (UNIT_PERA * 2) + 1;
	if (Unit_v == 0)
	{
		strcpy(Dsp_Str, "MM     ");
		strcpy(all_btnval[pos], Dsp_Str);
		if (unit_key == 1) // Unit Key is required For proper conversion between mm to inch . To get the values of MM correctly from inch otherwise values are changed
		Cnv_to_mm();
		unit_key = 0;
	} 
	else if (Unit_v == 1)
	{
		strcpy(Dsp_Str, "INCH   ");
		strcpy(all_btnval[pos], Dsp_Str);
		Cnv_to_inch();
		unit_key = 1;
	} 

	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
}

void Cnv_to_inch()
{
	long int tempL;

	Range_v = (Range_v * 100) / 254;
	val_ary[RANGE_PERA] = Range_v;
	scr_val = Range_v;

	Mtlvel_val = (Mtlvel_val * 100) / 254;
	val_ary[VELO_PERA] = Mtlvel_val;

	Delay_rv = (Delay_rv * 100) / 254;
	val_ary[DELAY_PERA] = Delay_rv;

	Gstart1_v = (Gstart1_v * 100) / 254;
	val_ary[GSTA1_PERA] = Gstart1_v;

	Gend1_v = (Gend1_v * 100) / 254;
	val_ary[GEND1_PERA] = Gend1_v;

	Gstart2_v = (Gstart2_v * 100) / 254;
	val_ary[GSTA2_PERA] = Gstart2_v;

	Gend2_v = (Gend2_v * 100) / 254;
	val_ary[GEND2_PERA] = Gend2_v;

	Range_dac = (Range_dac * 100) / 254;

	tempL = Dgs_crvs_v;
	tempL = (tempL * 500) / 127; // Convert to Inch
	Dgs_crvs_v = tempL;

	tempL = Ref_size_v;
	tempL = (tempL * 500) / 127; // Convert to Inch
	Ref_size_v = tempL;

	tempL = D_efect_vC;
	tempL = (tempL * 500) / 127; // Convert to Inch
	D_efect_vC = tempL;

	tempL = Dly_vel_vC;
	tempL = (tempL * 50) / 127; // Convert to Inch
	Dly_vel_vC = tempL;

	tempL = Thick_v;
	tempL = (tempL * 50) / 127; // Convert to Inch
	Thick_v = tempL;

	tempL = X_offset_v;
	tempL = (tempL * 50) / 127; // Convert to Inch
	X_offset_v = tempL;

	Dist1_val = (Dist1_val * 100) / 254;
	val_ary[DST1_PERA] = Dist1_val;

	Dist2_val = (Dist2_val * 100) / 254;
	val_ary[DST2_PERA] = Dist2_val;

	Range_f(0);
	Velo_f(0);
	Delay_f(0);
	
	STARTa_f(0);
	ENDa_f(0);
	STARTb_f(0);
	ENDb_f(0);
	X_OFFSET_f(0);
	THICK_f(0);
	DST1_f(0);
	DST2_f(0);

	Scal_f(0);
}

void Cnv_to_mm()
{
	long int tempL;
	char buffer[40];
	Range_v = (Range_v * 254) / 100;
	val_ary[RANGE_PERA] = Range_v;

	Mtlvel_val = (Mtlvel_val * 254) / 100;
	val_ary[VELO_PERA] = Mtlvel_val;

	Delay_rv = (Delay_rv * 254) / 100;
	val_ary[DELAY_PERA] = Delay_rv;
	// Rang_d=(Rang_d*254)/100;
	Gstart1_v = (Gstart1_v * 254) / 100;
	val_ary[GSTA1_PERA] = Gstart1_v;

	Gend1_v = (Gend1_v * 254) / 100;
	val_ary[GEND1_PERA] = Gend1_v;

	Gstart2_v = (Gstart2_v * 254) / 100;
	val_ary[GSTA2_PERA] = Gstart2_v;

	Gend2_v = (Gend2_v * 254) / 100;
	val_ary[GEND2_PERA] = Gend2_v;

	Range_dac = (Range_dac * 254) / 100;

	tempL = Dgs_crvs_v;
	tempL = (tempL * 127) / 500; // Convert to mm
	Dgs_crvs_v = tempL;

	tempL = Ref_size_v;
	tempL = (tempL * 127) / 500; // Convert to mm
	Ref_size_v = tempL;

	tempL = D_efect_vC;
	tempL = (tempL * 127) / 500; // Convert to mm
	D_efect_vC = tempL;

	tempL = Dly_vel_vC;
	tempL = (tempL * 127) / 50; // Convert to mm
	Dly_vel_vC = tempL;

	tempL = Thick_v;
	tempL = (tempL * 127) / 50; // Convert to mm
	Thick_v = tempL;

	tempL = X_offset_v;
	tempL = (tempL * 127) / 50; // Convert to mm
	X_offset_v = tempL;

	Dist1_val = (Dist1_val * 254) / 100;
	val_ary[DST1_PERA] = Dist1_val;

	Dist2_val = (Dist2_val * 254) / 100;
	val_ary[DST2_PERA] = Dist2_val;

	Range_f(0);
	Velo_f(0);
	Delay_f(0);
	
	STARTa_f(0);
	ENDa_f(0);
	STARTb_f(0);
	ENDb_f(0);
	X_OFFSET_f(0);
	THICK_f(0);
	DST1_f(0);
	DST2_f(0);

	Scal_f(0);
}

//*********************************************************************************************************
void Set_default_val() // During Power Up set values of all perameters to default value
{
	val_ary[ZERO_PERA] = 781  + 200; //  delay=16.39  260; // Menu 1  Zero,Range,Vel,Delay
	val_ary[RANGE_PERA] = 10000;
	val_ary[VELO_PERA] = 5920;
	val_ary[DELAY_PERA] = 000;
	val_ary[GAIN_PERA] = 250;
	val_ary[GATE1_PERA] = 1; // Menu 2    GATE 1, START 1, END 1, LEVEL 1 CHANGE THE VALUE 100 FOR REF GAIN
	val_ary[GSTA1_PERA] = 250;
	val_ary[GEND1_PERA] = 950;
	val_ary[GTHE1_PERA] = 30;
	val_ary[REF_GAIN] = 259;
	val_ary[GATE2_PERA] = 0; // Menu 3      Gate 2, START 2, END 2, LEVEL 2   10
	val_ary[GSTA2_PERA] = 400;
	val_ary[GEND2_PERA] = 500;
	val_ary[GTHE2_PERA] = 40;
	val_ary[MEM_PERA] = 0; // Menu 4       MEM, MEM NO, MEM ACTION, MEM NOTE
	val_ary[MEM_NO_PERA] = 1;
	val_ary[MEM_ACT_PERA] = 0;
	val_ary[MEM_NOTE_PERA] = 0;
	val_ary[DAC_PERA] = 0; // Menu 4            DAC,START,PRESS,POINT
	val_ary[CURSOR_PERA] = 0;
	val_ary[PRESS_PERA] = 0;
	val_ary[POINT_PERA] = 3;
	val_ary[DAMP_PERA] = 0; // Menu 5         DAMP,MODE,PRF,TX_VOLT
	val_ary[MODE_PERA] = 0;
	val_ary[PRF_PERA] = 0;
	val_ary[TXVOLT_PERA] = 4;
	val_ary[REJECT_PERA] = 0; // Menu 6        REJECT,FRE,RECTIFY,smooth
	val_ary[FREQ_PERA] = 1;
	val_ary[RECTIFY_PERA] = 0;
	val_ary[SMOOTH_PERA] = 0;
	val_ary[GRID_PERA] = 0; // Menu7           GRID,COLOR LEG,VIDEO,SET REF
	val_ary[COL_LEG_PERA] = 0;
	val_ary[VIDEO_PERA] = 0;
	val_ary[SET_REF_PERA] = 0;
	val_ary[SCR_THEME_PERA] = 0; // Menu 8     SCR THEME, A COLOR, BRIGHT, SCREEN
	val_ary[ACOLOR_PERA] = 3;
	val_ary[BRIGHT_PERA] = 5;
	val_ary[SCREEN_PERA] = 0;
	val_ary[XOFF_PERA] = 0; // Menu 9          XOFF, ANGLE, THICK , TRIG,
	val_ary[ANGLE_PERA] = 450;
	val_ary[THICK_PERA] = 10000;
	val_ary[TRIG_PERA] = 0;
	val_ary[HORN_PERA] = 0; // Menu 10         HORN, BEEP, CLOCK, UNIT
	val_ary[BEEP_PERA] = 0;
	val_ary[CLOCK_PERA] = 1;
	val_ary[UNIT_PERA] = 0;
	val_ary[ACAL_PERA] = 0; // Menu 11         A CAL, START A, DISAT 1 DIST 2
	val_ary[STRT_GA_PERA] = 0;
	val_ary[DST1_PERA] = 2500;
	val_ary[DST2_PERA] = 10000;
	val_ary[SIZE_EV_PERA] = 0; // Menu 12      SIZE EV, MEAPOS 1, MEAPOS 2, MEAPOS 3
	val_ary[MEA_POSI1_PERA] = 0;
	val_ary[MEA_POSI2_PERA] = 0;
	val_ary[MEA_POSI3_PERA] = 0;
	val_ary[REC_TYPE_PERA] = 0; // Menu 13     REC TYPE, FILE NAME, ACTION, ENTER,
	val_ary[RECORD_NO_PERA] = 0;
	val_ary[RECORD_OP_PERA] = 0;
	val_ary[REC_ACTION_PERA] = 0;
	val_ary[ENCODER_PERA] = 0; // Menu 14      ENCODER, ENC CAL ENC START,
	val_ary[ENC_CAL_PERA] = 1;
	val_ary[ENC_STRT_PERA] = 0;
	val_ary[ENC_KMPST_PERA] = 0;
	val_ary[WELD_PROF_PERA] = 0; // Menu 15   W PROF, BEAM PROF, DIAMETER, PROB POS
	val_ary[BEAM_PROF_PERA] = 0;
	val_ary[THICK_CLR_PERA] = 1000;
	val_ary[CNG_OGL_PROF_POS] = 0;

	val_ary[MINUTE_v] = 0; // 16 Not Used
	val_ary[HOUR_v] = 0;   // 16 Not Used
	val_ary[DAY_v] = 0;	   // 16 Not Used
	val_ary[MONTH_v] = 0;  // 16 Not Used

	val_ary[SCALE_POS_PERA] = 0; // 17 Scal, Probe NAME, PRF frequency, Delay Val
	val_ary[PRBNM_POS_PERA] = 0;
	val_ary[PRFFRE_POS_PERA] = 0;
	val_ary[DELVEL_PERA] = 0;
	val_ary[D_EFECT_PERA] = 0; // 18  Defect, Dgscrv, ref echo, ref size
	val_ary[DGS_CRV_PERA] = 0;
	val_ary[REF_ECHO_PERA] = 0;
	val_ary[REF_SIZ_PERA] = 0;
	val_ary[DGS_EX_PERA] = 0; // 19  Exit, Att ref, Att obj, Amp cor
	val_ary[ATT_REF_PERA] = 0;
	val_ary[ATT_OBJ_PERA] = 0;
	val_ary[AMP_COR_PERA] = 0;
	val_ary[WELD_TYPE_PERA] = 0; // 20   WELD_TYPE_PERA, TOP_WIDTH_PERA, TOP_HEIGHT_PERA, ROOT_WIDTH_PERA
	val_ary[TOP_WIDTH_PERA] = 12;
	val_ary[TOP_HEIGHT_PERA] = 30;
	val_ary[ROOT_WIDTH_PERA] = 5;
	val_ary[OBJ_SHAPE_PERA] = 0; // 21     OBJ_SHAPE_PERA , PROB_POS_PERA , PROBE_ANGLE_PERA  , NOOF_LEGv_PERA
	val_ary[OBJ_WIDTH_PERA] = 200;
	val_ary[OBJ_THICK_PERA] = 100;
	val_ary[WPROF_POS_PERA] = 100;
	val_ary[EXT_WELD_PRF_PERA] = 5;
	val_ary[PROB_POS_PERA] = 60;
	val_ary[PROBE_ANGLE_PERA] = 45;
	val_ary[NOOF_LEGv_PERA] = 2;

	val_ary[EXT_31_PERA] = 200; // 22    WIDTH_PERA, OBJ_THICK_PERA
	val_ary[EXT_32_PERA] = 25;
	val_ary[EXT_33_PERA] = 0;
	val_ary[EXT_34_PERA] = 0;
	val_ary[EXT_41_PERA] = 0;
	val_ary[EXT_42_PERA] = 50;
	val_ary[EXT_43_PERA] = 15;
	val_ary[EXT_44_PERA] = 2; // 23
	val_ary[BEAM_PrbDia_PERA] = 50;
	val_ary[BEAM_PrbFreq_PERA] = 500;
	val_ary[BEAM_PRF_P13_PERA] = 100;
	val_ary[BEAM_PRF_P14_PERA] = 60; // 22
	val_ary[BEAM_PRF_P21_PERA] = 0;
	val_ary[BEAM_PRF_P22_PERA] = 15;
	val_ary[BEAM_PRF_P23_PERA] = 0;
	val_ary[BEAM_PRF_P24_PERA] = 0; // 23
	val_ary[BEAM_PRF_P31_PERA] = 0;
	val_ary[BEAM_PRF_P32_PERA] = 0;
	val_ary[BEAM_PRF_P33_PERA] = 0;
	val_ary[BEAM_PRF_P34_PERA] = 0; // 24
	val_ary[COLOR_METHOD_PERA] = 0;
	val_ary[START_THK_1_PERA] = 0;
	val_ary[START_THK_2_PERA] = 0;
	val_ary[START_THK_3_PERA] = 0; // 25
	val_ary[EXT_61_PERA] = 0;
	val_ary[END_THK_1_PERA] = 0;
	val_ary[END_THK_2_PERA] = 0;
	val_ary[END_THK_3_PERA] = 0; // 26
	val_ary[EXIT_71_PERA] = 0;
	val_ary[COLOR_1_PERA] = 0;
	val_ary[COLOR_2_PERA] = 0;
	val_ary[COLOR_3_PERA] = 0; // 27
	val_ary[THKFILE_TYPE_PERA] = 0;
	val_ary[START_ID_1_PERA] = 0;
	val_ary[START_ID_2_PERA] = 0;
	val_ary[START_ID_3_PERA] = 0; // 28
	val_ary[EXT_51_PERA] = 0;
	val_ary[END_ID_1_PERA] = 1;
	val_ary[END_ID_2_PERA] = 1;
	val_ary[END_ID_3_PERA] = 1; // 29
	val_ary[EXIT_PERA] = 0;
	val_ary[DIM_1_SIZE_PERA] = 1;
	val_ary[DIM_2_SIZE_PERA] = 1;
	val_ary[DIM_3_SIZE_PERA] = 1; // 30
	val_ary[175] = 0;
	val_ary[176] = 0;
	val_ary[177] = 0;
	val_ary[178] = 0; // 31

	// val_ary[125]=0; val_ary[126]=0; val_ary[127]=0;val_ary[128]=0;     // 23
	// val_ary[70]=0; val_ary[71]=0; val_ary[72]=1;val_ary[73]=1;          1,0,0,1000,0,  // 16
	// 150,0,0,0,0, // 17
	// 0,0,0,0,0,   // 18
	// 0,0,0,0,0,   //19
	// 0,0,0,0,0,  //20
	// 0,0,0,0,0,  //21
	// 0,0,0,0,0,  //22
	// 0,0,0,0,0,  //23
	// 0,0,0,0,0,  //24
	// 0,0,0,0,0,  //25
	// 0,0,0,0,0,  //26
	// 0,0,0,0,0,  //27
	// 0,0,0,0,0,  //28
	// 0,0,0,0,0,  //29
	// 0,0,0,0,0};  // 30
}

//*********************************************************************************************************
void Refresh_Allpera_val_f() // Refresh all peravalue by calling each function. It is used when Data recall from Memoery
{
	int key_v = 0;
	Zero_f(key_v); // MENU 0
	Range_f(key_v);
	Velo_f(key_v);
	Delay_f(key_v);
	Gain_f(key_v);
	dac_gen(&dac_pnt[0], &dac_cv[0], Gain_v, Range_v, Delay_rv); // If Dac ON then Draw DAC Curve  break; // MENU 0

	Gatea_f(key_v); // MENU 1
	STARTa_f(key_v);
	ENDa_f(key_v);
	LEVELa_f(key_v);

	GATEb_f(key_v); // MENU 2
	STARTb_f(key_v);
	ENDb_f(key_v);
	LEVELb_f(key_v);

	MEMORY_f(key_v); // MENU 3    // To be review
	MEMNO_f(key_v);	 // To be review
	ACTION_f(key_v); // To be review
	// Mem_Note_f(key_v);

	Dac_f(key_v);
	STARTa_f(key_v);
	Point_f(key_v);
	press_f(key_v);

	// AWS_f(0);
	// DGS_f(0);

	DAMP_f(key_v); // MENU 5
	Mode_f(key_v);
	Prf_f(key_v);
	// PRF_Set();
	Txvolt_f(key_v);

	Reject_f(key_v); // MENU 6
	Freq_f(key_v);
	Rectify_f(key_v);
	Smooth_f(key_v);

	Grid_f(key_v); // MENU 7
	Color_Leg_f(key_v);
	Video_f(key_v);
	Setref_f(key_v);

	COLOR_Theme_f(key_v); // MENU 8
	COLOR_f(key_v);
	Brightness_f(key_v);

	X_OFFSET_f(key_v); // MENU 9
	ANGLE_f(key_v);
	THICK_f(key_v);
	Trig_f(key_v);

	HORN_f(key_v); // MENU 10
	BEEP_f(key_v);
	CLOCK_f(key_v);
	Unit_f(key_v);

	Auto_Cal_f(key_v); // Menu 11
	// STARTa_f(key_v);
	DST1_f(key_v);
	DST2_f(key_v);

	Scal_f(key_v);
	Dgs_crv_f(key_v);
	Ref_echo_f(key_v);
	Ref_size_f(key_v);
	Att_ref_f(key_v);
	Att_obg_f(key_v);
	Amp_corr_f(key_v);

	Size_Eval_Select_f(key_v); // MENU 12

	Size_Eval_f(key_v);	 // MENU 4   // To be review
	Size_Eval_f1(key_v); // To be review
	Size_Eval_f2(key_v); // To be review
	Size_Eval_f3(key_v); // To be review

	Mea_fLn1_f(key_v);
	Mea_fLn2_f(key_v);
	// Mea_fLn3_f(key_v);

	Record_type_f(key_v); // MENU 13
	// Record_No_f(key_v);
	Bs_Action_Select_f(key_v);
	// Bs_Perf_Action(key_v);

	ENCODER_f(key_v); // MENU 14
	Enc_CAL_F_f(key_v);
	Enc_Start_posF_f(key_v);

	Weld_Prof_f(key_v);
	Beam_Prof_f(key_v);
	Change_ogl_probe_pos_f(key_v);
}

//*******************************************************************************************************
void Create_appFolder()
{
	sprintf(path_h, "/Ascan");
	if (access(path_h, F_OK) == 0)
	{
		sprintf(Dsp_Str, "%02d*", memno_val);
	}
	else
	{
		// Create Folder
	}
}

//*******************************************************************************************************
//*******************************************************************************************************
void Auto_Cal_f(int key_t)
{
	Autocal_val = val_ary[ACAL_PERA];
	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
	}

	pos = (ACAL_PERA * 2) + 1;

	switch (Autocal_val)
	{
	case 0: // If Key pressed with step key then register, if key pressed +1 then give warning mesage, if key pressed -1 then give warning mesage   else just refresh display
		if (key_t > 0 && Key_stp == 10)
		{
			Echo1_posi = G1_sp1;
			dsp_msg(13);
			strcpy(all_btnval[pos], "REG ECHO 2");
			Autocal_val = 1;
		} // Display_warn(" ECHO POSITION 1 REGISTERED "); }
		else if (key_t > 0)
		{
			dsp_msg(14);
			strcpy(all_btnval[pos], "REG ECHO 1");
		} // Display_warn(" TO REGISTER ECHO PRESS STEP AND PERA UP KEY "); }
		else if (key_t < 0)
		{
			dsp_msg(14);
			Autocal_val = 0;
			strcpy(all_btnval[pos], "REG ECHO 1");
		} // Display_warn(" TO REGISTER ECHO PRESS STEP AND PERA UP KEY "); }
		else
			strcpy(all_btnval[pos], "REG ECHO 1");
		break;

	case 1:
		if (key_t > 0 && Key_stp == 10)
		{
			Echo2_posi = G1_sp1;
			Auto_cal_range();
			Autocal_val = 2; // "CAL OK " or CAL FAILED generated in Auto_cal_range function
		}
		else if (key_t > 0)
		{
			dsp_msg(14);
			strcpy(all_btnval[pos], "REG ECHO 2");
		} // Display_warn(" TO REGISTER ECHO PRESS STEP AND PERA UP KEY "); }
		else if (key_t < 0)
		{
			dsp_msg(14);
			Autocal_val = 0;
			strcpy(all_btnval[pos], "REG ECHO 1");
		} // Display_warn(" TO REGISTER ECHO PRESS STEP AND PERA UP KEY "); }
		else
			strcpy(all_btnval[pos], "REG ECHO 2");
		break;

	case 2:
		if (key_t != 0)
		{
			strcpy(all_btnval[pos], "REG ECHO 1");
			Autocal_val = 0;
			Echo1_posi = 0;
			Echo2_posi = 0;
		}
		break;

	default:
		strcpy(all_btnval[pos], "REG ECHO 1");
		Autocal_val = 0;
		Echo1_posi = 0;
		Echo2_posi = 0;
		break;
	}
	val_ary[ACAL_PERA] = Autocal_val;
}

//*******************************************************************************************************
//*******************************************************************************************************
void Auto_Cal_f_old(int key_t)
{
	Autocal_val = val_ary[ACAL_PERA];
	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
	}

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
	{
		Autocal_val = Autocal_val + key_t;
	}

	if (Autocal_val < 0)
	{
		Autocal_val = 0;
	}
	if (Autocal_val > 2)
	{
		Autocal_val = 2;
	}

	val_ary[ACAL_PERA] = Autocal_val;
	pos = (ACAL_PERA * 2) + 1;

	switch (Autocal_val)
	{
	case 1: // If Key pressed and truns to DAC draw then Make Point to zero else not required // Make Gate 1 ON Automatic
		if (key_t > 0 && Key_stp == 10)
		{
			Echo1_posi = G1_sp1;
			dsp_msg(13);
		}
		else
		{
			dsp_msg(14);
		}
		strcpy(all_btnval[pos], "ECHO 2 ");
		break;
	case 2:
		if (key_t > 0 && Key_stp == 10)
		{
			Echo2_posi = G1_sp1;
			Auto_cal_range(); // "CAL OK " or CAL FAILED generated in Auto_cal_range function
		}
		else
		{
			if (Echo2_posi == 0)
			{
				dsp_msg(14);
			}
		}

		break;
	default:
		strcpy(all_btnval[pos], "ECHO 1 ");
		dsp_msg(14); // Display_warn(" TO REGISTER ECHO PRESS STEP AND PERA UP KEY ");
		break;
	}
}

//******************************************************************************
//******************************************************************************
void Auto_cal_range()
{
	long val_tmp, dst_dif;
	long vel_cur, Vel_new_cal;
	long tav, tmv;
	val_tmp = (Echo2_posi - Echo1_posi); // 10;
	dst_dif = Dist2_val - Dist1_val;

	pos = (ACAL_PERA * 2) + 1;

	if (Echo1_posi == 0)
	{
		dsp_msg(15);
		return;
	}
	if (Echo2_posi == 0)
	{
		dsp_msg(16);
		return;
	}

	if (Echo1_posi == 0 || Echo2_posi == 0 || Dist2_val == 0 || Dist1_val == 0 || dst_dif == 0 || val_tmp == 0)
	{
		dsp_msg(17);
	}

	vel_cur = Mtlvel_val;
	val_tmp = (dst_dif * vel_cur) / val_tmp;

	if ((val_tmp > 1000 && val_tmp < 9999 && Unit_v == MM) || (val_tmp > 400 && val_tmp < 6000 && Unit_v == INCH)) // If Velocity value out of range then give warning message and exit
	{
		Vel_new_cal = val_tmp;
	}
	else // If Velocity value out of range then give warning message and exit
	{
		dsp_msg(17);
		Echo1_posi = 0;
		Echo2_posi = 0;
		strcpy(all_btnval[pos], "CAL FAILED");
		return;
	} // Give Warning message and exit

	tav = (Dist1_val * 1000) / Vel_new_cal; // Required Delay
	tmv = (Echo1_posi * 1000) / vel_cur;	// Current Delay

	vel_cur = (int)(tmv - tav); // to be corrected
	vel_cur = vel_cur * 2;
	vel_cur = zero_val + vel_cur;

	if (vel_cur < 0 || vel_cur > 19999) // If Zero value is out of range then display warning message and exit
	{
		dsp_msg(17);
		Echo1_posi = 0;
		Echo2_posi = 0;
		strcpy(all_btnval[pos], "CAL FAILED");
		return;
	} // Out of range so Calibration is not possible
	else
	{
		zero_val = vel_cur;
		Mtlvel_val = Vel_new_cal;
	}
	vel_cur = vel_cur;
	val_ary[ZERO_PERA] = zero_val;
	val_ary[RANGE_PERA] = Range_v;
	val_ary[VELO_PERA] = Mtlvel_val;

	dsp_msg(18);
	Echo1_posi = 0;
	Echo2_posi = 0;
	strcpy(all_btnval[pos], "CAL OK "); // return;

	Zero_f(0);
	Range_f(0);
	Velo_f(0);
}

//****************************************************************************************
//****************************************************************************************
void DST1_f(int key_t)
{
	char *unitm[] = {" mm"}, *uniti[] = {" in"};
	float tmpDst1_rv = 0.0;
	int astp = 1, temp;
	int ndgt = 0;

	Dist1_val = val_ary[DST1_PERA];

	if (Unit_v == INCH) // If unit is INCH
	{
		gtk_adjustment_set_lower(adj, 0);
		gtk_adjustment_set_upper(adj, 2100);
	}
	else // If Unit is MM
	{
		gtk_adjustment_set_lower(adj, 0);
		gtk_adjustment_set_upper(adj, 1920);
	}

	Dist1_val = val_ary[DST1_PERA];
	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
		if (Unit_v == MM) // If Unit is MM Dist1_val=scr_val;
		{
			Dist1_val = scr_val;
			temp = scr_val;
			if (scr_val < 1000)
			{
				Dist1_val = scr_val;
			}
			else if (scr_val < 1900)
			{
				temp = (scr_val - 1000);
				Dist1_val = 1000 + (10 * temp);
			}
			else if (scr_val < 100899)
			{
				temp = (scr_val - 1900);
				Dist1_val = 10000 + (100 * temp);
			}
		}
		if (Unit_v == INCH) // If Unit is MM
		{
			Dist1_val = scr_val;
			temp = scr_val;
			if (scr_val < 1000)
			{
				Dist1_val = scr_val;
			}
			else if (scr_val < 1900)
			{
				temp = (scr_val - 1000);
				Dist1_val = 1000 + (10 * temp);
			}
			else if (scr_val < 100899)
			{
				temp = (scr_val - 1900);
				Dist1_val = 10000 + (100 * temp);
			}
		}
	}

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
	{
		if (Unit_v == MM) // If Unit is MM
		{
			if (key_t == 1)
			{
				if (Dist1_val >= 1000)
				{
					astp = 10;
				}
				if (Dist1_val >= 10000 && Dist1_val < 100000)
				{
					astp = 100;
				}
				if (Dist1_val >= 100000)
				{
					astp = 1000;
				}
			}
			else
			{
				if (Dist1_val > 1000)
				{
					astp = 10;
				}
				if (Dist1_val > 10000 && Dist1_val <= 100000)
				{
					astp = 100;
				}
				if (Dist1_val > 100000)
				{
					astp = 1000;
				}
			}
			Dist1_val = Dist1_val + (key_t * astp * Key_stp);

		} //  if (Unit_v == MM)

		if (Unit_v == INCH) // If Unit is MM
		{
			if (key_t == 1)
			{
				if (Dist1_val >= 1000)
				{
					astp = 10;
				}
				if (Dist1_val >= 10000 && Dist1_val < 100000)
				{
					astp = 100;
				}
				if (Dist1_val >= 100000)
				{
					astp = 1000;
				}
			}
			else
			{
				if (Dist1_val > 1000)
				{
					astp = 10;
				}
				if (Dist1_val > 10000 && Dist1_val <= 100000)
				{
					astp = 100;
				}
				if (Dist1_val > 100000)
				{
					astp = 1000;
				}
			}
			Dist1_val = Dist1_val + (key_t * astp * Key_stp);
		}
	}

	//**********KEY_SCR = 2*********************
	if (key_scr == 2) // Get the value from touch keypad
	{
		if (Unit_v == MM) // If Unit is MM
		{
			tmpDst1_rv = key_array[DST1_PERA];

			if (Dist1_val >= 1000)
			{
				astp = 10;
			}
			if (Dist1_val >= 10000 && Dist1_val < 100000)
			{
				astp = 100;
			}
			if (Dist1_val >= 100000)
			{
				astp = 1000;
			}

			if (tmpDst1_rv < 1000)
			{
				Dist1_val = tmpDst1_rv * astp * 100;
			}
			else
			{
				Dist1_val = tmpDst1_rv * astp * 10;
			}

			val_ary[DST1_PERA] = Dist1_val;

		} //  if (Unit_v == MM)  over

		if (Unit_v == INCH) // If Unit is MM
		{
			tmpDst1_rv = key_array[DST1_PERA];
			if (Dist1_val >= 1000)
			{
				astp = 10;
			}
			if (Dist1_val >= 10000 && Dist1_val < 100000)
			{
				astp = 100;
			}
			if (Dist1_val >= 100000)
			{
				astp = 1000;
			}

			Dist1_val = tmpDst1_rv * astp * 1000;
			val_ary[DST1_PERA] = Dist1_val;
		}
	}

	pos = (DST1_PERA * 2) + 1;
	ndgt = 0;
	if (Unit_v == INCH)
	{
		if (Dist1_val < 0)
		{
			Dist1_val = 0;
		}
		if (Dist1_val > 50000)
		{
			Dist1_val = 50000; // 100000;
		} // Check Max limit
		if (Dist1_val >= 1000 && Dist1_val < 10000)
		{
			ndgt = Dist1_val % 10;
			Dist1_val = Dist1_val - ndgt;
			ndgt = 1;
		} // When Value is higher then Fraction of value to be round of
		if (Dist1_val >= 10000)
		{
			ndgt = Dist1_val % 100;
			Dist1_val = Dist1_val - ndgt;
			ndgt = 2;
		}
		toarry(Dist1_val, pos, ndgt, 3, uniti[0]);
		val_ary[DST1_PERA] = Dist1_val;
	}
	else
	{
		if (Dist1_val < 0)
		{
			Dist1_val = 0;
		}
		if (Dist1_val > 12000)
		{
			Dist1_val = 12000; // 250000;
		} // Check Max limit
		if (Dist1_val >= 1000 && Dist1_val < 10000)
		{
			ndgt = Dist1_val % 10;
			Dist1_val = Dist1_val - ndgt;
			ndgt = 1;
		} // When Value is higher then 10 mm then Fraction to be round of
		if (Dist1_val >= 10000)
		{
			ndgt = Dist1_val % 100;
			Dist1_val = Dist1_val - ndgt;
			ndgt = 2;
		}
		toarry(Dist1_val, pos, ndgt, 2, unitm[0]);
		val_ary[DST1_PERA] = Dist1_val;
	}
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
}

//*****************************************************************************************************************************
//*****************************************************************************************************************************
//*****************************************************************************************************************************
void DST2_f(int key_t)
{
	char *unitm[] = {" mm"}, *uniti[] = {" in"};
	float tmpDst2_rv = 0.0;
	int astp = 1, temp;
	int ndgt = 0;

	Dist2_val = val_ary[DST2_PERA];

	if (Unit_v == INCH) // If unit is INCH
	{
		gtk_adjustment_set_lower(adj, 0);
		gtk_adjustment_set_upper(adj, 2100);
	}
	else // If Unit is MM
	{
		gtk_adjustment_set_lower(adj, 0);
		gtk_adjustment_set_upper(adj, 1920);
	}

	Dist2_val = val_ary[DST2_PERA];
	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
		if (Unit_v == MM) // If Unit is MM
		{
			Dist2_val = scr_val;
			temp = scr_val;
			if (scr_val < 1000)
			{
				Dist2_val = scr_val;
			}
			else if (scr_val < 1900)
			{
				temp = (scr_val - 1000);
				Dist2_val = 1000 + (10 * temp);
			}
			else if (scr_val < 100899)
			{
				temp = (scr_val - 1900);
				Dist2_val = 10000 + (100 * temp);
			}
		}
		if (Unit_v == INCH) // If Unit is MM
		{
			Dist2_val = scr_val;
			temp = scr_val;
			if (scr_val < 1000)
			{
				Dist2_val = scr_val;
			}
			else if (scr_val < 1900)
			{
				temp = (scr_val - 1000);
				Dist2_val = 1000 + (10 * temp);
			}
			else if (scr_val < 100899)
			{
				temp = (scr_val - 1900);
				Dist2_val = 10000 + (100 * temp);
			}
		}
	}

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
	{
		if (Unit_v == MM) // If Unit is MM
		{
			if (key_t == 1)
			{
				if (Dist2_val >= 1000)
				{
					astp = 10;
				}
				if (Dist2_val >= 10000 && Dist2_val < 100000)
				{
					astp = 100;
				}
				if (Dist2_val >= 100000)
				{
					astp = 1000;
				}
			}
			else
			{
				if (Dist2_val > 1000)
				{
					astp = 10;
				}
				if (Dist2_val > 10000 && Dist2_val <= 100000)
				{
					astp = 100;
				}
				if (Dist2_val > 100000)
				{
					astp = 1000;
				}
			}
			Dist2_val = Dist2_val + (key_t * astp * Key_stp);
		} //  if (Unit_v == MM)  over

		if (Unit_v == INCH) // If Unit is MM
		{
			if (key_t == 1)
			{
				if (Dist2_val >= 1000)
				{
					astp = 10;
				}
				if (Dist2_val >= 10000 && Dist2_val < 100000)
				{
					astp = 100;
				}
				if (Dist2_val >= 100000)
				{
					astp = 1000;
				}
			}
			else
			{
				if (Dist2_val > 1000)
				{
					astp = 10;
				}
				if (Dist2_val > 10000 && Dist2_val <= 100000)
				{
					astp = 100;
				}
				if (Dist2_val > 100000)
				{
					astp = 1000;
				}
			}
			Dist2_val = Dist2_val + (key_t * astp * Key_stp);
		}
	}

	//**********KEY_SCR = 2*********************
	if (key_scr == 2) // Get the value from touch keypad
	{
		if (Unit_v == MM) // If Unit is MM
		{
			tmpDst2_rv = key_array[DST2_PERA];

			if (Dist2_val >= 1000)
			{
				astp = 10;
			}
			if (Dist2_val >= 10000 && Dist2_val < 100000)
			{
				astp = 100;
			}
			if (Dist2_val >= 100000)
			{
				astp = 1000;
			}

			if (tmpDst2_rv < 1000)
			{
				Dist2_val = tmpDst2_rv * astp * 100;
			}
			else
			{
				Dist2_val = tmpDst2_rv * astp * 10;
			}
			val_ary[DST2_PERA] = Dist2_val;
		} //  if (Unit_v == MM)  over

		if (Unit_v == INCH) // If Unit is MM
		{
			tmpDst2_rv = key_array[DST2_PERA];

			if (Dist2_val >= 1000)
			{
				astp = 10;
			}
			if (Dist2_val >= 10000 && Dist2_val < 100000)
			{
				astp = 100;
			}
			if (Dist2_val >= 100000)
			{
				astp = 1000;
			}

			Dist2_val = tmpDst2_rv * astp * 1000;
			val_ary[DST2_PERA] = Dist2_val;
		}
	}

	pos = (DST2_PERA * 2) + 1;
	ndgt = 0;
	if (Unit_v == INCH)
	{
		if (Dist2_val < 0)
		{
			Dist2_val = 0;
		}
		if (Dist2_val > 50000)
		{
			Dist2_val = 100000;
		} // Check Max limit
		if (Dist2_val >= 1000 && Dist2_val < 10000)
		{
			ndgt = Dist2_val % 10;
			Dist2_val = Dist2_val - ndgt;
			ndgt = 1;
		} // When Value is higher then Fraction of value to be round of
		if (Dist2_val >= 10000)
		{
			ndgt = Dist2_val % 100;
			Dist2_val = Dist2_val - ndgt;
			ndgt = 2;
		}
		toarry(Dist2_val, pos, ndgt, 3, uniti[0]);
		val_ary[DST2_PERA] = Dist2_val;
	}
	else
	{
		if (Dist2_val < 0)
		{
			Dist2_val = 0;
		}
		if (Dist2_val > 12000)
		{
			Dist2_val = 12000;
		} // Check Max limit
		if (Dist2_val >= 1000 && Dist2_val < 10000)
		{
			ndgt = Dist2_val % 10;
			Dist2_val = Dist2_val - ndgt;
			ndgt = 1;
		} // When Value is higher then 10 mm then Fraction to be round of
		if (Dist2_val >= 10000)
		{
			ndgt = Dist2_val % 100;
			Dist2_val = Dist2_val - ndgt;
			ndgt = 2;
		}
		toarry(Dist2_val, pos, ndgt, 2, unitm[0]);
		val_ary[DST2_PERA] = Dist2_val;
	}
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
}

//-----------
/*MENU 10*/
//-----------

/**************************************************************************/
/*****************************EVALUATION FUNCTION**************************/
/**************************************************************************/
void Size_Eval_Select_f(int key_t) // Select Size Evalution method
{
	int Size_ev_state;

	Evaluate_val = val_ary[SIZE_EV_PERA];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0)  {} // Get the value from scrollbar
	
	if (key_t != 0) // If key press then change size evaluation mode but if current mode is On then issue warning message
	{
		if (val_ary[DAC_PERA] != 0 && Evaluate_val == 0)
		{
			dsp_msg(10);
		}
		else if (val_ary[DAC_PERA] != 0 && Evaluate_val == 1)
		{
			dsp_msg(11);
		}
		else if (val_ary[DAC_PERA] != 0 && Evaluate_val == 2)
		{
			dsp_msg(12);
		}
		else
		{
			if (key_scr == 1) //  for key press
			{
				Evaluate_val = Evaluate_val + key_t;
				if (Evaluate_val < 0)
					Evaluate_val = 2;
				if (Evaluate_val > 2)
					Evaluate_val = 0;
			}
		}
	}

	val_ary[SIZE_EV_PERA] = Evaluate_val;

	if (Evaluate_val == 0) // When DAC is selected
	{
		strcpy(all_btnval[(DAC_PERA * 2)], "DAC(D) ");
		strcpy(all_btnval[(CURSOR_PERA * 2)], "START A");
		strcpy(all_btnval[PRESS_PERA * 2], "PRESS  ");
		strcpy(all_btnval[(PRESS_PERA * 2) + 1], "ENTER  ");
		strcpy(all_btnval[POINT_PERA * 2], "POINT  ");
		strcpy(all_btnval[(POINT_PERA * 2) + 1], "01     ");
		
		Mea_fLn1_f(0);

		// Measure_v2 = 3;
		// val_ary[MEA_POSI2_PERA] = Measure_v2;

		Mea_fLn2_f(0);
	}
	else if (Evaluate_val == 1) // When AWS is selected
	{
		strcpy(all_btnval[(DAC_PERA * 2)], "AWS(A) ");
		strcpy(all_btnval[(CURSOR_PERA * 2)], "START A");
		
		// Aws_onoff_v = 2;

		Mea_fLn1_f(0);

		// Measure_v2 = 3;
		// val_ary[MEA_POSI2_PERA] = Measure_v2;
		Mea_fLn2_f(0);

		Measure_f(0);
	}
	else if (Evaluate_val == 2) // When DGS is selected
	{
		strcpy(all_btnval[(DAC_PERA * 2)], "DGS(G) ");
		strcpy(all_btnval[(CURSOR_PERA * 2)], "START A");
		strcpy(all_btnval[(PRESS_PERA * 2)], "DGS-REF");
		strcpy(all_btnval[POINT_PERA * 2], "TL-CORR");
		
		Mea_fLn1_f(0);

		// Measure_v2 = 3;
		// val_ary[MEA_POSI2_PERA] = Measure_v2;
		Mea_fLn2_f(0);
	}

	pos = (SIZE_EV_PERA * 2) + 1;
	strcpy(all_btnval[pos], all_btnval[(DAC_PERA * 2)]);
	pos = pos % 10;

	//**********KEY_SCR = 1*********************

	// Draw_notificimg(SZEVAL_S, Evaluate_val); // Symbol type , Postion
}

/**************************************************************************/
/********************************MEA FL N1*********************************/
/**************************************************************************/

void Mea_fLn1_f(int key_t)
{
	int tpBk_img = 0;
	Measure_v1 = val_ary[MEA_POSI1_PERA];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) { } // Get the value from scrollbar

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
		Measure_v1 = Measure_v1 + key_t;

	if (Measure_v1 > 4)
		Measure_v1 = 0;
	if (Measure_v1 < 0)
		Measure_v1 = 4;
	val_ary[MEA_POSI1_PERA] = Measure_v1;

	if (Measure_v1 == 0) 
	{
		tpBk_img = 7;
		strcpy(Dsp_Str, "OFF");
	}
	else if (Measure_v1 == 1)
	{
		tpBk_img = 1;
		strcpy(Dsp_Str, "ON G A");
	}
	else if (Measure_v1 == 2)
	{
		tpBk_img = 2;
		strcpy(Dsp_Str, "ON G B");
	}
	else if (Measure_v1 == 3)
	{
		tpBk_img = 3;
		if (Evaluate_val == 0)
			strcpy(Dsp_Str, "DAC");
		if (Evaluate_val == 1)
			strcpy(Dsp_Str, "AWS");
		if (Evaluate_val == 2)
			strcpy(Dsp_Str, "DGS");
	}
	else if (Measure_v1 == 4)
	{
		tpBk_img = 6;
		strcpy(Dsp_Str, "ENCODER");
	}
	else
	{
		tpBk_img = 7;
		strcpy(Dsp_Str, "OFF");
	}

	pos = (MEA_POSI1_PERA * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;

	Creat_bk_img(tpBk_img, 1); // Creat_bk_img(Measure_v1, 1); // Create Image for Measurement Display Button
	Colour_Theme_Apply(Theme_color_val);
}

/**************************************************************************/
/********************************MEA FL N2*********************************/
/**************************************************************************/
void Mea_fLn2_f(int key_t)
{
	int tpBk_img = 0;
	Measure_v2 = val_ary[MEA_POSI2_PERA];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) { }  // Get the value from scrollbar

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
		Measure_v2 = Measure_v2 + key_t;

	if (Measure_v2 > 4)
		Measure_v2 = 0;
	if (Measure_v2 < 0)
		Measure_v2 = 4;
	val_ary[MEA_POSI2_PERA] = Measure_v2;

	if (Measure_v2 == 0)
	{
		tpBk_img = 7;
		strcpy(Dsp_Str, "OFF");
	}
	if (Measure_v2 == 1)
	{
		tpBk_img = 1;
		strcpy(Dsp_Str, "ON G A");
	}
	else if (Measure_v2 == 2)
	{
		tpBk_img = 2;
		strcpy(Dsp_Str, "ON G B");
	}
	else if (Measure_v2 == 3)
	{
		tpBk_img = 3;
		if (Evaluate_val == 0)
			strcpy(Dsp_Str, "DAC");
		if (Evaluate_val == 1)
			strcpy(Dsp_Str, "AWS");
		if (Evaluate_val == 2)
			strcpy(Dsp_Str, "DGS");
	}
	else if (Measure_v2 == 4)
	{
		tpBk_img = 6;
		strcpy(Dsp_Str, "ENCODER");
	}
	else
	{
		tpBk_img = 7;
		Measure_v2 = 0;
		strcpy(Dsp_Str, "OFF");
	}

	pos = (MEA_POSI2_PERA * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
	Creat_bk_img(tpBk_img, 2); // Creat_bk_img(Measure_v2, 2); // Create Image for Measurement Display Button
	Colour_Theme_Apply(Theme_color_val);
}

/**************************************************************************/
/********************************MEA FL N2*********************************/
/**************************************************************************/
void Mea_fLn3_f(int key_t) // To be USe for Last Measurement Display Column where Amplitude is display
{
	Measure_v3 = val_ary[MEA_POSI3_PERA];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
	}

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
	{
		Measure_v3 = Measure_v3 + key_t;
	}

	if (Measure_v3 > 4)
	{
		Measure_v3 = 0;
	}
	if (Measure_v3 < 0)
	{
		Measure_v3 = 4;
	}
	val_ary[MEA_POSI3_PERA] = Measure_v3;

	if (Measure_v3 == 0)
	{
		strcpy(Dsp_Str, "OFF    ");
	}
	if (Measure_v3 == 1)
	{
		strcpy(Dsp_Str, "ON G A ");
	}
	else if (Measure_v3 == 2)
	{
		strcpy(Dsp_Str, "ON G B ");
	}
	else if (Measure_v3 == 3)
	{
		if (Evaluate_val == 0)
		{
			strcpy(Dsp_Str, "DAC %  ");
		}
		if (Evaluate_val == 1)
		{
			strcpy(Dsp_Str, "AWS %  ");
		}
		if (Evaluate_val == 2)
		{
			strcpy(Dsp_Str, "DGS %  ");
		}
	}
	else if (Measure_v3 == 4)
	{
		strcpy(Dsp_Str, "ENCODER");
	}
	else
	{
		Measure_v3 = 0;
		strcpy(Dsp_Str, "OFF    ");
	}

	pos = (MEA_POSI3_PERA * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
}

//---------
/*MENU 11*/
//---------

//***********************************************************************************
void Record_type_f(int key_t) //    RECORD_TYPE_PERA
{
	gtk_adjustment_set_lower(adj, 0);
	gtk_adjustment_set_upper(adj, 5);

	Record_Type_val = scr_val;
	Record_Type_val = val_ary[REC_TYPE_PERA];

	//********** KEY_SCR = 0 *********************
	if (key_scr == 0) // Get the value from scrollbar
	{
		Record_Type_val = val_ary[REC_TYPE_PERA];
	}

	//********** KEY_SCR = 1 *********************
	if (key_scr == 1) // Get the value from button keypad
	{
		Record_Type_val = Record_Type_val + key_t;
	}

	if (Record_Type_val < 0)
	{
		Record_Type_val = 3;
	}
	if (Record_Type_val > 3)
	{
		Record_Type_val = 0;
	}
	val_ary[REC_TYPE_PERA] = Record_Type_val;

	if (Record_Type_val == 0)
	{
		strcpy(Dsp_Str, "BSC THICK");
		Rec_no = Bsc_thk_no;
	}
	if (Record_Type_val == 1)
	{
		strcpy(Dsp_Str, "BSC COLOR");
		Rec_no = Bsc_clr_no;
	}
	if (Record_Type_val == 2)
	{
		strcpy(Dsp_Str, "THICK LOG");
		Rec_no = Bsc_clr_no;
	}
	if (Record_Type_val == 3)
	{
		strcpy(Dsp_Str, "TOFD     ");
		Rec_no = Tofd_no;
	}

	val_ary[RECORD_NO_PERA] = Rec_no;

	pos = (REC_TYPE_PERA * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;

	Record_No_f(0);
	Bs_Action_Select_f(0);
}
//***********************************************************************************
void Record_No_f(int key_t) //    RECORD_NO_PERA
{
	if (splite_win_flg == 2)
	{
		Thk_Left_Right_ID(key_t);
	} // ID Left / Right
	else
	{
		Record_Nob_f(key_t);
	} //    RECORD_NO_PERA
}

//***********************************************************************************
void Thk_Left_Right_ID(int key_t) // Left Right
{
	if (key_t > 0)
	{
		if ((thk_dim_type != 0) && (column_real_id < ((szD2 * szD3) - 1)))
		{
			if (sc_idx > 1)
				sc_idx = sc_idx - 1;

			if (((szD2 * szD3) - 4) < column_real_id)
				ec_idx = ec_idx - 1;
			column_real_id = column_real_id + key_t;
		}
	}

	if (key_t < 0)
	{
		if ((thk_dim_type != 0) && (column_real_id > 0))
		{
			if ((sc_idx < 3) && (column_real_id < 3))
				sc_idx = sc_idx + 1;
			if (ec_idx < 6)
				ec_idx = ec_idx + 1;

			column_real_id--;
		}
	}
	refresh_thk_clr_data();
}

//***********************************************************************************
void Create_Directory()
{
	int check;
	char dirname[16];
	DIR *dir;

	if (menu_v == 3)
	{
		if (memory_val == 0)
			strcpy(dirname, "Ascan");
		else if (memory_val == 1)
			strcpy(dirname, "Cal");
		else if (memory_val == 2)
			strcpy(dirname, "Report");

		dir = opendir(dirname);

		if (dir)
			closedir(dir); /* Directory exists. */
		else
			check = mkdir(dirname, 0777); /* Create dir */
	}
	else if (menu_v == 13)
	{
		if (memory_val == 0)
			strcpy(dirname, "Bsc_thick");
		else if (memory_val == 1)
			strcpy(dirname, "Bsc_color");
		else if (memory_val == 2)
			strcpy(dirname, "Thick_log");
		else if (memory_val == 3)
			strcpy(dirname, "TOFD");

		dir = opendir(dirname);

		if (dir)
			closedir(dir); /* Directory exists. */
		else
			check = mkdir(dirname, 0777); /* Create dir */
	}
}

int delete_file(void)
{
	char buffer[128];

	if (menu_v == 3)
	{
		if (memory_val == 0)
			return system("rm ./Ascan/*");
		else if (memory_val == 1)
			return system("rm ./Cal/*");
	}
	else if (menu_v == 13)
	{
		if (memory_val == 0)
			return system("rm ./Bsc_thick/*");
		else if (memory_val == 1)
			return system("rm ./Bsc_color/*");
		else if (memory_val == 2)
			return system("rm ./Thick_log/*");
		else if (memory_val == 3)
			return system("rm ./TOFD/*");
	}
}


void set_bsc_label(void)
{
	if (Mem_actBS == 0 || Mem_actBS == 4)
	{
		if (thk_dim_type == 0)
			strcpy(Dsp_Str, " 1 DIM   ");
		if (thk_dim_type == 1)
			strcpy(Dsp_Str, " 2 DIM   ");
		if (thk_dim_type == 2)
			strcpy(Dsp_Str, " 3 DIM   ");
		gtk_label_set_label(GTK_LABEL(dgslabel[1]), Dsp_Str);

		gtk_label_set_label(GTK_LABEL(dgslabel[3]), sID1);
		gtk_label_set_label(GTK_LABEL(dgslabel[5]), sID2);
		// gtk_label_set_label(GTK_LABEL(dgslabel[7]), sID3);

		gtk_label_set_label(GTK_LABEL(dgslabel[11]), eID1);
		gtk_label_set_label(GTK_LABEL(dgslabel[13]), eID2);
		// gtk_label_set_label(GTK_LABEL(dgslabel[15]), eID3);

		sprintf(Dsp_Str, "%d", szD1);
		gtk_label_set_label(GTK_LABEL(dgslabel[19]), Dsp_Str);
		sprintf(Dsp_Str, "%d", szD2);
		gtk_label_set_label(GTK_LABEL(dgslabel[21]), Dsp_Str);
		// sprintf(Dsp_Str, "%d", szD3);
		// gtk_label_set_label(GTK_LABEL(dgslabel[23]), Dsp_Str);
	}
	else if (Mem_actBS == 2)
	{
		// gtk_label_set_label(GTK_LABEL(dgslabel[1]), "   -   ");
		sprintf(Dsp_Str, "%d", val_ary[START_THK_1_PERA]);
		gtk_label_set_label(GTK_LABEL(dgslabel[3]), Dsp_Str);
		sprintf(Dsp_Str, "%d", val_ary[START_THK_2_PERA]);
		gtk_label_set_label(GTK_LABEL(dgslabel[5]), Dsp_Str);
		// // sprintf(Dsp_Str, "%d", val_ary[START_THK_3_PERA]);
		gtk_label_set_label(GTK_LABEL(dgslabel[7]), Dsp_Str);

		sprintf(Dsp_Str, "%d", val_ary[END_THK_1_PERA]);
		gtk_label_set_label(GTK_LABEL(dgslabel[11]), Dsp_Str);
		sprintf(Dsp_Str, "%d", val_ary[END_THK_2_PERA]);
		gtk_label_set_label(GTK_LABEL(dgslabel[13]), Dsp_Str);
		// sprintf(Dsp_Str, "%d", val_ary[END_THK_3_PERA]);
		// gtk_label_set_label(GTK_LABEL(dgslabel[15]), Dsp_Str);

		gtk_label_set_label(GTK_LABEL(dgslabel[19]), " ");
		gtk_label_set_label(GTK_LABEL(dgslabel[21]), " ");
		// gtk_label_set_label(GTK_LABEL(dgslabel[23]), " ");
	}
}

void Record_Nob_f(int key_t) //    RECORD_NO_PERA
{
	char dir_path[64];

	gtk_adjustment_set_lower(adj, 0);
	gtk_adjustment_set_upper(adj, 5);

	if (Record_Type_val == 0)
	{
		Rec_no = Bsc_thk_no;
	}
	if (Record_Type_val == 1)
	{
		Rec_no = Bsc_clr_no;
	}
	if (Record_Type_val == 2)
	{
		Rec_no = Thkfl_no;
	}
	if (Record_Type_val == 3)
	{
		Rec_no = Tofd_no;
	}

	Rec_no = scr_val;
	Rec_no = val_ary[RECORD_NO_PERA];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
		Rec_no = val_ary[RECORD_NO_PERA];
	}

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
	{
		Rec_no = Rec_no + key_t * Key_stp;
	}

	if (Rec_no < 1)
	{
		Rec_no = 1;
	}
	if (Rec_no > 500)
	{
		Rec_no = 500;
	}
	val_ary[RECORD_NO_PERA] = Rec_no;

	Create_Directory(); // Create directory
	if (Record_Type_val == 0)
	{
		memory_val = 0;
		Bsc_thk_no = Rec_no;

		sprintf(dir_path, "Bsc_thick/BTH%04d.bth", Rec_no);
		if (access(dir_path, F_OK) == 0)
			sprintf(Dsp_Str, "BTH%04d*", Rec_no);
		else
			sprintf(Dsp_Str, "BTH%04d", Rec_no);
	}
	if (Record_Type_val == 1)
	{
		memory_val = 1;
		Bsc_clr_no = Rec_no;

		sprintf(dir_path, "Bsc_color/BCL%04d.bcl", Rec_no);
		if (access(dir_path, F_OK) == 0)
			sprintf(Dsp_Str, "BCL%04d*", Rec_no);
		else
			sprintf(Dsp_Str, "BCL%04d", Rec_no);
	}
	if (Record_Type_val == 2)
	{
		memory_val = 2;
		Thkfl_no = Rec_no;

		sprintf(dir_path, "Thick_log/THK%04d.csv", Rec_no);
		if (access(dir_path, F_OK) == 0)
			sprintf(Dsp_Str, "THK%04d*", Rec_no);
		else
			sprintf(Dsp_Str, "THK%04d", Rec_no);
	}
	if (Record_Type_val == 3)
	{
		memory_val = 3;
		Tofd_no = Rec_no;

		sprintf(dir_path, "TOFD/TFD%04d.tfd", Rec_no);
		if (access(dir_path, F_OK) == 0)
			sprintf(Dsp_Str, "TFD%04d*", Rec_no);
		else
			sprintf(Dsp_Str, "TFD%04d", Rec_no);
	}

	pos = (RECORD_NO_PERA * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
}

//***********************************************************************************
void Bs_Action_Select_f(int key_t) //    RECORD_NO_PERA
{
	if (splite_win_flg == 2)
	{
		Thk_Up_Down_ID(key_t);
	} // ID UP / DOWN
	else
	{
		Bs_Action_Selectb_f(key_t);
	} //    RECORD_NO_PERA
}

/**************************************************************************/
void Thk_Up_Down_ID(int key_t) //       ID UP / DOWN
{
	if (key_t > 0)
	{
		if (row_real_id < ((szD1 * szD4) - 1))
		{
			if (sr_idx > 1)
				sr_idx = sr_idx - 1;
			if (((szD1 * szD4) - 4) < row_real_id)
				er_idx = er_idx - 1;
			row_real_id++;
		}
	}
	if (key_t < 0)
	{
		if (row_real_id > 0)
		{
			if ((sr_idx < 3) && (row_real_id < 3))
				sr_idx = sr_idx + 1;
			if (er_idx < 6)
				er_idx = er_idx + 1;

			row_real_id--;
		}
	}
	refresh_thk_clr_data();
}

/**************************************************************************/
/********************************BS ACTION*********************************/
/**************************************************************************/
void Bs_Action_Selectb_f(int key_t)
{
	Mem_actBS = val_ary[RECORD_OP_PERA];
	Record_Type_val = val_ary[REC_TYPE_PERA];

	if (Record_Type_val == 0 || Record_Type_val == 1 || Record_Type_val == 3)	// Bscan Thick, Bscan Color, TOFD
	{
		//**********KEY_SCR = 0*********************
		if (key_scr == 0) {  } // Get the value from scrollbar

		//**********KEY_SCR = 1*********************
		if (key_scr == 1) // Get the value from button keypad
			Mem_actBS = Mem_actBS + key_t * Key_stp;

		if (Mem_actBS < 0)
			Mem_actBS = 8;
		else if (Mem_actBS > 8)
			Mem_actBS = 0;

		val_ary[RECORD_OP_PERA] = Mem_actBS;

		if (Mem_actBS == 0)
			sprintf(Dsp_Str, "RECORD ");
		else if (Mem_actBS == 1)
			sprintf(Dsp_Str, "PLAY   ");
		else if (Mem_actBS == 2)
			sprintf(Dsp_Str, "ANALYSE");
		else if (Mem_actBS == 3)
			sprintf(Dsp_Str, "DETAIL ");
		else if (Mem_actBS == 4)
			sprintf(Dsp_Str, "COPY");
		else if (Mem_actBS == 5)
			sprintf(Dsp_Str, "COPY ALL");
		else if (Mem_actBS == 6)
			sprintf(Dsp_Str, "EJECT");
		else if (Mem_actBS == 7)
			sprintf(Dsp_Str, "DELETE ");
		else if (Mem_actBS == 8)
			sprintf(Dsp_Str, "DELETE ALL");
		else
		{
			Mem_actBS = 0;
			sprintf(Dsp_Str, "RECORD ");
		}

		pos = (RECORD_OP_PERA * 2) + 1;
		strcpy(all_btnval[pos], Dsp_Str);
		pos = pos % 10;
	}
	else if (Record_Type_val == 2)
	{
		//**********KEY_SCR = 0*********************
		if (key_scr == 0) 	{  } // Get the value from scrollbar
	
		//**********KEY_SCR = 1*********************
		if (key_scr == 1) // Get the value from button keypad
			Mem_actBS = Mem_actBS + key_t;

		if (Mem_actBS < 0)
			Mem_actBS = 9;
		else if (Mem_actBS > 9)
			Mem_actBS = 0;

		val_ary[RECORD_OP_PERA] = Mem_actBS;

		if (Mem_actBS == 0)
			sprintf(Dsp_Str, "NEW    ");
		else if (Mem_actBS == 1)
			sprintf(Dsp_Str, "OPEN   ");
		else if (Mem_actBS == 2)
			sprintf(Dsp_Str, "SET COLOR");
		else if (Mem_actBS == 3)
			sprintf(Dsp_Str, "CLEAR  ");
		else if (Mem_actBS == 4)
			sprintf(Dsp_Str, "DETAIL ");
		else if (Mem_actBS == 5)
			sprintf(Dsp_Str, "COPY");
		else if (Mem_actBS == 6)
			sprintf(Dsp_Str, "COPY ALL");
		else if (Mem_actBS == 7)
			sprintf(Dsp_Str, "EJECT");
		else if (Mem_actBS == 8)
			sprintf(Dsp_Str, "DELETE ");
		else if (Mem_actBS == 9)
			sprintf(Dsp_Str, "DELETE ALL");
		else
		{
			Mem_actBS = 0;
			sprintf(Dsp_Str, "NEW    ");
		}

		pos = (RECORD_OP_PERA * 2) + 1;
		strcpy(all_btnval[pos], Dsp_Str);
		pos = pos % 10;
	}
}

/**************************************************************************/
/*****************************BS PERF ACTION*******************************/
/**************************************************************************/
void Bs_Perf_Action(int key_t) // REC_ACTION_PERA
{
	Mem_actBS = val_ary[RECORD_OP_PERA];
	Record_Type_val = val_ary[REC_TYPE_PERA];

	if (Record_Type_val == 0 || Record_Type_val == 1 || Record_Type_val == 3)	// Bscan Thick, Bscan Color, TOFD
	{
		switch (Mem_actBS)
		{
		case 0:
			Bsc_Record_Start_f(key_t);	//  Start RECORD
			break; 
		case 1:
			Bsc_Record_Start_f(key_t);	//  Start PLAY
			break; 
		case 2:
			Bsc_Record_Start_f(key_t);	//  Start ANALYSE
			break; 
		case 3:
			Bsc_Record_Start_f(key_t);	//  Show Detail
			break; 
		case 4:
			Bsc_Record_Start_f(key_t);	//  Copy single file to USB
			break; 
		case 5:
			Bsc_Record_Start_f(key_t);	//  Copy All file to USB
			break; 
		case 6:
			Bsc_Record_Start_f(key_t);	//  Umount
			break;
		case 7:
			Bsc_Record_Start_f(key_t);	//  Delete File
			break; 
		case 8:
			Bsc_Record_Start_f(key_t);	//  Delete all files 
			break; 
			 
		}
	}
	else if (Record_Type_val == 2) // Thickness Logging
	{
		switch (Mem_actBS)
		{
		case 0: 	
			Bsc_Record_Start_f(key_t);	//  Start NEW
			break;
		case 1: 
			Bsc_Record_Start_f(key_t);	//  Start OPEN
			break;
		case 2: 
			Bsc_Record_Start_f(key_t);	//  Set Color
			break;
		case 3:
			Bsc_Record_Start_f(key_t);	 //  Start CLEAR
			break;
		case 4: 
			Bsc_Record_Start_f(key_t);	//  Show Detail
			break;
		case 5: 
			Bsc_Record_Start_f(key_t);	//  Copy one file to USB
			break;
		case 6: 
			Bsc_Record_Start_f(key_t);	//  Copy All to USB
			break;
		case 7: 
			Bsc_Record_Start_f(key_t);	//  Umount
			break;
		case 8:
			Bsc_Record_Start_f(key_t);	 //  Delete File
			break;
		case 9:
			Bsc_Record_Start_f(key_t);	 //  Delete all file
			break;
		}
	}
}

/**************************************************************************/
/**************************************************************************/
void Bsc_Record_Start_f(int key_t)
{
	Mem_actBS = val_ary[RECORD_OP_PERA];
	char buff[64];

	if (Record_Type_val == 0) // Thickness
	{
		sprintf(buff, "./Bsc_thick/BTH%04d.bth", val_ary[RECORD_NO_PERA]);
		if (key_t < 0)
		{
			if (bsc_fp == NULL)
			{
				bsc_frame_no = 0;
				ruler_val = 0;
			}
			if (Mem_actBS == 0) // Start Recording
			{
				if (access(buff, F_OK) == -1)
				{
					if (access("./Bsc_thick", F_OK) == -1)
						Create_Directory();

					time_frame_flag = true;
					create_bsc_file(buff);
				}
				else if (access(buff, F_OK) == 0)
				{
					if (Key_stp == 10)
					{
						// remove file
						remove(buff);

						time_frame_flag = true;
						create_bsc_file(buff);
					}
					else
					{
						dsp_msg(21);
						return;
					}
				}
			}
			else if (Mem_actBS == 1) // Play
			{
				if (access(buff, F_OK) == 0)
				{
					time_frame_flag = true;
					open_bsc_file(buff);
					// After reading file in the file "ACTION title value index is 0 stored at the time of save file,
					// Due to that reason expleicitley changing RECORD to PLAY label"
					val_ary[RECORD_OP_PERA] = 1;
					Bs_Action_Selectb_f(0);
				}
			}
			else if (Mem_actBS == 2) // Analyse
			{
				if (access(buff, F_OK) == 0)
				{
					opengl_update = false;
					time_frame_flag = false;

					open_bsc_file(buff);

					// After reading file in the file "ACTION title value index is 0 stored at the time of save file,
					// Due to that reason expleicitley changing RECORD to ANALYSIS label"
					val_ary[RECORD_OP_PERA] = 2;
					Bs_Action_Selectb_f(0);

					if (gain_btnval_flag == false)
					{
						pos = (GAIN_PERA * 2) + 0;
						strcpy(gain_btnval[0], all_btnval[pos]);
						strcpy(gain_btnval[1], all_btnval[pos + 1]);
						strcpy(all_btnval[pos], "   Scroll   ");
						strcpy(all_btnval[pos + 1], "   0   ");
						pos = pos % 10;
						gain_btnval_flag = true;
					}
				}
			}
			else if (Mem_actBS == 3) // Detail
			{
				if (key_t == -1 && note_dsp == 0)
					Note_Display(key_t); // Display Note
			}
			else if (Mem_actBS == 4) // Copy one file
			{
				if (access(buff, F_OK) == 0)
				{
					sprintf(buff, "Bsc_thick/BTH%04d.bth", val_ary[RECORD_NO_PERA]);
					MountUSB(buff);
					dsp_msg(25);
				}
				else
				{
					dsp_msg(24);
				}
			}
			else if (Mem_actBS == 5) // Copy all files
			{
				if (access(buff, F_OK) == 0)
				{
					if (Key_stp == 10)
					{
						MountUSB("Bsc_thick");
						dsp_msg(44);
					}
					else
					{
						dsp_msg(26); // Warning enter stp key and enter key together to copy all files
					}
				}
			}
			else if (Mem_actBS == 6) // Umount
			{
				UmountUSB();
			}
			else if (Mem_actBS == 7) // delete
			{
				if (Key_stp == 10)
				{
					if (access(buff, F_OK) == 0)
					{
						sprintf(buff, "BTH%04d.bth", val_ary[RECORD_NO_PERA]);
						remove(buff);

						// after delete file from directory refresh label all well
						if (access(buff, F_OK) == -1)
						{
							pos = (RECORD_NO_PERA * 2) + 1;
							sprintf(Dsp_Str, "BTH%04d", val_ary[RECORD_NO_PERA]);
							strcpy(all_btnval[pos], Dsp_Str);
							pos = pos % 10;
							gtk_label_set_label(GTK_LABEL(label_dv[pos]), Dsp_Str);
							dsp_msg(42);
						}
					}
				}
				else
				{
					dsp_msg(27);
					return;
				}
			}
			else if (Mem_actBS == 8) //  Delete all file
			{
				if (Key_stp == 10)
				{
					system("rm -r /usr/share/wslprog/Bsc_thick/*");

					// after delete file from directory refresh label all well
					if (access(buff, F_OK) == -1)
					{
						pos = (RECORD_NO_PERA * 2) + 1;
						sprintf(Dsp_Str, "BTH%04d", val_ary[RECORD_NO_PERA]);
						strcpy(all_btnval[pos], Dsp_Str);
						pos = pos % 10;
						gtk_label_set_label(GTK_LABEL(label_dv[pos]), Dsp_Str);
						dsp_msg(43);
					}
				}
				else
				{
					dsp_msg(23);
					return;
				}
			}
		}
		else if (key_t > 0)
		{
			if (opengl_update == false)
				opengl_update = true;

			if (Mem_actBS == 0 || Mem_actBS == 1 || Mem_actBS == 2)
				close_bsc_file();

			if (Mem_actBS == 3) // Detail
			{
				if (key_t == 1 && note_dsp == 1)
					Note_Display(key_t); // Display Note
			}

			gtk_widget_show(nframe[8]);
			gtk_label_set_label(GTK_LABEL(Pause_lab), "");
		}
	}
	else if (Record_Type_val == 1) // Bscan
	{
		if (key_t < 0)
		{
			if (bsc_fp == NULL)
			{
				bsc_frame_no = 0;
				ruler_val = 0;
			}
			sprintf(buff, "./Bsc_color/BCL%04d.bcl", val_ary[RECORD_NO_PERA]);

			if (Mem_actBS == 0) // Start Recording
			{
				if (access(buff, F_OK) == -1)
				{
					if (access("./Bsc_color", F_OK) == -1)
						Create_Directory();

					time_frame_flag = true;
					create_bsc_file(buff);
				}
				else if (access(buff, F_OK) == 0)
				{
					if (Key_stp == 10)
					{
						// remove file
						remove(buff);

						time_frame_flag = true;
						create_bsc_file(buff);
					}
					else
					{
						dsp_msg(21);
						return;
					}
				}
			}
			else if (Mem_actBS == 1) // Play
			{	
				if (access(buff, F_OK) == 0)
				{
					time_frame_flag = true;
					open_bsc_file(buff);
					// After reading file in the file "ACTION title value index is 0 stored at the time of save file,
					// Due to that reason expleicitley changing RECORD to PLAY label"
					val_ary[RECORD_OP_PERA] = 1;
					Bs_Action_Selectb_f(0);
				}
			}
			else if (Mem_actBS == 2) // Analyse
			{
				if (access(buff, F_OK) == 0)
				{
					opengl_update = false;
					time_frame_flag = false;
					open_bsc_file(buff);
					// After reading file in the file "ACTION title value index is 0 stored at the time of save file,
					// Due to that reason expleicitley changing RECORD to ANALYSIS label"
					val_ary[RECORD_OP_PERA] = 2;
					Bs_Action_Selectb_f(0);

					if (gain_btnval_flag == false)
					{
						pos = (GAIN_PERA * 2) + 0;
						strcpy(gain_btnval[0], all_btnval[pos]);
						strcpy(gain_btnval[1], all_btnval[pos + 1]);
						strcpy(all_btnval[pos], "   Scroll   ");
						strcpy(all_btnval[pos + 1], "   0   ");
						pos = pos % 10;
						gain_btnval_flag = true;
					}
				}
			}
			else if (Mem_actBS == 3) // Detail
			{
				if (key_t == -1 && note_dsp == 0)
					Note_Display(key_t); // Display Note
			}
			else if (Mem_actBS == 4) // Copy one file
			{
				if (access(buff, F_OK) == 0)
				{
					sprintf(buff, "Bsc_color/BCL%04d.bcl", val_ary[RECORD_NO_PERA]);
					MountUSB(buff);
					dsp_msg(25);
				}
				else
				{
					dsp_msg(24);
				}
			}
			else if (Mem_actBS == 5) // Copy all files
			{
				if (access(buff, F_OK) == 0)
				{
					if (Key_stp == 10)
					{
						MountUSB("Bsc_color");
						dsp_msg(44);
					}
					else
					{
						dsp_msg(26); // Warning enter stp key and enter key together to copy all files
					}
				}
			}
			else if (Mem_actBS == 6) // Umount
			{
				UmountUSB();
			}
			else if (Mem_actBS == 7) // Delete single file
			{
				if (Key_stp == 10)
				{
					if (access(buff, F_OK) == 0)
					{
						sprintf(buff, "BCL%04d.bcl", val_ary[RECORD_NO_PERA]);
						remove(buff);
						
						// after delete file from directory refresh label all well
						if (access(buff, F_OK) == -1)
						{
							pos = (RECORD_NO_PERA * 2) + 1;
							sprintf(Dsp_Str, "BCL%04d", val_ary[RECORD_NO_PERA]);
							strcpy(all_btnval[pos], Dsp_Str);
							pos = pos % 10;
							gtk_label_set_label(GTK_LABEL(label_dv[pos]), Dsp_Str);
							dsp_msg(42);
						}
					}
				}
				else
				{
					dsp_msg(27);
					return;
				}
			}
			else if (Mem_actBS == 8) //  Delete all file
			{
				if (Key_stp == 10)
				{
					system("rm -r /usr/share/wslprog/Bsc_color/*");

					// after delete file from directory refresh label all well
					if (access(buff, F_OK) == -1)
					{
						pos = (RECORD_NO_PERA * 2) + 1;
						sprintf(Dsp_Str, "BCL%04d", val_ary[RECORD_NO_PERA]);
						strcpy(all_btnval[pos], Dsp_Str);
						pos = pos % 10;
						gtk_label_set_label(GTK_LABEL(label_dv[pos]), Dsp_Str);
						dsp_msg(43);
					}
				}
				else
				{
					dsp_msg(23);
					return;
				}
			}
		}
		else if (key_t > 0)
		{
			if (opengl_update == false)
				opengl_update = true;

			if (Mem_actBS == 0 || Mem_actBS == 1 || Mem_actBS == 2)
				close_bsc_file();

			else if (Mem_actBS == 3) // Detail
			{
				if (key_t == 1 && note_dsp == 1)
					Note_Display(key_t); // Display Note
			}
			gtk_widget_show(nframe[8]);
			gtk_label_set_label(GTK_LABEL(Pause_lab), "");
		}
	}
	else if (Record_Type_val == 2) // Thickness Excel
	{
		sprintf(buff, "./Thick_log/THK%04d.csv", val_ary[RECORD_NO_PERA]);
		if (key_t < 0)
		{
			if (Mem_actBS == 0) // 0 == Start NEW // if (Mem_actBS == 0 || Mem_actBS == 4)  //  0 == Start NEW and 4 == Show Detail
			{
				if ((Key_stp == 10) || (access(buff, F_OK) == -1))
				{
					if (access("./Thick_log", F_OK) == -1)
						Create_Directory();

					bsc_flg = 1;
					partial_uninitialize();
					btn_idx = 0;
					Menu_pre = menu_v;
					menu_v = 32;
					Sub_st_menu = menu_v - 2;
					Dsp_dgs_selection(5);

					if (Mem_actBS == 4)
						read_data_from_thk_file();

					set_bsc_label();
				}
				else
				{
					// thk_data_file_modify(3131);
					if (Measure_v1 == 1)
						thk_data_file_modify(spa_thick_log);
					else if (Measure_v2 == 2)
						thk_data_file_modify(spb_thick_log);
					// dsp_msg(21);
					return;
				}
			}
			else if (Mem_actBS == 1) //  Start OPEN
			{
				if (thk_toggle_flag == 1)
				{
					SplitWindow(2);

					read_data_from_thk_file();
					refresh_thk_clr_data();

					strcpy(all_btnval[(RECORD_NO_PERA * 2) + 0], "LEFT ");
					strcpy(all_btnval[(RECORD_NO_PERA * 2) + 1], " RIGHT");
					strcpy(all_btnval[(RECORD_NO_PERA * 2) + 2], "UP   ");
					strcpy(all_btnval[(RECORD_NO_PERA * 2) + 3], " DOWN ");
					thk_toggle_flag = 2;
				}
				else if (thk_toggle_flag == 2)
				{
					// thk_data_file_modify(3535);
					if (Measure_v1 == 1)
						thk_data_file_modify(spa_thick_log);
					else if (Measure_v2 == 2)
						thk_data_file_modify(spb_thick_log);
				}
			}
			else if (Mem_actBS == 2) //  Set Color
			{
				bsc_flg = 0;
				partial_uninitialize();
				Menu_pre = menu_v;
				menu_v = 29;
				Sub_st_menu = menu_v - 2;
				Dsp_dgs_selection(4);

				set_bsc_label();
			}
			else if (Mem_actBS == 3) //  Start CLEAR
			{
				// thk_data_file_modify(0000);
				// refresh_thk_clr_data();
			}
			else if (Mem_actBS == 4) //  DETAIL
			{
				if (key_t == -1 && note_dsp == 0)
				{
					Note_Display(key_t); // Display Note
				}
			}
			else if (Mem_actBS == 5) //  Copy to USB
			{
				sprintf(buff, "./Thick_log/THK%04d.csv", val_ary[RECORD_NO_PERA]);
				if (access(buff, F_OK) == 0)
				{
					sprintf(buff, "Thick_log/THK%04d.csv", val_ary[RECORD_NO_PERA]);
					MountUSB(buff);
					dsp_msg(25);
				}
				else
				{
					dsp_msg(24);
				}
			}
			else if (Mem_actBS == 6) //  Copy All to USB
			{
				sprintf(buff, "./Thick_log/THK%04d.csv", val_ary[RECORD_NO_PERA]);
				if (access(buff, F_OK) == 0)
				{
					if (Key_stp == 10)
					{
						MountUSB("Thick_log");
						dsp_msg(44);
					}
					else
					{
						dsp_msg(26); // Warning enter stp key and enter key together to copy all files
					}
				}
			}
			else if (Mem_actBS == 7) // Umount
			{
				UmountUSB();
			}
			else if (Mem_actBS == 8) // Delete single file
			{
				if (Key_stp == 10)
				{
					if (access(buff, F_OK) == 0)
					{
						sprintf(buff, "THK%04d.csv", val_ary[RECORD_NO_PERA]);
						remove(buff);

						// after delete file from directory refresh label all well
						if (access(buff, F_OK) == -1)
						{
							pos = (RECORD_NO_PERA * 2) + 1;
							sprintf(Dsp_Str, "THK%04d", val_ary[RECORD_NO_PERA]);
							strcpy(all_btnval[pos], Dsp_Str);
							pos = pos % 10;
							gtk_label_set_label(GTK_LABEL(label_dv[pos]), Dsp_Str);
							dsp_msg(42);
						}
					}					
				}
				else
				{
					dsp_msg(27);
					return;
				}
			}
			else if (Mem_actBS == 9) //  Delete all file
			{
				if (Key_stp == 10)
				{
					system("rm -r /usr/share/wslprog/Thick_log/*");

					// after delete file from directory refresh label all well
					if (access(buff, F_OK) == -1)
					{
						pos = (RECORD_NO_PERA * 2) + 1;
						sprintf(Dsp_Str, "THK%04d", val_ary[RECORD_NO_PERA]);
						strcpy(all_btnval[pos], Dsp_Str);
						pos = pos % 10;
						gtk_label_set_label(GTK_LABEL(label_dv[pos]), Dsp_Str);
						dsp_msg(43);
					}
				}
				else
				{
					dsp_msg(23);
					return;
				}
			}
		}
		else if (key_t > 0)
		{
			if (Mem_actBS == 0 || Mem_actBS == 1 || Mem_actBS == 2)
			{
				if (bsc_flg == 1)
				{
					SplitWindow(2);
					// write_data_into_thk_file();
					// refresh_thk_clr_data(); // Start Recording

					strcpy(all_btnval[(RECORD_NO_PERA * 2) + 0], "LEFT ");
					strcpy(all_btnval[(RECORD_NO_PERA * 2) + 1], " RIGHT");
					strcpy(all_btnval[(RECORD_NO_PERA * 2) + 2], "UP   ");
					strcpy(all_btnval[(RECORD_NO_PERA * 2) + 3], " DOWN ");
				}
				else if (bsc_flg == 0)
				{
					SplitWindow(0);
					thk_toggle_flag = 1;
				}
				bsc_flg = 0;
			}
			else if (Mem_actBS == 4) // Detail
			{
				if (key_t == 1 && note_dsp == 1)
				{
					Note_Display(key_t); // Display Note
				}
			}
		} // Stop Recording
	}
	else if (Record_Type_val == 3) // TOFD
	{
		if (key_t < 0)
		{
			if (bsc_fp == NULL)
			{
				bsc_frame_no = 0;
				ruler_val = 0;
			}
			sprintf(buff, "./TOFD/TFD%04d.tfd", val_ary[RECORD_NO_PERA]);

			if (Mem_actBS == 0) // Start Recording
			{
				if (access(buff, F_OK) == -1)
				{
					if (access("./TOFD", F_OK) == -1)
						Create_Directory();

					time_frame_flag = true;
					create_bsc_file(buff);
				}
				else if (access(buff, F_OK) == 0)
				{
					if (Key_stp == 10)
					{
						// remove file
						remove(buff);

						time_frame_flag = true;
						create_bsc_file(buff);
					}
					else
					{
						dsp_msg(21);
						return;
					}
				}
			}
			else if (Mem_actBS == 1) // Play
			{
				if (access(buff, F_OK) == 0)
				{
					time_frame_flag = true;
					open_bsc_file(buff);
					// After reading file in the file "ACTION title value index is 0 stored at the time of save file,
					// Due to that reason expleicitley changing RECORD to PLAY label"
					val_ary[RECORD_OP_PERA] = 1;
					Bs_Action_Selectb_f(0);
				}
			}
			else if (Mem_actBS == 2) // Analyse
			{
				if (access(buff, F_OK) == 0)
				{
					opengl_update = false;
					time_frame_flag = false;
					open_bsc_file(buff);
					// After reading file in the file "ACTION title value index is 0 stored at the time of save file,
					// Due to that reason expleicitley changing RECORD to ANALYSIS label"
					val_ary[RECORD_OP_PERA] = 2;
					Bs_Action_Selectb_f(0);

					if (gain_btnval_flag == false)
					{
						pos = (GAIN_PERA * 2) + 0;
						strcpy(gain_btnval[0], all_btnval[pos]);
						strcpy(gain_btnval[1], all_btnval[pos + 1]);
						strcpy(all_btnval[pos], "   Scroll   ");
						strcpy(all_btnval[pos + 1], "   0   ");
						pos = pos % 10;
						gain_btnval_flag = true;
					}
				}
			}
			else if (Mem_actBS == 3) // Detail
			{
				if (key_t == -1 && note_dsp == 0)
					Note_Display(key_t); // Display Note
			}
			else if (Mem_actBS == 4) // Copy one file
			{
				if (access(buff, F_OK) == 0)
				{
					sprintf(buff, "TOFD/TFD%04d.tfd", val_ary[RECORD_NO_PERA]);
					MountUSB(buff);
					dsp_msg(25);
				}
				else
				{
					dsp_msg(24);
				}
			}
			else if (Mem_actBS == 5) // Copy all files
			{
				if (access(buff, F_OK) == 0)
				{
					if (Key_stp == 10)
					{
						MountUSB("TOFD");
						dsp_msg(44);
					}
					else
					{
						dsp_msg(26); // Warning enter stp key and enter key together to copy all files
					}
				}
			}
			else if (Mem_actBS == 6) // Umount
			{
				UmountUSB();
			}
			else if (Mem_actBS == 7) // Delete single file
			{
				if (Key_stp == 10)
				{
					if (access(buff, F_OK) == 0)
					{
						sprintf(buff, "TFD%04d.tfd", val_ary[RECORD_NO_PERA]);
						remove(buff);

						// after delete file from directory refresh label all well
						if (access(buff, F_OK) == -1)
						{
							pos = (RECORD_NO_PERA * 2) + 1;
							sprintf(Dsp_Str, "TFD%04d", val_ary[RECORD_NO_PERA]);
							strcpy(all_btnval[pos], Dsp_Str);
							pos = pos % 10;
							gtk_label_set_label(GTK_LABEL(label_dv[pos]), Dsp_Str);
							dsp_msg(42);
						}
					}
				}
				else
				{
					dsp_msg(27);
					return;
				}
			}
			else if (Mem_actBS == 8) // Delete all files
			{
				if (Key_stp == 10)
				{
					system("rm -r /usr/share/wslprog/TOFD/*");

					// after delete file from directory refresh label all well
					if (access(buff, F_OK) == -1)
					{
						pos = (RECORD_NO_PERA * 2) + 1;
						sprintf(Dsp_Str, "TFD%04d", val_ary[RECORD_NO_PERA]);
						strcpy(all_btnval[pos], Dsp_Str);
						pos = pos % 10;
						gtk_label_set_label(GTK_LABEL(label_dv[pos]), Dsp_Str);
						dsp_msg(43);
					}
				}
				else
				{
					dsp_msg(23);
					return;
				}
			}
		}
		else if (key_t > 0)
		{
			if (opengl_update == false)
				opengl_update = true;

			if (Mem_actBS == 0 || Mem_actBS == 1 || Mem_actBS == 2)
				close_bsc_file();

			else if (Mem_actBS == 3) // Detail
			{
				if (key_t == 1 && note_dsp == 1)
					Note_Display(key_t); // Display Note
			}
			gtk_widget_show(nframe[8]);
			gtk_label_set_label(GTK_LABEL(Pause_lab), "");
		}
	}
}

/**************************************************************************/
/********************************BS SCROLL*********************************/
/**************************************************************************/
void Bs_Scroll_curp(int key_t)
{
	// menu_v = 11;
	// m_val = 11;
	// Cur_pos = scr_val;

	////**********KEY_SCR = 0*********************
	// if (key_scr == 0)
	// {
	//	Cur_pos = val_ary[SCROL_PERA];
	// }

	////**********KEY_SCR = 1*********************
	// if (key_scr == 1)//  for key press
	// {
	//	if (val_ary[SCROL_PERA] < 0) { val_ary[SCROL_PERA] = 0; }
	//	if (key_t == 1)
	//	{
	//		Cur_pos = val_ary[SCROL_PERA];
	//		Cur_pos = Cur_pos + 1;
	//		if (Cur_pos < 0) { Cur_pos = 0; }
	//		if (val_ary[SCROL_PERA] < 0) { val_ary[SCROL_PERA] = 0; }
	//		val_ary[SCROL_PERA] = Cur_pos;
	//	}
	//	if (key_t == -1)
	//	{
	//		Cur_pos = val_ary[SCROL_PERA];
	//		Cur_pos = Cur_pos - 1;
	//		if (Cur_pos < 0) { Cur_pos = 0; }
	//		if (val_ary[SCROL_PERA] < 0) { val_ary[SCROL_PERA] = 0; }
	//		val_ary[SCROL_PERA] = Cur_pos;
	//	}
	// }

	// sprintf(snum, "%d", Cur_pos);
	// pos = m_val * 10;
	// strcpy(all_btnval[pos + 7], snum);
	// gtk_label_set_label(GTK_LABEL(label_dv[7]), all_btnval[pos + 7]);
}

//---------
/*MENU 12*/
//---------

/************************************************************************************/
/*************************************ENCODER FUNCTION*******************************/
/************************************************************************************/
void ENCODER_f(int key_t)
{
	// Encoder_val = scr_val;
	Encoder_val = val_ary[ENCODER_PERA];
	//**********KEY_SCR = 0*********************
	if (key_scr == 0) {  }// Get the value from scrollbar

	//**********KEY_SCR = 1*********************
	if (Key_stp != 10 && key_scr == 1) // Get the value from button keypad
		Encoder_val = Encoder_val + key_t;

	if (Key_stp == 10 && key_t == 1 || Key_stp == 10 && key_t == -1)
		Encoder_Reset();

	val_ary[ENCODER_PERA] = Encoder_val;

	if (Encoder_val < 0)
		Encoder_val = 1;
	else if (Encoder_val > 1)
		Encoder_val = 0;

	val_ary[ENCODER_PERA] = Encoder_val;

	if (Encoder_val == 0) // OFF
		sprintf(Dsp_Str, "OFF    ");
	else if (Encoder_val == 1) // ON
		sprintf(Dsp_Str, "ON     ");

	pos = (ENCODER_PERA * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
	// gtk_label_set_label(GTK_LABEL(label_dv[pos]), Dsp_Str);
}

/************************************************************************************/
/**********************************ENC CAL FUNCTION**********************************/
/************************************************************************************/

void Enc_CAL_F_f(int key_t)
{
	Encoder_cal = val_ary[ENC_CAL_PERA];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) { }	// Get the value from scrollbar

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) 	// Get the value from button keypad
		Encoder_cal = Encoder_cal + (key_t * Key_stp);

	if (Encoder_cal < 1)
		Encoder_cal = 10000;
	else if (Encoder_cal > 10000)
		Encoder_cal = 1;

	val_ary[ENC_CAL_PERA] = Encoder_cal;

	sprintf(Dsp_Str, "%d", Encoder_cal);
	pos = (ENC_CAL_PERA * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
}

/************************************************************************************/
/**********************************ENC START FUNCTION********************************/
/************************************************************************************/
void Enc_Start_posF_f(int key_t)
{
	// Enc_strtP = scr_val;
	Enc_strtP = val_ary[ENC_STRT_PERA];

	////**********KEY_SCR = 0*********************
	if (key_scr == 0) {  } // Get the value from scrollbar

	////**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
		Enc_strtP = Enc_strtP + (key_t * Key_stp);

	if (Enc_strtP >= 9999)
		Enc_strtP = 0;
	else if (Enc_strtP < 0)
		Enc_strtP = 9999;
	
	val_ary[ENC_STRT_PERA] = Enc_strtP;

	sprintf(Dsp_Str, "%d", Enc_strtP);
	pos = (ENC_STRT_PERA * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
}

void Bsc_Analysis_thk_f(int key_t)
{
	int idx_pos = GAIN_PERA;

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) {  }// Get the value from scrollbar

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
		bsc_frame_no = bsc_frame_no + key_t * (Key_stp);

	if (bsc_frame_no < 1)
		bsc_frame_no = 1;
	else if (bsc_frame_no > 9999)
		bsc_frame_no = 9999;

	ruler_val = bsc_frame_no;

	if (key_t > 0)
		fwbw_flag = 0;
	else if (key_t < 0)
		fwbw_flag = 1;

	if ((Record_Type_val == 0 || Record_Type_val == 1 || Record_Type_val == 3) && (rw_flag != -1))
	{
		if (Spi_open == false)
			read_data_using_button_fun(key_t);
		else if (Spi_open == true)
			read_data_using_button_fun_for_Board(key_t);
	}

	sprintf(Dsp_Str, "%d", bsc_frame_no);
	pos = (idx_pos * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
	gtk_label_set_label(GTK_LABEL(dgslabel[9]), Dsp_Str);
}

/************************************************************************************/
/**********************************BSC DSP FUNCTION**********************************/
/************************************************************************************/
void Bsc_DSP_f(int key_t)
{
	// menu_v = 12;
	// m_val = 12;
	// Bsc_Dsp_v = scr_val;
	// pos = m_val * 10;

	////**********KEY_SCR = 0*********************
	// if (key_scr == 0)
	//{
	//	Bsc_Dsp_v = val_ary[ENC_STRT_PERA];
	// }

	////**********KEY_SCR = 1*********************
	// if (key_scr == 1)//  for key press
	//{
	//	if (key_t == 1)
	//	{
	//		//Bsc_Dsp_v = val_ary[ENC_STRT_PERA];
	//		Bsc_Dsp_v = Bsc_Dsp_v + 1;
	//		printf("%d", Bsc_Dsp_v);
	//		if (Bsc_Dsp_v < 0) { Bsc_Dsp_v = 1; }
	//		if (Bsc_Dsp_v > 1) { Bsc_Dsp_v = 0; }
	//		//val_ary[ENC_STRT_PERA] = Bsc_Dsp_v;
	//	}
	//	if (key_t == -1)
	//	{
	//		//Bsc_Dsp_v = val_ary[ENC_STRT_PERA];
	//		//Bsc_Dsp_v = Bsc_Dsp_v - 1;
	//		Bsc_Dsp_v = Bsc_Dsp_v;
	//		printf("%d", Bsc_Dsp_v);
	//		if (Bsc_Dsp_v < 0) { Bsc_Dsp_v = 1; }
	//		if (Bsc_Dsp_v > 1) { Bsc_Dsp_v = 0; }
	//		//val_ary[ENC_STRT_PERA] = Bsc_Dsp_v;
	//	}
	// }

	// if (Bsc_Dsp_v == 0) { strcpy(all_btnval[pos + 5], "OFF    "); } // OFF
	// if (Bsc_Dsp_v == 1) { strcpy(all_btnval[pos + 5], "ON     "); } // ON

	// if (gtk_adjustment_get_value(adj) > 1) { gtk_adjustment_set_value(adj, Bsc_Dsp_v); }

	////strcpy(all_btnval[pos + 5], snum);
	// gtk_label_set_label(GTK_LABEL(label_dv[5]), all_btnval[pos + 5]);
}

//***********************************************************************************
void Weld_Prof_f(int key_t) // WELD_PROF_PERA
{
	gtk_adjustment_set_lower(adj, 0);
	gtk_adjustment_set_upper(adj, 5);

	Weld_prf_val = scr_val;
	Weld_prf_val = val_ary[WELD_PROF_PERA];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
		Weld_prf_val = val_ary[WELD_PROF_PERA];
	}

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
	{
		Weld_prf_val = Weld_prf_val + key_t;
	}

	if (Weld_prf_val < 0)
	{
		Weld_prf_val = 0;
	}
	if (Weld_prf_val > 2)
	{
		Weld_prf_val = 0;
	}

	val_ary[WELD_PROF_PERA] = Weld_prf_val;

	if (Weld_prf_val == 0)
	{
		strcpy(Dsp_Str, "OFF     ");
		gl_clear_color_background_data(width_sh, height_sh);

	} // Update Weld Profile in Background  }   // OFF
	if (Weld_prf_val == 1)
	{
		// Remove partial opengl
		partial_uninitialize();
		draw_function();
		strcpy(Dsp_Str, "SET     ");
	} // DRAW
	if (Weld_prf_val == 2)
	{
		strcpy(Dsp_Str, "ON      ");
	} // Update Weld Profile in Background  }  // DRAW
	// if (Weld_prf_val == 3)  { strcpy(Dsp_Str, "ON      "); }   // ON

	pos = (WELD_PROF_PERA * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
	gtk_label_set_label(GTK_LABEL(label_dv[pos]), Dsp_Str);

	if (Weld_prf_val == 1)
	{
		// partial_uninitialize();
		Menu_pre = menu_v;
		menu_v = 22;
		Sub_st_menu = menu_v - 2;
		Dsp_dgs_selection(1);
	}

	/*if (Weld_prf_val == 2)
	  {  ogl.oglrecreate_flag = true;
		 recreate_surface(0, width_sh, height_sh, ogl_x_position, ogl_y_position);
		 Menu_pre=menu_v; menu_v=25; Sub_st_menu=menu_v-2; Dsp_dgs_selection(2);
	  }*/

	// if (Weld_prf_val == 3)
	//	  {  /*ogl.oglrecreate_flag = true;
	//		 recreate_surface(0, width_sh, height_sh, ogl_x_position, ogl_y_position);
	//		 Menu_pre=menu_v; menu_v=25; Sub_st_menu=menu_v-2; Dsp_dgs_selection(2); */
	//	  }
}

//***********************************************************************************************
void Beam_Prof_f(int key_t) // BEAM_PROF_PERA
{
	gtk_adjustment_set_lower(adj, 0);
	gtk_adjustment_set_upper(adj, 5);

	// Beam_prf_val = scr_val;
	Beam_prf_val = val_ary[BEAM_PROF_PERA];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
		// Beam_prf_val = val_ary[BEAM_PROF_PERA];
	}

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
	{
		Beam_prf_val = Beam_prf_val + key_t;
	}

	if (Beam_prf_val < 0)
	{
		Beam_prf_val = 0;
	}
	if (Beam_prf_val > 2)
	{
		Beam_prf_val = 0;
	}
	val_ary[BEAM_PROF_PERA] = Beam_prf_val;

	if (Beam_prf_val == 0)
	{
		strcpy(Dsp_Str, "OFF     ");
		gl_clear_color_background_data(width_sh, height_sh);

	} // OFF
	if (Beam_prf_val == 1)
	{
		strcpy(Dsp_Str, "SET     ");

		btn_idx = 0;
		partial_uninitialize();
		Menu_pre = menu_v;
		menu_v = 28;
		Sub_st_menu = menu_v - 2;
		Dsp_dgs_selection(3);
		// Refresh Value on Screen When Beam Profile menu display on Screen
		Beam_Prof_PDia_f(0); //  Probe Near Field Beam Profile
		Beam_Prof_PFreq_f(0);

	} // DRAW
	if (Beam_prf_val == 2)
	{
		recreate_surface(width_sh, height_sh, ogl_x_position, ogl_y_position);
		strcpy(Dsp_Str, "ON      ");
	} // ON

	pos = (BEAM_PROF_PERA * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
	gtk_label_set_label(GTK_LABEL(label_dv[pos]), Dsp_Str);

	// if (Beam_prf_val == 1)
	// {
	// 	btn_idx = 0;
	// 	partial_uninitialize();
	// 	Menu_pre = menu_v;
	// 	menu_v = 28;
	// 	Sub_st_menu = menu_v - 2;
	// 	Dsp_dgs_selection(3);
	// 	// Refresh Value on Screen When Beam Profile menu display on Screen
	// 	Beam_Prof_PDia_f(0); //  Probe Near Field Beam Profile
	// 	Beam_Prof_PFreq_f(0);
	// }
	// else
	// {
	// 	gl_clear_color_background_data(width_sh, height_sh); // Update Weld Profile in Background
	// }
}

//***********************************************************************************************
void Thick_color_f(int key_t) // THICK_CLR_PERA break;
{
	gtk_adjustment_set_lower(adj, 0);
	gtk_adjustment_set_upper(adj, 5);

	Thick_color_val = scr_val;
	Thick_color_val = val_ary[THICK_CLR_PERA];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
		Thick_color_val = val_ary[THICK_CLR_PERA];
	}

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
	{
		Thick_color_val = Thick_color_val + key_t;
	}

	if (Thick_color_val < 0)
	{
		Thick_color_val = 3;
	}
	if (Thick_color_val > 2)
	{
		Thick_color_val = 0;
	}
	val_ary[THICK_CLR_PERA] = Thick_color_val;

	if (Thick_color_val == 0)
	{
		strcpy(Dsp_Str, "OFF     ");
	} // OFF
	if (Thick_color_val == 1)
	{
		strcpy(Dsp_Str, "SET     ");
	} // DRAW
	if (Thick_color_val == 2)
	{
		strcpy(Dsp_Str, "ON      ");
	} // ON

	pos = (THICK_CLR_PERA * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
	// gtk_label_set_label(GTK_LABEL(label_dv[pos]), Dsp_Str);

	if (Thick_color_val == 1)
	{
		partial_uninitialize();
		Menu_pre = menu_v;
		menu_v = 29;
		Sub_st_menu = menu_v - 2;
		Dsp_dgs_selection(4);
	}
}

void Change_ogl_probe_pos_f(int key_t)
{
	int Data_v, range;
	int idx_pos = PROB_POS_PERA;
	Data_v = val_ary[idx_pos];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
	}

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
	{
		Data_v = Data_v + key_t * (Key_stp);
	}

	if (val_ary[OBJ_SHAPE_PERA] == 0)
		range = orignal_gtk_shape[0];
	else if (val_ary[OBJ_SHAPE_PERA] == 1 || val_ary[OBJ_SHAPE_PERA] == 2 || val_ary[OBJ_SHAPE_PERA] == 3)
		range = 360;

	if (Data_v < 0)
	{
		Data_v = 0;
	}
	if (Data_v > range)
	{
		Data_v = range;
	}
	val_ary[idx_pos] = Data_v;

	copy_rays_data();
	gl_clear_color_background_data(width_sh, height_sh);

	sprintf(Dsp_Str, "%d mm", Data_v - val_ary[WPROF_POS_PERA]);
	pos = (CNG_OGL_PROF_POS * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
	gtk_label_set_label(GTK_LABEL(label_dv[pos]), Dsp_Str);
}

//********************************************************************************************************************************************
void Battery_Symbol(int btrper, int chr_no) // // Draw charging battery image(battery %, charge symbol) 0 = No charge symbol, 1 = charge symbol
{
	int Data, len;
	char buffer[20];

	// Data = ADC_read(); // Read Battery Voltage
	// ADC_read();
	cairo_t *cr;

	cairo_surface_t *surface = cairo_image_surface_create(CAIRO_FORMAT_RGB24, image_w + 20, image_h);
	cr = cairo_create(surface);
	cairo_set_line_width(cr, 1.0);

	// cairo_set_source_rgb(cr, 1.0, 0.87, 0.678);
	// for background color  below if conditions

	if (Theme_color_val == 0) //Black // old Blue
	{
		cairo_set_source_rgb(cr, 0.0, 0.0, 0.0);
		// cairo_set_source_rgb(cr, 0.439, 0.50, 0.564);		
	}
	if (Theme_color_val == 1)  // Blue // old Gray
	{
		cairo_set_source_rgb(cr, 0.529, 0.80, 0.980);
	}
	if (Theme_color_val == 2) // Orange(NOT USED)
	{
		cairo_set_source_rgb(cr, 1.0, 0.87, 0.678);
	}
	cairo_paint(cr);

	// 15 -> low battery // 40  -> battery high
	len = (btrper * 39) / 100; //   len=(btrper*40)/100;    // btrper moves from 0 to 40 incrementing in the value of 5 i.e. 0,5,10
	if (btrper < 25)		   // If btrper < 25 then red colour to be filled in battery
	{
		cairo_set_source_rgb(cr, 1.0, 0.64, 0.5);
	}
	else
	{
		cairo_set_source_rgb(cr, 0.0, 1.0, 0.0); // If btrper > 25 then green colour to be filled in battery
	}

	cairo_rectangle(cr, 1, 10, len, 20);
	cairo_fill(cr);

	cairo_set_source_rgb(cr, 1.0, 1.0, 1.0); // Draw Black Border
	cairo_rectangle(cr, 0, 10, 40, 20);
	cairo_stroke(cr);
	// cairo_set_source_rgb(cr, 0.0, 0.0, 0.0);   // Draw Black Border
	cairo_rectangle(cr, 40, 17, 4, 6);
	cairo_stroke(cr);

	if (len > 37) // To fill the small rectangle box with green colour
	{
		cairo_set_source_rgb(cr, 0.0, 1.0, 0.0);
		cairo_rectangle(cr, 41, 19, 3, 2);
		cairo_fill(cr);
	}

	chr_no = 0;

	if (chr_no == 1) // CHARGING SYMBOL LINES DRAWN
	{
		cairo_set_line_width(cr, 1.0);
		cairo_set_source_rgb(cr, 0.0, 0.0, 0.0);

		cairo_move_to(cr, 15, 13);
		cairo_line_to(cr, 23, 13);
		cairo_line_to(cr, 20, 19);
		cairo_line_to(cr, 24, 19);
		cairo_line_to(cr, 14, 28);

		cairo_move_to(cr, 15, 13);
		cairo_line_to(cr, 12, 21);
		cairo_line_to(cr, 16, 21);
		cairo_line_to(cr, 14, 28);
		cairo_stroke(cr);
	}

fun_exit:
	// cairo_surface_write_to_png(surface, "Images/Images/n8.png");

	// n_pximage[0] = gdk_pixbuf_new_from_file_at_scale("Images/Images/n8.png", image_w + 20, image_h, false, NULL);
	n_pximage[0] = gdk_pixbuf_get_from_surface(surface, 0, 0, image_w + 20, image_h);
	gtk_image_set_from_pixbuf(GTK_IMAGE(n_image[6]), n_pximage[0]);
}

// Battery   From    To
// Perc      Voltage Voltage
// 100		2020    >
// 95		2010	2020
// 90		2000	2010
// 85		1990	2000
// 80		1980	1990
// 75		1970	1980
// 70		1960	1970
// 65		1950	1960
// 60		1940	1950
// 55		1930	1940
// 50		1920	1930
// 45		1910	1920
// 40		1900	1910
// 35		1890	1900
// 30		1880	1890
// 25		1870	1880
// 20		1860	1870
// 15		1850	1860
// 10		1840	1850
// 5			1830	1840
// 0			1820	1830
//  The above voltages are in milli volt . Divide by 1000 to get volt

// Refer to Excel Document Battery Percent in the current folder
//**********************************************************************************************
int ADC_read() // Read Battery Voltage
{
	int fadc;
	int value;
	char buffer[5];

	fadc = open("/sys/bus/iio/devices/iio:device0/in_voltage3_raw", O_RDONLY);
	// /sys/bus/iio/devices/iio\:device0/in_voltage_scale
	if (fadc == -1)
		return (-1);

	if (read(fadc, buffer, 4) == -1)
		return (-1);

	close(fadc);

	buffer[4] = '\0';
	value = atoi(buffer);

	if (value >= 1860 && value < 1870) // 1860	1870
	{
		Batt_val = 20;
		sprintf(Battpr, "%s", "20%");
		gtk_label_set_label(GTK_LABEL(Batt_Perc), Battpr);
		dsp_msg(45);
		// gtk_label_set_markup(GTK_LABEL(Batt_Perc), "<b>Text to be bold</b>");
	}
	else if (value >= 1870 && value < 1880) // 1870	1880
	{
		Batt_val = 25;
		sprintf(Battpr, "%s", "25%");
		gtk_label_set_label(GTK_LABEL(Batt_Perc), Battpr);
	}
	else if (value >= 1880 && value < 1890) // 1880	1890
	{
		Batt_val = 30;
		sprintf(Battpr, "%s", "30%");
		gtk_label_set_label(GTK_LABEL(Batt_Perc), Battpr);
	}
	else if (value >= 1890 && value < 1900) // 1890	1900
	{
		Batt_val = 35;
		sprintf(Battpr, "%s", "35%");
		gtk_label_set_label(GTK_LABEL(Batt_Perc), Battpr);
	}
	else if (value >= 1900 && value < 1910) // 1900	1910
	{
		Batt_val = 40;
		sprintf(Battpr, "%s", "40%");
		gtk_label_set_label(GTK_LABEL(Batt_Perc), Battpr);
	}
	else if (value >= 1910 && value < 1920) // 1910	1920
	{
		Batt_val = 45;
		sprintf(Battpr, "%s", "45%");
		gtk_label_set_label(GTK_LABEL(Batt_Perc), Battpr);
	}
	else if (value >= 1920 && value < 1930) // 1920	1930
	{
		Batt_val = 50;
		sprintf(Battpr, "%s", "50%");
		gtk_label_set_label(GTK_LABEL(Batt_Perc), Battpr);
	}
	else if (value >= 1930 && value < 1940) // 1930	1940
	{
		Batt_val = 55;
		sprintf(Battpr, "%s", "55%");
		gtk_label_set_label(GTK_LABEL(Batt_Perc), Battpr);
	}
	else if (value >= 1940 && value < 1950) // 1940	1950
	{
		Batt_val = 60;
		sprintf(Battpr, "%s", "60%");
		gtk_label_set_label(GTK_LABEL(Batt_Perc), Battpr);
	}
	else if (value >= 1950 && value < 1960) // // 1950	1960
	{
		Batt_val = 65;
		sprintf(Battpr, "%s", "65%");
		gtk_label_set_label(GTK_LABEL(Batt_Perc), Battpr);
	}
	else if (value >= 1960 && value < 1970) // 1960	1970
	{
		Batt_val = 70;
		sprintf(Battpr, "%s", "70%");
		gtk_label_set_label(GTK_LABEL(Batt_Perc), Battpr);
	}
	else if (value >= 1970 && value < 1980) // 1970	1980
	{
		Batt_val = 75;
		sprintf(Battpr, "%s", "75%");
		gtk_label_set_label(GTK_LABEL(Batt_Perc), Battpr);
	}
	else if (value >= 1980 && value < 1990) // 1980	1990
	{
		Batt_val = 80;
		sprintf(Battpr, "%s", "80%");
		gtk_label_set_label(GTK_LABEL(Batt_Perc), Battpr);
	}
	else if (value >= 1990 && value < 2000) // 1990	2000
	{
		Batt_val = 85;
		sprintf(Battpr, "%s", "85%");
		gtk_label_set_label(GTK_LABEL(Batt_Perc), Battpr);
	}
	else if (value >= 2000 && value < 2010) // 2000	2010
	{
		Batt_val = 90;
		sprintf(Battpr, "%s", "90%");
		gtk_label_set_label(GTK_LABEL(Batt_Perc), Battpr);
	}
	else if (value >= 2010 && value < 2020) // 2010	2020
	{
		Batt_val = 95;
		sprintf(Battpr, "%s", "95%");
		gtk_label_set_label(GTK_LABEL(Batt_Perc), Battpr);
	}
	else if (value >= 2020) // >2020
	{
		Batt_val = 100;
		sprintf(Battpr, "%s", "100%");
		gtk_label_set_label(GTK_LABEL(Batt_Perc), Battpr);
	}
	else if (value < 1860) // 1860
	{
		Batt_val = 15;
		sprintf(Battpr, "%s", "15%");
		gtk_label_set_label(GTK_LABEL(Batt_Perc), Battpr);
		dsp_msg(45);
	}

	Battery_Symbol(Batt_val, 0);
}

//********************************************************************************************************************************************
int Gate_Adjust(int key_t, int gstad) // Adjust Gate Start Value
{
	char *unitm[] = {" mm"}, *uniti[] = {" in"};
	int ndgt, temp, j = 1, i;

	if (key_scr == 5)
		i = gstep;
	else
		i = gstad;

	if (Unit_v == MM) // If mm
	{
		if (key_t == 1)
		{
			if (i >= 1000)
				j = 10;
		}
		else
		{
			if (i > 1000)
				j = 10;
		}

		temp = Key_stp;
		temp = key_t * j * temp;		
		gstad = gstad + temp;

		if (gstad < 1)
			gstad = 1;
		else if (gstad > 100000)
			gstad = 100000;

		ndgt = 0;
		if (gstad >= 1000)
			ndgt = 1;

		toarry((long)gstad, pos, ndgt, 1, unitm[0]);
	}
	else if (Unit_v == INCH) // If Unit is Inch
	{
		j = 1;
		if (key_t == 1)
		{
			if (i >= 10000)
				j = 10;
			if (i >= 100000)
				j = 100;
		}
		else
		{
			if (i > 10000)
				j = 10;
			if (i > 100000)
				j = 100;
		}

		temp = Key_stp;
		temp = key_t * j * temp;		
		gstad = gstad + temp;

		if (gstad < 1)
			gstad = 1;
		else if (gstad > 40000)
			gstad = 40000;

		ndgt = 0;
		if (gstad >= 10000)
			ndgt = 1;

		toarry((long)gstad, pos, ndgt, 2, uniti[0]);
	}

	/*
	if (Unit_v == INCH) // If Unit is Inch
	{
		if (gstad > 40000)
		{
			gstad = 40000;
		}
		if (gstad < 1)
		{
			gstad = 1;
		}

		ndgt = 0;
		if (gstad >= 10000)
		{
			ndgt = gstad % 10;
			gstad = gstad - ndgt;
			ndgt = 1;
		} // When Value is high then Frection of value to be round off
		toarry((long)gstad, pos, ndgt, 2, uniti[0]);
	}
	else
	{
		if (gstad > 100000)
			gstad = 100000;
		if (gstad < 1)
		{
			gstad = 1;
		}

		ndgt = 0;
		if (gstad >= 1000)
		{
			ndgt = gstad % 10;
			gstad = gstad - ndgt;
			ndgt = 1;
		} // When Value is high then Frection of value to be round off
		toarry((long)gstad, pos, ndgt, 1, unitm[0]);
	}*/

	return gstad;
}

//**************************************************************************************************************************
void Weld_type_f(int key_t) //  WELD_TYPE_PERA
{
	int Data_v;
	int idx_pos = WELD_TYPE_PERA;
	Data_v = val_ary[idx_pos];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0)
	{
	}

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) //  for key press
	{
		Data_v = Data_v + key_t * (Key_stp);
	}

	if (Data_v < 0)
	{
		Data_v = 0;
	}
	if (Data_v > 2)
	{
		Data_v = 2;
	}
	val_ary[idx_pos] = Data_v;

	if (Data_v == 0)
	{
		strcpy(Dsp_Str, " V SHAPE ");
		val_ary[TOP_WIDTH_PERA] = profiler_data[0];
		val_ary[TOP_HEIGHT_PERA] = profiler_data[1];
		val_ary[ROOT_WIDTH_PERA] = profiler_data[2];
	} //
	if (Data_v == 1)
	{
		strcpy(Dsp_Str, "DBL V   ");
		val_ary[TOP_WIDTH_PERA] = profiler_data[3];
		val_ary[TOP_HEIGHT_PERA] = profiler_data[4];
		val_ary[ROOT_WIDTH_PERA] = profiler_data[5];
	} //
	if (Data_v == 2)
	{
		strcpy(Dsp_Str, " J PRE  ");
		val_ary[TOP_WIDTH_PERA] = profiler_data[6];
		val_ary[TOP_HEIGHT_PERA] = profiler_data[7];
		val_ary[ROOT_WIDTH_PERA] = profiler_data[8];
	} //

	init_profiler_value();
	draw_function();

	pos = (idx_pos * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
	gtk_label_set_label(GTK_LABEL(dgslabel[1]), Dsp_Str);
}

float mm_to_inch(int mm)
{
 	float oneInch = 25.4f;    // 1 inch = 25.4 mm

	float result = mm / oneInch;

	return result;
}

float inch_to_mm(int inch)
{
	float oneInch = 25.4f;    // 1 inch = 25.4 mm

	float result = inch * oneInch;

	return result;
}

//**************************************************************************************************************************
void Weld_Width_f(int key_t) //  TOP_WIDTH_PERA
{
	int Data_v;
	int idx_pos = TOP_WIDTH_PERA;
	gchar unitm[3] = "mm", uniti[3] = "in";
	float res;

	Data_v = val_ary[idx_pos];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0)
	{
	}

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) //  for key press
	{
		Data_v = Data_v + key_t * (Key_stp);
	}

	if (Data_v < 5)
	{
		Data_v = 5;
	}
	if (Data_v > 200)
	{
		Data_v = 200;
	}

	val_ary[idx_pos] = Data_v;

	init_profiler_value();
	draw_function();

	if(val_ary[UNIT_PERA] == 0)
	{
		// res = mm_to_inch(Data_v);
		sprintf(Dsp_Str, "%d %s", Data_v, unitm);
	}
	else if	(val_ary[UNIT_PERA] == 1)
	{
		// res = inch_to_mm(Data_v);
		sprintf(Dsp_Str, "%d %s", Data_v, uniti);
	}

	pos = (idx_pos * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
	gtk_label_set_label(GTK_LABEL(dgslabel[3]), Dsp_Str);
}

//**************************************************************************************************************************
void Weld_TpHeight_f(int key_t) //  TOP_HEIGHT_PERA
{
	int Data_v;
	int idx_pos = TOP_HEIGHT_PERA;
	Data_v = val_ary[idx_pos];
	gchar unitm[3] = "mm", uniti[3] = "in"; // tmp   Posi Array index of Range  its 3 for Range Value

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
	}

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
	{
		Data_v = Data_v + key_t * (Key_stp);
	}

	if (Data_v < 5)
	{
		Data_v = 5;
	}
	if (Data_v > 99)
	{
		Data_v = 99;
	}
	if (Data_v > val_ary[OBJ_THICK_PERA])
	{
		Data_v = val_ary[OBJ_THICK_PERA];
	}

	val_ary[idx_pos] = Data_v;

	init_profiler_value();
	draw_function();

	if(val_ary[UNIT_PERA] == 0)
		sprintf(Dsp_Str, "%d %s", Data_v, unitm);
	else if	(val_ary[UNIT_PERA] == 1)
		sprintf(Dsp_Str, "%d %s", Data_v, uniti);
	
	pos = (idx_pos * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
	gtk_label_set_label(GTK_LABEL(dgslabel[5]), Dsp_Str);
}

//**************************************************************************************************************************
void Weld_Root_width_f(int key_t) //  ROOT_WIDTH_PERA
{
	int Data_v;
	int idx_pos = ROOT_WIDTH_PERA;
	Data_v = val_ary[idx_pos];
	gchar unitm[3] = "mm", uniti[3] = "in";

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) 	{	}// Get the value from scrollbar

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
	{
		Data_v = Data_v + key_t * (Key_stp);
	}

	if (Data_v < 2)
	{
		Data_v = 2;
	}
	if (Data_v > 99)
	{
		Data_v = 99;
	}
	val_ary[idx_pos] = Data_v;

	init_profiler_value();
	draw_function();

	if(val_ary[UNIT_PERA] == 0)
		sprintf(Dsp_Str, "%d %s", Data_v, unitm);
	else if	(val_ary[UNIT_PERA] == 1)
		sprintf(Dsp_Str, "%d %s", Data_v, uniti);

	pos = (idx_pos * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
	gtk_label_set_label(GTK_LABEL(dgslabel[7]), Dsp_Str);
}

//**************************************************************************************************************************
void Weld_EXT11_f(int key_t) //  EXT_11_PERA
{
	int Data_v;
	int idx_pos = EXT_WELD_PRF_PERA;
	Data_v = val_ary[idx_pos];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
	}

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
	{
		Data_v = Data_v + key_t * (Key_stp);
	}

	if (Data_v < 0)
	{
		Data_v = 0;
	}
	if (Data_v > 99)
	{
		Data_v = 99;
	}
	val_ary[idx_pos] = Data_v;

	sprintf(Dsp_Str, "%d", Data_v);
	pos = (idx_pos * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
	gtk_label_set_label(GTK_LABEL(dgslabel[9]), Dsp_Str);
}

//**************************************************************************************************************************
void Weld_EXT12_f(int key_t) //  EXT_12_PERA
{
	int Data_v;
	int idx_pos = EXT_WELD_PRF_PERA;
	Data_v = val_ary[idx_pos];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
	}

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
	{
		Data_v = Data_v + key_t * (Key_stp);
	}

	if (Data_v < 0)
	{
		Data_v = 0;
	}
	if (Data_v > 99)
	{
		Data_v = 99;
	}
	val_ary[idx_pos] = Data_v;

	sprintf(Dsp_Str, "%d", Data_v);
	pos = (idx_pos * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
	gtk_label_set_label(GTK_LABEL(dgslabel[11]), Dsp_Str);
}

//**************************************************************************************************************************
void Weld_EXT13_f(int key_t) //  EXT_13_PERA
{
	int Data_v;
	int idx_pos = EXT_WELD_PRF_PERA;
	Data_v = val_ary[idx_pos];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
	}

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
	{
		Data_v = Data_v + key_t * (Key_stp);
	}

	if (Data_v < 0)
	{
		Data_v = 0;
	}
	if (Data_v > 99)
	{
		Data_v = 99;
	}
	val_ary[idx_pos] = Data_v;

	sprintf(Dsp_Str, "%d", Data_v);
	pos = (idx_pos * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
	gtk_label_set_label(GTK_LABEL(dgslabel[13]), Dsp_Str);
}

//**************************************************************************************************************************
void Weld_EXT14_f(int key_t) //  EXT_14_PERA
{
	int Data_v;
	int idx_pos = EXT_WELD_PRF_PERA;

	Data_v = val_ary[idx_pos];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
	}

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
	{
		Data_v = Data_v + key_t * (Key_stp);
	}

	if (Data_v < 0)
	{
		Data_v = 0;
	}
	if (Data_v > 99)
	{
		Data_v = 99;
	}
	val_ary[idx_pos] = Data_v;

	sprintf(Dsp_Str, "%d", Data_v);
	pos = (idx_pos * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
	gtk_label_set_label(GTK_LABEL(dgslabel[15]), Dsp_Str);
}

//**************************************************************************************************************************
void Weld_Exit_f(int key_t) //  EXT_21_PERA
{
	// copy_profiler_data();
	copy_shape_data();
	copy_profiler_data();
	copy_rays_data();
	Weld_prf_val = 2;
	val_ary[WELD_PROF_PERA] = Weld_prf_val;
	Weld_Prof_f(0);
}

//**************************************************************************************************************************
void Weld_EXT22_f(int key_t) //  EXT_22_PERA
{
	int Data_v;
	int idx_pos = EXT_22_PERA;
	Data_v = val_ary[idx_pos];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
	}

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
	{
		Data_v = Data_v + key_t * (Key_stp);
	}

	if (Data_v < 0)
	{
		Data_v = 0;
	}
	if (Data_v > 99)
	{
		Data_v = 99;
	}
	val_ary[idx_pos] = Data_v;

	sprintf(Dsp_Str, "%d", Data_v);
	pos = (idx_pos * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
	gtk_label_set_label(GTK_LABEL(dgslabel[19]), Dsp_Str);
}

//**************************************************************************************************************************
void Weld_EXT23_f(int key_t) //  EXT_23_PERA
{
	int Data_v;
	int idx_pos = EXT_23_PERA;
	Data_v = val_ary[idx_pos];

	//**********KEY_SCR = 0*************************
	if (key_scr == 0) // Get the value from scrollbar
	{
	}

	//**********KEY_SCR = 1**************************
	if (key_scr == 1) // Get the value from button keypad
	{
		Data_v = Data_v + key_t * (Key_stp);
	}

	if (Data_v < 0)
	{
		Data_v = 0;
	}
	if (Data_v > 99)
	{
		Data_v = 99;
	}
	val_ary[idx_pos] = Data_v;

	sprintf(Dsp_Str, "%d", Data_v);
	pos = (idx_pos * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
	gtk_label_set_label(GTK_LABEL(dgslabel[21]), Dsp_Str);
}

//**************************************************************************************************************************
void Weld_EXT24_f(int key_t) //  EXT_24_PERA
{
	int Data_v;
	int idx_pos = EXT_24_PERA;
	Data_v = val_ary[idx_pos];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
	}

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
	{
		Data_v = Data_v + key_t * (Key_stp);
	}

	if (Data_v < 0)
	{
		Data_v = 0;
	}
	if (Data_v > 99)
	{
		Data_v = 99;
	}
	val_ary[idx_pos] = Data_v;

	sprintf(Dsp_Str, "%d", Data_v);
	pos = (idx_pos * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
	gtk_label_set_label(GTK_LABEL(dgslabel[23]), Dsp_Str);
}

//***************************************************************************************
void ConcaveCal(double OD, double ID, double angle_pos, double angle_prb)
{
	double sinA, sinB, sinC, angleOfB, dtor;
	char buffer[30];
	// double sd, flsp, fld, flsd;
	/*double sd;*/
	// position angle
	angle_pos = 180.0 - angle_pos;
	angle_pos = (angle_pos * M_PI) / 180.0;

	// probe angle
	angleOfB = 180.0 - angle_prb;
	dtor = (angleOfB * M_PI) / 180.0;

	sinB = sin(dtor);
	sinC = asin((sinB * ID) / OD);
	sinA = 180 - (angleOfB + ((sinC * 180) / M_PI));
	sinA = (sinA * M_PI) / 180.0;

	/*
	printf("concave **************\n\n");
	printf("angleOfB = %lf\n", angleOfB);
	printf("dtor = %lf\n", dtor);
	printf("sinB = %lf\n", sinB);
	printf("sinC = %lf\n", sinC);
	printf("sinA = %lf\n", sinA);
	printf("**************\n\n");
	*/

	// flsp = first leg sound path
	flsp = sqrt((((ID * ID) + (OD * OD)) - (2 * OD * ID * cos(sinA))));
	sd = sqrt(((flsp * flsp) + (ID * ID)) - (2 * ID * flsp * cos(dtor)));
	// fld = first leg depth
	fld = sd - ID;
	/*sprintf(buffer, "%lf", fld);
	gtk_label_set_label(GTK_LABEL(t_label[1]), buffer);*/
	// flsd = first leg surface distance
	flsd = OD * asin((flsp * sin(dtor)) / sd);
}
//***************************************************************************************
void ConvexCal(double OD, double ID, double angle_pos, double angle_prb)
{
	double ratio, dtor, sinA;
	double phi, diff;

	// Position angle
	angle_pos = (angle_pos * M_PI) / 180.0; // Radian = ((angleInDegree * M_PI) / 180.0)

	ratio = OD / ID;
	dtor = ((angle_prb * M_PI) / 180);
	sinA = sin(dtor);

	// Projection angle at ID (first leg)
	phi = asin(ratio * sinA);
	diff = phi - dtor;
	// flsp = first leg sound path
	flsp = ID * (sin(diff) / sinA);
	// fld = first leg depth
	fld = OD - sqrt(((flsp * flsp) + (OD * OD)) - (2 * OD * flsp * cos(dtor)));
	// flsd = first leg surface distance
	flsd = (((M_PI * OD) / 180) * ((diff * 180) / M_PI));
}

//**************************************************************************************************************************
void Tst_Obh_shape_f(int key_t) // OBJ_SHAPE_PERA           //    Test Object Shape Selection
{
	int Data_v;
	int idx_pos = OBJ_SHAPE_PERA;
	pos = (idx_pos * 2) + 1;
	Data_v = val_ary[idx_pos];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
	}

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
	{
		Data_v = Data_v + key_t * (Key_stp);
	}

	if (Data_v < 0)
	{
		Data_v = 0;
	}
	if (Data_v > 3)
	{
		Data_v = 3;
	}
	val_ary[idx_pos] = Data_v;

	strcpy(all_btnval[pos + 3], "THICKNESS ");

	if (Data_v == 0)
	{
		strcpy(Dsp_Str, "  FLAT  ");
		strcpy(all_btnval[pos + 1], " WIDTH ");

		X1_idx = 2;
		Y1_idx = 3;
		X2_idx = 0;
		Y2_idx = 0;
		rw_idx = 4; // Width
		rh_idx = 5; // Thick

		val_ary[OBJ_WIDTH_PERA] = orignal_gtk_shape[0];
		zoom_ratio = zoom_in_out_function(val_ary[PROB_POS_PERA]);
		val_ary[OBJ_THICK_PERA] = orignal_gtk_shape[1];
		val_ary[PROB_POS_PERA] = ray_data[0];
		val_ary[PROBE_ANGLE_PERA] = ray_data[1];
	} // OFF
	else if (Data_v == 1)
	{
		strcpy(Dsp_Str, " CONCAVE ");
		strcpy(all_btnval[pos + 1], "OUT DIA");
		strcpy(all_btnval[pos + 3], "IN DIA");

		X1_idx = 22;
		Y1_idx = 23;
		X2_idx = 32;
		Y2_idx = 33;
		rw_idx = 24; // OD
		rh_idx = 34; // ID

		val_ary[OBJ_WIDTH_PERA] = orignal_gtk_shape[2]; // val_ary[OBJ_WIDTH_PERA] = gtk_shape[24];
		val_ary[OBJ_THICK_PERA] = orignal_gtk_shape[3]; // val_ary[OBJ_THICK_PERA] = gtk_shape[34];
		val_ary[PROB_POS_PERA] = ray_data[2];
		val_ary[PROBE_ANGLE_PERA] = ray_data[3];
	} // DRAW
	else if (Data_v == 2)
	{
		strcpy(Dsp_Str, " CONVEX  ");
		strcpy(all_btnval[pos + 1], "OUT DIA");
		strcpy(all_btnval[pos + 3], "IN DIA");

		X1_idx = 52;
		Y1_idx = 53;
		X2_idx = 62;
		Y2_idx = 63;
		rw_idx = 54; // OD
		rh_idx = 64; // ID

		val_ary[OBJ_WIDTH_PERA] = orignal_gtk_shape[4]; // val_ary[OBJ_WIDTH_PERA] = gtk_shape[54];
		val_ary[OBJ_THICK_PERA] = orignal_gtk_shape[5]; // val_ary[OBJ_THICK_PERA] = gtk_shape[64];
		val_ary[PROB_POS_PERA] = ray_data[4];
		val_ary[PROBE_ANGLE_PERA] = ray_data[5];
	} // ON
	else if (Data_v == 3)
	{
		strcpy(Dsp_Str, " ROD ");
		strcpy(all_btnval[pos + 1], "DIAMETER");
		strcpy(all_btnval[pos + 3], "      ");
		strcpy(all_btnval[pos + 4], "      ");

		X1_idx = 82;
		Y1_idx = 83;
		X2_idx = 0;
		Y2_idx = 0;
		rw_idx = 84; // OD
		rh_idx = 0;	 // ID

		val_ary[OBJ_WIDTH_PERA] = orignal_gtk_shape[6]; // val_ary[OBJ_THICK_PERA] = gtk_shape[84];
		val_ary[PROB_POS_PERA] = ray_data[6];
		val_ary[PROBE_ANGLE_PERA] = ray_data[7];
	} // ON

	// sprintf(Dsp_Str, "%d", Data_v);
	// pos = (idx_pos * 2)+1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
	gtk_label_set_label(GTK_LABEL(dgslabel[9]), Dsp_Str);
	pos = (idx_pos * 2) + 1;
	gtk_label_set_label(GTK_LABEL(dgslabel[10]), all_btnval[pos + 1]);
	gtk_label_set_label(GTK_LABEL(dgslabel[12]), all_btnval[pos + 3]);
	gtk_label_set_label(GTK_LABEL(dgslabel[13]), all_btnval[pos + 4]);

	Obj_width_f(0);
	if (Data_v != 3)
	{
		Obj_thick_f(0);
	}

	init_rays_value();
	init_profiler_value();
	draw_function();
	// Weld_type_f(0);
	// Probe_pos_f(0);
}

//**************************************************************************************************************************

void CurveSurfaceCorrection(void)
{
	if (val_ary[OBJ_SHAPE_PERA] == 1) // Concave
		ConcaveCal(val_ary[OBJ_WIDTH_PERA], val_ary[OBJ_THICK_PERA], val_ary[PROB_POS_PERA], val_ary[PROBE_ANGLE_PERA]);
	// THICKNESS For Concave = 20; OD = 100; ANGLE = 45; -> SP = 48.2, DP = 40, SD=34.75 : - TESTED VALUES
	// THICKNESS For Concave = 10; OD = 80; ANGLE = 45; -> SP = 25.39, DP = 20, SD=18.11 : - TESTED VALUES
	else if (val_ary[OBJ_SHAPE_PERA] == 2) // Convex
		ConvexCal(val_ary[OBJ_WIDTH_PERA], val_ary[OBJ_THICK_PERA], val_ary[PROB_POS_PERA], val_ary[PROBE_ANGLE_PERA]);
	// THICKNESS For Convex = 20; OD = 100; ANGLE = 30; -> SP = 53.43, DP = 40, SD=46.15 : - TESTED VALUES
	// THICKNESS For Convex = 10; OD = 100; ANGLE = 30; -> SP = 24.15, DP = 20, SD=15.15 : - TESTED VALUES

	Measure_v1 = 5;
	Creat_bk_img(8, 1);					 // To Create the Text Spa, Dp, Sd on buttons
	Colour_Theme_Apply(Theme_color_val); // To give theme color on button
										 // g_print("%d, %d, %lf, %lf, %lf\n", val_ary[OBJ_WIDTH_PERA], val_ary[OBJ_THICK_PERA], flsp, fld, flsd);
}

//**************************************************************************************************************************
void Probe_pos_f(int key_t) //  PROB_POS_PERA
{
	int Data_v, range;
	int idx_pos = PROB_POS_PERA;
	Data_v = val_ary[idx_pos];
	gchar unitm[3] = "mm", uniti[3] = "in";

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
	}

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
	{
		Data_v = Data_v + key_t * (Key_stp);
	}

	if (val_ary[OBJ_SHAPE_PERA] == 0)
		range = orignal_gtk_shape[0];
	else if (val_ary[OBJ_SHAPE_PERA] == 1 || val_ary[OBJ_SHAPE_PERA] == 2 || val_ary[OBJ_SHAPE_PERA] == 3)
		range = 360;

	if (Data_v < 0)
	{
		Data_v = 0;
	}
	if (Data_v > range)
	{
		Data_v = range;
	}
	val_ary[idx_pos] = Data_v;

	init_rays_value();
	draw_function();

	if(val_ary[UNIT_PERA] == 0)
		sprintf(Dsp_Str, "%d %s", Data_v - val_ary[WPROF_POS_PERA], unitm);
	else if	(val_ary[UNIT_PERA] == 1)
		sprintf(Dsp_Str, "%d %s", Data_v - val_ary[WPROF_POS_PERA], uniti);
	pos = (idx_pos * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
	gtk_label_set_label(GTK_LABEL(dgslabel[19]), Dsp_Str);
}

//**************************************************************************************************************************
void Probe_angle_f(int key_t) // PROBE_ANGLE_PERA
{
	int Data_v;
	int idx_pos = PROBE_ANGLE_PERA;
	Data_v = val_ary[idx_pos];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
	}

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
	{
		Data_v = Data_v + key_t * (Key_stp);
	}

	if (Data_v < 0)
	{
		Data_v = 0;
	}
	if (Data_v > 90)
	{
		Data_v = 90;
	}
	val_ary[idx_pos] = Data_v;

	CurveSurfaceCorrection();
	init_rays_value();
	draw_function();

	sprintf(Dsp_Str, "%d deg", Data_v);
	pos = (idx_pos * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
	gtk_label_set_label(GTK_LABEL(dgslabel[21]), Dsp_Str);
}

//**************************************************************************************************************************
void NoofLeg_f(int key_t) //  NOOF_LEGv_PERA
{
	int Data_v;
	int idx_pos = NOOF_LEGv_PERA;
	Data_v = val_ary[idx_pos];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
	}

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
	{
		Data_v = Data_v + key_t * (Key_stp);
	}

	if (Data_v < 1)
	{
		Data_v = 1;
	}
	if (Data_v > 4)
	{
		Data_v = 4;
	}
	val_ary[idx_pos] = Data_v;

	init_rays_value();
	draw_function();

	sprintf(Dsp_Str, "%d", Data_v);
	pos = (idx_pos * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
	gtk_label_set_label(GTK_LABEL(dgslabel[23]), Dsp_Str);
}

//**************************************************************************************************************************
double zoom_in_out_function(int val)
{
	zoom_val = 1.0;

	if (val_ary[OBJ_SHAPE_PERA] == 0)
	{
		if (val > 0 && val <= 200)
			zoom_val = 1;
		else if (val > 200 && val <= 400)
			zoom_val = 2;
		else if (val > 400 && val <= 800)
			zoom_val = 4;
		else if (val > 800 && val <= 1600)
			zoom_val = 8;
		else if (val > 1600 && val <= 3200)
			zoom_val = 16;
		else
			zoom_val = 32;
	}
	else
	{
		if (val > 0 && val <= 50)
			zoom_val = 0.5;
		else if (val > 50 && val <= 100)
			zoom_val = 1;
		else if (val > 100 && val <= 200)
			zoom_val = 2;
		else if (val > 200 && val <= 400)
			zoom_val = 4;
		else if (val > 400 && val <= 800)
			zoom_val = 8;
		else if (val > 800 && val <= 1600)
			zoom_val = 16;
		else if (val > 1600 && val <= 3200)
			zoom_val = 32;
		else if (val > 3200)
			zoom_val = 64;
	}

	return (zoom_val);
}

//**************************************************************************************************************************
void Obj_width_f(int key_t) //  WIDTH_PERA   // OD
{
	int Data_v;
	int idx_pos = OBJ_WIDTH_PERA;
	Data_v = val_ary[idx_pos];
	gchar unitm[3] = "mm", uniti[3] = "in";

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
	}

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
	{
		Data_v = Data_v + key_t * (Key_stp);
	}

	if (Data_v < 10)
	{
		Data_v = 10;
	}
	if (Data_v > 3200)
	{
		Data_v = 3200;
	}
	val_ary[idx_pos] = Data_v;

	zoom_ratio = zoom_in_out_function(Data_v);

	if (val_ary[OBJ_SHAPE_PERA] == 0)
	{
		orignal_gtk_shape[0] = val_ary[idx_pos];
		gtk_shape[4] = val_ary[idx_pos] / zoom_ratio;
		gtk_profiler_for_flat_plate();
	}
	else if (val_ary[OBJ_SHAPE_PERA] == 1) // Concave
	{
		if (val_ary[idx_pos] < (gtk_shape[34] + 5)) // IF Od < ID+5 then Make OD ID+5
		{
			val_ary[idx_pos] = (gtk_shape[34] + 5);
			Data_v = val_ary[idx_pos];
		}

		orignal_gtk_shape[2] = val_ary[idx_pos];
		gtk_shape[24] = val_ary[idx_pos] / zoom_ratio;
		gtk_shape[34] = val_ary[OBJ_THICK_PERA] / zoom_ratio;

		// gtk_shape[24] = val_ary[idx_pos]; //  OD
		gtk_profiler_for_hollow_circle();
	}
	else if (val_ary[OBJ_SHAPE_PERA] == 2) // Convex
	{
		if (val_ary[idx_pos] < (gtk_shape[64] + 5)) // IF Od < ID+5 then Make OD ID+5
		{
			val_ary[idx_pos] = (gtk_shape[64] + 5);
			Data_v = val_ary[idx_pos];
		}
		// g_print("* %lf - %d - %d - %d - %d\n", zoom_ratio, val_ary[idx_pos], orignal_gtk_shape[4], gtk_shape[54], gtk_shape[64]);
		orignal_gtk_shape[4] = val_ary[idx_pos];
		gtk_shape[54] = val_ary[idx_pos] / zoom_val;
		gtk_shape[64] = val_ary[OBJ_THICK_PERA] / zoom_val;
		// g_print("# %lf - %d - %d - %d - %d\n", zoom_ratio, val_ary[idx_pos], orignal_gtk_shape[4], gtk_shape[54], gtk_shape[64]);
		// gtk_shape[54] = val_ary[idx_pos]; //  OD
		gtk_profiler_for_hollow_circle();
	}
	else // ROD
	{
		orignal_gtk_shape[6] = val_ary[idx_pos];
		gtk_shape[84] = val_ary[idx_pos] / zoom_ratio;
		gtk_profiler_for_solid_rod();
	}

	if(val_ary[UNIT_PERA] == 0)
		sprintf(Dsp_Str, "%d %s", Data_v, unitm);
	else if	(val_ary[UNIT_PERA] == 1)
		sprintf(Dsp_Str, "%d %s", Data_v, uniti);
	pos = (idx_pos * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
	gtk_label_set_label(GTK_LABEL(dgslabel[11]), Dsp_Str);

	CurveSurfaceCorrection();
	init_rays_value();
	draw_function();
	// Weld_type_f(0);
}

//**************************************************************************************************************************
void Obj_thick_f(int key_t) //  OBJ_THICK_PERA    ID
{
	int Data_v;
	int idx_pos = OBJ_THICK_PERA; // Thickness/OD
	Data_v = val_ary[idx_pos];
	pos = (idx_pos * 2) + 1;
	gchar unitm[3] = "mm", uniti[3] = "in";

	if (val_ary[OBJ_SHAPE_PERA] == 3)
	{
		key_t = 0;
	} // If Shape is ROD selected then Thickness is not used so inc/dec to be bypass

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
	}

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
	{
		Data_v = Data_v + key_t * (Key_stp);
	}

	if (Data_v < 5)
	{
		Data_v = 5;
	}
	if (Data_v > 3195)
	{
		Data_v = 3195;
	}
	val_ary[idx_pos] = Data_v;

	if (val_ary[OBJ_SHAPE_PERA] == 0)
	{
		zoom_ratio = zoom_in_out_function(Data_v);

		orignal_gtk_shape[1] = val_ary[idx_pos];
		gtk_shape[5] = val_ary[idx_pos] / zoom_ratio;
		gtk_profiler_for_flat_plate();
	}
	else if (val_ary[OBJ_SHAPE_PERA] == 1)
	{
		if (val_ary[idx_pos] > (val_ary[OBJ_WIDTH_PERA] - 5)) // IF ID > OD-5 then Make ID=OD-5
		{
			val_ary[idx_pos] = (val_ary[OBJ_WIDTH_PERA] - 5);
			Data_v = val_ary[idx_pos];
		}

		orignal_gtk_shape[3] = val_ary[idx_pos];
		gtk_shape[34] = val_ary[idx_pos] / zoom_ratio; // gtk_shape[34] = val_ary[idx_pos]; // gtk_shape[24] = val_ary[idx_pos];
		gtk_profiler_for_hollow_circle();
	}
	else if (val_ary[OBJ_SHAPE_PERA] == 2)
	{
		if (val_ary[idx_pos] > (val_ary[OBJ_WIDTH_PERA] - 5)) // IF ID > OD-5 then Make ID=OD-5
		{
			val_ary[idx_pos] = (val_ary[OBJ_WIDTH_PERA] - 5);
			Data_v = val_ary[idx_pos];
		}

		orignal_gtk_shape[5] = val_ary[idx_pos];
		gtk_shape[64] = val_ary[idx_pos] / zoom_val; // gtk_shape[64] = val_ary[idx_pos]; // gtk_shape[54] =val_ary[idx_pos];
		gtk_profiler_for_hollow_circle();
	}
	else if (val_ary[OBJ_SHAPE_PERA] == 3)
	{
		// Nothing to do task here
	}

	if(val_ary[UNIT_PERA] == 0)
		sprintf(Dsp_Str, "%d %s", Data_v, unitm);
	else if	(val_ary[UNIT_PERA] == 1)
		sprintf(Dsp_Str, "%d %s", Data_v, uniti);

	if (val_ary[OBJ_SHAPE_PERA] == 3)
	{
		sprintf(Dsp_Str, "       "); // strcpy(all_btnval[pos - 1], "        ");
	}

	pos = (idx_pos * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
	gtk_label_set_label(GTK_LABEL(dgslabel[13]), Dsp_Str);

	CurveSurfaceCorrection();
	init_rays_value();
	draw_function();
	// Probe_angle_f(0);
	// pos = (idx_pos * 2)+1;
	// gtk_label_set_label(GTK_LABEL(dgslabel[12]), all_btnval[pos+3]);
	// Weld_type_f(0);
}

//**************************************************************************************************************************
void Obj_EXT33_f(int key_t) //  EXT_33_PERA
{
	int Data_v;
	int idx_pos = EXT_33_PERA;
	//    Data_v = val_ary[idx_pos];
	////**********KEY_SCR = 0*********************
	// if (key_scr == 0)
	//     {}
	////**********KEY_SCR = 1*********************
	// if (key_scr == 1)//  for key press
	//  { 	Data_v = Data_v + key_t*(Key_stp);
	//   }
	//
	// if (Data_v < 0) { Data_v = 0; } if (Data_v > 99) { Data_v = 99; }
	//	val_ary[idx_pos] = Data_v;

	//   if (val_ary[OBJ_SHAPE_PERA] == 1)
	//	gtk_shape[24] = val_ary[idx_pos];
	// else if (val_ary[OBJ_SHAPE_PERA] == 2)
	//	gtk_shape[54] = val_ary[idx_pos];
	// else if (val_ary[OBJ_SHAPE_PERA] == 3)
	//{
	//	gtk_shape[84] = val_ary[idx_pos];
	//	gtk_rays_for_solid_rod();
	//}

	// gtk_profiler_for_hollow_circle();

	// draw_function();
	// sprintf(Dsp_Str, "%d", Data_v);
	// pos = (idx_pos * 2)+1;
	// strcpy(all_btnval[pos], Dsp_Str);  pos=pos % 10;
	// gtk_label_set_label(GTK_LABEL(dgslabel[13]), Dsp_Str);
}

//**************************************************************************************************************************
void Obj_EXT34_f(int key_t) //  EXT_34_PERA
{
	int Data_v;
	int idx_pos = EXT_34_PERA;
	//    Data_v = val_ary[idx_pos];
	////**********KEY_SCR = 0*********************
	// if (key_scr == 0)
	//     {}
	////**********KEY_SCR = 1*********************
	// if (key_scr == 1)//  for key press
	//  { 	Data_v = Data_v + key_t*(Key_stp);
	//   }
	//
	// if (Data_v < 0) { Data_v = 0; } if (Data_v > 99) { Data_v = 99; }
	//	val_ary[idx_pos] = Data_v;

	// if (val_ary[OBJ_SHAPE_PERA] == 1)
	//	gtk_shape[34] = val_ary[idx_pos];
	// else if (val_ary[OBJ_SHAPE_PERA] == 2)
	//	gtk_shape[64] = val_ary[idx_pos];

	// gtk_profiler_for_hollow_circle();
	// draw_function();

	// sprintf(Dsp_Str, "%d", Data_v);
	// pos = (idx_pos * 2)+1;
	// strcpy(all_btnval[pos], Dsp_Str);  pos=pos % 10;
	// gtk_label_set_label(GTK_LABEL(dgslabel[15]), Dsp_Str);
}

//**************************************************************************************************************************

void Obj_Exit_f(int key_t) //  EXT_42_PERA
{
	copy_shape_data();
	copy_profiler_data();
	copy_rays_data();
}

//**************************************************************************************************************************
void Obj_Wprof_pos_f(int key_t) //  EXT_42_PERA
{
	int Data_v;
	int idx_pos = WPROF_POS_PERA;
	Data_v = val_ary[idx_pos];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
	}

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
	{
		Data_v = Data_v + key_t; //*(Key_stp);
	}

	val_ary[idx_pos] = Data_v;
	// gtk_profiler_for_flat_plate();

	if (val_ary[OBJ_SHAPE_PERA] == 0)
	{
		/*if (Data_v < val_ary[TOP_WIDTH_PERA]) { Data_v = val_ary[TOP_WIDTH_PERA]; }
		if (Data_v > (val_ary[WIDTH_PERA] - val_ary[TOP_WIDTH_PERA])) { Data_v = (val_ary[WIDTH_PERA] - val_ary[TOP_WIDTH_PERA]); }
			val_ary[idx_pos] = Data_v;*/
		gtk_profiler_for_flat_plate();
	}
	else if (val_ary[OBJ_SHAPE_PERA] == 1 || val_ary[OBJ_SHAPE_PERA] == 2 || val_ary[OBJ_SHAPE_PERA] == 3)
	{
		/*if (Data_v < 0) { Data_v = 359; } if (Data_v > 359) { Data_v = 0; }
			val_ary[idx_pos] = Data_v;*/

		if (val_ary[OBJ_SHAPE_PERA] == 1 || val_ary[OBJ_SHAPE_PERA] == 2)
			gtk_profiler_for_hollow_circle();
		else if (val_ary[OBJ_SHAPE_PERA] == 3)
			gtk_profiler_for_solid_rod();
	}
	draw_function();

	sprintf(Dsp_Str, "%d", Data_v);
	pos = (idx_pos * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
	gtk_label_set_label(GTK_LABEL(dgslabel[15]), Dsp_Str);
}

//**************************************************************************************************************************
void Obj_EXT43_f(int key_t) //  EXT_43_PERA
{
	int Data_v;
	int idx_pos = EXT_43_PERA;
	Data_v = val_ary[idx_pos];
	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
	}
	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
	{
		Data_v = Data_v + key_t * (Key_stp);
	}

	if (Data_v < 0)
	{
		Data_v = 0;
	}
	if (Data_v > 99)
	{
		Data_v = 99;
	}
	val_ary[idx_pos] = Data_v;

	sprintf(Dsp_Str, "%d", Data_v);
	pos = (idx_pos * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
	gtk_label_set_label(GTK_LABEL(dgslabel[21]), Dsp_Str);
}

//**************************************************************************************************************************
void Obj_EXT44_f(int key_t) //  EXT_44_PERA
{
	int Data_v;
	int idx_pos = EXT_44_PERA;
	Data_v = val_ary[idx_pos];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
	}

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
	{
		Data_v = Data_v + key_t * (Key_stp);
	}

	if (Data_v < 0)
	{
		Data_v = 0;
	}
	if (Data_v > 99)
	{
		Data_v = 99;
	}
	val_ary[idx_pos] = Data_v;

	sprintf(Dsp_Str, "%d", Data_v);
	pos = (idx_pos * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
	gtk_label_set_label(GTK_LABEL(dgslabel[23]), Dsp_Str);
}

//**************************************************************************************************************************
void Beam_Prof_PDia_f(int key_t) // BEAM_PROFILE_PERA             // Probe Dia
{
	char *unitm[] = {" mm"}, *uniti[] = {" in"};
	gtk_adjustment_set_lower(adj, 0);
	gtk_adjustment_set_upper(adj, 100);
	int ndgt = 1;

	int Data_v;
	int idx_pos = BEAM_PrbDia_PERA;
	Data_v = val_ary[idx_pos];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
	}

	//**********KEY_SCR = 1*********************
	//  if(Scal_v == 0)   // If Custom then ey value is ok else make it to zero so only valy get update in display
	{
		if (key_scr == 1) // Get the value from button keypad
		{
			// D_efect_vC = val_ary[D_EFECT_PERA];
			if (Unit_v == INCH)
			{
				Data_v = Data_v + (key_t * Key_stp);
				if (Data_v > 1200)
				{
					Data_v = 1200;
				}
				if (Data_v < 200)
				{
					Data_v = 200;
				}
			}
			else // UNit is mm
			{
				Data_v = Data_v + (key_t * Key_stp);
				if (Data_v > 300)
				{
					Data_v = 300;
				}
				if (Data_v < 50)
				{
					Data_v = 50;
				}
			}
			val_ary[idx_pos] = Data_v;
		}
	}

	pos = (idx_pos * 2) + 1;
	// pos=181;
	if (Unit_v == INCH)
	{
		toarry(Data_v, pos, 0, 3, uniti[0]);
	}
	else
	{
		toarry(Data_v, pos, 0, 1, unitm[0]);
	}

	strcpy(all_btnval[pos], Dsp_Str);
	// gtk_label_set_label(GTK_LABEL(dgslabel[9]), Dsp_Str);
	gtk_label_set_label(GTK_LABEL(dgslabel[1]), Dsp_Str);

	Beam_Profile_Cal_f(); // Calculate Near Field Value and Angle
	Nearfield = true;
	draw_function();
}

//**************************************************************************************************************************
void Beam_Prof_PFreq_f(int key_t) // BEAM_PRF_P12_PERA     // Probe Frequency
{
	char *unitm[] = {"Mhz"};
	gtk_adjustment_set_lower(adj, 0);
	gtk_adjustment_set_upper(adj, 100);
	int ndgt = 1;

	int Data_v;
	int idx_pos = BEAM_PrbFreq_PERA;
	Data_v = val_ary[idx_pos];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
	}

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
	{
		Data_v = Data_v + (key_t * Key_stp);
		if (Data_v > 2000)
		{
			Data_v = 2000;
		}
		if (Data_v < 25)
		{
			Data_v = 25;
		}
		val_ary[idx_pos] = Data_v;
	}

	pos = (idx_pos * 2) + 1;
	toarry(Data_v, pos, 0, 2, unitm[0]);
	strcpy(all_btnval[pos], Dsp_Str);
	gtk_label_set_label(GTK_LABEL(dgslabel[3]), Dsp_Str);

	Beam_Profile_Cal_f(); // Calculate Near Field Value and Angle
	Nearfield = true;
	draw_function();
}

//**************************************************************************************************************************
//**************************************************************************************************************************
void Beam_Profile_Cal_f() // Calculate Near Field Value and Angle
{
	char buffer[40];
	int Prb_Dia_v, Prb_freq_v, x, Rng, Dly, Nfl;
	double Ang, Beamdv, Prb_Beam_DivAngle, Ht, Degrees; // Prb_Near_field,Prb_div_Ht;

	Rng = val_ary[RANGE_PERA];
	Prb_Dia_v = val_ary[BEAM_PrbDia_PERA];
	Prb_freq_v = val_ary[BEAM_PrbFreq_PERA];
	Mtlvel_val = val_ary[VELO_PERA];
	Dly = val_ary[DELAY_PERA];

	Prb_Near_field = (Prb_Dia_v * Prb_Dia_v * Prb_freq_v * 10) / (4 * Mtlvel_val); // N=D*D *f /(4*V)
	Prb_Near_field_v = Prb_Near_field / 100;
	Prb_Near_field = Prb_Near_field - Dly;
	// Beam Divergence Sin a= (k* V) /(DF)
	Ang = (0.514 * Mtlvel_val * 1000) / (Prb_Dia_v * Prb_freq_v);
	// Ang=(0.514*Mtlvel_val)/(Prb_Dia_v*Prb_freq_v*1000);
	// Prb_Beam_DivAngle=Ang*1000;                                   //   K=0.514 for 50% (-6dB) intensity edge
	Beamdv = asin(Ang / 1000); //   K=1.08 for 10% (-20dB) intensity edge //   K=1.22 for 0% intensity edge... // Ht=200*tan(Beamdv);
	Beam_dv_angle_v = Beamdv * 180.0f / 3.14159265359f;
	x = (Prb_Near_field * Asc_Width) / Rng; // Calculate postion of Near field for the Drawing on LCD
	if (x > Asc_Width)
	{
		x = Asc_Width; // Also Consider Probe Zero and Delay
	}
	Prb_Near_field = x;

	x = Asc_Width - x;
	if (x < 0)
	{
		x = 0;
	}

	Ht = x * tan(Beamdv); // Based on Divergent Angle find the point
	Prb_div_Ht = Ht;

	//   x=Ht;               //x=Prb_Near_field;
	//   sprintf(buffer,"Ht=%d",x);  gtk_label_set_label(GTK_LABEL(t_label[0]), buffer);
	//   x=Nfl;
	//   sprintf(buffer,"Nf=%d",x);  gtk_label_set_label(GTK_LABEL(t_label[1]), buffer);
	//   x=Degrees*100;
	//   sprintf(buffer," %d",x);    gtk_label_set_label(GTK_LABEL(t_label[2]), buffer);

	// Nearfield=true;
	// draw_function();
}

//**************************************************************************************************************************
void Beam_Prof_p13_f(int key_t) // BEAM_PRF_P13_PERA
{
	int Data_v;
	int idx_pos = BEAM_PRF_P13_PERA;
	Data_v = val_ary[idx_pos];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
	}

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
	{
		Data_v = Data_v + key_t * (Key_stp);
	}

	if (Data_v < 0)
	{
		Data_v = 0;
	}
	if (Data_v > 99)
	{
		Data_v = 99;
	}
	val_ary[idx_pos] = Data_v;

	sprintf(Dsp_Str, "%d", Data_v);
	pos = (idx_pos * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
	gtk_label_set_label(GTK_LABEL(dgslabel[5]), Dsp_Str);
}

//**************************************************************************************************************************
void Beam_Prof_p14_f(int key_t) // BEAM_PRF_P14_PERA
{
	int Data_v;
	int idx_pos = BEAM_PRF_P14_PERA;
	Data_v = val_ary[idx_pos];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
	}

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
	{
		Data_v = Data_v + key_t * (Key_stp);
	}

	if (Data_v < 0)
	{
		Data_v = 0;
	}
	if (Data_v > 99)
	{
		Data_v = 99;
	}
	val_ary[idx_pos] = Data_v;

	sprintf(Dsp_Str, "%d", Data_v);
	pos = (idx_pos * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
	gtk_label_set_label(GTK_LABEL(dgslabel[7]), Dsp_Str);
}

//**************************************************************************************************************************
void Beam_Prof_p21_f(int key_t) // BEAM_PRF_P21_PERA
{
	int Data_v;
	int idx_pos = BEAM_PRF_P21_PERA;
	Data_v = val_ary[idx_pos];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
	}

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
	{
		Data_v = Data_v + key_t * (Key_stp);
	}

	if (Data_v < 0)
	{
		Data_v = 0;
	}
	if (Data_v > 99)
	{
		Data_v = 99;
	}
	val_ary[idx_pos] = Data_v;

	sprintf(Dsp_Str, "%d", Data_v);
	pos = (idx_pos * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
	gtk_label_set_label(GTK_LABEL(dgslabel[9]), Dsp_Str);
}

//**************************************************************************************************************************
void Beam_Prof_p22_f(int key_t) // BEAM_PRF_P22_PERA
{
	int Data_v;
	int idx_pos = BEAM_PRF_P22_PERA;
	Data_v = val_ary[idx_pos];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
	}

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
	{
		Data_v = Data_v + key_t * (Key_stp);
	}

	if (Data_v < 0)
	{
		Data_v = 0;
	}
	if (Data_v > 99)
	{
		Data_v = 99;
	}
	val_ary[idx_pos] = Data_v;

	sprintf(Dsp_Str, "%d", Data_v);
	pos = (idx_pos * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
	gtk_label_set_label(GTK_LABEL(dgslabel[11]), Dsp_Str);
}

//**************************************************************************************************************************
void Beam_Prof_p23_f(int key_t) // BEAM_PRF_P23_PERA
{
	int Data_v;
	int idx_pos = BEAM_PRF_P23_PERA;
	Data_v = val_ary[idx_pos];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
	}

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
	{
		Data_v = Data_v + key_t * (Key_stp);
	}

	if (Data_v < 0)
	{
		Data_v = 0;
	}
	if (Data_v > 99)
	{
		Data_v = 99;
	}
	val_ary[idx_pos] = Data_v;

	sprintf(Dsp_Str, "%d", Data_v);
	pos = (idx_pos * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
	gtk_label_set_label(GTK_LABEL(dgslabel[13]), Dsp_Str);
}

//**************************************************************************************************************************
void Beam_Prof_p24_f(int key_t) // BEAM_PRF_P24_PERA
{
	int Data_v;
	int idx_pos = BEAM_PRF_P24_PERA;
	Data_v = val_ary[idx_pos];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
	}

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
	{
		Data_v = Data_v + key_t * (Key_stp);
	}

	if (Data_v < 0)
	{
		Data_v = 0;
	}
	if (Data_v > 99)
	{
		Data_v = 99;
	}
	val_ary[idx_pos] = Data_v;

	sprintf(Dsp_Str, "%d", Data_v);
	pos = (idx_pos * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
	gtk_label_set_label(GTK_LABEL(dgslabel[15]), Dsp_Str);
}

//**************************************************************************************************************************
void Beam_Prof_Exit_f(int key_t) // BEAM_PRF_P31_PERA
{
	int Data_v;
	int idx_pos = BEAM_PRF_P31_PERA;
	Data_v = val_ary[idx_pos];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
	}

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
	{
		Data_v = Data_v + key_t * (Key_stp);
	}

	if (Data_v < 0)
	{
		Data_v = 0;
	}
	if (Data_v > 99)
	{
		Data_v = 99;
	}
	val_ary[idx_pos] = Data_v;

	sprintf(Dsp_Str, "%d", Data_v);
	pos = (idx_pos * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
	gtk_label_set_label(GTK_LABEL(label_dv[pos]), Dsp_Str);
}

//**************************************************************************************************************************
void Beam_Prof_p32_f(int key_t) // BEAM_PRF_P32_PERA
{
	int Data_v;
	int idx_pos = BEAM_PRF_P32_PERA;
	Data_v = val_ary[idx_pos];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
	}

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
	{
		Data_v = Data_v + key_t * (Key_stp);
	}

	if (Data_v < 0)
	{
		Data_v = 0;
	}
	if (Data_v > 99)
	{
		Data_v = 99;
	}
	val_ary[idx_pos] = Data_v;

	sprintf(Dsp_Str, "%d", Data_v);
	pos = (idx_pos * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
	gtk_label_set_label(GTK_LABEL(dgslabel[19]), Dsp_Str);
}

//**************************************************************************************************************************
void Beam_Prof_p33_f(int key_t) // BEAM_PRF_P33_PERA
{
	int Data_v;
	int idx_pos = BEAM_PRF_P33_PERA;
	Data_v = val_ary[idx_pos];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
	}

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
	{
		Data_v = Data_v + key_t * (Key_stp);
	}

	if (Data_v < 0)
	{
		Data_v = 0;
	}
	if (Data_v > 99)
	{
		Data_v = 99;
	}
	val_ary[idx_pos] = Data_v;

	sprintf(Dsp_Str, "%d", Data_v);
	pos = (idx_pos * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
	gtk_label_set_label(GTK_LABEL(dgslabel[21]), Dsp_Str);
}

//**************************************************************************************************************************
void Beam_Prof_p34_f(int key_t) // BEAM_PRF_P34_PERA
{
	int Data_v;
	int idx_pos = BEAM_PRF_P34_PERA;
	Data_v = val_ary[idx_pos];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
	}

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
	{
		Data_v = Data_v + key_t * (Key_stp);
	}

	if (Data_v < 0)
	{
		Data_v = 0;
	}
	if (Data_v > 99)
	{
		Data_v = 99;
	}
	val_ary[idx_pos] = Data_v;

	sprintf(Dsp_Str, "%d", Data_v);
	pos = (idx_pos * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
	gtk_label_set_label(GTK_LABEL(dgslabel[23]), Dsp_Str);
}

//**************************************************************************************************************************
void Thk_File_type_f(int key_t) //  THKFILE_TYPE_PERA           // Thickness file type Selection
{
	int Data_v;
	int idx_pos = THKFILE_TYPE_PERA;
	Data_v = val_ary[idx_pos];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
	}

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
	{
		Data_v = Data_v + key_t * (Key_stp);
	}

	if (Data_v < 0)
	{
		Data_v = 0;
	}
	if (Data_v > 1)
	{
		Data_v = 1;
	}
	val_ary[idx_pos] = Data_v;

	if (Data_v == 0)
	{
		thk_dim_type = Data_v;
		strcpy(Dsp_Str, " 1 DIM   ");
	} // ON
	if (Data_v == 1)
	{
		thk_dim_type = Data_v;
		strcpy(Dsp_Str, " 2 DIM   ");
	} // ON
	if (Data_v == 2)
	{
		thk_dim_type = Data_v;
		strcpy(Dsp_Str, " 3 DIM   ");
	} // ON

	// sprintf(Dsp_Str, "%d", Data_v);
	pos = (idx_pos * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
	gtk_label_set_label(GTK_LABEL(dgslabel[1]), Dsp_Str);
}

//**************************************************************************************************************************
void Start_ID_1_f(int key_t) //  START_ID_1_PERA
{
	char id_buff[8] = "   AAAA";

	int Data_v;
	int idx_pos = START_ID_1_PERA;
	Data_v = val_ary[idx_pos];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
	}

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
	{
		Data_v = Data_v + key_t * (Key_stp);
	}

	if (Data_v < 0)
	{
		Data_v = 0;
	}
	if (Data_v > 999)
	{
		Data_v = 999;
	}
	val_ary[idx_pos] = Data_v;

	// sprintf(Dsp_Str, "%d", Data_v);

	create_display_id(&id_buff[0], &sID1[3], Data_v);
	Dim_1_size_f(0);

	pos = (idx_pos * 2) + 1;
	// strcpy(all_btnval[pos], Dsp_Str);
	strcpy(all_btnval[pos], sID1);
	pos = pos % 10;
	// gtk_label_set_label(GTK_LABEL(dgslabel[3]), Dsp_Str);
	gtk_label_set_label(GTK_LABEL(dgslabel[3]), sID1);
}

//**************************************************************************************************************************
void Start_ID_2_f(int key_t) //  START_ID_2_PERA
{
	char id_buff[8] = "   AAAA";

	int Data_v;
	int idx_pos = START_ID_2_PERA;
	Data_v = val_ary[idx_pos];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
	}

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
	{
		Data_v = Data_v + key_t * (Key_stp);
	}

	if (Data_v < 0)
	{
		Data_v = 0;
	}
	if (Data_v > 999)
	{
		Data_v = 999;
	}
	val_ary[idx_pos] = Data_v;

	create_display_id(&id_buff[0], &sID2[3], Data_v);
	Dim_2_size_f(0);

	// sprintf(Dsp_Str, "%d", Data_v);
	pos = (idx_pos * 2) + 1;
	// strcpy(all_btnval[pos], Dsp_Str);
	strcpy(all_btnval[pos], sID2);
	pos = pos % 10;
	// gtk_label_set_label(GTK_LABEL(dgslabel[5]), Dsp_Str);
	gtk_label_set_label(GTK_LABEL(dgslabel[5]), sID2);
}

//**************************************************************************************************************************
void Start_ID_3_f(int key_t) //  START_ID_3_PERA
{
	char id_buff[8] = "   AAAA";

	int Data_v;
	int idx_pos = START_ID_3_PERA;
	Data_v = val_ary[idx_pos];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
	}

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
	{
		Data_v = Data_v + key_t * (Key_stp);
	}

	if (Data_v < 0)
	{
		Data_v = 0;
	}
	if (Data_v > 999)
	{
		Data_v = 999;
	}
	val_ary[idx_pos] = Data_v;

	create_display_id(&id_buff[0], &sID3[3], Data_v);
	Dim_3_size_f(0);

	// sprintf(Dsp_Str, "%d", Data_v);
	pos = (idx_pos * 2) + 1;
	// strcpy(all_btnval[pos], Dsp_Str);
	strcpy(all_btnval[pos], sID3);
	pos = pos % 10;
	// gtk_label_set_label(GTK_LABEL(dgslabel[7]), Dsp_Str);
	gtk_label_set_label(GTK_LABEL(dgslabel[7]), sID3);
}

//**************************************************************************************************************************

void Thk_EXT_51_f(int key_t) //  EXT_51_PERA
{
	// int Data_v;
	// int idx_pos = EXT_51_PERA;
	// Data_v = val_ary[idx_pos];
	// //**********KEY_SCR = 0*********************
	// if (key_scr == 0)
	// {
	// }
	// //**********KEY_SCR = 1*********************
	// if (key_scr == 1) //  for key press
	// {
	// 	Data_v = Data_v + key_t * (Key_stp);
	// }

	// if (Data_v < 0)
	// {
	// 	Data_v = 0;
	// }
	// if (Data_v > 99)
	// {
	// 	Data_v = 99;
	// }
	// val_ary[idx_pos] = Data_v;

	// sprintf(Dsp_Str, "%d", Data_v);
	// pos = (idx_pos * 2) + 1;
	// strcpy(all_btnval[pos], Dsp_Str);
	// pos = pos % 10;
	// gtk_label_set_label(GTK_LABEL(dgslabel[9]), Dsp_Str);
}

//**************************************************************************************************************************
void END_ID_1_f(int key_t) //  END_ID_1_PERA
{
	char id_buff[8] = "   AAAA";

	int Data_v;
	int idx_pos = END_ID_1_PERA;
	Data_v = val_ary[idx_pos];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
	}

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
	{
		Data_v = Data_v + key_t * (Key_stp);
	}

	if (Data_v < 0)
	{
		Data_v = 0;
	}
	if (Data_v > 999)
	{
		Data_v = 999;
	}
	val_ary[idx_pos] = Data_v;

	create_display_id(&id_buff[0], &eID1[3], Data_v);
	Dim_1_size_f(0);

	// sprintf(Dsp_Str, "%d", Data_v);
	pos = (idx_pos * 2) + 1;
	// strcpy(all_btnval[pos], Dsp_Str);
	strcpy(all_btnval[pos], eID1);
	pos = pos % 10;
	// gtk_label_set_label(GTK_LABEL(dgslabel[11]), Dsp_Str);
	gtk_label_set_label(GTK_LABEL(dgslabel[11]), eID1);
}

//**************************************************************************************************************************
void END_ID_2_f(int key_t) //  END_ID_2_PERA
{
	char id_buff[8] = "   AAAA";

	int Data_v;
	int idx_pos = END_ID_2_PERA;
	Data_v = val_ary[idx_pos];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
	}

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
	{
		Data_v = Data_v + key_t * (Key_stp);
	}

	if (Data_v < 0)
	{
		Data_v = 0;
	}
	if (Data_v > 999)
	{
		Data_v = 999;
	}
	val_ary[idx_pos] = Data_v;

	create_display_id(&id_buff[0], &eID2[3], Data_v);
	Dim_2_size_f(0);

	// sprintf(Dsp_Str, "%d", Data_v);
	pos = (idx_pos * 2) + 1;
	strcpy(all_btnval[pos], eID2);
	// strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
	// gtk_label_set_label(GTK_LABEL(dgslabel[13]), Dsp_Str);
	gtk_label_set_label(GTK_LABEL(dgslabel[13]), eID2);
}

//**************************************************************************************************************************
void END_ID_3_f(int key_t) //  END_ID_3_PERA
{
	char id_buff[8] = "   AAAA";

	int Data_v;
	int idx_pos = END_ID_3_PERA;
	Data_v = val_ary[idx_pos];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
	}

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
	{
		Data_v = Data_v + key_t * (Key_stp);
	}

	if (Data_v < 0)
	{
		Data_v = 0;
	}
	if (Data_v > 999)
	{
		Data_v = 999;
	}
	val_ary[idx_pos] = Data_v;

	create_display_id(&id_buff[0], &eID3[3], Data_v);

	Dim_3_size_f(0);

	// sprintf(Dsp_Str, "%d", Data_v);
	pos = (idx_pos * 2) + 1;
	// strcpy(all_btnval[pos], Dsp_Str);
	strcpy(all_btnval[pos], eID3);

	pos = pos % 10;
	// gtk_label_set_label(GTK_LABEL(dgslabel[15]), Dsp_Str);
	gtk_label_set_label(GTK_LABEL(dgslabel[15]), eID3);
}

//**************************************************************************************************************************
void Thk_File_Exit_f(int key_t) //  EXIT_PERA
{
	frame_type_num = -1;
	// if(key_t == 1 || key_t == -1)
	//{   menu_v=Menu_pre;
	//	gtk_widget_hide(f2_box);       // DGS Menu Exit
	// }
	//{
	//	gtk_widget_set_can_focus(GTK_WIDGET(btn_dv[1]), true);
	//	gtk_widget_grab_focus(GTK_WIDGET(btn_dv[1]));
	//	gtk_widget_set_name(btn_dv[1], "btnv1_1-entry");
	// }
	//   ogl.oglrecreate_flag = false;
	// recreate_surface(0, width_sh, height_sh, ogl_x_position, ogl_y_position);
	// gl_clear_color_background_data(width_sh, height_sh);
	// ogl_render(width_sh, height_sh);
	//   menu_v=Menu_pre;
}

//**************************************************************************************************************************
void set_color_to_id(int btn_idx, int Data_v)
{
	char buffer[16];

	sprintf(buffer, "color%03d", Data_v);
	gtk_widget_set_name(dgs_btn[btn_idx], buffer);

	/*
	if (Data_v == 0)
		gtk_widget_set_name(dgs_btn[btn_idx], "color000");
	if (Data_v == 1)
		gtk_widget_set_name(dgs_btn[btn_idx], "color001");
	if (Data_v == 2)
		gtk_widget_set_name(dgs_btn[btn_idx], "color002");
	if (Data_v == 3)
		gtk_widget_set_name(dgs_btn[btn_idx], "color003");
	if (Data_v == 4)
		gtk_widget_set_name(dgs_btn[btn_idx], "color004");
	if (Data_v == 5)
		gtk_widget_set_name(dgs_btn[btn_idx], "color005");
	if (Data_v == 6)
		gtk_widget_set_name(dgs_btn[btn_idx], "color006");
	if (Data_v == 7)
		gtk_widget_set_name(dgs_btn[btn_idx], "color007");
	if (Data_v == 8)
		gtk_widget_set_name(dgs_btn[btn_idx], "color008");
	if (Data_v == 9)
		gtk_widget_set_name(dgs_btn[btn_idx], "color009");
	if (Data_v == 10)
		gtk_widget_set_name(dgs_btn[btn_idx], "color010");
	if (Data_v == 11)
		gtk_widget_set_name(dgs_btn[btn_idx], "color011");
	if (Data_v == 12)
		gtk_widget_set_name(dgs_btn[btn_idx], "color012");
	if (Data_v == 13)
		gtk_widget_set_name(dgs_btn[btn_idx], "color013");
	if (Data_v == 14)
		gtk_widget_set_name(dgs_btn[btn_idx], "color014");
	if (Data_v == 15)
		gtk_widget_set_name(dgs_btn[btn_idx], "color015");
	if (Data_v == 16)
		gtk_widget_set_name(dgs_btn[btn_idx], "color016");
	if (Data_v == 17)
		gtk_widget_set_name(dgs_btn[btn_idx], "color017");
	if (Data_v == 18)
		gtk_widget_set_name(dgs_btn[btn_idx], "color018");
	if (Data_v == 19)
		gtk_widget_set_name(dgs_btn[btn_idx], "color019");
	if (Data_v == 20)
		gtk_widget_set_name(dgs_btn[btn_idx], "color020");
	if (Data_v == 21)
		gtk_widget_set_name(dgs_btn[btn_idx], "color021");
	if (Data_v == 22)
		gtk_widget_set_name(dgs_btn[btn_idx], "color022");
	if (Data_v == 23)
		gtk_widget_set_name(dgs_btn[btn_idx], "color023");
	if (Data_v == 24)
		gtk_widget_set_name(dgs_btn[btn_idx], "color024");
	if (Data_v == 25)
		gtk_widget_set_name(dgs_btn[btn_idx], "color025");
	if (Data_v == 26)
		gtk_widget_set_name(dgs_btn[btn_idx], "color026");
	if (Data_v == 27)
		gtk_widget_set_name(dgs_btn[btn_idx], "color027");
	if (Data_v == 28)
		gtk_widget_set_name(dgs_btn[btn_idx], "color028");
	if (Data_v == 29)
		gtk_widget_set_name(dgs_btn[btn_idx], "color029");
	if (Data_v == 30)
		gtk_widget_set_name(dgs_btn[btn_idx], "color030");
	if (Data_v == 31)
		gtk_widget_set_name(dgs_btn[btn_idx], "color031");
	if (Data_v == 32)
		gtk_widget_set_name(dgs_btn[btn_idx], "color032");
	if (Data_v == 33)
		gtk_widget_set_name(dgs_btn[btn_idx], "color033");
	if (Data_v == 34)
		gtk_widget_set_name(dgs_btn[btn_idx], "color034");
	if (Data_v == 35)
		gtk_widget_set_name(dgs_btn[btn_idx], "color035");
	if (Data_v == 36)
		gtk_widget_set_name(dgs_btn[btn_idx], "color036");
	if (Data_v == 37)
		gtk_widget_set_name(dgs_btn[btn_idx], "color037");
	if (Data_v == 38)
		gtk_widget_set_name(dgs_btn[btn_idx], "color038");
	if (Data_v == 39)
		gtk_widget_set_name(dgs_btn[btn_idx], "color039");
	if (Data_v == 40)
		gtk_widget_set_name(dgs_btn[idx], "color040");
	if (Data_v == 41)
		gtk_widget_set_name(dgs_btn[idx], "color041");
	if (Data_v == 42)
		gtk_widget_set_name(dgs_btn[idx], "color042");
	if (Data_v == 43)
		gtk_widget_set_name(dgs_btn[idx], "color043");
	if (Data_v == 44)
		gtk_widget_set_name(dgs_btn[idx], "color044");
	if (Data_v == 45)
		gtk_widget_set_name(dgs_btn[idx], "color045");
	if (Data_v == 46)
		gtk_widget_set_name(dgs_btn[idx], "color046");
	if (Data_v == 47)
		gtk_widget_set_name(dgs_btn[idx], "color047");
	if (Data_v == 48)
		gtk_widget_set_name(dgs_btn[idx], "color048");
	if (Data_v == 49)
		gtk_widget_set_name(dgs_btn[idx], "color049");
	if (Data_v == 50)
		gtk_widget_set_name(dgs_btn[idx], "color050");
	if (Data_v == 61)
		gtk_widget_set_name(dgs_btn[idx], "color061");
	if (Data_v == 62)
		gtk_widget_set_name(dgs_btn[idx], "color062");
	if (Data_v == 63)
		gtk_widget_set_name(dgs_btn[idx], "color063");
	if (Data_v == 64)
		gtk_widget_set_name(dgs_btn[idx], "color064");
	if (Data_v == 65)
		gtk_widget_set_name(dgs_btn[idx], "color065");
	if (Data_v == 66)
		gtk_widget_set_name(dgs_btn[idx], "color066");
	if (Data_v == 67)
		gtk_widget_set_name(dgs_btn[idx], "color067");
	if (Data_v == 68)
		gtk_widget_set_name(dgs_btn[idx], "color068");
	if (Data_v == 69)
		gtk_widget_set_name(dgs_btn[idx], "color069");
	if (Data_v == 70)
		gtk_widget_set_name(dgs_btn[idx], "color070");
	if (Data_v == 71)
		gtk_widget_set_name(dgs_btn[idx], "color071");
	if (Data_v == 72)
		gtk_widget_set_name(dgs_btn[idx], "color072");
	if (Data_v == 73)
		gtk_widget_set_name(dgs_btn[idx], "color073");
	if (Data_v == 74)
		gtk_widget_set_name(dgs_btn[idx], "color074");
	if (Data_v == 75)
		gtk_widget_set_name(dgs_btn[idx], "color075");
	if (Data_v == 76)
		gtk_widget_set_name(dgs_btn[idx], "color076");
	if (Data_v == 77)
		gtk_widget_set_name(dgs_btn[idx], "color077");
	if (Data_v == 78)
		gtk_widget_set_name(dgs_btn[idx], "color078");
	if (Data_v == 79)
		gtk_widget_set_name(dgs_btn[idx], "color079");
	if (Data_v == 80)
		gtk_widget_set_name(dgs_btn[idx], "color080");
	if (Data_v == 91)
		gtk_widget_set_name(dgs_btn[idx], "color091");
	if (Data_v == 92)
		gtk_widget_set_name(dgs_btn[idx], "color092");
	if (Data_v == 93)
		gtk_widget_set_name(dgs_btn[idx], "color093");
	if (Data_v == 94)
		gtk_widget_set_name(dgs_btn[idx], "color094");
	if (Data_v == 95)
		gtk_widget_set_name(dgs_btn[idx], "color095");
	if (Data_v == 96)
		gtk_widget_set_name(dgs_btn[idx], "color096");
	if (Data_v == 97)
		gtk_widget_set_name(dgs_btn[idx], "color097");
	if (Data_v == 98)
		gtk_widget_set_name(dgs_btn[idx], "color098");
	if (Data_v == 99)
		gtk_widget_set_name(dgs_btn[idx], "color099");
	if (Data_v == 100)
		gtk_widget_set_name(dgs_btn[idx], "color100");
	if (Data_v == 101)
		gtk_widget_set_name(dgs_btn[idx], "color101");
	if (Data_v == 102)
		gtk_widget_set_name(dgs_btn[idx], "color102");
	if (Data_v == 103)
		gtk_widget_set_name(dgs_btn[idx], "color103");
	if (Data_v == 104)
		gtk_widget_set_name(dgs_btn[idx], "color104");
	if (Data_v == 105)
		gtk_widget_set_name(dgs_btn[idx], "color105");
	if (Data_v == 106)
		gtk_widget_set_name(dgs_btn[idx], "color106");
	if (Data_v == 107)
		gtk_widget_set_name(dgs_btn[idx], "color107");
	if (Data_v == 108)
		gtk_widget_set_name(dgs_btn[idx], "color108");
	if (Data_v == 109)
		gtk_widget_set_name(dgs_btn[idx], "color109");
	if (Data_v == 110)
		gtk_widget_set_name(dgs_btn[idx], "color110");
	if (Data_v == 111)
		gtk_widget_set_name(dgs_btn[idx], "color111");
	if (Data_v == 112)
		gtk_widget_set_name(dgs_btn[idx], "color112");
	if (Data_v == 113)
		gtk_widget_set_name(dgs_btn[idx], "color113");
	if (Data_v == 114)
		gtk_widget_set_name(dgs_btn[idx], "color114");
	if (Data_v == 115)
		gtk_widget_set_name(dgs_btn[idx], "color115");
	if (Data_v == 116)
		gtk_widget_set_name(dgs_btn[idx], "color116");
	if (Data_v == 117)
		gtk_widget_set_name(dgs_btn[idx], "color117");
	if (Data_v == 118)
		gtk_widget_set_name(dgs_btn[idx], "color118");
	if (Data_v == 119)
		gtk_widget_set_name(dgs_btn[idx], "color119");
	*/
}

//**************************************************************************************************************************
void Dim_1_size_f(int key_t) //  DIM_1_SIZE_PERA
{
	int Data_v;
	int idx_pos = DIM_1_SIZE_PERA;
	Data_v = val_ary[idx_pos];
	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
	}
	//**********KEY_SCR = 1*********************
	// if (key_scr == 1) //  for key press
	// {
	// 	Data_v = Data_v + key_t * (Key_stp);
	// }

	// if (Data_v < 0)
	// {
	// 	Data_v = 0;
	// }
	// if (Data_v > 119)
	// {
	// 	Data_v = 119;
	// }
	Data_v = val_ary[END_ID_1_PERA] - val_ary[START_ID_1_PERA];
	val_ary[idx_pos] = Data_v;

	sprintf(Dsp_Str, "%d", Data_v);
	pos = (idx_pos * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
	gtk_label_set_label(GTK_LABEL(dgslabel[19]), Dsp_Str);
}

//**************************************************************************************************************************
void Dim_2_size_f(int key_t) //  DIM_2_SIZE_PERA
{
	int Data_v;
	int idx_pos = DIM_2_SIZE_PERA;
	Data_v = val_ary[idx_pos];
	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
	}
	//**********KEY_SCR = 1*********************
	// if (key_scr == 1) //  for key press
	// {
	// 	Data_v = Data_v + key_t * (Key_stp);
	// }

	// if (Data_v < 0)
	// {
	// 	Data_v = 0;
	// }
	// if (Data_v > 119)
	// {
	// 	Data_v = 119;
	// }
	Data_v = val_ary[END_ID_2_PERA] - val_ary[START_ID_2_PERA];
	val_ary[idx_pos] = Data_v;

	sprintf(Dsp_Str, "%d", Data_v);
	pos = (idx_pos * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
	gtk_label_set_label(GTK_LABEL(dgslabel[21]), Dsp_Str);
}

//**************************************************************************************************************************
void Dim_3_size_f(int key_t) //  DIM_3_SIZE_PERA
{
	int Data_v;
	int idx_pos = DIM_3_SIZE_PERA;
	Data_v = val_ary[idx_pos];
	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
	}
	//**********KEY_SCR = 1*********************
	// if (key_scr == 1) //  for key press
	// {
	// 	Data_v = Data_v + key_t * (Key_stp);
	// }

	// if (Data_v < 0)
	// {
	// 	Data_v = 0;
	// }
	// if (Data_v > 119)
	// {
	// 	Data_v = 119;
	// }
	Data_v = val_ary[END_ID_3_PERA] - val_ary[START_ID_3_PERA];
	val_ary[idx_pos] = Data_v;

	sprintf(Dsp_Str, "%d", Data_v);
	pos = (idx_pos * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
	gtk_label_set_label(GTK_LABEL(dgslabel[23]), Dsp_Str);
}

//**************************************************************************************************************************
void Thk_Color_method_f(int key_t) //  COLOR_METHOD_PERA  EXIT_PERA+5           // Thickness file Color Selection
{
	int Data_v;
	int idx_pos = COLOR_METHOD_PERA;
	Data_v = val_ary[idx_pos];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
	}

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) //  Get the value from button keypad
	{
		Data_v = Data_v + key_t * (Key_stp);
	}

	if (Data_v < 0)
	{
		Data_v = 0;
	}
	if (Data_v > 99)
	{
		Data_v = 99;
	}
	val_ary[idx_pos] = Data_v;

	sprintf(Dsp_Str, "%d", Data_v);
	pos = (idx_pos * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
	gtk_label_set_label(GTK_LABEL(dgslabel[1]), Dsp_Str);
}

//**************************************************************************************************************************
void Start_Thk_1_f(int key_t) //  START_THK_1_PERA
{
	int Data_v;
	int idx_pos = START_THK_1_PERA;
	Data_v = val_ary[idx_pos];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
	}

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) //  Get the value from button keypad
	{
		Data_v = Data_v + key_t * (Key_stp);
	}

	if (Data_v < 0)
	{
		Data_v = 0;
	}
	if (Data_v > 10000)
	{
		Data_v = 10000;
	}
	val_ary[idx_pos] = Data_v;
	st_clr[0] = Data_v;

	sprintf(Dsp_Str, "%d", Data_v);
	pos = (idx_pos * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
	gtk_label_set_label(GTK_LABEL(dgslabel[3]), Dsp_Str);
}

//**************************************************************************************************************************
void Start_Thk_2_f(int key_t) //  START_THK_2_PERA
{
	int Data_v;
	int idx_pos = START_THK_2_PERA;
	Data_v = val_ary[idx_pos];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
	}

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
	{
		Data_v = Data_v + key_t * (Key_stp);
	}

	if (Data_v < 3333)
	{
		Data_v = 3333;
	}
	if (Data_v > 10000)
	{
		Data_v = 10000;
	}
	val_ary[idx_pos] = Data_v;
	st_clr[1] = Data_v;

	sprintf(Dsp_Str, "%d", Data_v);
	pos = (idx_pos * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
	gtk_label_set_label(GTK_LABEL(dgslabel[5]), Dsp_Str);
}

//**************************************************************************************************************************
void Start_Thk_3_f(int key_t) //  START_THK_3_PERA
{
	int Data_v;
	int idx_pos = START_THK_3_PERA;
	Data_v = val_ary[idx_pos];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
	}

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
	{
		Data_v = Data_v + key_t * (Key_stp);
	}

	if (Data_v < 6666)
	{
		Data_v = 6666;
	}
	if (Data_v > 10000)
	{
		Data_v = 10000;
	}
	val_ary[idx_pos] = Data_v;
	st_clr[2] = Data_v;

	sprintf(Dsp_Str, "%d", Data_v);
	pos = (idx_pos * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
	gtk_label_set_label(GTK_LABEL(dgslabel[7]), Dsp_Str);
}

//**************************************************************************************************************************
void Thk_EXT_61_f(int key_t) //  EXT_61_PERA
{
	int Data_v;
	int idx_pos = EXT_61_PERA;
	Data_v = val_ary[idx_pos];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
	}

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) //  Get the value from button keypad
	{
		Data_v = Data_v + key_t * (Key_stp);
	}

	if (Data_v < 0)
	{
		Data_v = 0;
	}
	if (Data_v > 10000)
	{
		Data_v = 10000;
	}
	val_ary[idx_pos] = Data_v;

	sprintf(Dsp_Str, "%d", Data_v);
	pos = (idx_pos * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
	gtk_label_set_label(GTK_LABEL(dgslabel[9]), Dsp_Str);
}

//**************************************************************************************************************************
void End_Thk_1_f(int key_t) //  END_THK_1_PERA
{
	int Data_v;
	int idx_pos = END_THK_1_PERA;
	Data_v = val_ary[idx_pos];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
	}

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) //  Get the value from button keypad
	{
		Data_v = Data_v + key_t * (Key_stp);
	}

	if (Data_v < 3333)
	{
		Data_v = 3333;
	}
	if (Data_v > 10000)
	{
		Data_v = 10000;
	}
	val_ary[idx_pos] = Data_v;
	ed_clr[0] = Data_v;

	sprintf(Dsp_Str, "%d", Data_v);
	pos = (idx_pos * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
	gtk_label_set_label(GTK_LABEL(dgslabel[11]), Dsp_Str);
}

//**************************************************************************************************************************
void End_Thk_2_f(int key_t) //  END_THK_2_PERA
{
	int Data_v;
	int idx_pos = END_THK_2_PERA;
	Data_v = val_ary[idx_pos];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
	}

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) //  Get the value from button keypad
	{
		Data_v = Data_v + key_t * (Key_stp);
	}

	if (Data_v < 6666)
	{
		Data_v = 6666;
	}
	if (Data_v > 10000)
	{
		Data_v = 10000;
	}
	val_ary[idx_pos] = Data_v;
	ed_clr[1] = Data_v;

	sprintf(Dsp_Str, "%d", Data_v);
	pos = (idx_pos * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
	gtk_label_set_label(GTK_LABEL(dgslabel[13]), Dsp_Str);
}

//**************************************************************************************************************************
void End_Thk_3_f(int key_t) //  END_THK_3_PERA
{
	int Data_v;
	int idx_pos = END_THK_3_PERA;
	Data_v = val_ary[idx_pos];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
	}

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
	{
		Data_v = Data_v + key_t * (Key_stp);
	}

	if (Data_v < 9998)
	{
		Data_v = 9998;
	}
	if (Data_v > 10000)
	{
		Data_v = 10000;
	}
	val_ary[idx_pos] = Data_v;
	ed_clr[2] = Data_v;

	sprintf(Dsp_Str, "%d", Data_v);
	pos = (idx_pos * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
	gtk_label_set_label(GTK_LABEL(dgslabel[15]), Dsp_Str);
}

//**************************************************************************************************************************
void Thk_Clr_Exit_f(int key_t) //  EXIT_71_PERA
{
	int Data_v;
	int idx_pos = EXIT_71_PERA;
	Data_v = val_ary[idx_pos];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
	}

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
	{
		Data_v = Data_v + key_t * (Key_stp);
	}

	if (Data_v < 0)
	{
		Data_v = 0;
	}
	if (Data_v > 99)
	{
		Data_v = 99;
	}
	val_ary[idx_pos] = Data_v;

	sprintf(Dsp_Str, "%d", Data_v);
	pos = (idx_pos * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
	gtk_label_set_label(GTK_LABEL(dgslabel[15]), Dsp_Str);
}

//**************************************************************************************************************************
void Thk_Clr_1_f(int key_t) //  COLOR_1_PERA
{
	char buffer[16];
	int Data_v;
	int idx_pos = COLOR_1_PERA;
	Data_v = val_ary[idx_pos];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
	}

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
	{
		Data_v = Data_v + key_t * (Key_stp);
	}
	if (Data_v < 0)
	{
		Data_v = 0;
	}
	if (Data_v > 102)
	{
		Data_v = 102;
	}
	val_ary[idx_pos] = Data_v;

	// sprintf(Dsp_Str, "%d", Data_v);
	pos = (idx_pos * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
	// gtk_label_set_label(GTK_LABEL(dgslabel[19]), Dsp_Str);

	sprintf(buffer, "color%03d", val_ary[COLOR_1_PERA]);
	gtk_widget_set_name(dgs_btn[19], buffer);
}

//**************************************************************************************************************************
void Thk_Clr_2_f(int key_t) //  COLOR_2_PERA
{
	char buffer[16];
	int Data_v;
	int idx_pos = COLOR_2_PERA;
	Data_v = val_ary[idx_pos];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
	}

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
	{
		Data_v = Data_v + key_t * (Key_stp);
	}

	if (Data_v < 0)
	{
		Data_v = 0;
	}
	if (Data_v > 102)
	{
		Data_v = 102;
	}
	val_ary[idx_pos] = Data_v;

	// sprintf(Dsp_Str, "%d", Data_v);
	pos = (idx_pos * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
	// gtk_label_set_label(GTK_LABEL(dgslabel[21]), Dsp_Str);

	sprintf(buffer, "color%03d", val_ary[COLOR_2_PERA]);
	gtk_widget_set_name(dgs_btn[21], buffer);
}

//**************************************************************************************************************************
void Thk_Clr_3_f(int key_t) //  COLOR_3_PERA
{
	char buffer[16];
	int Data_v;
	int idx_pos = COLOR_3_PERA;
	Data_v = val_ary[idx_pos];

	//**********KEY_SCR = 0*********************
	if (key_scr == 0) // Get the value from scrollbar
	{
	}

	//**********KEY_SCR = 1*********************
	if (key_scr == 1) // Get the value from button keypad
	{
		Data_v = Data_v + key_t * (Key_stp);
	}

	if (Data_v < 0)
	{
		Data_v = 0;
	}
	if (Data_v > 102)
	{
		Data_v = 102;
	}
	val_ary[idx_pos] = Data_v;

	// sprintf(Dsp_Str, "%d", Data_v);
	pos = (idx_pos * 2) + 1;
	strcpy(all_btnval[pos], Dsp_Str);
	pos = pos % 10;
	// gtk_label_set_label(GTK_LABEL(dgslabel[23]), Dsp_Str);

	sprintf(buffer, "color%03d", val_ary[COLOR_3_PERA]);
	gtk_widget_set_name(dgs_btn[23], buffer);
}

//**************************************************************************************************************************
void Measure_Gate1_f() // Read Measurement of Gate from FPGA
{
	int ds = 0;
	int data = 0;
	float val1;
	float a = 0.0f, b = 0.0f, c = 0.0f, d = 0.0f;
	// int bt1,bt2,bt3,amp;
	// float Val_f;

	if (Measure_v1 > 0 || Measure_v2 > 0) // If Gate 1 measurement is ON
	{
		tx_cmd[ds++] = 0x1B;
		tx_cmd[ds++] = 0x029;
		tx_cmd[ds++] = 0x0;
		tx_cmd[ds++] = 0x1B; // Fill Template data with default Flank trigger
		tx_cmd[ds++] = 0x0;
		tx_cmd[ds++] = 0x0;
		tx_cmd[ds++] = 0x00;
		tx_cmd[ds++] = 0x0; // Dummy data to read from SPI
		tx_cmd[ds++] = 0x0;
		tx_cmd[ds++] = 0x0;
		tx_cmd[ds++] = 0x00;
		tx_cmd[ds++] = 0x0; // Dummy data to read from SPI
		tx_cmd[ds++] = 0x0;
		tx_cmd[ds++] = 0x0;
		tx_cmd[ds++] = 0x00;
		tx_cmd[ds++] = 0x0; // Dummy data to read from SPI

		trig_val = val_ary[TRIG_PERA];
		if (trig_val == 0) // "FLANK  "   // 1B29001B   Threshold Cross Value
		{
			tx_cmd[1] = 0x029;
			Send_SPI(ds);
			Cal_Tval();
			a = Val_f;
			G1_sp1 = (int)Val_f;			
			G1_Amp1 = amp;
			c = Val_f;
		}

		if (trig_val == 1) //  "PEAK   "    // 1B 22 00  1B   // Max Amp  Peak
		{
			tx_cmd[1] = 0x022;
			Send_SPI(ds);
			Cal_Tval();
			a = Val_f;
			G1_sp1 = (int)Val_f;			
			G1_Amp1 = amp;
			c = Val_f;
		}

		if (trig_val == 2) // "ZERO CRS "   // 1B 26 00 1B    // Zero Crossing read Gate 1  Receive Gate 1 zero cross address value before threshold value.
		{
			tx_cmd[1] = 0x026;
			Send_SPI(ds);
			Cal_Tval();
			a = Val_f;
			G1_sp1 = (int)Val_f;
			G1_Amp1 = amp;
			c = Val_f;
		}

		if (trig_val == 3) // "J CROSS ")   // 1B 2D 00 1B    // Command for receive Gate 1 zero cross point address value before max data.
		{
			tx_cmd[1] = 0x02D;
			Send_SPI(ds);
			Cal_Tval();
			a = Val_f;
			G1_sp1 = (int)Val_f;
			G1_Amp1 = amp;
			c = Val_f;
		}

		
	}

	if (Measure_v1 > 0 || Measure_v2 > 0) // If Gate 2 measurement is ON
	{
		tx_cmd[ds++] = 0x1B;
		tx_cmd[ds++] = 0x02A;
		tx_cmd[ds++] = 0x0;
		tx_cmd[ds++] = 0x1B; // Fill Template data with default Flank trigger
		tx_cmd[ds++] = 0x0;
		tx_cmd[ds++] = 0x0;
		tx_cmd[ds++] = 0x00;
		tx_cmd[ds++] = 0x0; // Dummy data to read from SPI
		tx_cmd[ds++] = 0x0;
		tx_cmd[ds++] = 0x0;
		tx_cmd[ds++] = 0x00;
		tx_cmd[ds++] = 0x0; // Dummy data to read from SPI
		tx_cmd[ds++] = 0x0;
		tx_cmd[ds++] = 0x0;
		tx_cmd[ds++] = 0x00;
		tx_cmd[ds++] = 0x0; // Dummy data to read from SPI

		trig_val = val_ary[TRIG_PERA];
		if (trig_val == 0) // "FLANK  "   // 1B 29 00 1B   Threshold Cross Value
		{
			tx_cmd[1] = 0x02A;
			Send_SPI(ds);
			Cal_Tval();
			b = Val_f;
			G2_sp2 = (int)Val_f;
			G2_Amp2 = amp;
			d = Val_f;
		}

		if (trig_val == 1) //  "PEAK   "    // 1B 22 00  1B   // Max Amp  Peak
		{
			tx_cmd[1] = 0x023;
			Send_SPI(ds);
			Cal_Tval();
			b = Val_f;
			G2_sp2 = (int)Val_f;
			G2_Amp2 = amp;
			d = Val_f;
		}

		if (trig_val == 2) // "ZERO CRS "   // 1B 26 00 1B    // Zero Crossing read Gate 1  Receive Gate 1 zero cross address value before threshold value.
		{
			tx_cmd[1] = 0x027;
			Send_SPI(ds);
			Cal_Tval();
			b = Val_f;
			G2_sp2 = (int)Val_f;
			G2_Amp2 = amp;
			d = Val_f;
		}

		if (trig_val == 3) // "J CROSS ")   // 1B 2D 00 1B    // Command for receive Gate 1 zero cross point address value before max data.
		{
			tx_cmd[1] = 0x02E;
			Send_SPI(ds);
			Cal_Tval();
			b = Val_f;
			G2_sp2 = (int)Val_f;
			G2_Amp2 = amp;
			d = Val_f;
		}
	}

	if (Encoder_val > 0)
	{
		Encoder_rd();
	}

	// if (Measure_v1 == 4 || Measure_v2 == 4 || Measure_v3 == 4) // Read Encoder Value
	{
		// sprintf(Dsp_Str, "EA=%d", Enc_1p);
		// gtk_label_set_label(GTK_LABEL(t_label[0]), Dsp_Str);
		// sprintf(Dsp_Str, "EB=%d", Enc_2p);
		// gtk_label_set_label(GTK_LABEL(t_label[1]), Dsp_Str);
	}
	// else
	// {
	// 	val1 = G1_sp1;
	// 	val1 = val1 / 1000;
	// 	sprintf(Dsp_Str, "Sp=%.2f", val1);
	// 	gtk_label_set_label(GTK_LABEL(t_label[0]), Dsp_Str);
	// 	sprintf(Dsp_Str, "A=%d%%", G1_Amp1);
	// 	gtk_label_set_label(GTK_LABEL(t_label[1]), Dsp_Str);
	// }
}

//**********************************************************************************
void Measure_f()
{
	double x, y, x1, y1, y2, dy; //,z,pi,Angr;
	// long int thk_v,thk_v2,thk_v3,thk_v4;
	double tempd;
	int i, Gst, Gend; //,E_end; //j
	char buffer[40], buffer1[40];
	int Gme1, Gme2;

	// rep_buf1[40], rep_buf2[40], rep_buf3[40], rep_buf4[40]
	// If Freez then disaply SP DP SD directly without calculation used in Recall
	if (Freez_v == FREEZ || Video_State == PLAY && Mem_actBS == BSC_ANALYSE)
	{
		goto Dsp_READING;
	} // When Freez then value calculated in "Measure_Frz(hWnd);" function to be get display

	if (Video_State == PLAY && Mem_actBS == BSC_PLAY)
	{
		Measure_Frz();
		goto Dsp_READING;
	}
	else //(Delay_rv/10)//      // If Peak Trigger Measurement then
	{
		Measure_Gate1_f(); // Read Gate 1 Measurement Reading
		// sp1=G1_sp1;
		G1_sp1 = G1_sp1 + Delay_rv;
		spc = G1_sp1;
		Cal_sddp_f();
		G1_dp1 = dpc;
		G1_sd1 = sdc; // Calculate SD and DP on basis of SP1 value
		G2_sp2 = G2_sp2 + Delay_rv;
		spc = G2_sp2;
		Cal_sddp_f();
		G2_dp2 = dpc;
		G2_sd2 = sdc; // Calculate SD and DP on basis of SP1 value // sp2=sp2+Delay_rv; spc=sp2; Cal_sddp_f(); dp2=dpc; sd2=sdc;  // Calculate SD and DP on basis of SP1 value
	}

Dsp_READING:
	//==FREEZ
	if (Dac_v == 2 && Freez_v != FREEZ) // Calculate DCA curve % and DAC db Diff
	{
		Get_dbtoCrv_f();
	}
	if (Dgs_onoff_v == 3 && Freez_v != FREEZ) // If DGS is ON then Calculate ERS Value
	{
		Cal_Ers_f(); // Calculate ERS Value
	}
	if (Aws_onoff_v == 2 && Freez_v != FREEZ) // If AWS Measure if ON then Calculate AWS rating and display
	{
		AWS_rat();
	}

	if (Measure_v1 == 1)
	{
		if (G1_Amp1 > level1_v) //  If Amplitide cross the Threshold level then display reading else "-----"
		{
			if (Unit_v == INCH)
			{
				x = G1_sp1;
				spa_thick_log = G1_sp1;
				x = x / 1000;
				sprintf(buffer, " %6.3f", x);
				sprintf(mea_rd[0], " %6.3f", x);
				gtk_label_set_label(GTK_LABEL(t_label[0]), buffer); // Display Sound path  "SPa: %6.3f"
				x = G1_dp1;
				x = x / 1000;
				sprintf(buffer, " %6.3f", x);
				sprintf(mea_rd[1], " %6.3f", x);
				gtk_label_set_label(GTK_LABEL(t_label[1]), buffer); // Display Depth    "DPa: %6.3f"
				x = G1_sd1;
				x = x / 1000;
				sprintf(buffer, " %6.3f", x);
				sprintf(mea_rd[2], " %6.3f", x);
				gtk_label_set_label(GTK_LABEL(t_label[2]), buffer); // Display Surface distance  "SDa: %6.3f"
			}
			else
			{
				x = G1_sp1;
				spa_thick_log = G1_sp1;
				x = x / 100;
				sprintf(buffer, " %6.2f", x);
				sprintf(mea_rd[0], " %6.2f", x);
				gtk_label_set_label(GTK_LABEL(t_label[0]), buffer); // Display Sound path "SPa: %6.2f"
				x = G1_dp1;
				x = x / 100;
				sprintf(buffer, " %6.2f", x);
				sprintf(mea_rd[1], " %6.2f", x);
				gtk_label_set_label(GTK_LABEL(t_label[1]), buffer); // Display Depth  "DPa: %6.2f"
				x = G1_sd1;
				x = x / 100;
				sprintf(buffer, " %6.2f", x);
				sprintf(mea_rd[2], " %6.2f", x);
				gtk_label_set_label(GTK_LABEL(t_label[2]), buffer); // Display Surface distance  "SDa: %6.2f"
			}
			sprintf(buffer, "%d%%", G1_Amp1);
			sprintf(mea_rd[3], "%d%%", G1_Amp1);
			gtk_label_set_label(GTK_LABEL(t_label[3]), buffer); // Display Amplitude  sprintf(buffer,"A%d%%",G1_Amp1);
		}
		else // If Amplitide cross the Threshold level then display reading else "-----"
		{
			sprintf(buffer, "---:--"); // 6.2f
			sprintf(mea_rd[0], "---:--");
			sprintf(mea_rd[1], "---:--");
			sprintf(mea_rd[2], "---:--");
			gtk_label_set_label(GTK_LABEL(t_label[0]), buffer); // Display Sound path
			gtk_label_set_label(GTK_LABEL(t_label[1]), buffer); // Display Depth
			gtk_label_set_label(GTK_LABEL(t_label[2]), buffer); // Display Surface distance
			sprintf(buffer, "%d%%", G1_Amp1);
			sprintf(mea_rd[3], "%d%%", G1_Amp1);
			// sprintf(buffer, "Ea:%d%%", val_ary[ZERO_PERA]); // ONLY FOR TESTING PURPOSE
			gtk_label_set_label(GTK_LABEL(t_label[3]), buffer); // Display Amplitude
		}
	}
	else if (Measure_v1 == 2)
	{
		if (G2_Amp2 > level2_v) // If Amplitide cross the Threshold level then display reading else "-----"
		{
			if (Unit_v == INCH)
			{
				x = G2_sp2;
				spb_thick_log = G2_sp2;
				x = x / 1000;
				sprintf(buffer, " %6.3f", x);
				sprintf(mea_rd[0], " %6.3f", x);
				gtk_label_set_label(GTK_LABEL(t_label[0]), buffer); // Display Sound path "SPb: %6.3f"
				x = G2_dp2;
				x = x / 1000;
				sprintf(buffer, " %6.3f", x);
				sprintf(mea_rd[1], " %6.3f", x);
				gtk_label_set_label(GTK_LABEL(t_label[1]), buffer); // Display Depth  "DPb: %6.3f"
				x = G2_sd2;
				x = x / 1000;
				sprintf(buffer, " %6.3f", x);
				sprintf(mea_rd[2], " %6.3f", x);
				gtk_label_set_label(GTK_LABEL(t_label[2]), buffer); // Display Surface distance "SDb: %6.3f"
			}
			else
			{
				x = G2_sp2;
				spb_thick_log = G2_sp2;
				x = x / 100;
				sprintf(buffer, " %6.2f", x);
				sprintf(mea_rd[0], " %6.2f", x);
				gtk_label_set_label(GTK_LABEL(t_label[0]), buffer); // Display Sound path  "SPb: %6.2f"
				x = G2_dp2;
				x = x / 100;
				sprintf(buffer, " %6.2f", x);
				sprintf(mea_rd[1], " %6.2f", x);
				gtk_label_set_label(GTK_LABEL(t_label[1]), buffer); // Display Depth  "DPb: %6.2f"
				x = G2_sd2;
				x = x / 100;
				sprintf(buffer, " %6.2f", x);
				sprintf(mea_rd[2], " %6.2f", x);
				gtk_label_set_label(GTK_LABEL(t_label[2]), buffer); // Display Surface distance  "SDb: %6.2f"
			}
			sprintf(buffer, "%d%%", G2_Amp2);
			sprintf(mea_rd[3], "%d%%", G2_Amp2);
			gtk_label_set_label(GTK_LABEL(t_label[3]), buffer); // Display Amplitude
		}
		else // If Amplitide less then Threshold level then display "-----"
		{
			sprintf(buffer, "---:--"); // Not Present in the original code
			sprintf(mea_rd[0], "---:--");
			sprintf(mea_rd[1], "---:--");
			sprintf(mea_rd[2], "---:--");
			gtk_label_set_label(GTK_LABEL(t_label[0]), buffer); // Display Sound path
			gtk_label_set_label(GTK_LABEL(t_label[1]), buffer); // Display Depth
			gtk_label_set_label(GTK_LABEL(t_label[2]), buffer); // Display Surface distance
			sprintf(buffer, "%d%%", G2_Amp2);
			sprintf(mea_rd[3], "%d%%", G2_Amp2);
			gtk_label_set_label(GTK_LABEL(t_label[3]), buffer); // Display Amplitude
		}
	}
	else if (Measure_v1 == 3)
	{
		if (G1_Amp1 > level1_v && G1_Amp1 < 125 && (Dac_v == 2 || Dgs_onoff_v == 3 || Aws_onoff_v == 2)) // If Amplitide cross the Threshold level then display reading else "-----"
		{
			if (Dac_v == 2) // DAC is on
			{
				x = Dac_ph;
				sprintf(buffer, " %d%%", Dac_ph); // Dac_ph   Crv_db_dif   "DAC: %d%%"
				sprintf(mea_rd[0], " %d%%", Dac_ph);
				gtk_label_set_label(GTK_LABEL(t_label[0]), buffer);
				x = Crv_db_dif;
				x = x / 10;
				sprintf(buffer, " %2.1f dB", x);
				sprintf(mea_rd[1], " %2.1f dB", x);
				gtk_label_set_label(GTK_LABEL(t_label[1]), buffer);

				x = G2_sd2;
				x = x / 100;
				sprintf(buffer, "          ");
				gtk_label_set_label(GTK_LABEL(t_label[2]), buffer);
				sprintf(buffer, "%d%%", G1_Amp1);
				sprintf(mea_rd[3], "%d%%", G1_Amp1);
				gtk_label_set_label(GTK_LABEL(t_label[3]), buffer); // Display Amplitude
			}
			if (Dgs_onoff_v == 3) // If DGS is ON
			{
				x = Crv_db_dif;
				x = x / 10;
				sprintf(buffer, " %2.1f dB", x);
				sprintf(mea_rd[1], " %2.1f dB", x);
				gtk_label_set_label(GTK_LABEL(t_label[1]), buffer); // "C dB: %2.1f dB"
				x = Dgs_crvs_v;
				if (Unit_v == INCH) // Inch
				{
					x = Ers_v;
					x = x / 1000;
					sprintf(buffer, " %6.2f", x);
					sprintf(mea_rd[0], " %6.2f", x);
					gtk_label_set_label(GTK_LABEL(t_label[0]), buffer); // "ERS: %6.2f"
					x = Dgs_crvs_v;
					x = x / 1000;
					sprintf(buffer, " %2.3f", x);
					sprintf(mea_rd[2], " %2.3f", x);
					gtk_label_set_label(GTK_LABEL(t_label[2]), buffer); // "DGS c: %2.3f"
				}
				else // mm
				{
					x = Ers_v;
					x = x / 10;
					sprintf(buffer, " %6.1f", x);
					sprintf(mea_rd[0], " %6.1f", x);
					gtk_label_set_label(GTK_LABEL(t_label[0]), buffer); // "ERS: %6.1f"
					x = Dgs_crvs_v;
					x = x / 10;
					sprintf(buffer, " %2.1f", x);
					sprintf(mea_rd[2], " %2.1f", x);
					gtk_label_set_label(GTK_LABEL(t_label[2]), buffer); // "DGS c: %2.1f"
				}
				sprintf(buffer, "   ");
				sprintf(mea_rd[3], "   ");
				gtk_label_set_label(GTK_LABEL(t_label[3]), buffer); // Display Amplitude
			}
			if (Aws_onoff_v == 2) // If AWS is ON then Display Reading of AWS
			{
				tempd = Refg_v;
				sprintf(buffer, " %2.1f", tempd / 10);
				sprintf(mea_rd[0], " %2.1f", tempd / 10);
				gtk_label_set_label(GTK_LABEL(t_label[0]), buffer); // "RG:%2.1f"

				tempd = IL_v;
				sprintf(buffer, " %2.1f", tempd / 10);
				sprintf(mea_rd[1], " %2.1f", tempd / 10);
				gtk_label_set_label(GTK_LABEL(t_label[1]), buffer); // "IL:%2.1f"

				tempd = Af_v; // tempd=187; //Af_lt;
				sprintf(buffer, " %2.1f", tempd / 10);
				sprintf(mea_rd[2], " %2.1f", tempd / 10);
				gtk_label_set_label(GTK_LABEL(t_label[2]), buffer); // "AF:%2.1f"

				tempd = Rt_v;
				sprintf(buffer, " %2.1f", tempd / 10);
				sprintf(mea_rd[3], " %2.1f", tempd / 10);
				gtk_label_set_label(GTK_LABEL(t_label[3]), buffer); // "RT:%2.1f"
			}
		}
		else // If Amplitide is less then the Threshold level then display reading else "-----"
		{
			if (Aws_onoff_v == 2) // If AWS is ON then Display Reading of AWS
			{
				sprintf(buffer, "---:--");
				sprintf(mea_rd[0], "---:--");
				sprintf(mea_rd[1], "---:--");
				gtk_label_set_label(GTK_LABEL(t_label[0]), buffer);
				gtk_label_set_label(GTK_LABEL(t_label[1]), buffer);
			}
			else
			{
				sprintf(buffer, "---:--");	  // 6.2f
				sprintf(mea_rd[0], "---:--"); // 6.2f
				sprintf(mea_rd[1], "---:--"); // 6.2f
				gtk_label_set_label(GTK_LABEL(t_label[0]), buffer);
				gtk_label_set_label(GTK_LABEL(t_label[1]), buffer);
			}
			sprintf(buffer, "---:--");							// 6.2f
			sprintf(mea_rd[2], "---:--");						// 6.2f
			gtk_label_set_label(GTK_LABEL(t_label[2]), buffer); // Display Surface distance
			sprintf(buffer, "---:--");
			sprintf(mea_rd[3], "---:--");						// 6.2f
			gtk_label_set_label(GTK_LABEL(t_label[3]), buffer); // Display Amplitude
		}
	}
	else if (Measure_v1 == 4) // For Encoder in MEA_1
	{
		if (Encoder_val == 1)
		{
			sprintf(buffer, " %d", Enc_pos1);
			strcpy(mea_rd[0], buffer);
			gtk_label_set_label(GTK_LABEL(t_label[0]), buffer);
		}
		else
			sprintf(buffer, "     ");

		strcpy(mea_rd[0], buffer);

		for (i = 1; i < 4; i++)
			strcpy(mea_rd[i], buffer);
	}

	//******************************** Measurement Disp second line ******************************************
	if (Measure_v2 == 1)
	{
		if (G1_Amp1 > level1_v) //  If Amplitide cross the Threshold level then display reading else "-----"
		{
			if (Unit_v == INCH)
			{
				x = G1_sp1;
				spa_thick_log = G1_sp1;
				x = x / 1000;
				sprintf(buffer, " %6.3f", x);
				sprintf(mea_rd[4], " %6.3f", x);
				gtk_label_set_label(GTK_LABEL(s_label[0]), buffer); // Display Sound path "SPa: %6.3f"
				x = G1_dp1;
				x = x / 1000;
				sprintf(buffer, " %6.3f", x);
				sprintf(mea_rd[5], " %6.3f", x);
				gtk_label_set_label(GTK_LABEL(s_label[1]), buffer); // Display Depth  "DPa: %6.3f"
				x = G1_sd1;
				x = x / 1000;
				sprintf(buffer, " %6.3f", x);
				sprintf(mea_rd[6], " %6.3f", x);
				gtk_label_set_label(GTK_LABEL(s_label[2]), buffer); // Display Surface distance  "SDa: %6.3f"
			}
			else
			{
				x = G1_sp1;
				spa_thick_log = G1_sp1;
				x = x / 100;
				sprintf(buffer, " %6.2f", x);
				sprintf(mea_rd[4], " %6.2f", x);
				gtk_label_set_label(GTK_LABEL(s_label[0]), buffer); // Display Sound path "SPa: %6.2f"
				x = G1_dp1;
				x = x / 100;
				sprintf(buffer, " %6.2f", x);
				sprintf(mea_rd[5], " %6.2f", x);
				gtk_label_set_label(GTK_LABEL(s_label[1]), buffer); // Display Depth  "DPa: %6.2f"
				x = G1_sd1;
				x = x / 100;
				sprintf(buffer, " %6.2f", x);
				sprintf(mea_rd[6], " %6.2f", x);
				gtk_label_set_label(GTK_LABEL(s_label[2]), buffer); // Display Surface distance  "SDa: %6.2f"
			}
			sprintf(buffer, "%d%%", G1_Amp1);
			sprintf(mea_rd[7], "%d%%", G1_Amp1);
			gtk_label_set_label(GTK_LABEL(s_label[3]), buffer); // Display Amplitude
		}
		else // If Amplitide cross the Threshold level then display reading else "-----"
		{
			sprintf(buffer, "---:--"); // 6.2f
			for (i = 4; i < 7; i++)
			{
				strcpy(mea_rd[i], buffer);
			}
			gtk_label_set_label(GTK_LABEL(s_label[0]), buffer); // Display Sound path
			gtk_label_set_label(GTK_LABEL(s_label[1]), buffer); // Display Depth
			gtk_label_set_label(GTK_LABEL(s_label[2]), buffer); // Display Surface distance
			sprintf(buffer, "%d%%", G1_Amp1);
			sprintf(mea_rd[7], "%d%%", G1_Amp1);
			gtk_label_set_label(GTK_LABEL(s_label[3]), buffer); // Display Amplitude
		}
	}
	else if (Measure_v2 == 2)
	{
		if (G2_Amp2 > level2_v) // If Amplitide cross the Threshold level then display reading else "-----"
		{
			if (Unit_v == INCH)
			{
				x = G2_sp2;
				spb_thick_log = G2_sp2;
				x = x / 1000;
				sprintf(buffer, " %6.3f", x);
				sprintf(mea_rd[4], " %6.3f", x);
				gtk_label_set_label(GTK_LABEL(s_label[0]), buffer); // Display Sound path "SPb: %6.3f"
				x = G2_dp2;
				x = x / 1000;
				sprintf(buffer, " %6.3f", x);
				sprintf(mea_rd[5], " %6.3f", x);
				gtk_label_set_label(GTK_LABEL(s_label[1]), buffer); // Display Depth  "DPb: %6.3f"
				x = G2_sd2;
				x = x / 1000;
				sprintf(buffer, " %6.3f", x);
				sprintf(mea_rd[6], " %6.3f", x);
				gtk_label_set_label(GTK_LABEL(s_label[2]), buffer); // Display Surface distance  "SDb: %6.3f"
			}
			else
			{
				x = G2_sp2;
				spb_thick_log = G2_sp2;
				x = x / 100;
				sprintf(buffer, " %6.2f", x);
				sprintf(mea_rd[4], " %6.2f", x);
				gtk_label_set_label(GTK_LABEL(s_label[0]), buffer); // Display Sound path  "SPb: %6.2f"
				x = G2_dp2;
				x = x / 100;
				sprintf(buffer, " %6.2f", x);
				sprintf(mea_rd[5], " %6.2f", x);
				gtk_label_set_label(GTK_LABEL(s_label[1]), buffer); // Display Depth  "DPb: %6.2f"
				x = G2_sd2;
				x = x / 100;
				sprintf(buffer, " %6.2f", x);
				sprintf(mea_rd[6], " %6.2f", x);
				gtk_label_set_label(GTK_LABEL(s_label[2]), buffer); // Display Surface distance  "SDb: %6.2f"
			}

			sprintf(buffer, "%d%%", G2_Amp2);
			sprintf(mea_rd[7], "%d%%", G2_Amp2);
			gtk_label_set_label(GTK_LABEL(s_label[3]), buffer); // Display Amplitude
		}
		else // If Amplitide less then Threshold level then display "-----"
		{
			sprintf(buffer, "---:--");
			for (i = 4; i < 7; i++)
			{
				strcpy(mea_rd[i], buffer);
			}
			gtk_label_set_label(GTK_LABEL(s_label[0]), buffer); // Display Sound path
			gtk_label_set_label(GTK_LABEL(s_label[1]), buffer); // Display Depth
			gtk_label_set_label(GTK_LABEL(s_label[2]), buffer); // Display Surface distance
			sprintf(buffer, "%d%%", G2_Amp2);
			sprintf(mea_rd[7], "%d%%", G2_Amp2);
			gtk_label_set_label(GTK_LABEL(s_label[3]), buffer); // Display Amplitude
		}
	}
	else if (Measure_v2 == 3)
	{
		if (G1_Amp1 > level1_v && G1_Amp1 < 125 && (Dac_v == 2 || Dgs_onoff_v == 3 || Aws_onoff_v == 2)) // If Amplitide cross the Threshold level then display reading else "-----"
		{
			if (Dac_v == 2) // DAC is on
			{
				x = Dac_ph;
				sprintf(buffer, " %d%%", Dac_ph); // Dac_ph   Crv_db_dif           "DAC: %d%%",
				sprintf(mea_rd[4], " %d%%", Dac_ph);
				gtk_label_set_label(GTK_LABEL(s_label[0]), buffer); // Display Sound path
				x = Crv_db_dif;
				x = x / 10;
				sprintf(buffer, " %2.1f dB", x); //     "C dB: %2.1f dB"
				sprintf(mea_rd[5], " %2.1f dB", x);
				gtk_label_set_label(GTK_LABEL(s_label[1]), buffer); // Display Depth

				x = G2_sd2;
				x = x / 100;
				sprintf(buffer, "          ");
				sprintf(mea_rd[6], "          ");
				gtk_label_set_label(GTK_LABEL(s_label[2]), buffer); // Display Surface distance
				sprintf(buffer, "%d%%", G1_Amp1);
				sprintf(mea_rd[7], "%d%%", G1_Amp1);
				gtk_label_set_label(GTK_LABEL(s_label[3]), buffer); // Display Amplitude
			}
			else if (Dgs_onoff_v == 3) // If DGS is ON
			{
				x = Crv_db_dif;
				x = x / 10;
				sprintf(buffer, " %2.1f dB", x);
				sprintf(mea_rd[5], " %2.1f dB", x);
				gtk_label_set_label(GTK_LABEL(s_label[1]), buffer); // "C dB: %2.1f dB"
				x = Dgs_crvs_v;
				if (Unit_v == INCH) // Inch
				{
					x = Ers_v;
					x = x / 1000;
					sprintf(buffer, " %6.2f", x);
					sprintf(mea_rd[4], " %6.2f", x);
					gtk_label_set_label(GTK_LABEL(s_label[0]), buffer); // "ERS: %6.2f"
					x = Dgs_crvs_v;
					x = x / 1000;
					sprintf(buffer, " %2.3f", x);
					sprintf(mea_rd[6], " %2.3f", x);
					gtk_label_set_label(GTK_LABEL(s_label[2]), buffer); // "DGS c: %2.3f"
				}
				else // mm
				{
					x = Ers_v;
					x = x / 10;
					sprintf(buffer, " %6.1f", x);
					sprintf(mea_rd[4], " %6.1f", x);
					gtk_label_set_label(GTK_LABEL(s_label[0]), buffer); // "ERS: %6.1f"
					x = Dgs_crvs_v;
					x = x / 10;
					sprintf(buffer, " %2.1f", x);
					sprintf(mea_rd[6], " %2.1f", x);
					gtk_label_set_label(GTK_LABEL(s_label[2]), buffer); // "DGS c: %2.1f"
				}
				sprintf(buffer, "   ");
				sprintf(mea_rd[7], "   ");
				gtk_label_set_label(GTK_LABEL(s_label[3]), buffer); // Display Amplitude
			}
			else if (Aws_onoff_v == 2) // If AWS is ON then Display Reading of AWS
			{
				tempd = Refg_v;
				sprintf(buffer, "%2.1f", tempd / 10);
				sprintf(mea_rd[4], "%2.1f", tempd / 10);
				gtk_label_set_label(GTK_LABEL(s_label[0]), buffer); // "RG:%2.1f"

				tempd = IL_v;
				sprintf(buffer, "%2.1f", tempd / 10);
				sprintf(mea_rd[5], "%2.1f", tempd / 10);
				gtk_label_set_label(GTK_LABEL(s_label[1]), buffer); // "IL:%2.1f"

				tempd = Af_v; // tempd=187; //Af_lt;
				sprintf(buffer, "%2.1f", tempd / 10);
				sprintf(mea_rd[6], "%2.1f", tempd / 10);
				gtk_label_set_label(GTK_LABEL(s_label[2]), buffer); // "AF:%2.1f"

				tempd = Rt_v;
				sprintf(buffer, "%2.1f", tempd / 10);
				sprintf(mea_rd[7], "%2.1f", tempd / 10);
				gtk_label_set_label(GTK_LABEL(s_label[3]), buffer); // "RT:%2.1f"
			}
		}
		else // If Amplitide is less then the Threshold level then display reading else "-----"
		{
			if (Aws_onoff_v == 2) // If AWS is ON then Display Reading of AWS
			{
				sprintf(buffer, "---:--");
				for (i = 4; i < 6; i++)
				{
					strcpy(mea_rd[i], buffer);
				}
				gtk_label_set_label(GTK_LABEL(s_label[0]), buffer);
				gtk_label_set_label(GTK_LABEL(s_label[1]), buffer);
			}
			else
			{
				sprintf(buffer, "---:--"); // 6.2f
				for (i = 6; i < 8; i++)
				{
					strcpy(mea_rd[i], buffer);
				}
				gtk_label_set_label(GTK_LABEL(s_label[0]), buffer);
				gtk_label_set_label(GTK_LABEL(s_label[1]), buffer);
			}
			sprintf(buffer, "---:--");							// 6.2f
			gtk_label_set_label(GTK_LABEL(s_label[2]), buffer); // Display Surface distance
			sprintf(buffer, "---:--");
			gtk_label_set_label(GTK_LABEL(s_label[3]), buffer); // Display Amplitude
		}
	}
	else if (Measure_v2 == 4) // For Encoder in MEA_2
	{
		if (Encoder_val == 1)
		{
			// sprintf(buffer, "E2-:--");
			sprintf(buffer, "%d", Enc_pos2);
			strcpy(mea_rd[0], buffer);
			gtk_label_set_label(GTK_LABEL(s_label[0]), buffer);
		}
		else
			sprintf(buffer, "--:--");

		for (i = 4; i < 8; i++)
		{
			strcpy(mea_rd[i], buffer);
		}
	}

	// FOR ECHO TO ECHO DIFFERENCE SIGNAL MEASUREMENT
	if (Measure_v1 == 1 && Measure_v2 == 2) // Difference between G1_sp1 of Gate A and G2_sp2 of Gate B
	{
		x = G1_sp1 - G2_sp2;
		x = fabs(x / 100);
		sprintf(buffer, "E2E:%6.3f", x);
		gtk_label_set_label(GTK_LABEL(s_label[4]), buffer);
	}
	else
	{
		gtk_label_set_label(GTK_LABEL(s_label[4]), "--");
	}

	if (Measure_v1 == 5)
	{
		sprintf(buffer, "%.3lf", flsp);
		gtk_label_set_label(GTK_LABEL(t_label[0]), buffer); // Display Sound path "SPa: %6.2f"

		sprintf(buffer, "%.3lf", fld);
		gtk_label_set_label(GTK_LABEL(t_label[1]), buffer); // Display Depth  "DPa: %6.2f"

		sprintf(buffer, "%.3lf", flsd);
		gtk_label_set_label(GTK_LABEL(t_label[2]), buffer);
	}

	/*
	if (Measure_v1 == 0) // This is MEA_POSI1 == OFF condition
	{
		gtk_label_set_label(GTK_LABEL(t_label[0]), "      ");
		gtk_label_set_label(GTK_LABEL(t_label[1]), "      ");
		gtk_label_set_label(GTK_LABEL(t_label[2]), "      ");
		gtk_label_set_label(GTK_LABEL(t_label[3]), "      ");
	}

	if (Measure_v2 == 0)  // This is MEA_POSI2 == OFF condition
	{
		gtk_label_set_label(GTK_LABEL(s_label[0]), "      ");
		gtk_label_set_label(GTK_LABEL(s_label[1]), "      ");
		gtk_label_set_label(GTK_LABEL(s_label[2]), "      ");
		gtk_label_set_label(GTK_LABEL(s_label[3]), "      ");
	}
	*/
}

///***************************************************************************
///******** Measure thickness reading when Freez is activated  ***************
///***************************************************************************
void Measure_Frz() // Measure thickness reading when Freez is activated Calculates SP1 etc + Redraw Ascan +GAte DAC etc
{
	double x, y;
}

///***********************************************************************************
void DGS_on_f(int key_v)
{
	long int temp, data; // Find Gain diffrence between Ref Cureve NF gain to New DGS curve NF gain diff
	int dia_ratio;		 //  that gain Diff to be added to Current gain
						 // Current Gain= Ref_db + ( New DGS Curve NF gain - Ref NF gain)
	//  D_efect_v=200;
	temp = Dgs_crvs_v;
	temp = temp << 8;
	temp = temp / D_efect_v;
	dia_ratio = temp; //  0xff;    //  temp;

	Get_Dgs_f(dia_ratio);
	if (key_v != 0) // If Switched on By pressing key then set value of  Dgs_gain to 180 but if recalled from Mem then not required
	{
		Dgs_gain = 180;
	} // Draw New DGS Curve as per Current selection and Bring it to 80% FSH
	  // else
	  //{ Dgs_gain=(gain+180)-Dgs_gn;}
	  // Grid();
	// dac_gen(&dac_pnt[0],&dac_cv[0],gain,range,dly_r);   // If Dac ON then Draw DAC Curve
	Dgs_Nfg = CDgs_Adat[9]; // Dgs_Nfg=CDgs_dat[9];

	// temp=Dgs_ref_Nfg;
	// data=Dgs_ref_gn;
	// temp=temp+data;
	// data=Dgs_Nfg;

	temp = Dgs_ref_Nfg;
	data = Dgs_Nfg;
	temp = data - temp;
	data = Dgs_ref_gn;

	temp = temp + data;
	// Dgs_gn=temp;                    // Save DGS gain dB value

	if (key_v == 0) // If Switched on By pressing key then set value of  Dgs_gain to 180 but if recalled from Mem then not required
	{

	} // Draw New DGS Curve as per Current selection and Bring it to 80% FSH
	else
	{
		Dgs_gn = temp;
		Gain_v = temp;
		val_ary[GAIN_PERA] = temp;
	}
	Gain_f(0);
}

//******************************************************************************
//******************************************************************************************
void Get_Dgs_f(int tempu) // Get DGS Crve points from Lkt as per value of ratio
{
	int temp, i, Ldb, Hdb, posi;
	int fact, tempL;
	long int DataL, Att, divs;

	//  D_efect_v=200;
	//  tempL=Dgs_crvs_v<<8;
	//  tempL=tempL/D_efect_v;

	if (tempu < 0xD)
		tempu = 0xD;
	if (tempu > 0xfe)
		tempu = 0xff;

	temp = 0;
	for (i = 0; i < 14; i++) // No of ratio stored is 13
	{
		if (tempu == Dia_ratio[i])
		{
			for (posi = 0; posi < 32; posi++)
			{
				CDgs_dat[posi] = DGS_CdB[temp++];
			}
			break;
		}
		else if (tempu < Dia_ratio[i])
		{
			fact = Dia_ratio[i] - Dia_ratio[i - 1];
			tempu = tempu - Dia_ratio[i - 1];
			fact = fact << 8;
			fact = fact / tempu;
			for (i = 0; i < 32; i++)
			{
				Hdb = DGS_CdB[temp - 32];
				Ldb = DGS_CdB[temp++];
				tempu = Hdb - Ldb;
				tempu = tempu << 8;
				tempu = tempu / fact;
				tempu = Hdb - tempu;
				CDgs_dat[i] = tempu;
			} // x+ (y-x)8 Factor
			break;
		}
		temp = temp + 32;
	}
	temp = 10;

	DataL = (Near_FD) / Mtlvel_val; // Calculate Near Field Value
	if (Dgs_onoff_v == 3)			// If DGS On then  then Test object
		DataL = DataL * Att_obg_v;	//  else take Ref Block Attnuation
	else
		DataL = DataL * Att_ref_v;

	if (Unit_v == 1)
	{
		divs = 20000;
	} // Inch selected then
	else
	{
		divs = 2000000;
	} // MM selected

	for (i = 0; i < 32; i++) // Apply Attenuation effect
	{
		fact = DGS_RP[i];
		Att = fact * DataL;
		Att = Att / divs;	 // 1000000*2; // Travel distance is round Trip
		tempL = CDgs_dat[i]; // Still verify
		tempL = tempL + Att;
		CDgs_Adat[i] = tempL;
	}
}

//******************************************************************************************
//******************************************************************************************
void DGS_Ref_on_f() // Record DGS Ref Gain Value
{
	int gst_p; //,g_width,peak_v,peak_pos; //,i,y;
	long int temp;

	temp = Ref_size_v;
	temp = temp << 8;
	temp = temp / D_efect_v;
	gst_p = temp;	  // 0x33 for 0.5 RatioRe
	Get_Dgs_f(gst_p); // As per Ratio Get DGS Curve points from LKT

	Dgs_gain = 180; // Draw DGS Curve at 80% FSH
	// Grid();
	// dac_gen(&dac_pnt[0],&dac_cv[0],gain,range,dly_r);   // If Dac ON then Draw DAC Curve

	Dgs_ref_Nfg = CDgs_Adat[9]; //   Dgs_ref_Nfg=CDgs_dat[9];    // Store Ref DGS  NF gain  usen during DGS on
	Get_dbtoCrv_f();			// Measure dB difference with respect to DGS Curve
	Gain_v = Gain_v - Crv_db_dif;
	Gain_v = Gain_v + Amp_corr_v; // Apply Effect of  Amp Correction
	Dgs_ref_gn = Gain_v;		  // Save ref dB value
	val_ary[GAIN_PERA] = Gain_v;
	Gain_f(0); // Change and Refresh Gain Value
}

//******************************************************************************************
//**************************  Measure dB Difference between Curve and Echo signal

void Get_dbtoCrv_f() //   Measure dB Difference between Curve and Echo signal
{
	int gst_p, g_width, peak_v, peak_pos, i, y;
	long int temp;

	temp = Gstart1_v * 10;			// Find gate Start position interms of Pixel
	temp = (temp - Delay_rv) * 250; // Range shift  kalu
	temp = (temp) / Range_v;
	gst_p = temp;

	temp = Gend1_v * 10;			// Find gate Width position interms of Pixel
	temp = (temp - Delay_rv) * 250; // Range shift
	temp = (temp) / Range_v;
	g_width = temp;
   //g_width = gst_p + temp;
	
	if (g_width > Screen_w)
	{
		g_width = Screen_w;
	}

	peak_v = 0;
	peak_pos = 0;
	for (i = gst_p; i < g_width; i++) // Find Echo peak value and position
	{
		y = All_Ascan_data[i];
		if (y > peak_v)
		{
			peak_v = y;
			peak_pos = i;
		}
	}

	// if (peak_pos>299)peak_pos=299;
	Echo_peak_pos = peak_pos;

	i = dac_cv[peak_pos] / 2; // Get Curve value at echo peak
	if (i < 10 || i > 125)
	{
		Dac_ph = 0;
	}
	else
	{
		Dac_ph = (peak_v * 100) / i;
	} // Echo Height with respect to Curve

	if (peak_v > i)
	{
		temp = (100 * i) / peak_v;
		if (temp > 100)
			temp = 100;
		// temp=ehtodb[200-(2*Eamp1)];
		Crv_db_dif = ehtodb[200 - (2 * temp)]; // Get Required db to Bring Echo at 80% Height in DB
	}
	else
	{
		if (i == 0)
		{
			temp = 0;
		}
		else
		{
			temp = (100 * peak_v) / i;
		}
		if (temp > 100)
			temp = 100;
		Crv_db_dif = -ehtodb[200 - (2 * temp)]; // Get Required db to Bring Echo at 80% Height in DB
	}
}

//******************************************************************************************
//******************************************************************************************
void Cal_sddp_f()
{
	double x, z, Angr, pi; // Read Current Gate Measured Data
	long temp, temph;
	long int thk_v, thk_v2, thk_v3, thk_v4;

	pi = 3.141592653;
	//*** Calculate angle in Redian
	Angr = Angle_v;
	Angr = Angr / 10;
	Angr = (pi * Angr) / 180;
	thk_v = Thick_v;
	thk_v2 = thk_v * 2;
	thk_v3 = thk_v * 3;
	thk_v4 = thk_v * 4;

	// Calculate Depth
	x = cos(Angr) * spc;
	dpc = (long)x;
	if ((dpc > thk_v) && (dpc <= thk_v2))
	{
		dpc = thk_v2 - dpc;
	} // Take care of skip correction
	else if ((dpc > thk_v2) && (dpc <= thk_v3))
	{
		dpc = dpc - thk_v2;
	}
	else if ((dpc > thk_v3) && (dpc <= thk_v4))
	{
		dpc = thk_v4 - dpc;
	}
	else if ((dpc > thk_v4) && (dpc <= (thk_v * 5)))
	{
		dpc = dpc - thk_v4;
	}
	else if ((dpc > (thk_v * 5)) && (dpc <= (thk_v * 6)))
	{
		dpc = (thk_v * 6) - dpc;
	}
	else if (dpc > (thk_v * 6))
	{
		dpc = dpc - (thk_v * 6);
	}

	z = X_offset_v;
	x = sin(Angr) * spc;
	x = x - z; // Calculate Surface distance
	sdc = (long)x;
}

// ************* If Gate is ON and any signal then generate signal for LED
void Check_Gate_cross()
{
	int LED1_ON, LED2_ON, LED1, LED2;
	unsigned char wData;
	int i, j, ch_n, Gst, Gend;
	char buffer[40], buffer1[40];
	LED1_ON = 0;
	LED2_ON = 0;

	LED1 = 0;										// GateCrsLed_Symb1 = 0;
	if ((Gate1_v == PLOGIC) || (Gate1_v == NLOGIC)) // if Gate 1 is Pos or Neg Logic
	{
		// LED1 = 0;
		for (i = Gatecrs_strt1; i < Gatecrs_end1; i++)
		{
			if (All_Ascan_data[i] > level1_v)
			{
				LED1 = 1;
			}
		}
	}

	if ((Gate1_v == PLOGIC) && (LED1 == 1))
	{
		LED1_ON = 1;
	}
	if ((Gate1_v == NLOGIC) && (LED1 == 0))
	{
		LED1_ON = 1;
	}

	if ((Gate1_v == CRV_M) || (Gate1_v == CRV_1N) || (Gate1_v == CRV_2N) || (Gate1_v == CRV_1P) || (Gate1_v == CRV_2P)) // if Gate 1 is Pos or Neg Logic
	{
		LED1_ON = 0;
		for (i = 0; i < 250; i++)
		{
			if (dac_trig[i] > 0)
			{
				if (All_Ascan_data[i] > dac_trig[i])
				{
					LED1_ON = 1;
				}
			}
		}
	}

	LED2 = 0;
	if ((Gate2_v == PLOGIC) || (Gate2_v == NLOGIC)) // if Gate 2 is Pos or Neg Logic
	{
		for (i = Gatecrs_strt2; i < Gatecrs_end2; i++)
		{
			if (All_Ascan_data[i] > level2_v)
			{
				LED2 = 1;
			}
		}
	}

	if ((Gate2_v == PLOGIC) && (LED2 == 1))
	{
		LED2_ON = 1;
	}
	if ((Gate2_v == NLOGIC) && (LED2 == 0))
	{
		LED2_ON = 1;
	}

	tx_bufidx = 0;
	wData = ENCRST_reg & 0x3F;			  // Clear LED bits
	if ((LED1_ON == 1) || (LED2_ON == 1)) // FOR LED is ON then GLOW LED
	{
		wData = wData | 0x040;
	}

	ENCRST_reg = wData;
	Write_data(r_addENCRST, wData);
	Send_SPI(tx_bufidx);

	if ((horn_val == 1) & ((LED1_ON == 1) | (LED2_ON == 1))) // If Horn is ON then Generate Buz pulse
	{
		Key_Beep();
	}
	else
	{
		// GateCross_Symbol(GateCrsLed_Symb, cr);
	}
}

//******************************************************************************************
//******************************************************************************************
void Cal_Ers_f()
{
	int i, j, Nf_rt, Ldb, Udb, Ddb, Ldia, Hdia, Ddia, echo_h_db;
	long int temp, Nf_real; // ,data,templ;

	Get_dbtoCrv_f();

	temp = Echo_peak_pos;
	temp = temp * Range_v;
	temp = temp / 25;

	Nf_real = (Near_FD) / Mtlvel_val; // Calculate Near Field Value
	temp = temp / Nf_real;			  // Find ratio of Echo pos/ Near field.
	if (temp > 0x0FA0)
		temp = 0x0FA0; // Maximum Limit is  0xFA0

	for (i = 0; i < 32; i++)
	{
		Nf_rt = DGS_RP[i];
		if (Nf_rt >= temp)
			break;
	}

	if (Crv_db_dif > -1 && Crv_db_dif < 1) // Difference is <0.3 dB then
	{
		Ers_v = Dgs_crvs_v;
		goto exit_f;
	}

	echo_h_db = CDgs_dat[i] - Crv_db_dif; // Echo height in db so now compare with

	temp = i; // DGS Lkt data
	for (j = 0; j < 15; j++)
	{
		// temp=(32*j)+i;
		Ldb = DGS_CdB[temp]; // Get Appropriate ratio Curve
		if (Ldb < echo_h_db)
			break;
		temp = temp + 32; // Point to Next Curve
	} // J holds Curve no

	if (j > 13) // Defect size is Greater then Deff	1`so exit
	{
		Ers_v = D_efect_v;
		goto exit_f;
	}

	Udb = DGS_CdB[temp - 32];

	Ldia = Dia_ratio[j - 1];
	Hdia = Dia_ratio[j];
	Ddia = Hdia - Ldia;

	temp = Udb - echo_h_db;
	temp = temp * Ddia;
	Ddb = Udb - Ldb;
	temp = temp / Ddb;
	temp = Ldia + temp; // Ratio of D Eff to Defect size

	Ers_v = (D_efect_v * temp) / 255;
exit_f:
	return;
}

void Encoder_rd()
{
	int ds = 0;
	int data = 0;

	tx_cmd[ds++] = 0x1B;
	tx_cmd[ds++] = 0x2C;
	tx_cmd[ds++] = 0x0;
	tx_cmd[ds++] = 0x1B; // Fill Template data with default Flank trigger
	tx_cmd[ds++] = 0x0;
	tx_cmd[ds++] = 0x0;
	tx_cmd[ds++] = 0x00;
	tx_cmd[ds++] = 0x0; // Dummy data to read from SPI
	tx_cmd[ds++] = 0x0;
	tx_cmd[ds++] = 0x0;
	tx_cmd[ds++] = 0x00;
	tx_cmd[ds++] = 0x0; // Dummy data to read from SPI
	tx_cmd[ds++] = 0x0;
	tx_cmd[ds++] = 0x0;
	tx_cmd[ds++] = 0x00;
	tx_cmd[ds++] = 0x0; // Dummy data to read from SPI

	tx_cmd[1] = 0x2C;
	Send_SPI(ds);

	bt1 = rx_cmd[6];
	bt2 = rx_cmd[7];
	bt3 = rx_cmd[8];
	bt4 = rx_cmd[9];

	Enc_1p = (bt2 * 256) + bt1;
	Enc_2p = (bt4 * 256) + bt3;

	Enc_pos1 = Enc_1p / val_ary[ENC_CAL_PERA];
	Enc_pos2 = Enc_2p / val_ary[ENC_CAL_PERA];

	// g_print("Enc_1p : %d\nEnc_2p : %d", Enc_1p, Enc_2p);
	// g_print("%d    %d    %d    %d \n", bt1, bt2, bt3, bt4);
}

//***************************************************************************************************
//***************************************************************************************************
void Encoder_rd_old() // Read Encoder Count
{
	int ds = 0;
	int data = 0;

	tx_cmd[ds++] = 0x1B;
	// tx_cmd[ds++] = 0x02C;
	tx_cmd[ds++] = 0x028;
	tx_cmd[ds++] = 0x00;
	tx_cmd[ds++] = 0x1B; // 1B 2C 00 1B      Receive encoder count 1 and 2 data.
	tx_cmd[ds++] = 0x0;
	tx_cmd[ds++] = 0x0;
	tx_cmd[ds++] = 0x00;
	tx_cmd[ds++] = 0x0; // Dummy data to read from SPI
	tx_cmd[ds++] = 0x0;
	tx_cmd[ds++] = 0x0;
	tx_cmd[ds++] = 0x00;
	tx_cmd[ds++] = 0x0; // Dummy data to read from SPI
	tx_cmd[ds++] = 0x0;
	tx_cmd[ds++] = 0x0;
	tx_cmd[ds++] = 0x00;
	tx_cmd[ds++] = 0x0; // Dummy data to read from SPI

	bt1 = rx_cmd[6];
	bt2 = rx_cmd[7];
	bt3 = rx_cmd[8];
	bt4 = rx_cmd[9];

	Enc_1p = (bt2 * 256) + bt1;
	Enc_2p = (bt4 * 256) + bt3;

	g_print("Enc_1p : %d\nEnc_2p : %d", Enc_1p, Enc_2p);
}

//***************************************************************************************************
//***************************************************************************************************
void Encoder_Reset() // Encoder Reset
{
	unsigned char wData;

	tx_bufidx = 0;
	wData = ENCRST_reg | 0x011; // Clear Encoder   Bit 0 is for Encoder reset
	Write_data(r_addENCRST, wData);
	wData = ENCRST_reg & 0x0EE; // Clear Encoder
	Write_data(r_addENCRST, wData);
	Send_SPI(tx_bufidx);
}

//***************************************************************************************************
void Cal_Tval()
{
	int ds;
	ds = 5;

	bt1 = rx_cmd[6];
	bt2 = rx_cmd[7];
	bt3 = rx_cmd[8];
	bt1 = (bt3 * 256 * 256) + (bt2 * 256) + bt1;
	amp = rx_cmd[9];

	Val_f = bt1;
	Val_f = (Val_f * Mtlvel_val) / 1000; // Val_f=(Val_f*5920)/100;
}

/********************************************************************************************************************************************/
/*************************************************TEMP FUNCTION FOR TESTING. REMOVE IT LATER*************************************************/
void Bat_temp(int dd)
{
	if (dd >= 1000 && dd < 1100)
	{
		Batt_val = 20;
		sprintf(Battpr, "%s", "20%");
		gtk_label_set_label(GTK_LABEL(Batt_Perc), Battpr);
		dsp_msg(45);
		// gtk_label_set_markup(GTK_LABEL(Batt_Perc), "<b>Text to be bold</b>");
	}
	else if (dd >= 1100 && dd < 1200)
	{
		Batt_val = 25;
		sprintf(Battpr, "%s", "25%");
		gtk_label_set_label(GTK_LABEL(Batt_Perc), Battpr);
	}
	else if (dd >= 1200 && dd < 1300)
	{
		Batt_val = 30;
		sprintf(Battpr, "%s", "30%");
		gtk_label_set_label(GTK_LABEL(Batt_Perc), Battpr);
	}
	else if (dd >= 1300 && dd < 1400)
	{
		Batt_val = 35;
		sprintf(Battpr, "%s", "35%");
		gtk_label_set_label(GTK_LABEL(Batt_Perc), Battpr);
	}
	else if (dd >= 1400 && dd < 1500)
	{
		Batt_val = 40;
		sprintf(Battpr, "%s", "40%");
		gtk_label_set_label(GTK_LABEL(Batt_Perc), Battpr);
	}
	else if (dd >= 1500 && dd < 1600)
	{
		Batt_val = 45;
		sprintf(Battpr, "%s", "45%");
		gtk_label_set_label(GTK_LABEL(Batt_Perc), Battpr);
	}
	else if (dd >= 1600 && dd < 1700)
	{
		Batt_val = 50;
		sprintf(Battpr, "%s", "50%");
		gtk_label_set_label(GTK_LABEL(Batt_Perc), Battpr);
	}
	else if (dd >= 1700 && dd < 1800)
	{
		Batt_val = 55;
		sprintf(Battpr, "%s", "55%");
		gtk_label_set_label(GTK_LABEL(Batt_Perc), Battpr);
	}
	else if (dd >= 1800 && dd < 1900)
	{
		Batt_val = 60;
		sprintf(Battpr, "%s", "60%");
		gtk_label_set_label(GTK_LABEL(Batt_Perc), Battpr);
	}
	else if (dd >= 1900 && dd < 2000)
	{
		Batt_val = 65;
		sprintf(Battpr, "%s", "65%");
		gtk_label_set_label(GTK_LABEL(Batt_Perc), Battpr);
	}
	else if (dd >= 2000 && dd < 2100)
	{
		Batt_val = 70;
		sprintf(Battpr, "%s", "70%");
		gtk_label_set_label(GTK_LABEL(Batt_Perc), Battpr);
	}
	else if (dd >= 2100 && dd < 2200)
	{
		Batt_val = 75;
		sprintf(Battpr, "%s", "75%");
		gtk_label_set_label(GTK_LABEL(Batt_Perc), Battpr);
	}
	else if (dd >= 2200 && dd < 2300)
	{
		Batt_val = 80;
		sprintf(Battpr, "%s", "80%");
		gtk_label_set_label(GTK_LABEL(Batt_Perc), Battpr);
	}
	else if (dd >= 2300 && dd < 2400)
	{
		Batt_val = 85;
		sprintf(Battpr, "%s", "85%");
		gtk_label_set_label(GTK_LABEL(Batt_Perc), Battpr);
	}
	else if (dd >= 2400 && dd < 2500)
	{
		Batt_val = 90;
		sprintf(Battpr, "%s", "90%");
		gtk_label_set_label(GTK_LABEL(Batt_Perc), Battpr);
	}
	else if (dd >= 2500 && dd < 2600)
	{
		Batt_val = 95;
		sprintf(Battpr, "%s", "95%");
		gtk_label_set_label(GTK_LABEL(Batt_Perc), Battpr);
	}
	else if (dd >= 2600 && dd < 2700)
	{
		Batt_val = 100;
		sprintf(Battpr, "%s", "100%");
		gtk_label_set_label(GTK_LABEL(Batt_Perc), Battpr);
	}
	else if (dd >= 2700)
	{
		Batt_val = 100;
		sprintf(Battpr, "%s", "100%");
		gtk_label_set_label(GTK_LABEL(Batt_Perc), Battpr);
	}
	Battery_Symbol(Batt_val, 0);
}

// void Bat_temp(int dd)
//{
//	int value;
//	if (value >= 1580 && value < 1610)
//	{
//		Batt_val = 20;
//		sprintf(Battpr, "%s", "20%");
//		gtk_label_set_label(GTK_LABEL(Batt_Perc), Battpr);
//		dsp_msg(45);
//		//gtk_label_set_markup(GTK_LABEL(Batt_Perc), "<b>Text to be bold</b>");
//	}
//	else if (value >= 1610 && value < 1645)
//	{
//		Batt_val = 25;
//		sprintf(Battpr, "%s", "25%");
//		gtk_label_set_label(GTK_LABEL(Batt_Perc), Battpr);
//	}
//	else if (value >= 1645 && value < 1670)
//	{
//		Batt_val = 30;
//		sprintf(Battpr, "%s", "30%");
//		gtk_label_set_label(GTK_LABEL(Batt_Perc), Battpr);
//	}
//	else if (value >= 1670 && value < 1695)
//	{
//		Batt_val = 35;
//		sprintf(Battpr, "%s", "35%");
//		gtk_label_set_label(GTK_LABEL(Batt_Perc), Battpr);
//	}
//	else if (value >= 1695 && value < 1720)
//	{
//		Batt_val = 40;
//		sprintf(Battpr, "%s", "40%");
//		gtk_label_set_label(GTK_LABEL(Batt_Perc), Battpr);
//	}
//	else if (value >= 1720 && value < 1740)
//	{
//		Batt_val = 45;
//		sprintf(Battpr, "%s", "45%");
//		gtk_label_set_label(GTK_LABEL(Batt_Perc), Battpr);
//	}
//	else if (value >= 1740 && value < 1775)
//	{
//		Batt_val = 50;
//		sprintf(Battpr, "%s", "50%");
//		gtk_label_set_label(GTK_LABEL(Batt_Perc), Battpr);
//	}
//	else if (value >= 1775 && value < 1800)
//	{
//		Batt_val = 55;
//		sprintf(Battpr, "%s", "55%");
//		gtk_label_set_label(GTK_LABEL(Batt_Perc), Battpr);
//	}
//	else if (value >= 1800 && value < 1825)
//	{
//		Batt_val = 60;
//		sprintf(Battpr, "%s", "60%");
//		gtk_label_set_label(GTK_LABEL(Batt_Perc), Battpr);
//	}
//	else if (value >= 1825 && value < 1845)
//	{
//		Batt_val = 65;
//		sprintf(Battpr, "%s", "65%");
//		gtk_label_set_label(GTK_LABEL(Batt_Perc), Battpr);
//	}
//	else if (value >= 1845 && value < 1870)
//	{
//		Batt_val = 70;
//		sprintf(Battpr, "%s", "70%");
//		gtk_label_set_label(GTK_LABEL(Batt_Perc), Battpr);
//	}
//	else if (value >= 1870 && value < 1895)
//	{
//		Batt_val = 75;
//		sprintf(Battpr, "%s", "75%");
//		gtk_label_set_label(GTK_LABEL(Batt_Perc), Battpr);
//	}
//	else if (value >= 1895 && value < 1915)
//	{
//		Batt_val = 80;
//		sprintf(Battpr, "%s", "80%");
//		gtk_label_set_label(GTK_LABEL(Batt_Perc), Battpr);
//	}
//	else if (value >= 1915 && value < 1940)
//	{
//		Batt_val = 85;
//		sprintf(Battpr, "%s", "85%");
//		gtk_label_set_label(GTK_LABEL(Batt_Perc), Battpr);
//	}
//	else if (value >= 1940 && value < 1960)
//	{
//		Batt_val = 90;
//		sprintf(Battpr, "%s", "90%");
//		gtk_label_set_label(GTK_LABEL(Batt_Perc), Battpr);
//	}
//	else if (value >= 1960 && value < 1990)
//	{
//		Batt_val = 95;
//		sprintf(Battpr, "%s", "95%");
//		gtk_label_set_label(GTK_LABEL(Batt_Perc), Battpr);
//
//	}
//	else if (value >= 1990 && value < 2020)
//	{
//		Batt_val = 100;
//		sprintf(Battpr, "%s", "100%");
//		gtk_label_set_label(GTK_LABEL(Batt_Perc), Battpr);
//
//	}
//	else if (value >= 2020)
//	{
//		Batt_val = 100;
//		sprintf(Battpr, "%s", "100%");
//		gtk_label_set_label(GTK_LABEL(Batt_Perc), Battpr);
//
//	}
//	else if (value <= 1580)
//	{
//	Batt_val = 15;
//	sprintf(Battpr, "%s", "15%");
//	gtk_label_set_label(GTK_LABEL(Batt_Perc), Battpr);
//	dsp_msg(45);
//	}
//
//	Battery_Symbol(Batt_val, 0);
// }
