
#define r_addR0 0x40 // 00
#define r_addR1 0x41 // 01
#define r_addR2 0x42 // 02
#define r_addR3 0x43 // 03

#define DATA1_Adr 0x44  // 04      // Add of Data1 Reg to Write data
#define DATA2_Adr 0x45  // 05      // Add of Data2 Reg to Write data
#define PRF_Adr 0x46    // 06      // Add of PRF Count to Write data
#define Gsta1_WAdr 0x47 // Gate 1 Start Write Address
#define Gsta2_WAdr 0x48 // Gate 2 Start Write Address
#define Gend1_WAdr 0x49 // Gate 1 End Write Address
#define Gend2_WAdr 0x4A // Gate 2 End Write Address
#define Gthe1_WAdr 0x4B // Gate 1 Threshold Write Address
#define Gthe2_WAdr 0x4C // Gate 2 Threshold Write Address

#define Gsta3_WAdr 0x4D // Gate 3 Start Write Address
#define Gend3_WAdr 0x4E // Gate 3 End Write Address
#define Gthe3_WAdr 0x4F // Gate 3 Threshold Write Address



#define r_addR5 0x05       // 03      // For Data Read from FPGA
#define r_Encoder1 0x06    // 06
#define r_addDAC2 0x07     // 07
#define r_addDAC3 0x08     // 08
#define r_addDAC4 0x09     // 09
#define r_addCHW 0x0A      // 10
#define r_addTXW 0x0B      // 11
#define r_addTXD 0x0C      // 12
#define r_addSSDLY 0x0D    // 13
#define r_addRCFACT 0x0E   // 14
#define r_addGAT1STA 0x0F  // 15
#define r_addGAT2STA 0x10  // 16
#define r_addGAT1THR 0x11  // 17
#define r_addGAT2THR 0x12  // 18
#define r_addDOP 0x13      // 19
#define r_addCHSLCT 0x14   // 20
#define r_addFREQBAND 0x15 // 21
#define r_addENCRST 0x56   //  0x16 //22
#define r_addCtrReg1 0x17  // 22

//*************** Data Write to FPGA Address

//*************** Data Read from FPGA Address
#define Byte1_Rdadr 0x01 // orded with 0010 XXXX
#define Byte2_Rdadr 0x02
#define Byte3_Rdadr 0x03
#define Byte4_Rdadr 0x04
#define Kyb_Rdadr 0x05
#define Enc1cnt_Rdadrl 0x06
#define Enc1cnt_Rdadrm 0x07
#define ADC_Rdadr 0x08
#define Gate1crs_Rdadr 0x09
#define Gate2crs_Rdadr 0x0A
#define Dip_Rdadr 0x0B
#define Enc1cnte_Rdadr 0x0C
#define Enc2cnte_Rdadr 0x0D

#define r_addTCGDATA 0x17 // 23
#define r_addTCGRST 0x18  // 24
#define r_addTCGRST0 0x19 // 25
#define r_addTCGRST1 0x1A // 26
#define r_addTCGRST2 0x1B // 27

// Key Code

#define K1_CODE 0x01    // 0000 0000 0000 0001                                          //  K1, 24    K2, 26  K3, 27  K4, 29
#define K2_CODE 0x02    // 0000 0000 0000 0010                                                       //  K5, 30    K6, 17  K7, 21  K8, 22
#define K3_CODE 0x04    // 0000 0000 0000 0100	                                                   //  K9, 23    K10, 32  K11, 33  K12, 34
#define K4_CODE 0x08    // 0000 0000 0000 1000	                                                   //  K13, 35    LED L11 15    LED L12 16
#define K5_CODE 0x10    // 0000 0000 0001 0000
#define K6_CODE 0x20    // 0000 0000 0010 0000
#define K7_CODE 0x40    // 0000 0000 0100 0000
#define K8_CODE 0x80    // 0000 0000 1000 0000
#define K9_CODE 0x100   // 0000 0000 0000 0000
#define K10_CODE 0x200  // 0000 0000 0000 0000
#define K11_CODE 0x400  // 0000 0000 0000 0000
#define K12_CODE 0x800  // 0000 0000 0000 0000
#define K13_CODE 0x1000 // 0000 0000 0000 0000

#define MAX_RangeMM 1000000
// #define MAX_RangeMM 1500000
#define MAX_RangeINCH 400000

#define MIN_Range 250 //  1000  Minimum Range 2.5mm

#define MAX_DiaMM 300000
#define MAX_DiaINCH 400000
#define MIN_Dia 1000 

#define MODE_S 0   // Probe Mode
#define TRIG_S 1   // Measurement Trigger Point
#define REJECT_S 2 // Reject Active Not Active
#define SZEVAL_S 3 // Size Evalution Mode
#define EXT_S 4    // Size Evalution Mode

#define ZERO_PERA 0 // Mnu 0
#define RANGE_PERA 1
#define VELO_PERA 2
#define DELAY_PERA 3
#define GAIN_PERA 4

#define GATE1_PERA 5 // Mnu 1
#define GSTA1_PERA 6
#define GEND1_PERA 7
#define GTHE1_PERA 8
#define REF_GAIN 9

#define GATE2_PERA 10 // Mnu 2
#define GSTA2_PERA 11
#define GEND2_PERA 12
#define GTHE2_PERA 13
// #define GAIN_v 14

#define MEM_PERA 15 // Mnu 3
#define MEM_NO_PERA 16
#define MEM_ACT_PERA 17
#define MEM_NOTE_PERA 18
// #define Gain_v 19

#define DAC_PERA 20 // Mnu 4
#define CURSOR_PERA 21
#define PRESS_PERA 22
#define POINT_PERA 23
// #define GAIN2_1_v 24

#define DAMP_PERA 25 // Mnu 5
#define POWER_PERA 260 // 26
#define MODE_PERA 26 //27
#define PRF_PERA 27 //28
#define TXVOLT_PERA 28
//#define PRFVAL_PERA 28
// #define GAIN2_v 29

#define REJECT_PERA 30 // Mnu 6
#define FREQ_PERA 31
#define RECTIFY_PERA 32
#define SMOOTH_PERA 33
// #define GAIN3_v 34

#define GRID_PERA 35 // Mnu 7  //GRID_PERA:    Grid_f(key_v);
#define COL_LEG_PERA 36
#define VIDEO_PERA 37
#define SET_REF_PERA 38
// #define GAIN3_v 34

#define SCR_THEME_PERA 40
#define ACOLOR_PERA 41
#define BRIGHT_PERA 42
#define SCREEN_PERA 43
// #define GAIN4_v 39

#define XOFF_PERA 45
#define ANGLE_PERA 46
#define THICK_PERA 47
#define TRIG_PERA 48

#define CLOCK_PERA  50
#define HORN_PERA   51
#define BEEP_PERA   52
#define UNIT_PERA   53 // FLNAME_PERA

#define ACAL_PERA 55
#define STRT_GA_PERA 56
#define DST1_PERA 57
#define DST2_PERA 58

#define SIZE_EV_PERA 60
#define MEA_POSI1_PERA 61
#define MEA_POSI2_PERA 62
#define MEA_POSI3_PERA 63

#define REC_TYPE_PERA 65
#define RECORD_NO_PERA 66
#define RECORD_OP_PERA 67
#define REC_ACTION_PERA 68

#define ENCODER_PERA 70
#define ENC_CAL_PERA 71
#define ENC_STRT_PERA 72
#define ENC_KMPST_PERA 73

#define WELD_PROF_PERA 75
#define BEAM_PROF_PERA 76
#define THICK_CLR_PERA 77
#define CNG_OGL_PROF_POS 78

// #define BSC_DSP_PERA   64

#define MINUTE_v 80 // 75
#define HOUR_v 81   // 76
#define DAY_v 82    // 77
#define MONTH_v 83  // 78
#define YEAR_v 84   // 79

#define SCALE_POS_PERA 85  // MINUTE_v+5              // DGS Configuration
#define PRBNM_POS_PERA 86  // SCALE_POS_PERA+1
#define PRFFRE_POS_PERA 87 // PRBNM_POS_PERA+1
#define DELVEL_PERA 88     // PRFFRE_POS_PERA+1

#define D_EFECT_PERA 90  // SCALE_POS_PERA+5
#define DGS_CRV_PERA 91  // D_EFECT_PERA+1
#define REF_ECHO_PERA 92 // DGS_CRV_PERA+1
#define REF_SIZ_PERA 93  // REF_ECHO_PERA+1

#define DGS_EX_PERA 95  // D_EFECT_PERA+5
#define ATT_REF_PERA 96 // DGS_EX_PERA+1
#define ATT_OBJ_PERA 97 // ATT_REF_PERA+1
#define AMP_COR_PERA 98 // ATT_OBJ_PERA+1

#define WELD_TYPE_PERA 100  // DGS_EX_PERA+5          // WELD PROFILE
#define TOP_WIDTH_PERA 101  // WELD_TYPE_PERA+1
#define TOP_HEIGHT_PERA 102 // TOP_WIDTH_PERA+1
#define ROOT_WIDTH_PERA 103 // TOP_HEIGHT_PERA+1

#define OBJ_SHAPE_PERA 105 // WELD_TYPE_PERA+5
#define OBJ_WIDTH_PERA 106 // EXT_11_PERA+1
#define OBJ_THICK_PERA 107 // EXT_12_PERA+1
#define WPROF_POS_PERA 108 // EXT_13_PERA+1

#define EXT_WELD_PRF_PERA 110 // EXT_11_PERA+5
#define PROB_POS_PERA 111     // EXT_21_PERA+1
#define PROBE_ANGLE_PERA 112  // EXT_22_PERA+1
#define NOOF_LEGv_PERA 113    // EXT_23_PERA+1

// #define  OBJ_SHAPE_PERA     115 // EXT_21_PERA+5           // Test Object Shape Configuration
// #define  PROB_POS_PERA      116 // OBJ_SHAPE_PERA+1
// #define  PROBE_ANGLE_PERA   117 // PROB_POS_PERA+1
// #define  NOOF_LEGv_PERA     118 // PROBE_ANGLE_PERA+1

#define EXT_21_PERA 115 // HEIGHT_PERA+1
#define EXT_22_PERA 116 // HEIGHT_PERA+1
#define EXT_23_PERA 117 // HEIGHT_PERA+1
#define EXT_24_PERA 118 // HEIGHT_PERA+1

// #define  WIDTH_PERA         120 // OBJ_SHAPE_PERA+5
// #define  HEIGHT_PERA        121 // WIDTH_PERA+1

#define EXT_31_PERA 120 // HEIGHT_PERA+1
#define EXT_32_PERA 121 // EXT_33_PERA+1
#define EXT_33_PERA 122 // HEIGHT_PERA+1
#define EXT_34_PERA 123 // EXT_33_PERA+1

#define EXT_41_PERA 125 // WIDTH_PERA+5
#define EXT_42_PERA 126 // EXT_41_PERA+1   EXT_42_PERA
#define EXT_43_PERA 127 // EXT_42_PERA+1
#define EXT_44_PERA 128 // EXT_43_PERA+1

#define BEAM_PrbDia_PERA 130  // EXT_21_PERA+5           // Test Object Shape Configuration
#define BEAM_PrbFreq_PERA 131 // OBJ_SHAPE_PERA+1
#define BEAM_PRF_P13_PERA 132 // PROB_POS_PERA+1
#define BEAM_PRF_P14_PERA 133 // PROBE_ANGLE_PERA+1

#define BEAM_PRF_P21_PERA 135 // OBJ_SHAPE_PERA+5
#define BEAM_PRF_P22_PERA 136 // WIDTH_PERA+1
#define BEAM_PRF_P23_PERA 137 // HEIGHT_PERA+1
#define BEAM_PRF_P24_PERA 138 // EXT_33_PERA+1

#define BEAM_PRF_P31_PERA 140 // WIDTH_PERA+5
#define BEAM_PRF_P32_PERA 141 // EXT_41_PERA+1
#define BEAM_PRF_P33_PERA 142 // EXT_42_PERA+1
#define BEAM_PRF_P34_PERA 143 // EXT_43_PERA+1

// #define THKFILE_TYPE_PERA 145 // EXT_41_PERA+5              // Thickness File Create Type
// #define START_ID_1_PERA 146   // THKFILE_TYPE_PERA+1
// #define START_ID_2_PERA 147   // START_ID_1_PERA+1
// #define START_ID_3_PERA 148  //149   // START_ID_2_PERA+1

// #define EXT_51_PERA 150   // THKFILE_TYPE_PERA+5
// #define END_ID_1_PERA 151 // EXT_51_PERA+1
// #define END_ID_2_PERA 152 // END_ID_1_PERA+1
// #define END_ID_3_PERA 153 // END_ID_2_PERA+1

// #define EXIT_PERA 155       // EXT_51_PERA+5
// #define DIM_1_SIZE_PERA 156 // EXIT_PERA+1
// #define DIM_2_SIZE_PERA 157 // DIM_1_SIZE_PERA+1
// #define DIM_3_SIZE_PERA 158 // DIM_2_SIZE_PERA+1

#define COLOR_METHOD_PERA 145 // EXIT_PERA+5           // Thickness file Color Selection
#define START_THK_1_PERA 146  // COLOR_METHOD_PERA+1
#define START_THK_2_PERA 147  // START_THK_1_PERA+1
#define START_THK_3_PERA 148  // START_THK_2_PERA+1

#define EXT_61_PERA 150    // COLOR_METHOD_PERA+5
#define END_THK_1_PERA 151 // EXT_61_PERA+1
#define END_THK_2_PERA 152 // END_THK_1_PERA+1
#define END_THK_3_PERA 153 // END_THK_2_PERA+1

#define EXIT_71_PERA 155 // EXT_61_PERA+5
#define COLOR_1_PERA 156 // EXIT_71_PERA+1
#define COLOR_2_PERA 157 // COLOR_1_PERA+1
#define COLOR_3_PERA 158 // COLOR_2_PERA+1

// #define COLOR_METHOD_PERA 160 // EXIT_PERA+5           // Thickness file Color Selection
// #define START_THK_1_PERA 161  // COLOR_METHOD_PERA+1
// #define START_THK_2_PERA 162  // START_THK_1_PERA+1
// #define START_THK_3_PERA 163  // START_THK_2_PERA+1

// #define EXT_61_PERA 165    // COLOR_METHOD_PERA+5
// #define END_THK_1_PERA 166 // EXT_61_PERA+1
// #define END_THK_2_PERA 167 // END_THK_1_PERA+1
// #define END_THK_3_PERA 168 // END_THK_2_PERA+1

// #define EXIT_71_PERA 170 // EXT_61_PERA+5
// #define COLOR_1_PERA 171 // EXIT_71_PERA+1
// #define COLOR_2_PERA 172 // COLOR_1_PERA+1
// #define COLOR_3_PERA 173 // COLOR_2_PERA+1

#define THKFILE_TYPE_PERA 160 // EXT_41_PERA+5              // Thickness File Create Type
#define START_ID_1_PERA 161   // THKFILE_TYPE_PERA+1
#define START_ID_2_PERA 162   // START_ID_1_PERA+1
#define START_ID_3_PERA 163  //149   // START_ID_2_PERA+1

#define EXT_51_PERA 165   // THKFILE_TYPE_PERA+5
#define END_ID_1_PERA 166 // EXT_51_PERA+1
#define END_ID_2_PERA 167 // END_ID_1_PERA+1
#define END_ID_3_PERA 168 // END_ID_2_PERA+1

#define EXIT_PERA 170       // EXT_51_PERA+5
#define DIM_1_SIZE_PERA 171 // EXIT_PERA+1
#define DIM_2_SIZE_PERA 172 // DIM_1_SIZE_PERA+1
#define DIM_3_SIZE_PERA 173 // DIM_2_SIZE_PERA+1


// #define  Scal_pos     161 // 80 //161
// #define  PrbNm_Pos    163 // 81 //163
// #define  PrbFrq_pos   165 // 82 //165
// #define  Del_vel_pos  167 // 83 //167

// #define  D_Effct_pos  171 // 85 //171
// #define  Dgs_crv_pos  173 // 86 //173
// #define  Ref_echo_pos 175 // 87 //175
// #define  Ref_sz_pos   177 // 88 //177

// #define  Dgs_ex_pos   181 // 90 //181
// #define  Att_ref_pos  183 // 91 //183
// #define  Att_obj_pos  185 // 92 //185
// #define  Amp_cor_pos  187 // 93 //187

// #define  val_Scal_pos     80
// #define  val_PrbNm_Pos    81
// #define  val_PrbFrq_pos   82
// #define  val_Del_vel_pos  83
//
// #define  val_D_Effct_pos  85
// #define  val_Dgs_crv_pos  86
// #define  val_Ref_echo_pos 87
// #define  val_Ref_sz_pos   88
//
// #define  val_Dgs_ex_pos   90
// #define  val_Att_ref_pos  91
// #define  val_Att_obj_pos  92
// #define  val_Amp_cor_pos  93

#define Menu_UP_K 0xE080
#define Menu_DN_K 0xE100
#define GAIN_UP_K 0xE002
#define GAIN_DN_K 0xE001
#define Pera_UP_K 0xE010
#define Pera_DN_K 0xE004
#define SLCT_UP_K 0xE008
#define SLCT_DN_K 0xE040
#define STP_Key_K 0xE020
