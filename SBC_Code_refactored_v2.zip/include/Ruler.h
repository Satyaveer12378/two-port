#ifndef _RULAR_H
#define _RULAR_H

char bscan_rng_s_val[8] = "0";
char bscan_rng_e_val[8] = "100";
gint scl_val = 1000, ndgt = 0;
int pos_ary[20] = {0, 82, 154, 226, 298, 370, 442, 514, 586, 658, 750}; // 750 = Asc_Width
gint find_string_length(gchar *str)
{
	gint length = 0;

	for (; *str != '\0'; str++)
	{
		length++;
	}
	return (length);
}

gint Scal_s = 0;
gint Scal_e = 0;

//************************************************************************
//  Scale function definitations
//************************************************************************
// void horizontal_ruler(GtkDrawingArea *draw, cairo_t *cr) // ;   gint width, gint height)
void horizontal_ruler(void)
{
	cairo_t *cr = h_ruler_cr;

	gint width = frame_width + ruler_Height_width + 1;
	gint height = ruler_Height_width;
	cairo_text_extents_t extents;

	float value, fltscl_val;
	char buffer[40],buffer1[40];
	gchar num[8], dec_num[8], num_s[8], num_e[8];
	gint i = 0, j = 0, len = 0, str_sz = 0;
	gdouble sp = ruler_Height_width + 1;
	// gdouble digit_pos = (Asc_Width / 10.0);
	// gdouble line_pos = digit_pos / 5.0;
	
	int rng_val = val_ary[RANGE_PERA];		
	
	// cairo_set_source_rgb(cr, 0.0, 1.0, 1.0);
	cairo_set_source_rgb(cr, 1.0, 1.0, 0.0);
	cairo_paint(cr); // Set Back Ground

	cairo_set_source_rgb(cr, 0.0, 0.0, 0.0); // Text /Line Color
	cairo_set_font_size(cr, 12.0);

	if (rng_val >= 10000)
	{
		if (Unit_v == MM)
		{
			scl_val = rng_val / 100;
		}
		else if (Unit_v == INCH)
		{
			scl_val = rng_val / 100;
			fltscl_val = scl_val;
			fltscl_val = fltscl_val / 10;
		}
	}
	else if (rng_val < 10000 && rng_val >= 1000)
	{
		if (Unit_v == MM)
		{
			scl_val = rng_val / 10;
			fltscl_val = scl_val;
			fltscl_val = fltscl_val / 10;
		}
		else if (Unit_v == INCH)
		{
			scl_val = rng_val / 10;
			fltscl_val = scl_val;
			fltscl_val = fltscl_val / 100;
		}
	}
	else
	{
		if (Unit_v == MM)
		{
			scl_val = rng_val;
			fltscl_val = scl_val;
			fltscl_val = fltscl_val / 100;
		}
		else if (Unit_v == INCH)
		{
			scl_val = rng_val;
			fltscl_val = scl_val;
			fltscl_val = fltscl_val / 1000;
		}
	}

	pos = (DELAY_PERA * 2) + 1;
	value = atof(all_btnval[pos]); // GET THE DELAY VALUE

	float tmpnew_val = 0.0; // To get the 10 values even when (scl_val % 10) not equal to 0
	tmpnew_val = (float)scl_val / 10;

	if (Gate1_v != 8)
	{
		if ((scl_val % 10) == 0) // If modulo 10 == 0
		{
			for (i = 0; i < 11; i++)
			{
				if (Unit_v == MM)
				{
					if (value > 0 || value < 0) // If modulo 10 == 0 with Delay value
					{
						if (rng_val >= 10000)
						{
							sprintf(num, "%.2f", ((scl_val / 10) * i) + value);
							sprintf(num_s, "%.2f", ((scl_val / 10) * 0) + value);
							sprintf(num_e, "%.2f", ((scl_val / 10) * 10) + value);
						}
						else if (rng_val < 10000 && rng_val >= 1000)
						{
							sprintf(num, "%.2f", ((fltscl_val / 10) * i) + value);
							sprintf(num_s, "%.2f", ((fltscl_val / 10) * 0) + value);
							sprintf(num_e, "%.2f", ((fltscl_val / 10) * 10) + value);
						}
						else
						{
							sprintf(num, "%.2f", ((fltscl_val / 10) * i) + value);
							sprintf(num_s, "%.2f", ((fltscl_val / 10) * 0) + value);
							sprintf(num_e, "%.2f", ((fltscl_val / 10) * 10) + value);
						}
					}
					else // If modulo 10 == 0 without Delay value
					{
						if (rng_val >= 10000)
						{
							sprintf(num, "%d", ((scl_val / 10) * i));
							sprintf(num_s, "%d", ((scl_val / 10) * 0));
							sprintf(num_e, "%d", ((scl_val / 10) * 10));
						}
						else if (rng_val < 10000 && rng_val >= 1000)
						{
							sprintf(num, "%.1f", ((fltscl_val / 10) * i));
							sprintf(num_s, "%.1f", ((fltscl_val / 10) * 0));
							sprintf(num_e, "%.1f", ((fltscl_val / 10)* 10));
						}
						else
						{
							sprintf(num, "%.2f", ((fltscl_val / 10) * i));
							sprintf(num_s, "%.2f", ((fltscl_val / 10)* 0));
							sprintf(num_e, "%.2f", ((fltscl_val / 10)* 10));
						}
					}
				}
				else if (Unit_v == INCH)
				{
					if (value > 0 || value < 0) // If modulo 10 == 0 with Delay value
					{
						if (rng_val >= 10000)
						{
							sprintf(num, "%.3f", ((fltscl_val / 10) * i) + value);
							sprintf(num_s, "%.3f", ((fltscl_val / 10)* 0) + value);
							sprintf(num_e, "%.3f", ((fltscl_val / 10)* 10) + value);
						}
						else if (rng_val < 10000 && rng_val >= 1000)
						{
							sprintf(num, "%.3f", ((fltscl_val / 10) * i) + value);
							sprintf(num_s, "%.3f", ((fltscl_val / 10)* 0) + value);
							sprintf(num_e, "%.3f", ((fltscl_val / 10)* 10) + value);
						}
						else
						{
							sprintf(num, "%.3f", ((fltscl_val / 10) * i) + value);
							sprintf(num_s, "%.3f", ((fltscl_val / 10)* 0) + value);
							sprintf(num_e, "%.3f", ((fltscl_val / 10)* 10) + value);
						}
					}
					else // If modulo 10 == 0 without Delay value
					{
						if (rng_val >= 10000)
						{
							sprintf(num, "%.2f", ((fltscl_val / 10) * i));
							sprintf(num_s, "%.2f", ((fltscl_val / 10)* 0));
							sprintf(num_e, "%.2f", ((fltscl_val / 10)* 10));
						}
						else if (rng_val < 10000 && rng_val >= 1000)
						{
							sprintf(num, "%.2f", ((fltscl_val / 10) * i));
							sprintf(num_s, "%.2f", ((fltscl_val / 10)* 0));
							sprintf(num_e, "%.2f", ((fltscl_val / 10)* 10));
						}
						else
						{
							sprintf(num, "%.2f", ((fltscl_val / 10) * i));
							sprintf(num_s, "%.2f", ((fltscl_val / 10) * 0));
							sprintf(num_e, "%.2f", ((fltscl_val / 10) * 10));
						}
					}
				}
				str_sz = find_string_length(num);

				if (str_sz <= ndgt)
				{
					dec_num[0] = '0';
					dec_num[1] = '.';
					dec_num[2] = num[0];
					dec_num[3] = num[1];
					dec_num[4] = num[2];
					dec_num[5] = num[3];
					dec_num[6] = num[4];
					dec_num[7] = num[5];
				}
				else
				{
					for (j = 0; j < sizeof(dec_num); j++)
					{
						if (j < (str_sz - ndgt))
						{
							dec_num[j] = num[j];
						}
						else if (j == (str_sz - ndgt))
						{
							dec_num[j] = ' ';
						}
						else
						{
							dec_num[j] = num[j - 1];
						}
					}
				}

				cairo_text_extents(cr, dec_num, &extents);
				if (i < 10)
				{
					cairo_move_to(cr, sp + (((Asc_Width * i) / 10) - (extents.width / 2.0)), 22.0);
				}
				else if (i == 10)
				{
					cairo_move_to(cr, (sp - 10.0) + (((Asc_Width * i) / 10) - (extents.width / 2.0)), 22.0);
				}

				cairo_show_text(cr, dec_num);
			}
		}
		else
		{
			if ((scl_val % 10) == 5) // If value modulo 5 == 0
			{
				if (value > 0 || value < 0) // If value modulo 5 == 0 && With Delay value
				{
					if (rng_val >= 10000)
					{
						if (Unit_v == MM)
						{
							sprintf(num, "%.2f", 0 + value); // For 0 value
							sprintf(num_s, "%.2f", 0 + value);
							cairo_text_extents(cr, num, &extents);
							cairo_move_to(cr, sp - extents.width / 2.0, 22.0);
							cairo_show_text(cr, num);

							for (i = 2; i < 10; i = i + 2)
							{
								sprintf(num, "%.2f", value + (tmpnew_val * i));
								cairo_text_extents(cr, num, &extents);
								cairo_move_to(cr, (sp - 10.0) + (pos_ary[i] - (extents.width / 2.0)), 22.0);
								cairo_show_text(cr, num);
							}

							sprintf(num, "%.2f", scl_val + value); // For 10th Value
							sprintf(num_e, "%.2f", scl_val + value); // For 10th Value
							cairo_text_extents(cr, num, &extents);
							cairo_move_to(cr, (sp - 10.0) + ((Asc_Width) - (extents.width / 2.0)), 22.0);
							cairo_show_text(cr, num);
						}
						else if (Unit_v == INCH)
						{
							sprintf(num, "%.3f", 0 + value);
							sprintf(num_s, "%.3f", 0 + value);
							cairo_text_extents(cr, num, &extents);
							cairo_move_to(cr, sp - extents.width / 2.0, 22.0);
							cairo_show_text(cr, num);

							sprintf(num, "%.3f", fltscl_val + value);
							sprintf(num_e, "%.3f", fltscl_val + value);
							cairo_text_extents(cr, num, &extents);
							cairo_move_to(cr, (sp - 10.0) + ((Asc_Width) - (extents.width / 2.0)), 22.0);
							cairo_show_text(cr, num);
						}
					}
					else if (rng_val < 10000 && rng_val >= 1000)
					{
						if (Unit_v == MM)
						{
							sprintf(num, "%.1f", 0 + value); // For 0 value
							sprintf(num_s, "%.1f", 0 + value);
							cairo_text_extents(cr, num, &extents);
							cairo_move_to(cr, sp - extents.width / 2.0, 22.0);
							cairo_show_text(cr, num);

							for (i = 2; i < 10; i = i + 2)
							{
								sprintf(num, "%.2f", value + (fltscl_val * i));
								cairo_text_extents(cr, num, &extents);
								cairo_move_to(cr, (sp - 10.0) + (pos_ary[i] - (extents.width / 2.0)), 22.0);
								cairo_show_text(cr, num);
							}

							sprintf(num, "%.1f", fltscl_val + value); // For 10th Value
							sprintf(num_e, "%.1f", fltscl_val + value);
							cairo_text_extents(cr, num, &extents);
							cairo_move_to(cr, (sp - 10.0) + ((Asc_Width) - (extents.width / 2.0)), 22.0);
							cairo_show_text(cr, num);

						}
						else if (Unit_v == INCH)
						{
							sprintf(num, "%.3f", 0 + value);
							sprintf(num_s, "%.3f", 0 + value);
							cairo_text_extents(cr, num, &extents);
							cairo_move_to(cr, sp - extents.width / 2.0, 22.0);
							cairo_show_text(cr, num);

							sprintf(num, "%.3f", fltscl_val + value);
							sprintf(num_e, "%.3f", fltscl_val + value);
							cairo_text_extents(cr, num, &extents);
							cairo_move_to(cr, (sp - 10.0) + ((Asc_Width) - (extents.width / 2.0)), 22.0);
							cairo_show_text(cr, num);
						}
					}
					else if (rng_val < 1000)
					{
						if (Unit_v == MM)
						{
							sprintf(num, "%.2f", 0 + value); // For 0 value
							sprintf(num_s, "%.2f", 0 + value);
							cairo_text_extents(cr, num, &extents);
							cairo_move_to(cr, sp - extents.width / 2.0, 22.0);
							cairo_show_text(cr, num);

							for (i = 2; i < 10; i = i + 2)
							{
								sprintf(num, "%.2f", value + (fltscl_val * i)); // For 2nd Value
								cairo_text_extents(cr, num, &extents);
								cairo_move_to(cr, (sp - 10.0) + (pos_ary[i] - (extents.width / 2.0)), 22.0);
								cairo_show_text(cr, num);
							}

							sprintf(num, "%.2f", fltscl_val + value); // For 10th Value
							sprintf(num_e, "%.2f", fltscl_val + value);
							cairo_text_extents(cr, num, &extents);
							cairo_move_to(cr, (sp - 10.0) + ((Asc_Width) - (extents.width / 2.0)), 22.0);
							cairo_show_text(cr, num);
						}
						else if (Unit_v == INCH)
						{
							sprintf(num, "%.3f", 0 + value);
							cairo_text_extents(cr, num, &extents);
							cairo_move_to(cr, sp - extents.width / 2.0, 22.0);
							cairo_show_text(cr, num);

							sprintf(num, "%.3f", fltscl_val + value);
							cairo_text_extents(cr, num, &extents);
							cairo_move_to(cr, (sp - 10.0) + ((Asc_Width) - (extents.width / 2.0)), 22.0);
							cairo_show_text(cr, num);
						}
					}
				}
				else // If value modulo 5 == 0 && Without Delay value
				{
					if (rng_val >= 10000)
					{
						if (Unit_v == MM)
						{
							sprintf(num, "%d", 0);
							sprintf(num_s, "%d", 0);
							cairo_text_extents(cr, num, &extents);
							cairo_move_to(cr, sp - extents.width / 2.0, 22.0);
							cairo_show_text(cr, num);

							for (i = 2; i < 10; i = i + 2)
							{
								sprintf(num, "%d", (int)(tmpnew_val * i));
								cairo_text_extents(cr, num, &extents);
								cairo_move_to(cr, (sp - 10.0) + (pos_ary[i] - (extents.width / 2.0)), 22.0);
								cairo_show_text(cr, num);
							}

							sprintf(num, "%d", scl_val);
							sprintf(num_e, "%d", scl_val);
							cairo_text_extents(cr, num, &extents);
							cairo_move_to(cr, (sp - 10.0) + ((Asc_Width) - (extents.width / 2.0)), 22.0);
							cairo_show_text(cr, num);
						}
						else if (Unit_v == INCH)
						{
							sprintf(num, "%d", 0);
							cairo_text_extents(cr, num, &extents);
							cairo_move_to(cr, sp - extents.width / 2.0, 22.0);
							cairo_show_text(cr, num);

							sprintf(num, "%.1f", fltscl_val);
							cairo_text_extents(cr, num, &extents);
							cairo_move_to(cr, (sp - 10.0) + ((Asc_Width) - (extents.width / 2.0)), 22.0);
							cairo_show_text(cr, num);
						}
					}
					else if (rng_val < 10000 && rng_val >= 1000)
					{
						if (Unit_v == MM)
						{
							sprintf(num, "%d", 0);
							sprintf(num_s, "%d", 0);
							cairo_text_extents(cr, num, &extents);
							cairo_move_to(cr, sp - extents.width / 2.0, 22.0);
							cairo_show_text(cr, num);

							sprintf(num, "%.1f", fltscl_val);
							sprintf(num_e, "%.1f", fltscl_val);
							cairo_text_extents(cr, num, &extents);
							cairo_move_to(cr, (sp - 10.0) + ((Asc_Width) - (extents.width / 2.0)), 22.0);
							cairo_show_text(cr, num);
						}
						else if (Unit_v == INCH)
						{
							sprintf(num, "%d", 0);
							cairo_text_extents(cr, num, &extents);
							cairo_move_to(cr, sp - extents.width / 2.0, 22.0);
							cairo_show_text(cr, num);

							sprintf(num, "%.2f", fltscl_val);
							cairo_text_extents(cr, num, &extents);
							cairo_move_to(cr, (sp - 10.0) + ((Asc_Width) - (extents.width / 2.0)), 22.0);
							cairo_show_text(cr, num);
						}
					}
					else if ( rng_val < 1000)
					{
						if (Unit_v == MM)
						{
							sprintf(num, "%d", 0);
							sprintf(num_s, "%d", 0);
							cairo_text_extents(cr, num, &extents);
							cairo_move_to(cr, sp - extents.width / 2.0, 22.0);
							cairo_show_text(cr, num);

							sprintf(num, "%.2f", fltscl_val);
							sprintf(num_e, "%.2f", fltscl_val);
							cairo_text_extents(cr, num, &extents);
							cairo_move_to(cr, (sp - 10.0) + ((Asc_Width) - (extents.width / 2.0)), 22.0);
							cairo_show_text(cr, num);
						}
						else if (Unit_v == INCH)
						{
							sprintf(num, "%d", 0);
							sprintf(num_s, "%d", 0);
							cairo_text_extents(cr, num, &extents);
							cairo_move_to(cr, sp - extents.width / 2.0, 22.0);
							cairo_show_text(cr, num);

							sprintf(num, "%.3f", fltscl_val);
							sprintf(num_e, "%.3f", fltscl_val);
							cairo_text_extents(cr, num, &extents);
							cairo_move_to(cr, (sp - 10.0) + ((Asc_Width) - (extents.width / 2.0)), 22.0);
							cairo_show_text(cr, num);
						}
					}
				}
			}
			else // For normal values
			{
				if (value > 0 || value < 0) // With the Delay value for normal values
				{
					if (rng_val >= 10000)
					{
						if (Unit_v == MM)
						{
							sprintf(num, "%.2f", 0 + value);
							sprintf(num_s, "%.2f", 0 + value);
							cairo_text_extents(cr, num, &extents);
							cairo_move_to(cr, sp - extents.width / 2.0, 22.0);
							cairo_show_text(cr, num);

							sprintf(num, "%.2f", scl_val + value);
							sprintf(num_e, "%.2f", scl_val + value);
							cairo_text_extents(cr, num, &extents);
							cairo_move_to(cr, (sp - 10.0) + ((Asc_Width) - (extents.width / 2.0)), 22.0);
							cairo_show_text(cr, num);
						}
						else if (Unit_v == INCH)
						{
							sprintf(num, "%.3f", 0 + value);
							cairo_text_extents(cr, num, &extents);
							cairo_move_to(cr, sp - extents.width / 2.0, 22.0);
							cairo_show_text(cr, num);

							sprintf(num, "%.3f", fltscl_val + value);
							cairo_text_extents(cr, num, &extents);
							cairo_move_to(cr, (sp - 10.0) + ((Asc_Width) - (extents.width / 2.0)), 22.0);
							cairo_show_text(cr, num);
						}
					}
					else if (rng_val < 10000 && rng_val >= 1000)
					{
						if (Unit_v == MM)
						{
							sprintf(num, "%.1f", 0 + value);
							sprintf(num_s, "%.1f", 0 + value);
							cairo_text_extents(cr, num, &extents);
							cairo_move_to(cr, sp - extents.width / 2.0, 22.0);
							cairo_show_text(cr, num);

							sprintf(num, "%.1f", fltscl_val + value);
							sprintf(num_e, "%.1f", fltscl_val + value);
							cairo_text_extents(cr, num, &extents);
							cairo_move_to(cr, (sp - 10.0) + ((Asc_Width) - (extents.width / 2.0)), 22.0);
							cairo_show_text(cr, num);
						}
						else if (Unit_v == INCH)
						{
							sprintf(num, "%.3f", 0 + value);
							cairo_text_extents(cr, num, &extents);
							cairo_move_to(cr, sp - extents.width / 2.0, 22.0);
							cairo_show_text(cr, num);

							sprintf(num, "%.3f", fltscl_val + value);
							cairo_text_extents(cr, num, &extents);
							cairo_move_to(cr, (sp - 10.0) + ((Asc_Width) - (extents.width / 2.0)), 22.0);
							cairo_show_text(cr, num);
						}
					}
					else if (rng_val < 1000)
					{
						if (Unit_v == MM)
						{
							sprintf(num, "%.1f", 0 + value);
							sprintf(num_s, "%.1f", 0 + value);
							cairo_text_extents(cr, num, &extents);
							cairo_move_to(cr, sp - extents.width / 2.0, 22.0);
							cairo_show_text(cr, num);

							sprintf(num, "%.2f", fltscl_val + value);
							sprintf(num_e, "%.2f", fltscl_val + value);
							cairo_text_extents(cr, num, &extents);
							cairo_move_to(cr, (sp - 10.0) + ((Asc_Width) - (extents.width / 2.0)), 22.0);
							cairo_show_text(cr, num);
						}
						else if (Unit_v == INCH)
						{
							sprintf(num, "%.3f", 0 + value);
							cairo_text_extents(cr, num, &extents);
							cairo_move_to(cr, sp - extents.width / 2.0, 22.0);
							cairo_show_text(cr, num);

							sprintf(num, "%.3f", fltscl_val + value);
							cairo_text_extents(cr, num, &extents);
							cairo_move_to(cr, (sp - 10.0) + ((Asc_Width) - (extents.width / 2.0)), 22.0);
							cairo_show_text(cr, num);
						}
					}
				}
				else // Without the Delay value for normal values
				{
					if (rng_val >= 10000)
					{
						if (Unit_v == MM)
						{
							sprintf(num, "%d", 0);
							sprintf(num_s, "%d", 0);
							cairo_text_extents(cr, num, &extents);
							cairo_move_to(cr, sp - extents.width / 2.0, 22.0);
							cairo_show_text(cr, num);

							sprintf(num, "%d", scl_val);
							sprintf(num_e, "%d", scl_val);
							cairo_text_extents(cr, num, &extents);
							cairo_move_to(cr, (sp - 10.0) + ((Asc_Width) - (extents.width / 2.0)), 22.0);
							cairo_show_text(cr, num);
						}
						if (Unit_v == INCH)
						{
							sprintf(num, "%d", 0);
							cairo_text_extents(cr, num, &extents);
							cairo_move_to(cr, sp - extents.width / 2.0, 22.0);
							cairo_show_text(cr, num);

							sprintf(num, "%.1f", fltscl_val);
							cairo_text_extents(cr, num, &extents);
							cairo_move_to(cr, (sp - 10.0) + ((Asc_Width) - (extents.width / 2.0)), 22.0);
							cairo_show_text(cr, num);
						}
					}
					else if (rng_val < 10000 && rng_val >= 1000)
					{
						if (Unit_v == MM)
						{
							sprintf(num, "%d", 0);
							sprintf(num_s, "%d", 0);
							cairo_text_extents(cr, num, &extents);
							cairo_move_to(cr, sp - extents.width / 2.0, 22.0);
							cairo_show_text(cr, num);

							sprintf(num, "%.1f", fltscl_val);
							sprintf(num_e, "%.1f", fltscl_val);
							cairo_text_extents(cr, num, &extents);
							cairo_move_to(cr, (sp - 10.0) + ((Asc_Width) - (extents.width / 2.0)), 22.0);
							cairo_show_text(cr, num);
						}
						if (Unit_v == INCH)
						{
							sprintf(num, "%d", 0);
							cairo_text_extents(cr, num, &extents);
							cairo_move_to(cr, sp - extents.width / 2.0, 22.0);
							cairo_show_text(cr, num);

							sprintf(num, "%.2f", fltscl_val);
							cairo_text_extents(cr, num, &extents);
							cairo_move_to(cr, (sp - 10.0) + ((Asc_Width) - (extents.width / 2.0)), 22.0);
							cairo_show_text(cr, num);
						}
					}
					else if (rng_val < 1000)
					{
						if (Unit_v == MM)
						{
							sprintf(num, "%d", 0);
							sprintf(num_s, "%d", 0);
							cairo_text_extents(cr, num, &extents);
							cairo_move_to(cr, sp - extents.width / 2.0, 22.0);
							cairo_show_text(cr, num);

							sprintf(num, "%.2f", fltscl_val);
							sprintf(num_e, "%.2f", fltscl_val);
							cairo_text_extents(cr, num, &extents);
							cairo_move_to(cr, (sp - 10.0) + ((Asc_Width) - (extents.width / 2.0)), 22.0);
							cairo_show_text(cr, num);
						}
						if (Unit_v == INCH)
						{
							sprintf(num, "%d", 0);
							cairo_text_extents(cr, num, &extents);
							cairo_move_to(cr, sp - extents.width / 2.0, 22.0);
							cairo_show_text(cr, num);

							sprintf(num, "%.3f", fltscl_val);
							cairo_text_extents(cr, num, &extents);
							cairo_move_to(cr, (sp - 10.0) + ((Asc_Width) - (extents.width / 2.0)), 22.0);
							cairo_show_text(cr, num);
						}
					}
				}
			}
		}
	}
	else  // else condition used only for Expand function.
	{
		cairo_text_extents(cr, gasDisp, &extents);
		cairo_move_to(cr, sp - extents.width / 2.0, 22.0);
		cairo_show_text(cr, gasDisp);
		
		cairo_text_extents(cr, gaeDisp, &extents);
		cairo_move_to(cr, (sp - 10.0) + ((Asc_Width) - (extents.width / 2.0)), 22.0);
		cairo_show_text(cr, gaeDisp);
	}

	for (i = 0; i < 51; i++)
	{
		if (i % 5 == 0)
			len = 12;
		else
			len = 6;

		cairo_move_to(cr, sp + ((Asc_Width * i) / 50), 0);
		cairo_line_to(cr, sp + ((Asc_Width * i) / 50), len);
		cairo_stroke(cr);
	}

	sprintf(bscan_rng_s_val, "%s", num_s); // num_s = start_no
	sprintf(bscan_rng_e_val, "%s", num_e); // num_e = end_no

	// refresh call
	gtk_image_set_from_surface(GTK_IMAGE(h_ruler_img), h_ruler_surface);
	// cairo_surface_write_to_png(surface, "Images/Images/output.png");
}

//*************************************************************************************
void vertical_ruler(void)
{
	cairo_t *cr = v_ruler_cr;
	cairo_text_extents_t extents;
	gint width = ruler_Height_width; // frame_width + ruler_Height_width + 1;
	gint height = frame_height;

	gchar num[4];
	gint i = 0, len = 6;
	gint voff = 0;

	cairo_set_source_rgb(cr, 0.7, 0.7, 0.7);
	cairo_paint(cr);
	cairo_set_source_rgb(cr, 0.0, 0.0, 0.0);
	cairo_set_font_size(cr, 12.0);

	if (splite_win_flg == 0)
	{
		voff = Voff + 1;
	}
	else if (splite_win_flg == 1)
	{
		voff = (height_sh / 2) + 15;
	}

	cairo_move_to(cr, 0.0, voff - 3.0);
	cairo_show_text(cr, "10");

	for (i = 1; i < 10; i++)
	{
		cairo_move_to(cr, 3.0, ((Asc_Height * i) / 10) + voff);
		sprintf(num, "%d", (10 - i));
		cairo_show_text(cr, num);
	}

	for (i = 50; i > 0; i--)
	{
		if (i % 5 == 0)
			len = 12;
		else
			len = 6;

		cairo_move_to(cr, width - len, ((Asc_Height * i) / 50) + voff);
		cairo_line_to(cr, width, ((Asc_Height * i) / 50) + voff);
		cairo_stroke(cr);
	}

	cairo_move_to(cr, width - 12.0, voff);
	cairo_line_to(cr, width, voff);
	cairo_stroke(cr);

	// vertically Bscan Scale
	if (splite_win_flg == 1)
	{
		voff = 3;

		cairo_move_to(cr, 0.0, bsc_height + voff + 13);
		cairo_show_text(cr, bscan_rng_e_val);

		for (i = 20; i > 0; i--)
		{
			if (i % 10 == 0)
				len = 12;
			else
				len = 6;

			cairo_move_to(cr, width - len, ((bsc_height * i) / 20) + voff);
			cairo_line_to(cr, width, ((bsc_height * i) / 20) + voff);
			cairo_stroke(cr);
		}

		cairo_move_to(cr, width - 12.0, voff + 1);
		cairo_line_to(cr, width, voff + 1);
		cairo_stroke(cr);

		cairo_move_to(cr, 0.0, 10.0 + voff);
		cairo_show_text(cr, bscan_rng_s_val);
	}

	// refresh call
	gtk_image_set_from_surface(GTK_IMAGE(v_ruler_img), v_ruler_surface);
	// cairo_surface_write_to_png(v_ruler_surface, "v_ruler.png");
}

//************************************************************************
//  Scale function definitations
//************************************************************************
GtkWidget *horizontal_ruler_working_old(gint width, gint height)
{
	// GtkWidget *ruler;

	// cairo_t *cr;
	// cairo_surface_t *surface;
	// cairo_text_extents_t extents;

	// gchar num[8], dec_num[8];
	// gint i = 0, j = 0, len = 0, str_sz = 0;
	// gdouble sp = height;
	// gdouble digit_pos = (((gdouble)width - height - 10.0) / 10.0);
	// gdouble line_pos = digit_pos / 5.0;

	// surface = cairo_image_surface_create(CAIRO_FORMAT_RGB24, width, height);
	// cr = cairo_create(surface);
	// cairo_set_source_rgb(cr, 0.7, 0.7, 0.7);
	// cairo_paint(cr);

	// cairo_set_source_rgb(cr, 0.0, 0.0, 1.0);
	// cairo_set_font_size(cr, 12.0);

	// scl_val = val_ary[RANGE_PERA]/100;  //  range_val = val_ary[RANGE_PERA]  //1000

	// if ((scl_val % 2) == 0)
	//{
	//   for (i = 0; i < 11; i++)
	//   {
	//     sprintf(num, "%d", (scl_val / 10) * i);
	//     str_sz = find_string_length(num);

	//    if (str_sz <= ndgt)
	//    {
	//      dec_num[0] = '0';
	//      dec_num[1] = '.';
	//      dec_num[2] = num[0];
	//      dec_num[3] = num[1];
	//      dec_num[4] = num[2];
	//      dec_num[5] = num[3];
	//      dec_num[6] = num[4];
	//      dec_num[7] = num[5];
	//    }
	//    else
	//    {
	//      for (j = 0; j < sizeof(dec_num); j++)
	//      {
	//        if (j < (str_sz - ndgt))
	//          dec_num[j] = num[j];
	//        else if (j == (str_sz - ndgt))
	//          dec_num[j] = '.';
	//        else
	//          dec_num[j] = num[j - 1];
	//      }
	//    }

	//    cairo_text_extents(cr, dec_num, &extents);
	//    if (i < 10)
	//      cairo_move_to(cr, sp + ((digit_pos * i) - (extents.width / 2.0)), 22.0);
	//    else if (i == 10)
	//      cairo_move_to(cr, (sp - 10.0) + ((digit_pos * i) - (extents.width / 2.0)), 22.0);

	//    cairo_show_text(cr, dec_num);
	//  }
	//}
	// else
	//{
	//  sprintf(num, "%d", 0);
	//  cairo_text_extents(cr, num, &extents);
	//  cairo_move_to(cr, sp - extents.width / 2.0, 22.0);
	//  cairo_show_text(cr, num);

	//  sprintf(num, "%d", scl_val);
	//  cairo_text_extents(cr, num, &extents);
	//  cairo_move_to(cr, (sp - 10.0) + ((digit_pos * 10.0) - (extents.width / 2.0)), 22.0);
	//  cairo_show_text(cr, num);
	//}

	// for (i = 0; i < 51; i++)
	//{
	//   if (i % 5 == 0)
	//     len = 12;
	//   else
	//     len = 6;

	//  cairo_move_to(cr, sp + (line_pos * i), 0);
	//  cairo_line_to(cr, sp + (line_pos * i), len);
	//  cairo_stroke(cr);
	//}

	// cairo_destroy(cr);
	// ruler = gtk_image_new_from_surface(surface);
	//// cairo_surface_write_to_png(surface, "Images/Images/output.png");
	// cairo_surface_destroy(surface);

	// return (ruler);
}

GtkWidget *vertical_ruler_safe(gint width, gint height)
{
	///*GtkWidget *ruler;

	// cairo_t *cr;
	// cairo_surface_t *surface;
	// cairo_text_extents_t extents;

	// gchar num[4];
	// gint i = 0, len = 6;
	// gdouble digit_pos = (gdouble)(height - 1.0) / 10.0;
	// gdouble line_pos = digit_pos / 5.0;

	// surface = cairo_image_surface_create(CAIRO_FORMAT_RGB24, width, height);
	// cr = cairo_create(surface);

	// cairo_set_source_rgb(cr, 0.7, 0.7, 0.7);
	// cairo_paint(cr);
	// cairo_set_source_rgb(cr, 0.0, 0.0, 1.0);
	// cairo_set_font_size(cr, 12.0);

	// cairo_move_to(cr, 0.0, 10.0);
	// cairo_show_text(cr, "10");

	// for (i = 1; i < 10; i++)
	//{
	//   cairo_move_to(cr, 3.0, (digit_pos * i) + 5.0);
	//   sprintf(num, "%d", (10 - i));
	//   cairo_show_text(cr, num);
	// }

	// for (i = 50; i > 0; i--)
	//{
	//   if (i % 5 == 0)
	//     len = 12;
	//   else
	//     len = 6;

	//  cairo_move_to(cr, width - len, (line_pos * i));
	//  cairo_line_to(cr, width, (line_pos * i));
	//  cairo_stroke(cr);
	//}

	// cairo_move_to(cr, width - 12.0, (line_pos * i) + 2.0);
	// cairo_line_to(cr, width, (line_pos * i) + 2.0);
	// cairo_stroke(cr);

	// cairo_destroy(cr);
	// ruler = gtk_image_new_from_surface(surface);
	// cairo_surface_destroy(surface);

	// return (ruler);*/
}

#endif /* _RULAR_H */
