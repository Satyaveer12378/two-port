#ifndef _RULAR_H
#define _RULAR_H

gint scl_val = 1000, ndgt = 0;

gint find_string_length(gchar *str)
{
  gint length = 0;

  for (; *str != '\0'; str++)
  {
    length++;
  }
  return (length);
}

//************************************************************************
//  Scale function definitations
//************************************************************************
// void horizontal_ruler(GtkDrawingArea *draw, cairo_t *cr) // ;   gint width, gint height)
void horizontal_ruler(void)
{
  cairo_t *cr = h_ruler_cr;
 
  gint width = frame_width + ruler_Height_width + 1;
  gint height = ruler_Height_width;
  cairo_text_extents_t extents;

  float value;
  gchar num[8], dec_num[8];
  gint i = 0, j = 0, len = 0, str_sz = 0;
  gdouble sp = ruler_Height_width + 1;
  // gdouble digit_pos = (Asc_Width / 10.0);
  // gdouble line_pos = digit_pos / 5.0;

  cairo_set_source_rgb(cr, 0.0, 1.0, 1.0);
  cairo_paint(cr); // Set Back Ground

  cairo_set_source_rgb(cr, 0.0, 0.0, 1.0); // Text /Line Color
  cairo_set_font_size(cr, 12.0);

  scl_val = val_ary[RANGE_PERA] / 100; //  range_val = val_ary[RANGE_PERA]  //1000

  pos = (DELAY_PERA * 2) + 1;
	value = atof(all_btnval[pos]); // GET THE DELAY VALUE

  if ((scl_val % 10) == 0)
  {
    for (i = 0; i < 11; i++)
    {
      sprintf(num, "%.2f", ((scl_val / 10) * i) + value);
      str_sz = find_string_length(num);

      if (str_sz <= ndgt)
      {
        dec_num[0] = '0';
        dec_num[1] = '.';
        dec_num[2] = num[0];
        dec_num[3] = num[1];
        dec_num[4] = num[2];
        dec_num[5] = num[3];
        dec_num[6] = num[4];
        dec_num[7] = num[5];
      }
      else
      {
        for (j = 0; j < sizeof(dec_num); j++)
        {
          if (j < (str_sz - ndgt))
            dec_num[j] = num[j];
          else if (j == (str_sz - ndgt))
            dec_num[j] = ' ';
          else
            dec_num[j] = num[j - 1];
        }
      }

      cairo_text_extents(cr, dec_num, &extents);
      if (i < 10)
        cairo_move_to(cr, sp + (((Asc_Width * i) / 10) - (extents.width / 2.0)), 22.0);
      else if (i == 10)
        cairo_move_to(cr, (sp - 10.0) + (((Asc_Width * i) / 10) - (extents.width / 2.0)), 22.0);

      cairo_show_text(cr, dec_num);
    }
  }
  else
  {
    sprintf(num, "%d", 0);
    cairo_text_extents(cr, num, &extents);
    cairo_move_to(cr, sp - extents.width / 2.0, 22.0);
    cairo_show_text(cr, num);

    sprintf(num, "%d", scl_val);
    cairo_text_extents(cr, num, &extents);
    cairo_move_to(cr, (sp - 10.0) + ((Asc_Width) - (extents.width / 2.0)), 22.0);
    cairo_show_text(cr, num);
  }

  for (i = 0; i < 51; i++)
  {
    if (i % 5 == 0)
      len = 12;
    else
      len = 6;

    cairo_move_to(cr, sp + ((Asc_Width * i) / 50), 0);
    cairo_line_to(cr, sp + ((Asc_Width * i) / 50), len);
    cairo_stroke(cr);
  }

  // refresh call
  gtk_image_set_from_surface(GTK_IMAGE(h_ruler_img), h_ruler_surface);
  // cairo_surface_write_to_png(surface, "Images/Images/output.png");
}

//************************************************************************
//  Scale function definitations
//************************************************************************
GtkWidget *horizontal_ruler_working_old(gint width, gint height)
{
  // GtkWidget *ruler;

  // cairo_t *cr;
  // cairo_surface_t *surface;
  // cairo_text_extents_t extents;

  // gchar num[8], dec_num[8];
  // gint i = 0, j = 0, len = 0, str_sz = 0;
  // gdouble sp = height;
  // gdouble digit_pos = (((gdouble)width - height - 10.0) / 10.0);
  // gdouble line_pos = digit_pos / 5.0;

  // surface = cairo_image_surface_create(CAIRO_FORMAT_RGB24, width, height);
  // cr = cairo_create(surface);
  // cairo_set_source_rgb(cr, 0.7, 0.7, 0.7);
  // cairo_paint(cr);

  // cairo_set_source_rgb(cr, 0.0, 0.0, 1.0);
  // cairo_set_font_size(cr, 12.0);

  // scl_val = val_ary[RANGE_PERA]/100;  //  range_val = val_ary[RANGE_PERA]  //1000

  // if ((scl_val % 2) == 0)
  //{
  //   for (i = 0; i < 11; i++)
  //   {
  //     sprintf(num, "%d", (scl_val / 10) * i);
  //     str_sz = find_string_length(num);

  //    if (str_sz <= ndgt)
  //    {
  //      dec_num[0] = '0';
  //      dec_num[1] = '.';
  //      dec_num[2] = num[0];
  //      dec_num[3] = num[1];
  //      dec_num[4] = num[2];
  //      dec_num[5] = num[3];
  //      dec_num[6] = num[4];
  //      dec_num[7] = num[5];
  //    }
  //    else
  //    {
  //      for (j = 0; j < sizeof(dec_num); j++)
  //      {
  //        if (j < (str_sz - ndgt))
  //          dec_num[j] = num[j];
  //        else if (j == (str_sz - ndgt))
  //          dec_num[j] = '.';
  //        else
  //          dec_num[j] = num[j - 1];
  //      }
  //    }

  //    cairo_text_extents(cr, dec_num, &extents);
  //    if (i < 10)
  //      cairo_move_to(cr, sp + ((digit_pos * i) - (extents.width / 2.0)), 22.0);
  //    else if (i == 10)
  //      cairo_move_to(cr, (sp - 10.0) + ((digit_pos * i) - (extents.width / 2.0)), 22.0);

  //    cairo_show_text(cr, dec_num);
  //  }
  //}
  // else
  //{
  //  sprintf(num, "%d", 0);
  //  cairo_text_extents(cr, num, &extents);
  //  cairo_move_to(cr, sp - extents.width / 2.0, 22.0);
  //  cairo_show_text(cr, num);

  //  sprintf(num, "%d", scl_val);
  //  cairo_text_extents(cr, num, &extents);
  //  cairo_move_to(cr, (sp - 10.0) + ((digit_pos * 10.0) - (extents.width / 2.0)), 22.0);
  //  cairo_show_text(cr, num);
  //}

  // for (i = 0; i < 51; i++)
  //{
  //   if (i % 5 == 0)
  //     len = 12;
  //   else
  //     len = 6;

  //  cairo_move_to(cr, sp + (line_pos * i), 0);
  //  cairo_line_to(cr, sp + (line_pos * i), len);
  //  cairo_stroke(cr);
  //}

  // cairo_destroy(cr);
  // ruler = gtk_image_new_from_surface(surface);
  //// cairo_surface_write_to_png(surface, "Images/Images/output.png");
  // cairo_surface_destroy(surface);

  // return (ruler);
}

//*************************************************************************************
void vertical_ruler(void)
//void vertical_ruler_old(GtkDrawingArea *draw, cairo_t *cr)
{
  cairo_t *cr = v_ruler_cr;
  cairo_text_extents_t extents;
  gint width = ruler_Height_width; // frame_width + ruler_Height_width + 1;
  gint height = frame_height;

  gchar num[4];
  gint i = 0, len = 6;
  gint voff;
  voff = Voff + 1; //  ruler_Height_width;

  // gdouble digit_pos = (gdouble)(height - 1.0) / 10.0;
  // gdouble line_pos = digit_pos / 5.0;

  cairo_set_source_rgb(cr, 0.7, 0.7, 0.7);
  cairo_paint(cr);
  cairo_set_source_rgb(cr, 0.0, 0.0, 1.0);
  cairo_set_font_size(cr, 12.0);

  cairo_move_to(cr, 0.0, 10.0 + voff);
  cairo_show_text(cr, "10");

  for (i = 1; i < 10; i++)
  {
    cairo_move_to(cr, 3.0, ((Asc_Height * i) / 10) + voff);
    sprintf(num, "%d", (10 - i));
    cairo_show_text(cr, num);
  }

  for (i = 50; i > 0; i--)
  {
    if (i % 5 == 0)
      len = 12;
    else
      len = 6;

    cairo_move_to(cr, width - len, ((Asc_Height * i) / 50) + voff);
    cairo_line_to(cr, width, ((Asc_Height * i) / 50) + voff);
    cairo_stroke(cr);
  }

  cairo_move_to(cr, width - 12.0, voff);
  cairo_line_to(cr, width, voff);
  cairo_stroke(cr);

  // refresh call
  gtk_image_set_from_surface(GTK_IMAGE(v_ruler_img), v_ruler_surface);
  // cairo_surface_write_to_png(v_ruler_surface, "v_ruler.png");
}

GtkWidget *vertical_ruler_safe(gint width, gint height)
{
  ///*GtkWidget *ruler;

  // cairo_t *cr;
  // cairo_surface_t *surface;
  // cairo_text_extents_t extents;

  // gchar num[4];
  // gint i = 0, len = 6;
  // gdouble digit_pos = (gdouble)(height - 1.0) / 10.0;
  // gdouble line_pos = digit_pos / 5.0;

  // surface = cairo_image_surface_create(CAIRO_FORMAT_RGB24, width, height);
  // cr = cairo_create(surface);

  // cairo_set_source_rgb(cr, 0.7, 0.7, 0.7);
  // cairo_paint(cr);
  // cairo_set_source_rgb(cr, 0.0, 0.0, 1.0);
  // cairo_set_font_size(cr, 12.0);

  // cairo_move_to(cr, 0.0, 10.0);
  // cairo_show_text(cr, "10");

  // for (i = 1; i < 10; i++)
  //{
  //   cairo_move_to(cr, 3.0, (digit_pos * i) + 5.0);
  //   sprintf(num, "%d", (10 - i));
  //   cairo_show_text(cr, num);
  // }

  // for (i = 50; i > 0; i--)
  //{
  //   if (i % 5 == 0)
  //     len = 12;
  //   else
  //     len = 6;

  //  cairo_move_to(cr, width - len, (line_pos * i));
  //  cairo_line_to(cr, width, (line_pos * i));
  //  cairo_stroke(cr);
  //}

  // cairo_move_to(cr, width - 12.0, (line_pos * i) + 2.0);
  // cairo_line_to(cr, width, (line_pos * i) + 2.0);
  // cairo_stroke(cr);

  // cairo_destroy(cr);
  // ruler = gtk_image_new_from_surface(surface);
  // cairo_surface_destroy(surface);

  // return (ruler);*/
}

#endif /* _RULAR_H */
