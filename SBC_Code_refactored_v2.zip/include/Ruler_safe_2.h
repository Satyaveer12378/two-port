#ifndef _RULAR_H
#define _RULAR_H

gint bscan_rng_s_val = 5;
gint bscan_rng_e_val = 50;
gint scl_val = 1000, ndgt = 0;
int pos_ary[20] = {0, 82, 154, 226, 298, 370, 442, 514, 586, 658, 750}; // 750 = Asc_Width
gint find_string_length(gchar *str)
{
	gint length = 0;

	for (; *str != '\0'; str++)
	{
		length++;
	}
	return (length);
}

//************************************************************************
//  Scale function definitations
//************************************************************************
// void horizontal_ruler(GtkDrawingArea *draw, cairo_t *cr) // ;   gint width, gint height)
void horizontal_ruler(void)
{
	cairo_t *cr = h_ruler_cr;

	gint width = frame_width + ruler_Height_width + 1;
	gint height = ruler_Height_width;
	cairo_text_extents_t extents;

	float value, fltscl_val;
	char buffer[40];
	gchar num[8], dec_num[8];
	gint i = 0, j = 0, len = 0, str_sz = 0;
	gdouble sp = ruler_Height_width + 1;
	// gdouble digit_pos = (Asc_Width / 10.0);
	// gdouble line_pos = digit_pos / 5.0;

	cairo_set_source_rgb(cr, 0.0, 1.0, 1.0);
	cairo_paint(cr); // Set Back Ground

	cairo_set_source_rgb(cr, 0.0, 0.0, 1.0); // Text /Line Color
	cairo_set_font_size(cr, 12.0);

	if (val_ary[RANGE_PERA] >= 10000)
	{
		if (Unit_v == MM)
		{
			scl_val = val_ary[RANGE_PERA] / 100;
		}
		else if (Unit_v == INCH)
		{
			scl_val = val_ary[RANGE_PERA] / 100;
			fltscl_val = scl_val;
			fltscl_val = fltscl_val / 10;
		}
	}
	else if (val_ary[RANGE_PERA] < 10000 && val_ary[RANGE_PERA] >= 1000)
	{
		if (Unit_v == MM)
		{
			scl_val = val_ary[RANGE_PERA] / 10;
			fltscl_val = scl_val;
			fltscl_val = fltscl_val / 10;
		}
		else if (Unit_v == INCH)
		{
			scl_val = val_ary[RANGE_PERA] / 10;
			fltscl_val = scl_val;
			fltscl_val = fltscl_val / 100;
		}

		// sprintf(buffer, "%.2f", fltscl_val);
		// gtk_label_set_label(GTK_LABEL(t_label[0]), buffer);
		// sprintf(buffer, "%.1f", fltscl_val);
		// gtk_label_set_label(GTK_LABEL(t_label[0]), buffer);
	}
	else
	{
		if (Unit_v == MM)
		{
			scl_val = val_ary[RANGE_PERA];
			fltscl_val = scl_val;
			fltscl_val = fltscl_val / 100;
		}
		else if (Unit_v == INCH)
		{
			scl_val = val_ary[RANGE_PERA];
			fltscl_val = scl_val;
			fltscl_val = fltscl_val / 1000;
		}

		// sprintf(buffer, "%f", fltscl_val);
		// gtk_label_set_label(GTK_LABEL(t_label[0]), buffer);
		// sprintf(buffer, "%f", fltscl_val);
		// gtk_label_set_label(GTK_LABEL(t_label[0]), buffer);
	}

	// sprintf(buffer, "%d", val_ary[RANGE_PERA]);  gtk_label_set_label(GTK_LABEL(t_label[0]), buffer);
	// sprintf(buffer, "%d", scl_val);  gtk_label_set_label(GTK_LABEL(t_label[1]), buffer);
	// sprintf(buffer, "%f", fltscl_val);  gtk_label_set_label(GTK_LABEL(t_label[2]), buffer);

	pos = (DELAY_PERA * 2) + 1;
	value = atof(all_btnval[pos]); // GET THE DELAY VALUE
	/*sprintf(buffer, "Bt=%f", value);
	gtk_label_set_label(GTK_LABEL(t_label[0]), buffer);*/

	float tmpnew_val = 0.0; // To get the 10 values even when (scl_val % 10) not equal to 0
	tmpnew_val = (float)scl_val / 10;

	if ((scl_val % 10) == 0) // If modulo 10 == 0
	{
		for (i = 0; i < 11; i++)
		{
			if (Unit_v == MM)
			{
				if (value > 0 || value < 0) // If modulo 10 == 0 with Delay value
				{
					if (val_ary[RANGE_PERA] >= 10000)
					{
						sprintf(num, "%.2f", ((scl_val / 10) * i) + value);
					}
					else if (val_ary[RANGE_PERA] < 10000 && val_ary[RANGE_PERA] >= 1000)
					{
						sprintf(num, "%.1f", ((fltscl_val / 10) * i) + value);
					}
					else
					{
						sprintf(num, "%.2f", ((fltscl_val / 10) * i) + value);
					}
				}
				else // If modulo 10 == 0 without Delay value
				{
					if (val_ary[RANGE_PERA] >= 10000)
					{
						sprintf(num, "%d", ((scl_val / 10) * i));
					}
					else if (val_ary[RANGE_PERA] < 10000 && val_ary[RANGE_PERA] >= 1000)
					{
						sprintf(num, "%.1f", ((fltscl_val / 10) * i));
					}
					else
					{
						sprintf(num, "%.2f", ((fltscl_val / 10) * i));
					}
				}
			}
			else if (Unit_v == INCH)
			{
				if (value > 0 || value < 0) // If modulo 10 == 0 with Delay value
				{
					if (val_ary[RANGE_PERA] >= 10000)
					{
						sprintf(num, "%.3f", ((fltscl_val / 10) * i) + value);
					}
					else if (val_ary[RANGE_PERA] < 10000 && val_ary[RANGE_PERA] >= 1000)
					{
						sprintf(num, "%.3f", ((fltscl_val / 10) * i) + value);
					}
					else
					{
						sprintf(num, "%.3f", ((fltscl_val / 10) * i) + value);
					}
				}
				else // If modulo 10 == 0 without Delay value
				{
					if (val_ary[RANGE_PERA] >= 10000)
					{
						sprintf(num, "%.2f", ((fltscl_val / 10) * i));
					}
					else if (val_ary[RANGE_PERA] < 10000 && val_ary[RANGE_PERA] >= 1000)
					{
						sprintf(num, "%.2f", ((fltscl_val / 10) * i));
					}
					else
					{
						sprintf(num, "%.2f", ((fltscl_val / 10) * i));
					}
				}
			}
			/*else
			{
				if (value > 0 || value < 0)
				{
					sprintf(num, "%.f", ((scl_val / 10) * i) + value);
				}
				else
				{
					sprintf(num, "%.1f", (float)((scl_val / 10) * i));
				}
			}*/
			// sprintf(num, "%.2f", ((scl_val / 10) * i) + value);
			str_sz = find_string_length(num);

			if (str_sz <= ndgt)
			{
				dec_num[0] = '0';
				dec_num[1] = '.';
				dec_num[2] = num[0];
				dec_num[3] = num[1];
				dec_num[4] = num[2];
				dec_num[5] = num[3];
				dec_num[6] = num[4];
				dec_num[7] = num[5];
			}
			else
			{
				for (j = 0; j < sizeof(dec_num); j++)
				{
					if (j < (str_sz - ndgt))
					{
						dec_num[j] = num[j];
					}
					else if (j == (str_sz - ndgt))
					{
						dec_num[j] = ' ';
					}
					else
					{
						dec_num[j] = num[j - 1];
					}
				}
			}

			cairo_text_extents(cr, dec_num, &extents);
			if (i < 10)
			{
				cairo_move_to(cr, sp + (((Asc_Width * i) / 10) - (extents.width / 2.0)), 22.0);
			}
			else if (i == 10)
			{
				cairo_move_to(cr, (sp - 10.0) + (((Asc_Width * i) / 10) - (extents.width / 2.0)), 22.0);
			}

			cairo_show_text(cr, dec_num);
		}
	}
	else
	{
		if ((scl_val % 10) == 5) // If value modulo 5 == 0
		{
			if (value > 0 || value < 0) // If value modulo 5 == 0 && With Delay value
			{
				if (val_ary[RANGE_PERA] >= 10000)
				{
					if (Unit_v == MM)
					{
						sprintf(num, "%.2f", 0 + value); // For 0 value
						cairo_text_extents(cr, num, &extents);
						cairo_move_to(cr, sp - extents.width / 2.0, 22.0);
						cairo_show_text(cr, num);

						for (i = 2; i < 10; i = i + 2)
						{
							sprintf(num, "%.2f", value + (tmpnew_val * i));
							cairo_text_extents(cr, num, &extents);
							cairo_move_to(cr, (sp - 10.0) + (pos_ary[i] - (extents.width / 2.0)), 22.0);
							cairo_show_text(cr, num);
						}

						sprintf(num, "%.2f", scl_val + value); // For 10th Value
						cairo_text_extents(cr, num, &extents);
						cairo_move_to(cr, (sp - 10.0) + ((Asc_Width) - (extents.width / 2.0)), 22.0);
						cairo_show_text(cr, num);

						/*sprintf(num, "%.2f", value + tmpnew_val);  // For 1st Value
						cairo_text_extents(cr, num, &extents);
						cairo_move_to(cr, (sp - 10.0) + (82 - (extents.width / 2.0)), 22.0);
						cairo_show_text(cr, num);*/

						// sprintf(num, "%.2f", value + (tmpnew_val * 2)); // For 2nd Value
						// cairo_text_extents(cr, num, &extents);
						// cairo_move_to(cr, (sp - 10.0) + (154 - (extents.width / 2.0)), 22.0);
						// cairo_show_text(cr, num);

						/*sprintf(num, "%.2f", value + (tmpnew_val * 3)); // For 3rd Value
						cairo_text_extents(cr, num, &extents);
						cairo_move_to(cr, (sp - 10.0) + (226 - (extents.width / 2.0)), 22.0);
						cairo_show_text(cr, num);*/

						// sprintf(num, "%.2f", value + (tmpnew_val * 4)); // For 4th Value
						// cairo_text_extents(cr, num, &extents);
						// cairo_move_to(cr, (sp - 10.0) + (298 - (extents.width / 2.0)), 22.0);
						// cairo_show_text(cr, num);

						/*sprintf(num, "%.2f", value + (tmpnew_val * 5)); // For 5th Value
						cairo_text_extents(cr, num, &extents);
						cairo_move_to(cr, (sp - 10.0) + (370 - (extents.width / 2.0)), 22.0);
						cairo_show_text(cr, num);*/

						// sprintf(num, "%.2f", value + (tmpnew_val * 6)); // For 6th Value
						// cairo_text_extents(cr, num, &extents);
						// cairo_move_to(cr, (sp - 10.0) + (442 - (extents.width / 2.0)), 22.0);
						// cairo_show_text(cr, num);

						/*sprintf(num, "%.2f", value + (tmpnew_val * 7)); // For 7th Value
						cairo_text_extents(cr, num, &extents);
						cairo_move_to(cr, (sp - 10.0) + (514 - (extents.width / 2.0)), 22.0);
						cairo_show_text(cr, num);*/

						// sprintf(num, "%.2f", value + (tmpnew_val * 8)); // For 8th Value
						// cairo_text_extents(cr, num, &extents);
						// cairo_move_to(cr, (sp - 10.0) + (586 - (extents.width / 2.0)), 22.0);
						// cairo_show_text(cr, num);

						/*sprintf(num, "%.2f", value + (tmpnew_val * 9)); // For 9th Value
						cairo_text_extents(cr, num, &extents);
						cairo_move_to(cr, (sp - 10.0) + (658 - (extents.width / 2.0)), 22.0);
						cairo_show_text(cr, num);*/
					}
					else if (Unit_v == INCH)
					{
						sprintf(num, "%.3f", 0 + value);
						cairo_text_extents(cr, num, &extents);
						cairo_move_to(cr, sp - extents.width / 2.0, 22.0);
						cairo_show_text(cr, num);

						sprintf(num, "%.3f", fltscl_val + value);
						cairo_text_extents(cr, num, &extents);
						cairo_move_to(cr, (sp - 10.0) + ((Asc_Width) - (extents.width / 2.0)), 22.0);
						cairo_show_text(cr, num);
					}
				}

				if (val_ary[RANGE_PERA] < 10000 && val_ary[RANGE_PERA] >= 1000)
				{
					if (Unit_v == MM)
					{
						sprintf(num, "%.1f", 0 + value); // For 0 value
						cairo_text_extents(cr, num, &extents);
						cairo_move_to(cr, sp - extents.width / 2.0, 22.0);
						cairo_show_text(cr, num);

						for (i = 2; i < 10; i = i + 2)
						{
							sprintf(num, "%.1f", value + (fltscl_val * i));
							cairo_text_extents(cr, num, &extents);
							cairo_move_to(cr, (sp - 10.0) + (pos_ary[i] - (extents.width / 2.0)), 22.0);
							cairo_show_text(cr, num);
						}

						sprintf(num, "%.1f", fltscl_val + value); // For 10th Value
						cairo_text_extents(cr, num, &extents);
						cairo_move_to(cr, (sp - 10.0) + ((Asc_Width) - (extents.width / 2.0)), 22.0);
						cairo_show_text(cr, num);

						/*sprintf(num, "%.2f", value + tmpnew_val);  // For 1st Value
						cairo_text_extents(cr, num, &extents);
						cairo_move_to(cr, (sp - 10.0) + (82 - (extents.width / 2.0)), 22.0);
						cairo_show_text(cr, num);*/

						// sprintf(num, "%.1f", value + (fltscl_val * 2)); // For 2nd Value
						// cairo_text_extents(cr, num, &extents);
						// cairo_move_to(cr, (sp - 10.0) + (154 - (extents.width / 2.0)), 22.0);
						// cairo_show_text(cr, num);

						/*sprintf(num, "%.2f", value + (tmpnew_val * 3)); // For 3rd Value
						cairo_text_extents(cr, num, &extents);
						cairo_move_to(cr, (sp - 10.0) + (226 - (extents.width / 2.0)), 22.0);
						cairo_show_text(cr, num);*/

						// sprintf(num, "%.1f", value + (fltscl_val * 4)); // For 4th Value
						// cairo_text_extents(cr, num, &extents);
						// cairo_move_to(cr, (sp - 10.0) + (298 - (extents.width / 2.0)), 22.0);
						// cairo_show_text(cr, num);

						/*sprintf(num, "%.2f", value + (tmpnew_val * 5)); // For 5th Value
						cairo_text_extents(cr, num, &extents);
						cairo_move_to(cr, (sp - 10.0) + (370 - (extents.width / 2.0)), 22.0);
						cairo_show_text(cr, num);*/

						// sprintf(num, "%.1f", value + (fltscl_val * 6)); // For 6th Value
						// cairo_text_extents(cr, num, &extents);
						// cairo_move_to(cr, (sp - 10.0) + (442 - (extents.width / 2.0)), 22.0);
						// cairo_show_text(cr, num);

						/*sprintf(num, "%.2f", value + (tmpnew_val * 7)); // For 7th Value
						cairo_text_extents(cr, num, &extents);
						cairo_move_to(cr, (sp - 10.0) + (514 - (extents.width / 2.0)), 22.0);
						cairo_show_text(cr, num);*/

						// sprintf(num, "%.1f", value + (fltscl_val * 8)); // For 8th Value
						// cairo_text_extents(cr, num, &extents);
						// cairo_move_to(cr, (sp - 10.0) + (586 - (extents.width / 2.0)), 22.0);
						// cairo_show_text(cr, num);

						/*sprintf(num, "%.2f", value + (tmpnew_val * 9)); // For 9th Value
						cairo_text_extents(cr, num, &extents);
						cairo_move_to(cr, (sp - 10.0) + (658 - (extents.width / 2.0)), 22.0);
						cairo_show_text(cr, num);*/
					}
					else if (Unit_v == INCH)
					{
						sprintf(num, "%.3f", 0 + value);
						cairo_text_extents(cr, num, &extents);
						cairo_move_to(cr, sp - extents.width / 2.0, 22.0);
						cairo_show_text(cr, num);

						sprintf(num, "%.3f", fltscl_val + value);
						cairo_text_extents(cr, num, &extents);
						cairo_move_to(cr, (sp - 10.0) + ((Asc_Width) - (extents.width / 2.0)), 22.0);
						cairo_show_text(cr, num);
					}
				}

				if (val_ary[RANGE_PERA] < 1000)
				{
					if (Unit_v == MM)
					{
						sprintf(num, "%.2f", 0 + value); // For 0 value
						cairo_text_extents(cr, num, &extents);
						cairo_move_to(cr, sp - extents.width / 2.0, 22.0);
						cairo_show_text(cr, num);

						/*sprintf(num, "%.2f", value + tmpnew_val);  // For 1st Value
						cairo_text_extents(cr, num, &extents);
						cairo_move_to(cr, (sp - 10.0) + (82 - (extents.width / 2.0)), 22.0);
						cairo_show_text(cr, num);*/

						sprintf(num, "%.2f", value + (fltscl_val * 2)); // For 2nd Value
						cairo_text_extents(cr, num, &extents);
						cairo_move_to(cr, (sp - 10.0) + (154 - (extents.width / 2.0)), 22.0);
						cairo_show_text(cr, num);

						/*sprintf(num, "%.2f", value + (tmpnew_val * 3)); // For 3rd Value
						cairo_text_extents(cr, num, &extents);
						cairo_move_to(cr, (sp - 10.0) + (226 - (extents.width / 2.0)), 22.0);
						cairo_show_text(cr, num);*/

						sprintf(num, "%.2f", value + (fltscl_val * 4)); // For 4th Value
						cairo_text_extents(cr, num, &extents);
						cairo_move_to(cr, (sp - 10.0) + (298 - (extents.width / 2.0)), 22.0);
						cairo_show_text(cr, num);

						/*sprintf(num, "%.2f", value + (tmpnew_val * 5)); // For 5th Value
						cairo_text_extents(cr, num, &extents);
						cairo_move_to(cr, (sp - 10.0) + (370 - (extents.width / 2.0)), 22.0);
						cairo_show_text(cr, num);*/

						sprintf(num, "%.2f", value + (fltscl_val * 6)); // For 6th Value
						cairo_text_extents(cr, num, &extents);
						cairo_move_to(cr, (sp - 10.0) + (442 - (extents.width / 2.0)), 22.0);
						cairo_show_text(cr, num);

						/*sprintf(num, "%.2f", value + (tmpnew_val * 7)); // For 7th Value
						cairo_text_extents(cr, num, &extents);
						cairo_move_to(cr, (sp - 10.0) + (514 - (extents.width / 2.0)), 22.0);
						cairo_show_text(cr, num);*/

						sprintf(num, "%.2f", value + (fltscl_val * 8)); // For 8th Value
						cairo_text_extents(cr, num, &extents);
						cairo_move_to(cr, (sp - 10.0) + (586 - (extents.width / 2.0)), 22.0);
						cairo_show_text(cr, num);

						/*sprintf(num, "%.2f", value + (tmpnew_val * 9)); // For 9th Value
						cairo_text_extents(cr, num, &extents);
						cairo_move_to(cr, (sp - 10.0) + (658 - (extents.width / 2.0)), 22.0);
						cairo_show_text(cr, num);*/

						sprintf(num, "%.2f", fltscl_val + value); // For 10th Value
						cairo_text_extents(cr, num, &extents);
						cairo_move_to(cr, (sp - 10.0) + ((Asc_Width) - (extents.width / 2.0)), 22.0);
						cairo_show_text(cr, num);
					}
					else if (Unit_v == INCH)
					{
						sprintf(num, "%.3f", 0 + value);
						cairo_text_extents(cr, num, &extents);
						cairo_move_to(cr, sp - extents.width / 2.0, 22.0);
						cairo_show_text(cr, num);

						sprintf(num, "%.3f", fltscl_val + value);
						cairo_text_extents(cr, num, &extents);
						cairo_move_to(cr, (sp - 10.0) + ((Asc_Width) - (extents.width / 2.0)), 22.0);
						cairo_show_text(cr, num);
					}
				}
			}

			else // If value modulo 5 == 0 && Without Delay value
			{
				if (val_ary[RANGE_PERA] >= 10000)
				{
					if (Unit_v == MM)
					{
						sprintf(num, "%d", 0);
						cairo_text_extents(cr, num, &extents);
						cairo_move_to(cr, sp - extents.width / 2.0, 22.0);
						cairo_show_text(cr, num);

						for (i = 2; i < 10; i = i + 2)
						{
							sprintf(num, "%d", (int)(tmpnew_val * i));
							cairo_text_extents(cr, num, &extents);
							cairo_move_to(cr, (sp - 10.0) + (pos_ary[i] - (extents.width / 2.0)), 22.0);
							cairo_show_text(cr, num);
						}

						sprintf(num, "%d", scl_val);
						cairo_text_extents(cr, num, &extents);
						cairo_move_to(cr, (sp - 10.0) + ((Asc_Width) - (extents.width / 2.0)), 22.0);
						cairo_show_text(cr, num);
					}
					else if (Unit_v == INCH)
					{
						sprintf(num, "%d", 0);
						cairo_text_extents(cr, num, &extents);
						cairo_move_to(cr, sp - extents.width / 2.0, 22.0);
						cairo_show_text(cr, num);

						sprintf(num, "%.1f", fltscl_val);
						cairo_text_extents(cr, num, &extents);
						cairo_move_to(cr, (sp - 10.0) + ((Asc_Width) - (extents.width / 2.0)), 22.0);
						cairo_show_text(cr, num);
					}
				}

				if (val_ary[RANGE_PERA] < 10000 && val_ary[RANGE_PERA] >= 1000)
				{
					if (Unit_v == MM)
					{
						sprintf(num, "%d", 0);
						cairo_text_extents(cr, num, &extents);
						cairo_move_to(cr, sp - extents.width / 2.0, 22.0);
						cairo_show_text(cr, num);

						sprintf(num, "%.1f", fltscl_val);
						cairo_text_extents(cr, num, &extents);
						cairo_move_to(cr, (sp - 10.0) + ((Asc_Width) - (extents.width / 2.0)), 22.0);
						cairo_show_text(cr, num);
					}
					else if (Unit_v == INCH)
					{
						sprintf(num, "%d", 0);
						cairo_text_extents(cr, num, &extents);
						cairo_move_to(cr, sp - extents.width / 2.0, 22.0);
						cairo_show_text(cr, num);

						sprintf(num, "%.2f", fltscl_val);
						cairo_text_extents(cr, num, &extents);
						cairo_move_to(cr, (sp - 10.0) + ((Asc_Width) - (extents.width / 2.0)), 22.0);
						cairo_show_text(cr, num);
					}
				}

				if (val_ary[RANGE_PERA] < 1000)
				{
					if (Unit_v == MM)
					{
						sprintf(num, "%d", 0);
						cairo_text_extents(cr, num, &extents);
						cairo_move_to(cr, sp - extents.width / 2.0, 22.0);
						cairo_show_text(cr, num);

						sprintf(num, "%.2f", fltscl_val);
						cairo_text_extents(cr, num, &extents);
						cairo_move_to(cr, (sp - 10.0) + ((Asc_Width) - (extents.width / 2.0)), 22.0);
						cairo_show_text(cr, num);
					}
					else if (Unit_v == INCH)
					{
						sprintf(num, "%d", 0);
						cairo_text_extents(cr, num, &extents);
						cairo_move_to(cr, sp - extents.width / 2.0, 22.0);
						cairo_show_text(cr, num);

						sprintf(num, "%.3f", fltscl_val);
						cairo_text_extents(cr, num, &extents);
						cairo_move_to(cr, (sp - 10.0) + ((Asc_Width) - (extents.width / 2.0)), 22.0);
						cairo_show_text(cr, num);
					}
				}
			}
		}
		else // For normal values
		{
			if (value > 0 || value < 0) // With the Delay value for normal values
			{
				if (val_ary[RANGE_PERA] >= 10000)
				{
					if (Unit_v == MM)
					{
						sprintf(num, "%.2f", 0 + value);
						cairo_text_extents(cr, num, &extents);
						cairo_move_to(cr, sp - extents.width / 2.0, 22.0);
						cairo_show_text(cr, num);

						sprintf(num, "%.2f", scl_val + value);
						cairo_text_extents(cr, num, &extents);
						cairo_move_to(cr, (sp - 10.0) + ((Asc_Width) - (extents.width / 2.0)), 22.0);
						cairo_show_text(cr, num);
					}
					else if (Unit_v == INCH)
					{
						sprintf(num, "%.3f", 0 + value);
						cairo_text_extents(cr, num, &extents);
						cairo_move_to(cr, sp - extents.width / 2.0, 22.0);
						cairo_show_text(cr, num);

						sprintf(num, "%.3f", fltscl_val + value);
						cairo_text_extents(cr, num, &extents);
						cairo_move_to(cr, (sp - 10.0) + ((Asc_Width) - (extents.width / 2.0)), 22.0);
						cairo_show_text(cr, num);
					}
				}

				if (val_ary[RANGE_PERA] < 10000 && val_ary[RANGE_PERA] >= 1000)
				{
					if (Unit_v == MM)
					{
						sprintf(num, "%.1f", 0 + value);
						cairo_text_extents(cr, num, &extents);
						cairo_move_to(cr, sp - extents.width / 2.0, 22.0);
						cairo_show_text(cr, num);

						sprintf(num, "%.1f", fltscl_val + value);
						cairo_text_extents(cr, num, &extents);
						cairo_move_to(cr, (sp - 10.0) + ((Asc_Width) - (extents.width / 2.0)), 22.0);
						cairo_show_text(cr, num);
					}
					else if (Unit_v == INCH)
					{
						sprintf(num, "%.3f", 0 + value);
						cairo_text_extents(cr, num, &extents);
						cairo_move_to(cr, sp - extents.width / 2.0, 22.0);
						cairo_show_text(cr, num);

						sprintf(num, "%.3f", fltscl_val + value);
						cairo_text_extents(cr, num, &extents);
						cairo_move_to(cr, (sp - 10.0) + ((Asc_Width) - (extents.width / 2.0)), 22.0);
						cairo_show_text(cr, num);
					}
				}

				if (val_ary[RANGE_PERA] < 1000)
				{
					if (Unit_v == MM)
					{
						sprintf(num, "%.1f", 0 + value);
						cairo_text_extents(cr, num, &extents);
						cairo_move_to(cr, sp - extents.width / 2.0, 22.0);
						cairo_show_text(cr, num);

						sprintf(num, "%.2f", fltscl_val + value);
						cairo_text_extents(cr, num, &extents);
						cairo_move_to(cr, (sp - 10.0) + ((Asc_Width) - (extents.width / 2.0)), 22.0);
						cairo_show_text(cr, num);
					}
					else if (Unit_v == INCH)
					{
						sprintf(num, "%.3f", 0 + value);
						cairo_text_extents(cr, num, &extents);
						cairo_move_to(cr, sp - extents.width / 2.0, 22.0);
						cairo_show_text(cr, num);

						sprintf(num, "%.3f", fltscl_val + value);
						cairo_text_extents(cr, num, &extents);
						cairo_move_to(cr, (sp - 10.0) + ((Asc_Width) - (extents.width / 2.0)), 22.0);
						cairo_show_text(cr, num);
					}
				}
			}
			else // Without the Delay value for normal values
			{
				if (val_ary[RANGE_PERA] >= 10000)
				{
					if (Unit_v == MM)
					{
						sprintf(num, "%d", 0);
						cairo_text_extents(cr, num, &extents);
						cairo_move_to(cr, sp - extents.width / 2.0, 22.0);
						cairo_show_text(cr, num);

						sprintf(num, "%d", scl_val);
						cairo_text_extents(cr, num, &extents);
						cairo_move_to(cr, (sp - 10.0) + ((Asc_Width) - (extents.width / 2.0)), 22.0);
						cairo_show_text(cr, num);
					}
					if (Unit_v == INCH)
					{
						sprintf(num, "%d", 0);
						cairo_text_extents(cr, num, &extents);
						cairo_move_to(cr, sp - extents.width / 2.0, 22.0);
						cairo_show_text(cr, num);

						sprintf(num, "%.1f", fltscl_val);
						cairo_text_extents(cr, num, &extents);
						cairo_move_to(cr, (sp - 10.0) + ((Asc_Width) - (extents.width / 2.0)), 22.0);
						cairo_show_text(cr, num);
					}
				}
				if (val_ary[RANGE_PERA] < 10000 && val_ary[RANGE_PERA] >= 1000)
				{
					if (Unit_v == MM)
					{
						sprintf(num, "%d", 0);
						cairo_text_extents(cr, num, &extents);
						cairo_move_to(cr, sp - extents.width / 2.0, 22.0);
						cairo_show_text(cr, num);

						sprintf(num, "%.1f", fltscl_val);
						cairo_text_extents(cr, num, &extents);
						cairo_move_to(cr, (sp - 10.0) + ((Asc_Width) - (extents.width / 2.0)), 22.0);
						cairo_show_text(cr, num);
					}
					if (Unit_v == INCH)
					{
						sprintf(num, "%d", 0);
						cairo_text_extents(cr, num, &extents);
						cairo_move_to(cr, sp - extents.width / 2.0, 22.0);
						cairo_show_text(cr, num);

						sprintf(num, "%.2f", fltscl_val);
						cairo_text_extents(cr, num, &extents);
						cairo_move_to(cr, (sp - 10.0) + ((Asc_Width) - (extents.width / 2.0)), 22.0);
						cairo_show_text(cr, num);
					}
				}

				if (val_ary[RANGE_PERA] < 1000)
				{
					if (Unit_v == MM)
					{
						sprintf(num, "%d", 0);
						cairo_text_extents(cr, num, &extents);
						cairo_move_to(cr, sp - extents.width / 2.0, 22.0);
						cairo_show_text(cr, num);

						sprintf(num, "%.2f", fltscl_val);
						cairo_text_extents(cr, num, &extents);
						cairo_move_to(cr, (sp - 10.0) + ((Asc_Width) - (extents.width / 2.0)), 22.0);
						cairo_show_text(cr, num);
					}
					if (Unit_v == INCH)
					{
						sprintf(num, "%d", 0);
						cairo_text_extents(cr, num, &extents);
						cairo_move_to(cr, sp - extents.width / 2.0, 22.0);
						cairo_show_text(cr, num);

						sprintf(num, "%.3f", fltscl_val);
						cairo_text_extents(cr, num, &extents);
						cairo_move_to(cr, (sp - 10.0) + ((Asc_Width) - (extents.width / 2.0)), 22.0);
						cairo_show_text(cr, num);
					}
				}
			}
		}
		/*sprintf(num, "%.2f", 0 + value);
		cairo_text_extents(cr, num, &extents);
		cairo_move_to(cr, sp - extents.width / 2.0, 22.0);
		cairo_show_text(cr, num);

		sprintf(num, "%.2f", value + tmpnew_val);
		cairo_text_extents(cr, num, &extents);
		cairo_move_to(cr, (sp - 10.0) + (82-(extents.width / 2.0)), 22.0);
		cairo_show_text(cr, num);

		sprintf(num, "%.2f", value + (tmpnew_val * 2));
		cairo_text_extents(cr, num, &extents);
		cairo_move_to(cr, (sp - 10.0) + (154 - (extents.width / 2.0)), 22.0);
		cairo_show_text(cr, num);

		sprintf(num, "%.2f", value + (tmpnew_val * 3));
		cairo_text_extents(cr, num, &extents);
		cairo_move_to(cr, (sp - 10.0) + (226 - (extents.width / 2.0)), 22.0);
		cairo_show_text(cr, num);

		sprintf(num, "%.2f", value + (tmpnew_val * 4));
		cairo_text_extents(cr, num, &extents);
		cairo_move_to(cr, (sp - 10.0) + (298 - (extents.width / 2.0)), 22.0);
		cairo_show_text(cr, num);

		sprintf(num, "%.2f", value + (tmpnew_val * 5));
		cairo_text_extents(cr, num, &extents);
		cairo_move_to(cr, (sp - 10.0) + (370 - (extents.width / 2.0)), 22.0);
		cairo_show_text(cr, num);

		sprintf(num, "%.2f", value + (tmpnew_val * 6));
		cairo_text_extents(cr, num, &extents);
		cairo_move_to(cr, (sp - 10.0) + (442 - (extents.width / 2.0)), 22.0);
		cairo_show_text(cr, num);

		sprintf(num, "%.2f", value + (tmpnew_val * 7));
		cairo_text_extents(cr, num, &extents);
		cairo_move_to(cr, (sp - 10.0) + (514 - (extents.width / 2.0)), 22.0);
		cairo_show_text(cr, num);

		sprintf(num, "%.2f", value + (tmpnew_val * 8));
		cairo_text_extents(cr, num, &extents);
		cairo_move_to(cr, (sp - 10.0) + (586 - (extents.width / 2.0)), 22.0);
		cairo_show_text(cr, num);

		sprintf(num, "%.2f", value + (tmpnew_val * 9));
		cairo_text_extents(cr, num, &extents);
		cairo_move_to(cr, (sp - 10.0) + (658 - (extents.width / 2.0)), 22.0);
		cairo_show_text(cr, num);

		sprintf(num, "%.2f", scl_val + value);
		cairo_text_extents(cr, num, &extents);
		cairo_move_to(cr, (sp - 10.0) + ((Asc_Width)-(extents.width / 2.0)), 22.0);
		cairo_show_text(cr, num);*/
	}

	for (i = 0; i < 51; i++)
	{
		if (i % 5 == 0)
			len = 12;
		else
			len = 6;

		cairo_move_to(cr, sp + ((Asc_Width * i) / 50), 0);
		cairo_line_to(cr, sp + ((Asc_Width * i) / 50), len);
		cairo_stroke(cr);
	}

	// refresh call
	gtk_image_set_from_surface(GTK_IMAGE(h_ruler_img), h_ruler_surface);
	// cairo_surface_write_to_png(surface, "Images/Images/output.png");
}

//*************************************************************************************
void vertical_ruler(void)
{
	cairo_t *cr = v_ruler_cr;
	cairo_text_extents_t extents;
	gint width = ruler_Height_width; // frame_width + ruler_Height_width + 1;
	gint height = frame_height;

	gchar num[4];
	gint i = 0, len = 6;
	gint voff = 0;

	cairo_set_source_rgb(cr, 0.7, 0.7, 0.7);
	cairo_paint(cr);
	cairo_set_source_rgb(cr, 0.0, 0.0, 1.0);
	cairo_set_font_size(cr, 12.0);

	if (rw_flag == -1 || rw_flag == 0)
	{
		voff = Voff + 1;
	}
	else if (rw_flag == 1)
	{
		voff = (height_sh / 2) + 15;
	}

	cairo_move_to(cr, 0.0, voff - 2.0);
	cairo_show_text(cr, "10");

	for (i = 1; i < 10; i++)
	{
		cairo_move_to(cr, 3.0, ((Asc_Height * i) / 10) + voff);
		sprintf(num, "%d", (10 - i));
		cairo_show_text(cr, num);
	}

	for (i = 50; i > 0; i--)
	{
		if (i % 5 == 0)
			len = 12;
		else
			len = 6;

		cairo_move_to(cr, width - len, ((Asc_Height * i) / 50) + voff);
		cairo_line_to(cr, width, ((Asc_Height * i) / 50) + voff);
		cairo_stroke(cr);
	}

	cairo_move_to(cr, width - 12.0, voff);
	cairo_line_to(cr, width, voff);
	cairo_stroke(cr);

	// vertically Bscan Scale
	if (rw_flag == 1)
	{
		voff = 3;

		cairo_move_to(cr, 0.0, bsc_height + voff + 10);
		sprintf(num, "%d", bscan_rng_s_val);
		cairo_show_text(cr, num);

		for (i = 20; i > 0; i--)
		{
			if (i % 10 == 0)
				len = 12;
			else
				len = 6;

			cairo_move_to(cr, width - len, ((bsc_height * i) / 20) + voff);
			cairo_line_to(cr, width, ((bsc_height * i) / 20) + voff);
			cairo_stroke(cr);
		}

		cairo_move_to(cr, width - 12.0, voff + 1);
		cairo_line_to(cr, width, voff + 1);
		cairo_stroke(cr);

		cairo_move_to(cr, 0.0, 10.0 + voff);
		sprintf(num, "%d", bscan_rng_e_val);
		cairo_show_text(cr, num);

	}

	// refresh call
	gtk_image_set_from_surface(GTK_IMAGE(v_ruler_img), v_ruler_surface);
	// cairo_surface_write_to_png(v_ruler_surface, "v_ruler.png");
}

//************************************************************************
//  Scale function definitations
//************************************************************************
GtkWidget *horizontal_ruler_working_old(gint width, gint height)
{
	// GtkWidget *ruler;

	// cairo_t *cr;
	// cairo_surface_t *surface;
	// cairo_text_extents_t extents;

	// gchar num[8], dec_num[8];
	// gint i = 0, j = 0, len = 0, str_sz = 0;
	// gdouble sp = height;
	// gdouble digit_pos = (((gdouble)width - height - 10.0) / 10.0);
	// gdouble line_pos = digit_pos / 5.0;

	// surface = cairo_image_surface_create(CAIRO_FORMAT_RGB24, width, height);
	// cr = cairo_create(surface);
	// cairo_set_source_rgb(cr, 0.7, 0.7, 0.7);
	// cairo_paint(cr);

	// cairo_set_source_rgb(cr, 0.0, 0.0, 1.0);
	// cairo_set_font_size(cr, 12.0);

	// scl_val = val_ary[RANGE_PERA]/100;  //  range_val = val_ary[RANGE_PERA]  //1000

	// if ((scl_val % 2) == 0)
	//{
	//   for (i = 0; i < 11; i++)
	//   {
	//     sprintf(num, "%d", (scl_val / 10) * i);
	//     str_sz = find_string_length(num);

	//    if (str_sz <= ndgt)
	//    {
	//      dec_num[0] = '0';
	//      dec_num[1] = '.';
	//      dec_num[2] = num[0];
	//      dec_num[3] = num[1];
	//      dec_num[4] = num[2];
	//      dec_num[5] = num[3];
	//      dec_num[6] = num[4];
	//      dec_num[7] = num[5];
	//    }
	//    else
	//    {
	//      for (j = 0; j < sizeof(dec_num); j++)
	//      {
	//        if (j < (str_sz - ndgt))
	//          dec_num[j] = num[j];
	//        else if (j == (str_sz - ndgt))
	//          dec_num[j] = '.';
	//        else
	//          dec_num[j] = num[j - 1];
	//      }
	//    }

	//    cairo_text_extents(cr, dec_num, &extents);
	//    if (i < 10)
	//      cairo_move_to(cr, sp + ((digit_pos * i) - (extents.width / 2.0)), 22.0);
	//    else if (i == 10)
	//      cairo_move_to(cr, (sp - 10.0) + ((digit_pos * i) - (extents.width / 2.0)), 22.0);

	//    cairo_show_text(cr, dec_num);
	//  }
	//}
	// else
	//{
	//  sprintf(num, "%d", 0);
	//  cairo_text_extents(cr, num, &extents);
	//  cairo_move_to(cr, sp - extents.width / 2.0, 22.0);
	//  cairo_show_text(cr, num);

	//  sprintf(num, "%d", scl_val);
	//  cairo_text_extents(cr, num, &extents);
	//  cairo_move_to(cr, (sp - 10.0) + ((digit_pos * 10.0) - (extents.width / 2.0)), 22.0);
	//  cairo_show_text(cr, num);
	//}

	// for (i = 0; i < 51; i++)
	//{
	//   if (i % 5 == 0)
	//     len = 12;
	//   else
	//     len = 6;

	//  cairo_move_to(cr, sp + (line_pos * i), 0);
	//  cairo_line_to(cr, sp + (line_pos * i), len);
	//  cairo_stroke(cr);
	//}

	// cairo_destroy(cr);
	// ruler = gtk_image_new_from_surface(surface);
	//// cairo_surface_write_to_png(surface, "Images/Images/output.png");
	// cairo_surface_destroy(surface);

	// return (ruler);
}

GtkWidget *vertical_ruler_safe(gint width, gint height)
{
	///*GtkWidget *ruler;

	// cairo_t *cr;
	// cairo_surface_t *surface;
	// cairo_text_extents_t extents;

	// gchar num[4];
	// gint i = 0, len = 6;
	// gdouble digit_pos = (gdouble)(height - 1.0) / 10.0;
	// gdouble line_pos = digit_pos / 5.0;

	// surface = cairo_image_surface_create(CAIRO_FORMAT_RGB24, width, height);
	// cr = cairo_create(surface);

	// cairo_set_source_rgb(cr, 0.7, 0.7, 0.7);
	// cairo_paint(cr);
	// cairo_set_source_rgb(cr, 0.0, 0.0, 1.0);
	// cairo_set_font_size(cr, 12.0);

	// cairo_move_to(cr, 0.0, 10.0);
	// cairo_show_text(cr, "10");

	// for (i = 1; i < 10; i++)
	//{
	//   cairo_move_to(cr, 3.0, (digit_pos * i) + 5.0);
	//   sprintf(num, "%d", (10 - i));
	//   cairo_show_text(cr, num);
	// }

	// for (i = 50; i > 0; i--)
	//{
	//   if (i % 5 == 0)
	//     len = 12;
	//   else
	//     len = 6;

	//  cairo_move_to(cr, width - len, (line_pos * i));
	//  cairo_line_to(cr, width, (line_pos * i));
	//  cairo_stroke(cr);
	//}

	// cairo_move_to(cr, width - 12.0, (line_pos * i) + 2.0);
	// cairo_line_to(cr, width, (line_pos * i) + 2.0);
	// cairo_stroke(cr);

	// cairo_destroy(cr);
	// ruler = gtk_image_new_from_surface(surface);
	// cairo_surface_destroy(surface);

	// return (ruler);*/
}

#endif /* _RULAR_H */
