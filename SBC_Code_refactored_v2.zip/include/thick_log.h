#ifndef _THICK_LOG_H
#define _THICK_LOG_H

int scw = 0;
int sch = 0;

FILE *thk_fp = NULL;

char thk_file_name[128];

int weight[4];
int aord_n[4];
char aord_c[5];
int real_value[4];
char display_id[5];
int dim_size[4];

int thk_data[50000];
int file_sz;
int data_offset;
int null_data_count = 0;

// 1D
int thk_dim_type = 0;
// below sID and eID tmperary use only
char sID1[8] = "   AAAA";
char sID2[8] = "   AAAA";
char sID3[8] = "   AAAA";
char sID4[8] = "   ";

char eID1[8] = "   AAAB";
char eID2[8] = "   AAAB";
char eID3[8] = "   AAAB";
char eID4[8] = "   ";

int szD1 = 1;
int szD2 = 1;
int szD3 = 1;
int szD4 = 1;

char id1[8];
char id2[8];
char id3[8];
char id4[8];

int sr_idx = 3, er_idx = 6;
int sc_idx = 3, ec_idx = 6;
int row_real_id = 0, column_real_id = 0;

int st_clr[5] = {0, 1000, 2500, 5000, 7500};
int ed_clr[5] = {1000, 2500, 5000, 7500, 10000};

int pixel[190];
int clr_idx_val[5];

void display_id_and_data(cairo_t *cr);

void set_zero_data(void)
{
    void find_weight(const char *str);

    thk_dim_type = val_ary[THKFILE_TYPE_PERA];

    memset(thk_data, 0, sizeof(thk_data));
    find_weight(sID1);
}

void draw_thick_log(void)
{
    clr_idx_val[0] = val_ary[COLOR_1_PERA];
    clr_idx_val[1] = val_ary[COLOR_2_PERA];
    clr_idx_val[2] = val_ary[COLOR_3_PERA];

    for (int i = 0; i < 190; i++)
        pixel[i] = i;

    int gradient_type = 0;

    int row = 0, column = 0, iec_idx = 0;
    int border_line = 2, idx;
    double diff_value = 0.0, se_diff_value = 0.0;

    int iw = width_sh;
    int ih = (height_sh / 2);

    scw = iw / 6;
    sch = ih / 6;

    cairo_set_source_rgb(cr_clr, 0.8, 0.8, 0.8);
    cairo_rectangle(cr_clr, 0, 0, iw, ih);
    cairo_fill(cr_clr);

    if (thk_dim_type == 0)
        iec_idx = ec_idx - 3;
    else if (thk_dim_type == 1 || thk_dim_type == 2 || thk_dim_type == 3)
        iec_idx = ec_idx - 1;

    for (row = 0; row < 6; row++)
    {
        for (column = 0; column < 6; column++)
        {
            if (row == 0 || column == 0)
            {
                cairo_set_source_rgb(cr_clr, 0.5, 0.5, 0.5);
            }
            else if ((row >= sr_idx && row <= er_idx - 1) && (column >= sc_idx && column <= iec_idx))
            {
                idx = (((row - 3) + row_real_id) * (szD2 * szD3)) + ((column - 3) + column_real_id); // [ (i * (D2 * D3)) + k ]

                for (i = 0; i < 3; i++)
                {
                    if (thk_data[idx] == 0)
                        cairo_set_source_rgb(cr_clr, 255.0, 255.0, 255.0);
                    else if (st_clr[i] <= thk_data[idx] && ed_clr[i] >= thk_data[idx])
                        cairo_set_source_rgb(cr_clr,
                                             (double)clr_rgb[clr_idx_val[i]].r / 255.0,
                                             (double)clr_rgb[clr_idx_val[i]].g / 255.0,
                                             (double)clr_rgb[clr_idx_val[i]].b / 255.0);
                }
            }
            else
            {
                cairo_set_source_rgb(cr_clr, 1.0, 1.0, 1.0);
            }

            cairo_rectangle(cr_clr, column * scw, row * sch, scw - border_line, sch - border_line);
            cairo_fill(cr_clr);

            if (row == 3 && column == 3)
            {
                cairo_set_source_rgb(cr_clr, 0.0, 0.0, 0.0);
                cairo_rectangle(cr_clr, column * scw, row * sch, scw - border_line, sch - border_line);
                cairo_stroke(cr_clr);
            }
        }
    }

    display_id_and_data(cr_clr);
}

void refresh_thk_clr_data(void)
{
    draw_thick_log();
    gtk_image_set_from_surface(GTK_IMAGE(surface_clr_image), surface_clr);
}

//*****************************************************************************************************
//  find_weight() function is used to find weight of the each character
//*****************************************************************************************************
void find_weight(const char *str)
{
    gint i = 0, j = 0;

    for (i = 0; i < 4; i++)
    {
        j = i + 3;
        if (str[j] >= '0' && str[j] <= '9') // 0 = 48, 9 = 57
        {
            aord_n[i] = 10;
            aord_c[i] = '0';
        }
        else if (str[j] >= 'A' && str[j] <= 'Z') // A = 65, Z = 90
        {
            aord_n[i] = 26;
            aord_c[i] = 'A';
        }
        else if (str[j] >= 'a' && str[j] <= 'z') // a = 9 and z = 122
        {
            aord_n[i] = 26;
            aord_c[i] = 'a';
        }
        j++;
    }

    weight[3] = 1;
    weight[2] = aord_n[3];
    weight[1] = weight[2] * aord_n[2];
    weight[0] = weight[1] * aord_n[1];
}

//*****************************************************************************************************
//  splite_real_number() function is used to splite number according to weight and real number
//*****************************************************************************************************
void splite_real_number(int real_number)
{
    gint result1, result2;

    real_value[0] = real_number / weight[0];
    result1 = real_value[0] * weight[0];
    result2 = real_number - result1;

    real_value[1] = result2 / weight[1];
    result1 = real_value[1] * weight[1];
    result2 = result2 - result1;

    real_value[2] = result2 / weight[2];
    result1 = real_value[2] * weight[2];
    result2 = result2 - result1;

    real_value[3] = result2 / weight[3];
    result1 = real_value[3] * weight[3];
    result2 = result2 - result1;
}

//*****************************************************************************************************
//  create_display_id() function is used to create id to display
//*****************************************************************************************************
void create_display_id(char *id, char *ret_id, int value)
{
    gint i = 0, carry = 0;

    splite_real_number(value);

    for (i = 3; i > -1; i--)
    {
        display_id[i] = (char)((int)(id[i + 3] - aord_c[i]) + (real_value[i] + carry)) + aord_c[i];
        if (display_id[i] >= aord_c[i] + aord_n[i])
        {
            carry = 1;
            display_id[i] = display_id[i] - aord_n[i];
        }
        else
        {
            carry = 0;
        }
    }
    display_id[4] = '\0';
    ret_id[0] = ' ';
    ret_id[1] = ' ';
    ret_id[2] = ' ';

    strcpy(ret_id, display_id);
}

//*****************************************************************************************************
//  calculate_size_of_dim() function is used to Calculate dimention
//*****************************************************************************************************
int calculate_size_of_dim(char *start_id, char *end_id)
{
    char diff[8];
    int i = 0, borrowCarry = 1;

    find_weight(start_id);

    for (i = 3; i > -1; i--)
    {
        if (start_id[3 + i] == end_id[3 + i])
            diff[3 + i] = aord_c[i];
        else if (i > 0 && start_id[3 + i] > end_id[3 + i])
        {
            diff[3 + i] = ((end_id[3 + i] + aord_n[i]) - start_id[3 + i]) + aord_c[i];
            end_id[2 + i] = end_id[2 + i] - borrowCarry;
        }
        else if (i == 0 || start_id[3 + i] < end_id[3 + i])
            diff[3 + i] = (end_id[3 + i] - start_id[3 + i]) + aord_c[i];
    }

    dim_size[3] = diff[6] - aord_c[3];
    dim_size[2] = (aord_n[3] * (diff[5] - aord_c[2])) + dim_size[3];
    dim_size[1] = ((aord_n[2] * aord_n[3]) * (diff[4] - aord_c[1])) + dim_size[2];
    dim_size[0] = ((aord_n[1] * aord_n[2] * aord_n[3]) * (diff[3] - aord_c[0])) + dim_size[1];

    return (dim_size[0]);
}

//*****************************************************************************************************
//  is_empty() function is used to check each location is NULL or no
//*****************************************************************************************************
gboolean is_empty(gchar *id)
{
    if (id[3] == 0 || id[4] == 0 || id[5] == 0 || id[6] == 0)
        return (FALSE);
    return (TRUE);
}

//*****************************************************************************************************
//  write_data_into_thk_file() function is used to write data and attributes in file
//*****************************************************************************************************
void write_data_into_thk_file(void)
{
    int i = 0, j = 0, p = 0, q = 0;
    int idx;
    char buffer[8];

    sprintf(thk_file_name, "./Thick_log/THK%04d.csv", val_ary[RECORD_NO_PERA]);
    // remove file from directory
    remove(thk_file_name);
    // create new file with same
    thk_fp = fopen(thk_file_name, "w");

    thk_dim_type = val_ary[THKFILE_TYPE_PERA];

    szD1 = val_ary[DIM_1_SIZE_PERA];
    szD2 = val_ary[DIM_2_SIZE_PERA];
    szD3 = val_ary[DIM_3_SIZE_PERA];
    
    // Type and Size
    sprintf(buffer, "%d", thk_dim_type);
    fprintf(thk_fp, "%7s,", buffer);
    sprintf(buffer, "%d", szD1 * (szD2 * szD3));
    fprintf(thk_fp, "%7s\n", buffer);

    // D1
    find_weight(sID1);

    fprintf(thk_fp, "%7s,", sID1);
    fprintf(thk_fp, "%7s,", eID1);
    sprintf(buffer, "%d", szD1);
    fprintf(thk_fp, "%7s\n", buffer);

    // D2
    fprintf(thk_fp, "%7s,", sID2);
    fprintf(thk_fp, "%7s,", eID2);
    sprintf(buffer, "%d", szD2);
    fprintf(thk_fp, "%7s\n", buffer);

    // D3
    fprintf(thk_fp, "%7s,", sID3);
    fprintf(thk_fp, "%7s,", eID3);
    sprintf(buffer, "%d", szD3);
    fprintf(thk_fp, "%7s\n", buffer);

    // D4
    // sprintf(sID4, "%7s", gtk_entry_get_text(GTK_ENTRY(fd_w.est[2])));
    // sprintf(eID4, "%7s", gtk_entry_get_text(GTK_ENTRY(fd_w.eed[2])));

    fprintf(thk_fp, "%7s,", sID4);
    fprintf(thk_fp, "%7s,", eID4);
    sprintf(buffer, "%d", szD4);
    fprintf(thk_fp, "%7s\n", buffer);

    for (i = 0; i < 56; i++)
        fputs("\n", thk_fp);

    memset(&thk_data, 0, sizeof(thk_data));

    for (i = 0; i < ((szD1 * szD4) * (szD2 * szD3)); i++)
        thk_data[i] = 0; // rand() % 10000;

    // reset to default value all variables
    sr_idx = 3, er_idx = 6;
    sc_idx = 3, ec_idx = 6;
    row_real_id = 0;
    column_real_id = 0;

    // write array data in 1D form into 'csv' file
    for (i = 0; i < szD1 + 1; i++) // Number of rows
    {
        for (j = 0; j < szD4; j++) // Number of Rows * D4_size (Used for 4D, Total rows = D1*D4)
        {
            for (p = 0; p < szD2 + 1; p++) // Number of columns
            {
                for (q = 0; q < szD3; q++) // Number of columns * D3_size (Used for 3D,  Total columns = D2*D3)
                {
                    if (i == 0)
                    {
                        if (p == 0 && q == 0)
                        {
                            fprintf(thk_fp, "       ,");
                        }
                        else if (p > 0)
                        {
                            if (thk_dim_type == 0 || thk_dim_type == 1)
                            {
                                if (is_empty(sID2) != FALSE)
                                    create_display_id(sID2, id2, p - 1);

                                fprintf(thk_fp, "%7s,", id2);
                            }
                            else if (thk_dim_type == 2 || thk_dim_type == 3)
                            {
                                if (is_empty(sID2) != FALSE)
                                    create_display_id(sID2, id2, (p - 1));

                                if (is_empty(sID3) != FALSE)
                                    create_display_id(sID3, id3, q);

                                fprintf(thk_fp, "%s/%c%c,", id2, id3[2], id3[3]);
                            }
                        }
                    }
                    else if (i > 0)
                    {
                        if (p == 0 && q == 0)
                        {
                            // get file offset position
                            if (i == 1 && j == 0)
                            {
                                data_offset = ftell(thk_fp);
                                // g_print("read data_offset = %d\n", data_offset);
                            }

                            if (thk_dim_type == 0 || thk_dim_type == 1 || thk_dim_type == 2)
                            {
                                if (is_empty(sID1) != FALSE)
                                    create_display_id(sID1, id1, i - 1);

                                fprintf(thk_fp, "%7s,", id1);
                            }
                            else if (thk_dim_type == 3)
                            {
                                if (is_empty(sID1) != FALSE)
                                    create_display_id(sID1, id1, (i - 1));

                                if (is_empty(sID3) != FALSE)
                                    create_display_id(sID3, id3, j);

                                fprintf(thk_fp, "%s/%c%c,", id1, id3[2], id3[3]);
                            }
                        }
                        else if (p > 0)
                        {
                            // calculate idx and read data from array and write in file
                            idx = ((i - 1) * szD4 * szD2 * szD3) + (j * szD2 * szD3) + ((p - 1) * szD3) + q;
                            fprintf(thk_fp, "%7.2f,", (float)thk_data[idx] / 100);
                        }
                    }
                }
            }

            fprintf(thk_fp, "\n");
            if (i == 0 && j == 0)
                break;
        }
    }

    if (thk_fp)
    {
        fclose(thk_fp);
        thk_fp = NULL;
    }

    refresh_thk_clr_data();
}

//*****************************************************************************************************
//  thk_read_data_from_file() function is used to read data and attributes from file
//*****************************************************************************************************
void read_data_from_thk_file(void)
{
    char buffer[1024];
    char *pchar = NULL;
    int i = 0, j = 0, idx;

    sprintf(thk_file_name, "./Thick_log/THK%04d.csv",  val_ary[RECORD_NO_PERA]);

    if (access(thk_file_name, F_OK) == 0)
    {
        thk_fp = fopen(thk_file_name, "r");

        // Read Type and Size from file
        memset(buffer, 0, sizeof(buffer));
        fgets(buffer, sizeof(buffer), thk_fp);
        pchar = strtok(buffer, ",");
        thk_dim_type = atoi(pchar);
        pchar = strtok(NULL, "\n");
        file_sz = atoi(pchar);

        // Read D1 data
        memset(buffer, 0, sizeof(buffer));
        fgets(buffer, sizeof(buffer), thk_fp);
        pchar = strtok(buffer, ",");
        sprintf(sID1, "%s", pchar);
        pchar = strtok(NULL, ",");
        sprintf(eID1, "%s", pchar);
        pchar = strtok(NULL, "\n");
        szD1 = atoi(pchar);

        // Read D2 data
        memset(buffer, 0, sizeof(buffer));
        fgets(buffer, sizeof(buffer), thk_fp);
        pchar = strtok(buffer, ",");
        sprintf(sID2, "%s", pchar);
        pchar = strtok(NULL, ",");
        sprintf(eID2, "%s", pchar);
        pchar = strtok(NULL, "\n");
        szD2 = atoi(pchar);

        // Read D3 data
        memset(buffer, 0, sizeof(buffer));
        fgets(buffer, sizeof(buffer), thk_fp);
        pchar = strtok(buffer, ",");
        sprintf(sID3, "%s", pchar);
        pchar = strtok(NULL, ",");
        sprintf(eID3, "%s", pchar);
        pchar = strtok(NULL, "\n");
        szD3 = atoi(pchar);

        // Read D4 Data
        memset(buffer, 0, sizeof(buffer));
        fgets(buffer, sizeof(buffer), thk_fp);
        pchar = strtok(buffer, ",");
        strcpy(sID4, pchar);
        pchar = strtok(NULL, ",");
        strcpy(eID4, pchar);
        pchar = strtok(NULL, "\n");
        szD4 = atoi(pchar);

        // Read dummy 56 lines from  file
        for (i = 0; i < 56; i++)
            fgets(buffer, sizeof(buffer), thk_fp);

        // read line for starting ids in the 2D and 3D data
        if (thk_dim_type == 0 || thk_dim_type == 1 || thk_dim_type == 2 || thk_dim_type == 3)
            fgets(buffer, sizeof(buffer), thk_fp);

        // Hold offset for data modifications purpose
        data_offset = ftell(thk_fp);
        // g_print("read data_offset = %d\n", data_offset);

        memset(&buffer, 0, sizeof(buffer));
        memset(&thk_data, 0, sizeof(thk_data));

        // reset to default value all variables
        i = 0, j = 0;
        null_data_count = 0;
        sr_idx = 3, er_idx = 6;
        sc_idx = 3, ec_idx = 6;
        row_real_id = 0;
        column_real_id = 0;

        while (fgets(buffer, sizeof(buffer), thk_fp))
        {
            pchar = strtok(buffer, ",");
            pchar = strtok(NULL, ",");

            while (pchar != NULL)
            {
                idx = (i * szD2 * szD3) + j;
                thk_data[idx] = atof(pchar) * 100;

                if (thk_data[idx] <= 0)
                    null_data_count++;

                pchar = strtok(NULL, ",");
                j++;
                if (j > ((szD2 * szD3) - 1))
                {
                    j = 0;
                    i++;
                    break;
                }
            }

            if (i > ((szD1 * szD4) - 1))
                break;
        }

        if (thk_fp)
        {
            fclose(thk_fp);
            thk_fp = NULL;
        }

        find_weight(sID1);
    }
}

//*****************************************************************************************************
//  thk_data_file_modify() function is used to change data on selected loaction
//*****************************************************************************************************
void thk_data_file_modify(int m_data)
{
    int idx, offset;
    char cbuffer[16];

    sprintf(thk_file_name, "./Thick_log/THK%04d.csv",  val_ary[RECORD_NO_PERA]);
    if (access(thk_file_name, F_OK) == 0)
    {
        thk_fp = fopen(thk_file_name, "r+");
        if (thk_dim_type == 0)
        {
            thk_data[row_real_id] = m_data;
            if (Unit_v == INCH)
                sprintf(cbuffer, "%.2f", (float)m_data / 1000.0);
            else
                sprintf(cbuffer, "%.2f", (float)m_data / 100.0);

            offset = (data_offset + 8) + (17 * row_real_id);
            fseek(thk_fp, offset, SEEK_SET);
            fprintf(thk_fp, "%7s,", cbuffer);
        }
        else if (thk_dim_type == 1 || thk_dim_type == 2 || thk_dim_type == 3)
        {
            idx = (row_real_id * (szD2 * szD3)) + column_real_id;
            thk_data[idx] = m_data;
            if (Unit_v == INCH)
                sprintf(cbuffer, "%.2f", (float)m_data / 1000.0);
            else
                sprintf(cbuffer, "%.2f", (float)m_data / 100.0);
            offset = (data_offset + 8) + (8 * (row_real_id * (szD2 * szD3))) + (10 * row_real_id) + (8 * column_real_id) - row_real_id;
            fseek(thk_fp, offset, SEEK_SET);
            fprintf(thk_fp, "%7s,", cbuffer);
        }

        if (thk_fp)
        {
            fclose(thk_fp);
            thk_fp = NULL;
        }
        refresh_thk_clr_data();
    }
}

/*
void thk_data_file_modify(int m_data)
{
    int idx, offset;
    char cbuffer[16];

    sprintf(thk_file_name, "./Thick_log//thk%04d.csv",  val_ary[RECORD_NO_PERA]);
    if (access(thk_file_name, F_OK) == 0)
    {
        thk_fp = fopen(thk_file_name, "r+");
        if (thk_dim_type == 0)
        {
            thk_data[row_real_id] = m_data;
            sprintf(cbuffer, "%.2f", (float)m_data / 100.0);
            offset = (data_offset + 8) + (17 * row_real_id);
            fseek(thk_fp, offset, SEEK_SET);
            fprintf(thk_fp, "%7s,", cbuffer);
        }
        else if (thk_dim_type == 1 || thk_dim_type == 2 || thk_dim_type == 3)
        {
            idx = (row_real_id * (szD2 * szD3)) + column_real_id;
            thk_data[idx] = m_data;
            sprintf(cbuffer, "%.2f", (float)m_data / 100.0);
            offset = (data_offset + 8) + (8 * (row_real_id * (szD2 * szD3))) + (10 * row_real_id) + (8 * column_real_id) - row_real_id;
            fseek(thk_fp, offset, SEEK_SET);
            fprintf(thk_fp, "%7s,", cbuffer);
        }

        if (thk_fp)
        {
            fclose(thk_fp);
            thk_fp = NULL;
        }
        refresh_thk_clr_data();
    }
}
*/

//*******************************************************************************************************
//  thk_find_empty_data_location() function is used to find empty(00.00) data location's in file na array
//*******************************************************************************************************
//  Implemented 1D, 2D, 3D And 4D
void thk_find_empty_data_location(void)
{
    int num_of_col = -1;
    int num_of_row = -1;
    int idx;

    sprintf(thk_file_name, "./Thick_log//thk%04d.csv",  val_ary[RECORD_NO_PERA]);

    if (access(thk_file_name, F_OK) == 0)
    {
        num_of_col = (szD2 * szD3) - 1;
        num_of_row = (szD1 * szD4) - 1;

        while (1)
        {
            if (column_real_id < num_of_col)
            {
                if (sc_idx > 1)
                    sc_idx = sc_idx - 1;
                if (((szD2 * szD3) - 4) < column_real_id)
                    ec_idx = ec_idx - 1;

                column_real_id++;
            }
            else if (row_real_id < num_of_row)
            {
                if (sr_idx > 1)
                    sr_idx = sr_idx - 1;
                if (((szD1 * szD4) - 4) < row_real_id)
                    er_idx = er_idx - 1;

                row_real_id++;
                column_real_id = 0;
                sc_idx = 3, ec_idx = 6;
            }
            else
            {
                row_real_id = 0;
                column_real_id = 0;
                sr_idx = 3, er_idx = 6;
                sc_idx = 3, ec_idx = 6;
                break;
            }

            idx = (row_real_id * (szD2 * szD3)) + column_real_id;
            thk_data[idx];
            if (thk_data[idx] == 0)
                break;
        }
    }
    refresh_thk_clr_data();
}

//*****************************************************************************************************
//  display_id_and_data() function is used to display dimension id and data to user
//*****************************************************************************************************
void display_id_and_data(cairo_t *cr)
{
    char cbuffer[16];
    int border_line = 2;
    int column = 0, row = 0, idx = 0;
    double font_size;

    cairo_font_weight_t font_weight;
    cairo_text_extents_t extents;

    cairo_set_source_rgb(cr, 0.0, 0.0, 0.0);

    for (row = sr_idx; row < er_idx; row++)
    {
        for (column = sc_idx; column < ec_idx; column++)
        {
            // create id's for rows
            if (column == 3)
            {
                if (row == 3)
                {
                    font_weight = CAIRO_FONT_WEIGHT_BOLD; // Bold font
                    font_size = 18.0;
                }
                else
                {
                    font_weight = CAIRO_FONT_WEIGHT_NORMAL; // Normal font
                    font_size = 16.0;
                }
                cairo_select_font_face(cr, "Courier", CAIRO_FONT_SLANT_NORMAL, font_weight);
                cairo_set_font_size(cr, font_size);

                if (thk_dim_type == 3)
                {
                    if (is_empty(sID1) != FALSE)
                        create_display_id(sID1, id1, (int)(((row - 3) + row_real_id) / szD4));
                    if (is_empty(sID4) != FALSE)
                        create_display_id(sID4, id4, ((row - 3) + row_real_id) % szD4);

                    sprintf(cbuffer, "%s/%c%c", id1, id4[2], id4[3]);
                }
                else
                {
                    if (is_empty(sID1) != FALSE)
                        create_display_id(sID1, id1, (row - 3) + row_real_id);
                    sprintf(cbuffer, "%s", id1);
                }

                cairo_text_extents(cr, cbuffer, &extents);
                cairo_move_to(cr, (((column - 3) * scw) - border_line) + (scw - extents.width),
                              ((row * sch) + border_line) + (sch - (extents.height / 2)));
                cairo_show_text(cr, cbuffer);
            }

            // create id's for columns
            if (thk_dim_type != 0 && row == 3)
            {
                if (column == 3)
                {
                    font_weight = CAIRO_FONT_WEIGHT_BOLD; // Bold font
                    font_size = 18.0;
                }
                else
                {
                    font_weight = CAIRO_FONT_WEIGHT_NORMAL; // Normal font
                    font_size = 16.0;
                }
                cairo_select_font_face(cr, "Courier", CAIRO_FONT_SLANT_NORMAL, font_weight);
                cairo_set_font_size(cr, font_size);

                if (thk_dim_type == 1)
                {
                    if (is_empty(sID2) != FALSE)
                        create_display_id(sID2, id2, ((column - 3) + column_real_id));
                    sprintf(cbuffer, "%s", id2);
                }
                else if (thk_dim_type == 2 || thk_dim_type == 3)
                {
                    if (is_empty(sID2) != FALSE)
                        create_display_id(sID2, id2, (gint)(((column - 3) + column_real_id) / szD3));
                    if (is_empty(sID3) != FALSE)
                        create_display_id(sID3, id3, ((column - 3) + column_real_id) % szD3);

                    sprintf(cbuffer, "%s/%c%c", id2, id3[2], id3[3]);
                }

                cairo_text_extents(cr, cbuffer, &extents);
                cairo_move_to(cr, ((column * scw) - border_line) + (scw - extents.width),
                              (((row - 3) * sch) + border_line) + (sch - (extents.height / 2)));
                cairo_show_text(cr, cbuffer);
            }

            if (column >= sc_idx || row >= sr_idx)
            {
                if (row == 3 || column == 3)
                {
                    font_weight = CAIRO_FONT_WEIGHT_BOLD; // Bold font
                    font_size = 18.0;
                }
                else
                {
                    font_weight = CAIRO_FONT_WEIGHT_NORMAL; // Normal font
                    font_size = 16.0;
                }
                cairo_select_font_face(cr, "Courier", CAIRO_FONT_SLANT_NORMAL, font_weight);
                cairo_set_font_size(cr, font_size);

                idx = (((row - 3) + row_real_id) * (szD2 * szD3)) + ((column - 3) + column_real_id); // [ (i * (D2 * D3)) + k ]

                cairo_set_source_rgb(cr, 0.0, 0.0, 0.0);
                sprintf(cbuffer, "%.2f", (float)thk_data[idx] / 100.0f); // 1D Data
                if ((thk_dim_type == 0 && column == 3) || thk_dim_type == 1 || thk_dim_type == 2 || thk_dim_type == 3)
                {
                    cairo_text_extents(cr, cbuffer, &extents);
                    cairo_move_to(cr, ((column * scw) - border_line) + (scw - extents.width),
                                  ((row * sch) + border_line) + (sch - (extents.height / 2)));
                    cairo_show_text(cr, cbuffer);
                }
            }
        }
    }
}

#endif /*_THICK_LOG_H */
