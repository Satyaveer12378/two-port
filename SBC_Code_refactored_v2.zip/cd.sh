cd /usr/share/wslprog
