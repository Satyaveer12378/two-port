# Project Architecture (Auto-generated - Review & Edit)

This document describes the organization created by the refactor pass.
Edit and expand it to capture module responsibilities, data flow, and build instructions.

## High-level Layout
- `src/` - C/C++ source files moved here. Build system should compile these.
- `include/` - Header files moved here. Public headers should be placed here.
- `qml/` - QML UI files moved here (if present).
- `Images/` - Image assets consolidated here.
- `docs/` - Documentation (this file included).
- `CMakeLists.txt` / `meson.build` / `*.pro` - build system files at project root.

## Suggested module separation
- Group related source files into subdirectories under `src/` (e.g. `src/hmi/`, `src/db/`, `src/gps/`).
- Place internal headers under `include/` and consider a `include/project_name/` namespace for public headers.
- QML UI should be placed in `qml/` and can be loaded via qmlimportpaths or resource files.

## Build Notes
- This pass updates source/header paths in text files where possible. Please review build files to ensure build targets include `src/` and `include/` paths.
- If your project uses `.qrc` resource files or qmake `.pro`, ensure resource entries point to `Images/...` and `qml/...` paths.

## Next steps
1. Run a build to detect any missing references.
2. Move source files into logical subfolders under `src/` and update build targets.
3. Add unit tests under `tests/` and a CI configuration if desired.