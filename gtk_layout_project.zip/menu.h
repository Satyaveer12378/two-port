#ifndef MENU_H
#define MENU_H
#include <gtk/gtk.h>
GtkWidget* menu_panel_new(void);
#endif
