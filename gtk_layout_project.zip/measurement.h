#ifndef MEASUREMENT_H
#define MEASUREMENT_H
#include <gtk/gtk.h>
GtkWidget* measurement_area_new(void);
#endif
