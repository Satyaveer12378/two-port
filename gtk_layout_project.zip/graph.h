#ifndef GRAPH_H
#define GRAPH_H
#include <gtk/gtk.h>
GtkWidget* graph_view_new(void);
#endif
