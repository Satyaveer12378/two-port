#include "graph.h"

// A placeholder graph widget: a frame that contains a drawing area.
static gboolean on_draw(GtkWidget *widget, cairo_t *cr, gpointer user_data) {
    GtkAllocation alloc;
    gtk_widget_get_allocation(widget, &alloc);
    // draw simple grid background
    double w = alloc.width;
    double h = alloc.height;
    cairo_set_line_width(cr, 1.0);
    for (int x = 0; x < w; x += 50) {
        cairo_move_to(cr, x, 0);
        cairo_line_to(cr, x, h);
    }
    for (int y = 0; y < h; y += 50) {
        cairo_move_to(cr, 0, y);
        cairo_line_to(cr, w, y);
    }
    cairo_stroke(cr);
    return FALSE;
}

GtkWidget* graph_view_new(void) {
    GtkWidget *frame = gtk_frame_new(NULL);
    gtk_widget_set_size_request(frame, 700, 360);
    gtk_frame_set_label(GTK_FRAME(frame), "Graph Area");

    GtkWidget *drawing = gtk_drawing_area_new();
    gtk_widget_set_hexpand(drawing, TRUE);
    gtk_widget_set_vexpand(drawing, TRUE);
    gtk_container_add(GTK_CONTAINER(frame), drawing);
    g_signal_connect(G_OBJECT(drawing), "draw", G_CALLBACK(on_draw), NULL);
    return frame;
}
