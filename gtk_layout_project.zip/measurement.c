#include "measurement.h"

GtkWidget* measurement_area_new(void) {
    GtkWidget *frame = gtk_frame_new(NULL);
    gtk_widget_set_size_request(frame, 740, 120);
    gtk_frame_set_label(GTK_FRAME(frame), "Measurement Area");

    GtkWidget *label = gtk_label_new("Measurement Area: add controls here");
    gtk_container_add(GTK_CONTAINER(frame), label);
    return frame;
}
