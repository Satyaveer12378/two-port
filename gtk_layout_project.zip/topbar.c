#include "topbar.h"

GtkWidget* topbar_new(void) {
    GtkWidget *frame = gtk_frame_new(NULL);
    gtk_widget_set_size_request(frame, -1, 50);
    gtk_frame_set_shadow_type(GTK_FRAME(frame), GTK_SHADOW_IN);
    gtk_frame_set_label(GTK_FRAME(frame), "Top Bar");
    // You can add buttons / status icons inside this frame as needed:
    GtkWidget *hbox = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 6);
    GtkWidget *label = gtk_label_new(NULL);
    gtk_label_set_text(GTK_LABEL(label), "Top Bar");
    gtk_container_add(GTK_CONTAINER(frame), hbox);
    gtk_container_add(GTK_CONTAINER(hbox), label);
    return frame;
}
