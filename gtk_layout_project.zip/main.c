#include <gtk/gtk.h>
#include "topbar.h"
#include "graph.h"
#include "measurement.h"
#include "menu.h"

int main(int argc, char *argv[]) {
    GtkWidget *window;
    GtkWidget *grid;
    GtkWidget *graph_grid;

    gtk_init(&argc, &argv);

    window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(window), "GTK Layout - 1024x600");
    gtk_window_set_default_size(GTK_WINDOW(window), 1024, 600);
    gtk_window_set_position(GTK_WINDOW(window), GTK_WIN_POS_CENTER);

    g_signal_connect(window, "destroy", G_CALLBACK(gtk_main_quit), NULL);

    grid = gtk_grid_new();
    gtk_grid_set_row_spacing(GTK_GRID(grid), 6);
    gtk_grid_set_column_spacing(GTK_GRID(grid), 6);
    gtk_container_add(GTK_CONTAINER(window), grid);

    // Top bar spans both columns
    GtkWidget *top = topbar_new();
    gtk_grid_attach(GTK_GRID(grid), top, 0, 0, 2, 1);

    // Left column: graph grid (Y axis, Graph, X axis, Measurement)
    graph_grid = gtk_grid_new();
    gtk_grid_set_row_spacing(GTK_GRID(graph_grid), 2);
    gtk_grid_set_column_spacing(GTK_GRID(graph_grid), 2);
    gtk_grid_attach(GTK_GRID(grid), graph_grid, 0, 1, 1, 1);

    GtkWidget *y_axis = gtk_frame_new(NULL);
    gtk_widget_set_size_request(y_axis, 40, 360);
    gtk_frame_set_label(GTK_FRAME(y_axis), "Y Axis");
    gtk_grid_attach(GTK_GRID(graph_grid), y_axis, 0, 0, 1, 2);

    GtkWidget *graph = graph_view_new();
    gtk_grid_attach(GTK_GRID(graph_grid), graph, 1, 0, 1, 1);

    GtkWidget *x_axis = gtk_frame_new(NULL);
    gtk_widget_set_size_request(x_axis, 700, 30);
    gtk_frame_set_label(GTK_FRAME(x_axis), "X Axis");
    gtk_grid_attach(GTK_GRID(graph_grid), x_axis, 1, 1, 1, 1);

    // Measurement area below graph
    GtkWidget *measurement = measurement_area_new();
    gtk_grid_attach(GTK_GRID(grid), measurement, 0, 2, 1, 1);

    // Right column: menu area
    GtkWidget *menu = menu_panel_new();
    gtk_grid_attach(GTK_GRID(grid), menu, 1, 1, 1, 2);

    gtk_widget_show_all(window);
    gtk_main();
    return 0;
}
