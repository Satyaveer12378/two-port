#include "menu.h"

GtkWidget* menu_panel_new(void) {
    GtkWidget *frame = gtk_frame_new(NULL);
    gtk_widget_set_size_request(frame, 250, 480);
    gtk_frame_set_label(GTK_FRAME(frame), "Menu Area");

    GtkWidget *box = gtk_box_new(GTK_ORIENTATION_VERTICAL, 8);
    gtk_container_add(GTK_CONTAINER(frame), box);

    GtkWidget *btn1 = gtk_button_new_with_label("Menu Item 1");
    GtkWidget *btn2 = gtk_button_new_with_label("Menu Item 2");
    GtkWidget *btn3 = gtk_button_new_with_label("Menu Item 3");
    gtk_box_pack_start(GTK_BOX(box), btn1, FALSE, FALSE, 6);
    gtk_box_pack_start(GTK_BOX(box), btn2, FALSE, FALSE, 6);
    gtk_box_pack_start(GTK_BOX(box), btn3, FALSE, FALSE, 6);

    return frame;
}
