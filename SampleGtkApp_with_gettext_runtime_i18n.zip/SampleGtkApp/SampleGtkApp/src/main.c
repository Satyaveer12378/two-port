#define _(s) gettext(s)
#include <locale.h>
#include <libintl.h>
#include <gtk/gtk.h>
#include "ui.h"

// Application activation callback
static void on_app_activate(GtkApplication *app, gpointer user_data) {
    setlocale(LC_ALL, "");
    bindtextdomain("samplegtkapp", "locale");
    bind_textdomain_codeset("samplegtkapp", "UTF-8");
    textdomain("samplegtkapp");

    build_ui(app);
}

int main(int argc, char **argv) {
    GtkApplication *app;
    int status;

    app = gtk_application_new("com.example.sample", G_APPLICATION_FLAGS_NONE);
    g_signal_connect(app, "activate", G_CALLBACK(on_app_activate), NULL);

    status = g_application_run(G_APPLICATION(app), argc, argv);
    g_object_unref(app);

    return status;
}