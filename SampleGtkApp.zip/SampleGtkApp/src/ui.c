#include <gtk/gtk.h>
#include "ui.h"

// Button callbacks
static void on_zero_clicked(GtkWidget *widget, gpointer data) {
    g_print("ZERO button clicked!\n");
}
static void on_range_clicked(GtkWidget *widget, gpointer data) {
    g_print("RANGE button clicked!\n");
}

void build_ui(GtkApplication *app) {
    GtkWidget *window;
    GtkWidget *hbox;
    GtkWidget *image;
    GtkWidget *vbox;
    GtkWidget *btn_zero;
    GtkWidget *btn_range;

    // Create main window
    window = gtk_application_window_new(app);
    gtk_window_set_title(GTK_WINDOW(window), "Sample GTK App");
    gtk_window_set_default_size(GTK_WINDOW(window), 1024, 600);

    // Horizontal layout
    hbox = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 5);
    gtk_container_add(GTK_CONTAINER(window), hbox);

    // Left side image
    image = gtk_image_new_from_file("assets/St_Scrn.png");
    gtk_box_pack_start(GTK_BOX(hbox), image, TRUE, TRUE, 0);

    // Right side vertical layout
    vbox = gtk_box_new(GTK_ORIENTATION_VERTICAL, 10);
    gtk_box_pack_end(GTK_BOX(hbox), vbox, FALSE, FALSE, 10);

    // Buttons
    btn_zero = gtk_button_new_with_label("ZERO");
    g_signal_connect(btn_zero, "clicked", G_CALLBACK(on_zero_clicked), NULL);
    gtk_box_pack_start(GTK_BOX(vbox), btn_zero, FALSE, FALSE, 5);

    btn_range = gtk_button_new_with_label("RANGE");
    g_signal_connect(btn_range, "clicked", G_CALLBACK(on_range_clicked), NULL);
    gtk_box_pack_start(GTK_BOX(vbox), btn_range, FALSE, FALSE, 5);

    // Show everything
    gtk_widget_show_all(window);
}
