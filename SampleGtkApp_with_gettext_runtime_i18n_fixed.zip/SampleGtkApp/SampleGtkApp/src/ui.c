#define _(s) gettext(s)
#include <gtk/gtk.h>
#include <locale.h>
#include <libintl.h>
#include "ui.h"

static AppLanguage g_current_lang = LANG_EN;
static const char* locale_for_lang(AppLanguage lang) {
    switch (lang) {
        case LANG_EN: return "en_US.UTF-8";
        case LANG_ES: return "es_ES.UTF-8";
        case LANG_JA: return "ja_JP.UTF-8";
        default: return "en_US.UTF-8";
    }
}
static void switch_language(AppLanguage lang) {
    g_current_lang = lang;
    setlocale(LC_ALL, locale_for_lang(lang));
    bindtextdomain("samplegtkapp", "locale");
    bind_textdomain_codeset("samplegtkapp", "UTF-8");
    textdomain("samplegtkapp");
}
#include <locale.h>
#include <libintl.h>
#include <gtk/gtk.h>

typedef enum {
    LANG_EN = 0,
    LANG_ES = 1,
    LANG_JA = 2
} AppLanguage;

#include "ui.h"

// Button callbacks
static void on_zero_clicked(GtkWidget *widget, gpointer data) {
    g_print("ZERO button clicked!\n");
}
static void on_range_clicked(GtkWidget *widget, gpointer data) {
    g_print("RANGE button clicked!\n");
}

static gboolean switch_to_homepage_cb(gpointer data) {
	GtkWidget **widgets = (GtkWidget **)data;
	GtkWidget *splash = widgets[0];
	GtkWidget *homepage = widgets[1];

	gtk_widget_hide(splash);
	gtk_widget_show_all(homepage);



	return FALSE;
}




void build_ui(GtkApplication *app) {
    GtkWidget *window;
    GtkWidget *container;
    GtkWidget *splash;
    GtkWidget *homepage;
    GtkWidget *hbox;
    GtkWidget *vbox;
    GtkWidget *btn_zero;
    GtkWidget *btn_range;
    GtkWidget *label;

    // Create main window
    window = gtk_application_window_new(app);
    gtk_window_set_title(GTK_WINDOW(window), "Sample GTK App");
    gtk_window_set_default_size(GTK_WINDOW(window), 1024, 600);

   //Overlay lets us stack widgets on top of each other
    container = gtk_box_new(GTK_ORIENTATION_VERTICAL,0 );
    gtk_container_add(GTK_CONTAINER(window),container);

    //------ Screen 1: Image-----
    splash = gtk_image_new_from_file("assets/St_Scrn.png");
    gtk_box_pack_start(GTK_BOX(container), splash, TRUE, TRUE, 0);

    //--------Screen 2: Image-----
    hbox = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 5);

    //left  side vertical label
    label = gtk_label_new("Homepage");
    gtk_box_pack_start(GTK_BOX(hbox), label, TRUE, TRUE, 10);


    // Right side vertical layout
    vbox = gtk_box_new(GTK_ORIENTATION_VERTICAL, 10);
    gtk_box_pack_end(GTK_BOX(hbox), vbox, FALSE, FALSE, 10);

    // Buttons
    btn_zero = gtk_button_new_with_label("ZERO");
    g_signal_connect(btn_zero, "clicked", G_CALLBACK(on_zero_clicked), NULL);
    gtk_box_pack_start(GTK_BOX(vbox), btn_zero, FALSE, FALSE, 5);

    btn_range = gtk_button_new_with_label("RANGE");
    g_signal_connect(btn_range, "clicked", G_CALLBACK(on_range_clicked), NULL);
    gtk_box_pack_start(GTK_BOX(vbox), btn_range, FALSE, FALSE, 5);

    homepage = hbox;
    gtk_box_pack_start(GTK_BOX(container), homepage, TRUE, TRUE, 0);
    gtk_widget_hide(homepage);


    gtk_widget_show_all(window);
    gtk_widget_hide(homepage);


    GtkWidget **widgets = g_new(GtkWidget*, 2);
    widgets[0] = splash;
    widgets[1] = homepage;

    g_timeout_add(5000,switch_to_homepage_cb, widgets);



}

static void apply_i18n(GtkWidget *window,
                       GtkWidget *lbl_dashboard,
                       GtkWidget *lbl_weldlog,
                       GtkWidget *lbl_alarms,
                       GtkWidget *lbl_trends,
                       GtkWidget *btn_language) {
    if (window) gtk_window_set_title(GTK_WINDOW(window), _("Sample HMI"));
    if (lbl_dashboard) gtk_label_set_text(GTK_LABEL(lbl_dashboard), _("Dashboard"));
    if (lbl_weldlog)   gtk_label_set_text(GTK_LABEL(lbl_weldlog),   _("Weld Log"));
    if (lbl_alarms)    gtk_label_set_text(GTK_LABEL(lbl_alarms),    _("Alarms"));
    if (lbl_trends)    gtk_label_set_text(GTK_LABEL(lbl_trends),    _("Trends"));
    if (btn_language)  gtk_button_set_label(GTK_BUTTON(btn_language), _("Language"));
}


static void on_language_clicked(GtkButton *btn, gpointer user_data) {
    GtkWidget **widgets = (GtkWidget**)user_data;
    GtkWidget *window = widgets[0];
    GtkWidget *lbl_dashboard = widgets[1];
    GtkWidget *lbl_weldlog   = widgets[2];
    GtkWidget *lbl_alarms    = widgets[3];
    GtkWidget *lbl_trends    = widgets[4];
    GtkWidget *btn_language  = widgets[5];

    GtkWidget *dialog = gtk_dialog_new_with_buttons(
        _("Choose Language"),
        GTK_WINDOW(window),
        GTK_DIALOG_MODAL,
        "_OK", GTK_RESPONSE_OK,
        "_Cancel", GTK_RESPONSE_CANCEL,
        NULL
    );
    GtkWidget *area = gtk_dialog_get_content_area(GTK_DIALOG(dialog));

    GtkWidget *vbox = gtk_box_new(GTK_ORIENTATION_VERTICAL, 8);
    gtk_container_set_border_width(GTK_CONTAINER(vbox), 12);
    GtkWidget *prompt = gtk_label_new(_("Select a language:"));
    gtk_box_pack_start(GTK_BOX(vbox), prompt, FALSE, FALSE, 0);

    GtkWidget *rb_en = gtk_radio_button_new_with_label(NULL, "English");
    GtkWidget *rb_es = gtk_radio_button_new_with_label_from_widget(GTK_RADIO_BUTTON(rb_en), "Spanish");
    GtkWidget *rb_ja = gtk_radio_button_new_with_label_from_widget(GTK_RADIO_BUTTON(rb_en), "Japanese");
    switch (g_current_lang) {
        case LANG_EN: gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(rb_en), TRUE); break;
        case LANG_ES: gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(rb_es), TRUE); break;
        case LANG_JA: gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(rb_ja), TRUE); break;
    }
    gtk_box_pack_start(GTK_BOX(vbox), rb_en, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(vbox), rb_es, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(vbox), rb_ja, FALSE, FALSE, 0);

    gtk_box_pack_start(GTK_BOX(area), vbox, TRUE, TRUE, 0);
    gtk_widget_show_all(dialog);
    gint resp = gtk_dialog_run(GTK_DIALOG(dialog));

    if (resp == GTK_RESPONSE_OK) {
        if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(rb_en))) switch_language(LANG_EN);
        else if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(rb_es))) switch_language(LANG_ES);
        else if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(rb_ja))) switch_language(LANG_JA);
        apply_i18n(window, lbl_dashboard, lbl_weldlog, lbl_alarms, lbl_trends, btn_language);
    }
    gtk_widget_destroy(dialog);
}
