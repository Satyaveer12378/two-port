#ifndef UI_H
#define UI_H

#include <gtk/gtk.h>

// Runtime language switching
typedef enum {
    LANG_EN = 0,
    LANG_ES = 1,
    LANG_JA = 2
} AppLanguage;

void build_ui(GtkApplication *app);

#endif
