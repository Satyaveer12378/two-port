#ifndef _PLOT_DATA_H
#define _PLOT_DATA_H

#define BSC_START_DATA_POS 0
#define BSC_FILE_SIZE 1
#define BSC_TOTAL_DATA 2

extern GLubyte row_y[256];

time_t time_beg;
time_t time_end;
time_t time_pause;
time_t time_play;
struct tm *info;

struct BSCAN_TIME
{
    int hour;
    int min;
    int sec;
};

gboolean time_frame_flag = true;

struct BSCAN_TIME bsc_start_tm;
struct BSCAN_TIME bsc_total_tm;
int total_stop_sec = 0, stop_sec = 0, time_delta = 0;

int num_of_vertices = sizeof(row_y);
int Tmp_thick = 0;
FILE *bsc_fp = NULL;
char bsc_file_name[32] = "bsc_test.txt";
int bsc_data[16];

int icnt = 0;
int test_cnt = 0;

GLbyte bscfiledata[262144]; // GLbyte bsc_data_arr[1024][256];
int hold = 0;
extern int data_shift;

int cur_idx = 1, prev_idx = 0;
int asc_cur_pos = 1, asc_prev_pos = 1;

int p_prev_idx = 1;
int p_asc_pos_prev = 0;

int gc = (178 << 16) + (178 << 8) + (178);
int bc = (255 << 16) + (0 << 8) + (0);

int mouse_pre_x = 0;
int cursor_x_pos = 741; // width_sh = 741;
unsigned long int curr_offset = 1;
unsigned long int prev_offset = 0;
int flag_add = 0;
int Bscan_thk_arr[1024];

int check_file_position(void);
void write_data_in_bsc_file(GLubyte *data);

void init_bsc_data(void)
{   
    bsc_data[BSC_START_DATA_POS] = 4096;
    bsc_data[BSC_FILE_SIZE] = 0;
}

//*************************************************************************************************************************
void refresh_to_plot_data(void)
{
    ruler_val = ruler_val + 1;

    if (Record_Type_val == 0)
        Draw_Bsc_Thk();
    else if (Record_Type_val == 1)
        Draw_Bscan_Color();
    else if (Record_Type_val == 3)
        Draw_TOFD();
}

//**************************************************************************************
//*************************** PLOT BSCAN THICKNESS DATA ********************************
void Draw_Bsc_Thk(void)
{
    char buffer[30];
    int x, y, j, s, idx;
    int pic_w, st_pnt, st_pnt_temp;
    ubyte_t *pos = NULL, *dataptr = NULL;
    int h = bsc_height;
    int Sta = 20, End = 200, Level1 = 30;  // change 1

    if (fwbw_flag == 0)
    {
        gdk_pixbuf_copy_area(src_pixbuf, data_shift, 0, width_sh, h, dest_pixbuf, 0, 0);   // forword copy src to dest
        pic_w = width_sh - data_shift;
        st_pnt = prev_idx;
    }
    else if (fwbw_flag == 1)
    {
        gdk_pixbuf_copy_area(src_pixbuf, 0, 0, width_sh - data_shift, h, dest_pixbuf, data_shift, 0);   // backword copy src to dest
        pic_w = 0;
        st_pnt = p_prev_idx;
    }

    for (s = 0; s < data_shift; s++)
    {
        j = 0, idx = 0;
        x = pic_w + s;

        st_pnt = st_pnt + 1;
        if (st_pnt > 0x3FF)
            st_pnt = 0;

        st_pnt_temp = st_pnt << 8;

        // Tmp_thick=Tmp_thick+1;
        // if(Tmp_thick>250) {Tmp_thick=0;}
        // y=Tmp_thick ;

        for (y = Sta; y < End; y++)
        {
            if (rw_flag == 0) // write data into file or no
            {
                if (Level1 <= row_y[y])
                    break;
            }
            else if (rw_flag == 1) // read data from file
            {
                if (Level1 <= bscfiledata[st_pnt_temp + y])
                    break;
            }
        }
        
        y = (y * h / 250);

        /*for (y = 0; y < h; y++)
        {
            j = (y * num_of_vertices) / h;

            if (rw_flag == 0) // write data into file or no
                idx = row_y[j];
            else if (rw_flag == 1) // read data from file
                idx = bscfiledata[st_pnt_temp + j];

            if (idx > 100)
                idx = 100;

            pos = pixbuf_base_address + (y * rowstride + x * rgb_count);
            dataptr = (ubyte_t *)((char *)&color_gradient_arr[idx] + 0);

            pos[0] = dataptr[0];
            pos[1] = dataptr[1];
            pos[2] = dataptr[2];
        }*/

        // y = ((G1_sp1 * bsc_height) / Range_v);
        // g_print("%ld %d\n", G1_sp1, Range_v);

        // To Erase Old Data  (Blue color)
        dataptr = (ubyte_t *)((char *)&color_gradient_arr[20]);
        for (j = 0; j < h; j++)
        {
            pos = pixbuf_base_address + (j * rowstride + x * rgb_count);
            pos[0] = dataptr[0];
            pos[1] = dataptr[1];
            pos[2] = dataptr[2];
        }

        // Plot New Data  (Green Color)
        dataptr = (ubyte_t *)((char *)&color_gradient_arr[60]);
        for (j = 0; j < y; j++)
        {
            pos = pixbuf_base_address + (j * rowstride + x * rgb_count);
            pos[0] = dataptr[0];
            pos[1] = dataptr[1];
            pos[2] = dataptr[2];
        }
    }

    // copy src to dest
    gdk_pixbuf_copy_area(dest_pixbuf, 0, 0, width_sh, h, src_pixbuf, 0, 0);
    // refresh
    gtk_image_set_from_pixbuf(GTK_IMAGE(plot_bscan_data), dest_pixbuf);
    
    if (val_ary[ENCODER_PERA] == 0)
        surface_rular_update();
}

//**************************************************************************************
//*************************** PLOT BSCAN COLOR DATA ************************************
void Draw_Bscan_Color()
{
    char buffer[30];
    int x, y, j, s, idx;
    int pic_w, st_pnt, st_pnt_temp;
    ubyte_t *pos = NULL, *dataptr = NULL;
    int h = bsc_height;

    if (fwbw_flag == 0)
    {
        gdk_pixbuf_copy_area(src_pixbuf, data_shift, 0, width_sh, h, dest_pixbuf, 0, 0);   // forword copy src to dest
        pic_w = width_sh - data_shift;
        st_pnt = prev_idx;
    }
    else if (fwbw_flag == 1)
    {
        gdk_pixbuf_copy_area(src_pixbuf, 0, 0, width_sh - data_shift, h, dest_pixbuf, data_shift, 0);   // backword copy src to dest
        pic_w = 0;
        st_pnt = p_prev_idx;
    }

    for (s = 0; s < data_shift; s++)
    {
        j = 0, idx = 0;
        x = pic_w + s;

        st_pnt = st_pnt + 1;
        if (st_pnt > 0x3FF)
            st_pnt = 0;

        st_pnt_temp = st_pnt << 8;

        for (y = 0; y < h; y++)
        {
            j = (y * num_of_vertices) / h;

            if (rw_flag == 0) // write data into file or no
                idx = row_y[j];
            else if (rw_flag == 1) // read data from file
                idx = bscfiledata[st_pnt_temp + j]; //idx = bscfiledata[(st_pnt_temp - 256) + j];

            if (idx > 100)
                idx = 100;
            else if (idx < 0)
                idx = 0;

            pos = pixbuf_base_address + (y * rowstride + x * rgb_count);
            dataptr = (ubyte_t*)((char*)&color_gradient_arr[idx] + 0);

            pos[0] = dataptr[0];
            pos[1] = dataptr[1];
            pos[2] = dataptr[2];
        }
    }

    // copy src to dest
    gdk_pixbuf_copy_area(dest_pixbuf, 0, 0, width_sh, h, src_pixbuf, 0, 0);

    // refresh
    gtk_image_set_from_pixbuf(GTK_IMAGE(plot_bscan_data), dest_pixbuf);

    if (val_ary[ENCODER_PERA] == 0)
        surface_rular_update();
}

//**************************************************************************************
//*************************** PLOT BSCAN COLOR DATA ************************************
void Draw_Bscan_Color_encoder()
{
    char buffer[30];
    int x, y, j, s, idx;
    int pic_w, st_pnt, st_pnt_temp;
    ubyte_t *pos = NULL, *dataptr = NULL;
    int h = bsc_height;

    if (fwbw_flag == 0)
    {
        gdk_pixbuf_copy_area(src_pixbuf, data_shift, 0, width_sh, h, dest_pixbuf, 0, 0);   // forword copy src to dest
        pic_w = width_sh - data_shift;
        st_pnt = prev_idx;
    }
    else if (fwbw_flag == 1)
    {
        gdk_pixbuf_copy_area(src_pixbuf, 0, 0, width_sh - data_shift, h, dest_pixbuf, data_shift, 0);   // backword copy src to dest
        pic_w = 0;
        p_prev_idx = Enc_prev;
        st_pnt = p_prev_idx;
    }

    for (s = 0; s < data_shift; s++)
    {
        j = 0, idx = 0;
        x = pic_w + s;

        st_pnt = st_pnt + 1;
        if (st_pnt > 0x3FF)
            st_pnt = 0;

        st_pnt_temp = st_pnt << 8;

        for (y = 0; y < h; y++)
        {
            j = (y * num_of_vertices) / h;

            if (rw_flag == 0) // write data into file or no
            {
                if (s == (data_shift - 1))
                    idx = row_y[j];
                else
                    idx = 0;
            }
            else if (rw_flag == 1) // read data from file
                idx = bscfiledata[st_pnt_temp + j]; //idx = bscfiledata[(st_pnt_temp - 256) + j];

            if (idx > 100)
                idx = 100;
            else if (idx < 0)
                idx = 0;

            pos = pixbuf_base_address + (y * rowstride + x * rgb_count);
            dataptr = (ubyte_t *)((char *)&color_gradient_arr[idx] + 0);

            pos[0] = dataptr[0];
            pos[1] = dataptr[1];
            pos[2] = dataptr[2];
        }
    }

    // copy src to dest
    gdk_pixbuf_copy_area(dest_pixbuf, 0, 0, width_sh, h, src_pixbuf, 0, 0);

    // refresh
    gtk_image_set_from_pixbuf(GTK_IMAGE(plot_bscan_data), dest_pixbuf);

    if (val_ary[ENCODER_PERA] == 0)
        surface_rular_update();
}

//**************************************************************************************
//*************************** PLOT BSCAN TOFD DATA *************************************
void Draw_TOFD(void)
{
    char buffer[30];
    int x, y, j, s, idx;
    int pic_w, st_pnt, st_pnt_temp;
    ubyte_t *pos = NULL, *dataptr = NULL;
    int h = bsc_height;

    if (fwbw_flag == 0)
    { 
        gdk_pixbuf_copy_area(src_pixbuf, data_shift, 0, width_sh, h, dest_pixbuf, 0, 0);    // forword copy src to dest
        pic_w = width_sh - data_shift;
        st_pnt = prev_idx;
    }
    else if (fwbw_flag == 1)
    {
        gdk_pixbuf_copy_area(src_pixbuf, 0, 0, width_sh - data_shift, h, dest_pixbuf, data_shift, 0);   // backword copy src to dest
        pic_w = 0;
        st_pnt = p_prev_idx;
    }

    for (s = 0; s < data_shift; s++)
    {
        j = 0, idx = 0;
        x = pic_w + s;

        st_pnt = st_pnt + 1;
        if (st_pnt > 0x3FF)
            st_pnt = 0;

        st_pnt_temp = st_pnt << 8;

        for (y = 0; y < h; y++)
        {
            j = (y * num_of_vertices) / h;

            if (rw_flag == 0) // write data into file or no
                idx = All_Ascan_data[j]; // idx = row_y[j];
            else if (rw_flag == 1) // read data from file
                idx = bscfiledata[st_pnt_temp + j];

            if (idx > 100)
                idx = 100;
            else if (idx < 0)
                idx = 0;

            pos = pixbuf_base_address + (y * rowstride + x * rgb_count);
            dataptr = (ubyte_t *)((char *)&color_gradient_tfd_arr[idx]);

            pos[0] = dataptr[0];
            pos[1] = dataptr[1];
            pos[2] = dataptr[2];
        }
    }

    // copy src to dest
    gdk_pixbuf_copy_area(dest_pixbuf, 0, 0, width_sh, h, src_pixbuf, 0, 0);

    // refresh
    gtk_image_set_from_pixbuf(GTK_IMAGE(plot_bscan_data), dest_pixbuf);

    if (val_ary[ENCODER_PERA] == 0)
        surface_rular_update();
}

//*******************************************************************
//************************* CREATE DATA FILE ************************
void create_bsc_file(const char* bsc_file_name)
{
    if (bsc_fp != NULL)
    {
        dsp_msg(33);
        return;
    }
    else
    {
        // Create new file
        bsc_fp = fopen(bsc_file_name, "wb");
        if (bsc_fp == NULL)
        {
            g_print("Failed to create file.\n File = %s\n", bsc_file_name);
            return;
        }
        else
        {
            dsp_msg(30);

            fwrite(&val_ary[0], 1, sizeof(val_ary), bsc_fp);
            // It moves file pointer position to the specified location of the file. Using second parameter
            fseek(bsc_fp, bsc_data[BSC_START_DATA_POS], SEEK_SET);

            SplitWindow(1);

            stop_sec = 0;
            total_stop_sec = 0;
            time_beg = time(NULL);

            if (val_ary[ENCODER_PERA] == 0)
                data_shift = 1;
            else if (val_ary[ENCODER_PERA] == 1)
                data_shift = 0;

            rw_flag = 0; // For Write data in file
            fwbw_flag = 0;

            vertical_ruler();
        }
    }
}

//*******************************************************************
//************************* READ DATA *******************************
void open_bsc_file(const char* bsc_file_name)
{
    if (bsc_fp != NULL)
    {
        dsp_msg(33);
        return;
    }
    else
    {
        reset_plot_data();
        // Open file for read data
        
        bsc_fp = fopen(bsc_file_name, "rb");
        if (bsc_fp == NULL)
        {
            g_print("Failed to open file.\n");
            return;
        }
        else
        {
            dsp_msg(31);
            
            fread(&val_ary[0], 1, sizeof(val_ary), bsc_fp);

            //  It moves file pointer position to the end of file
            fseek(bsc_fp, 1, SEEK_END);
            // Get file data size
            bsc_data[BSC_FILE_SIZE] = ftell(bsc_fp);

            // It moves file pointer position to the specified location of the file. Using second parameter
            fseek(bsc_fp, bsc_data[BSC_START_DATA_POS], SEEK_SET);

            bsc_data[BSC_TOTAL_DATA] = (bsc_data[BSC_FILE_SIZE] - bsc_data[BSC_START_DATA_POS]) / num_of_vertices;

            memset(bscfiledata, 0, sizeof(bscfiledata));
            SplitWindow(1);

            stop_sec = 0;
			total_stop_sec = 0;
            time_beg = time(NULL);
          
            rw_flag = 1;    // For Read data from file
            fwbw_flag = 0;

            vertical_ruler();
            refresh_opengl_display();
            Refresh_Allpera_val_f();
        }
    }
}

//*******************************************************************
//************************* CLOSE DATA FILE *************************
void close_bsc_file(void)
{
    if (bsc_fp)
    {
        dsp_msg(32);
        SplitWindow(0); // Stop Recording

        if (rw_flag == 1)
		{
			opengl_update = true;
		}
        rw_flag = -1;
        vertical_ruler();

        fclose(bsc_fp);
        bsc_fp = NULL;
    }
    if (gain_btnval_flag == true)
    {
        pos = (GAIN_PERA * 2) + 0;
        strcpy(all_btnval[pos], gain_btnval[0]);
        strcpy(all_btnval[pos + 1], gain_btnval[1]);
        pos = pos % 10;
        gain_btnval_flag = false;
    }
}

//*******************************************************************
//************************* WRITE DATA *******************************
void write_data_in_bsc_file(GLubyte *data)
{
    fwrite(data, 1, num_of_vertices, bsc_fp);
}

//*******************************************************************
//***************** READ DATA USING SCROLLBAR ***********************
void read_data_using_scrollbar_fun(GtkAdjustment *adjustment, gpointer user_data)
{
    gdouble lower, upper;

    lower = gtk_adjustment_get_lower(adjustment);
    upper = gtk_adjustment_get_upper(adjustment);

    g_print("Data %lf, %lf\n", lower, upper);
}

//*******************************************************************
//***************** READ FORWORD DATA FROM FILE *********************
void read_data_from_bsc_file(int updn)
{
    int index, asc_temp;
    
    if(check_file_position() == -2)
    {
        return;
    }

    if (cur_idx > 1023)
        updn = 1023 - prev_idx; // g_print("updn 1 : %d\n", updn);

    index = (prev_idx << 8);

    if (asc_cur_pos < 1)
        asc_cur_pos = 1;
    if (asc_cur_pos > bsc_data[BSC_TOTAL_DATA])
        asc_cur_pos = bsc_data[BSC_TOTAL_DATA];

    fseek(bsc_fp, bsc_data[BSC_START_DATA_POS] + (asc_prev_pos * num_of_vertices), SEEK_SET);
    fread(&bscfiledata[index], 1, abs(updn + 1) * num_of_vertices, bsc_fp);

    if (cur_idx > 1023)
    {
        asc_temp = asc_prev_pos + updn;
        updn = cur_idx - 1023; // g_print("updn 2 : %d\n", updn);
        fseek(bsc_fp, bsc_data[BSC_START_DATA_POS] + (asc_temp * num_of_vertices), SEEK_SET);
        fread(&bscfiledata[0], 1, abs(updn) * num_of_vertices, bsc_fp);
    }
}

//*******************************************************************
//***************** READ BACKWORD DATA FROM FILE ********************
void read_prev_data_from_bsc_file(int updn)
{
    int index, asc_temp;

    if (p_asc_pos_prev <= 0)
    {
        dsp_msg(20);
        SplitWindow(0); // Stop Recording

        if (rw_flag == 1)
           opengl_update = true;
           
        rw_flag = -1;
        close_bsc_file();
        return;
    }

    if (hold < 0)
        updn = -hold; // g_print("updn 1 : %d\n", updn);

    index = (p_prev_idx << 8);

    if (asc_cur_pos < 1)
        asc_cur_pos = 1;
    if (asc_cur_pos > bsc_data[BSC_TOTAL_DATA])
        asc_cur_pos = bsc_data[BSC_TOTAL_DATA];

    fseek(bsc_fp, bsc_data[BSC_START_DATA_POS] + (p_asc_pos_prev * num_of_vertices), SEEK_SET);
    fread(&bscfiledata[index], 1, abs(updn) * num_of_vertices, bsc_fp);

    if (hold < 0)
    {
        asc_temp = p_asc_pos_prev + updn;
        updn = data_shift - updn; // g_print("updn 2 : %d\n", updn);
        fseek(bsc_fp, bsc_data[BSC_START_DATA_POS] + (asc_temp * num_of_vertices), SEEK_SET);
        fread(&bscfiledata[0], 1, abs(updn) * num_of_vertices, bsc_fp);
    }
}

//*******************************************************************
//************************* DATA OFFSET *****************************
void read_data_using_button_fun(int key)
{
    int delta = 0;

    if (key > 0)
    {
        asc_cur_pos = asc_cur_pos + key;

        delta = asc_cur_pos - asc_prev_pos;
        cur_idx = cur_idx + delta;

        data_shift = delta;

        read_data_from_bsc_file(data_shift);
        send_data();
      
        asc_prev_pos = asc_cur_pos;

        cur_idx = cur_idx & 0x3FF;
        prev_idx = cur_idx;
    }
    else if (key < 0 && asc_cur_pos > 741)
    {
        asc_cur_pos = asc_cur_pos + key;
        delta = asc_prev_pos - asc_cur_pos;

        // file position calculation
        p_asc_pos_prev = asc_prev_pos;
        p_asc_pos_prev = p_asc_pos_prev - width_sh;
        p_asc_pos_prev = p_asc_pos_prev - delta;
        asc_prev_pos = asc_prev_pos - delta;

        // array position calculation
        p_prev_idx = prev_idx;
        if (p_prev_idx <= width_sh)
        {
            p_prev_idx = width_sh - p_prev_idx;
            p_prev_idx = 1024 - p_prev_idx;
        }
        else if (p_prev_idx > width_sh)
        {
            p_prev_idx = p_prev_idx - width_sh;
        }
        
        p_prev_idx = p_prev_idx - delta;
        if (p_prev_idx < 0)
        {
            hold = p_prev_idx;
        }
        p_prev_idx = p_prev_idx & 0x3FF;

        prev_idx = prev_idx - delta;

        data_shift = delta;

        read_prev_data_from_bsc_file(data_shift);
        send_data();    

        asc_cur_pos = asc_prev_pos;
        
        prev_idx = prev_idx & 0x3FF;
        cur_idx = prev_idx;
    }
}

//*******************************************************************
//********************* DATA OFFSET for Bord ************************
//*******************************************************************
void read_data_using_button_fun_for_Board(int key)
{
    int delta = 0;

    if (key > 0)
    {
        asc_cur_pos = asc_cur_pos + key;

        delta = asc_cur_pos - asc_prev_pos;
        cur_idx = cur_idx + delta;

        data_shift = delta;

        read_data_from_bsc_file(data_shift);
        send_data_board();

        asc_prev_pos = asc_cur_pos;

        cur_idx = cur_idx & 0x3FF;
        prev_idx = cur_idx;
    }
    else if (key < 0 && asc_cur_pos > 741)
    {
        asc_cur_pos = asc_cur_pos + key;
        delta = asc_prev_pos - asc_cur_pos;

        // file position calculation
        p_asc_pos_prev = asc_prev_pos;
        p_asc_pos_prev = p_asc_pos_prev - width_sh;
        p_asc_pos_prev = p_asc_pos_prev - delta;
        asc_prev_pos = asc_prev_pos - delta;

        // array position calculation
        p_prev_idx = prev_idx;
        if (p_prev_idx <= width_sh)
        {
            p_prev_idx = width_sh - p_prev_idx;
            p_prev_idx = 1024 - p_prev_idx;
        }
        else if (p_prev_idx > width_sh)
        {
            p_prev_idx = p_prev_idx - width_sh;
        }
        
        p_prev_idx = p_prev_idx - delta;
        if (p_prev_idx < 0)
        {
            hold = p_prev_idx;
        }
        p_prev_idx = p_prev_idx & 0x3FF;

        prev_idx = prev_idx - delta;

        data_shift = delta;

        read_prev_data_from_bsc_file(data_shift); 
        send_data_board();

        asc_cur_pos = asc_prev_pos;
        
        prev_idx = prev_idx & 0x3FF;
        cur_idx = prev_idx;
    }
}

//*******************************************************************
//************************* PLAY DATA FROM FILE *********************
int check_file_position(void)
{
    if (feof(bsc_fp))
    {
        dsp_msg(19);
        SplitWindow(0); // Stop Recording

        if (rw_flag == 1)
            opengl_update = true;

        rw_flag = -1;
        close_bsc_file();

        asc_cur_pos = 1;
        asc_prev_pos = 0;
        cur_idx = 1;
        return (-2);
    }
}

// draw read line on mouse pointer position
void draw_cur_line(int x, int pre_x)
{
    int j = 0, y, prev_x_pos, h = bsc_height;
    int Sta = 20, End = 200, Level1 = 30;
    ubyte_t *prev_line = NULL, *curr_line = NULL, *dataptr = NULL;

    j = (asc_cur_pos - width_sh) + pre_x;
    prev_x_pos = j & 0x3FF;
    prev_x_pos = prev_x_pos << 8;

    if (Record_Type_val == 0)
    // if (Record_Type_val == 0 && rw_flag == 1)
    {
        for (y = Sta; y < End; y++)
        {
            if (Level1 <= bscfiledata[prev_x_pos + y]) // read data from file
            {
                break;
            }
        }
        y = (y * bsc_height / 250);

        // To Erase Old Data  (Blue color)
        dataptr = (ubyte_t *)((char *)&color_gradient_arr[20]);
        for (j = 0; j < bsc_height; j++)
        {
            prev_line = pixbuf_base_address + (j * rowstride + pre_x * rgb_count);
            prev_line[0] = dataptr[0];
            prev_line[1] = dataptr[1];
            prev_line[2] = dataptr[2];
        }

        // Plot New Data  (Green Color)
        dataptr = (ubyte_t *)((char *)&color_gradient_arr[60]);
        for (j = 0; j < y; j++)
        {
            prev_line = pixbuf_base_address + (j * rowstride + pre_x * rgb_count);
            prev_line[0] = dataptr[0];
            prev_line[1] = dataptr[1];
            prev_line[2] = dataptr[2];
        }
    }
    else if (Record_Type_val == 1)
    {
        // draw line on previous mouse cursor positon
        for (y = 0; y < h; y++)
        {
            j = (y * num_of_vertices) / h;

            j = bscfiledata[prev_x_pos + j];
            if (j > 100)
                j = 100;

            prev_line = (pixbuf_base_address + (y * rowstride + pre_x * rgb_count));
            dataptr = (ubyte_t *)((gchar *)&color_gradient_arr[j] + 0);

            prev_line[0] = dataptr[0];
            prev_line[1] = dataptr[1];
            prev_line[2] = dataptr[2];
        }
    }

    // draw red line on mouse cursor positon
    for (y = 0; y < h; y++)
    {
        curr_line = pixbuf_base_address + (y * rowstride + x * rgb_count);
        curr_line[0] = 255;
        curr_line[1] = 0;
        curr_line[2] = 0;
    }

    ogl_render(width_sh, height_sh);
}

// update vertices in opengl buffer
void update_on_mouse_move(int cur_x, int pre_x)
{
    int i = 0, j = 0, loc_idx;
    int y, h = bsc_height;
    ubyte_t *curr_line = NULL, *dataptr = NULL;
    float tfd, offst;
    tfd = (50.0f * ((float)splite_frame_height - 2.0f)) / (float)Asc_Height;
    offst = (50.0f + ((((float)splite_frame_height - 2.0f) - (float)Asc_Height) / 8.0f));

    j = (asc_cur_pos - width_sh) + cur_x;
    loc_idx = j & 0x3FF;
    loc_idx = loc_idx << 8;

    for (i = 0; i < num_of_vertices; i++)
        ogl.vertices_position[(i * 2) + 1] = ((GLfloat)bscfiledata[loc_idx + i] - offst) / tfd;
        // ogl.vertices_position[(i * 2) + 1] = ((GLfloat)bscfiledata[loc_idx + i] - 50.0f) / 50.0f;

    draw_cur_line(cur_x, pre_x);
    gtk_image_set_from_pixbuf(GTK_IMAGE(plot_bscan_data), dest_pixbuf);
}

// display content on mouse pointer position
void show_index_content(int x, int y)
{
    int i, x_pos, actual_y, h = bsc_height;

    i = (asc_cur_pos - width_sh) + x;
    x_pos = i & 0x3FF;
    x_pos = x_pos << 8;

    actual_y = (y * num_of_vertices) / h;
}

// Mouse event handling
gboolean get_mouse_coordinates(GtkWidget *widget, GdkEventMotion *event)
{
    int cur_x = 0, cur_y = 0, pre_x = 0;

    cur_x = (int)event->x;
    cur_y = (int)event->y;

    pre_x = mouse_pre_x;
    mouse_pre_x = cur_x;

    update_on_mouse_move(cur_x, pre_x);
    show_index_content(cur_x, cur_y);
    return(FALSE);
}

//*******************************************************************
//************************* RULAR VALUES UPDATE *********************
void surface_rular_update(void)
{
    cairo_text_extents_t extents;

    char num[32], dec_num[8]; char time_buf[64];
    double digit_pos = (((double)width_sh - 4.0) / 10.0);
    int i = 0, j = 0, str_sz = 0;
    double len = 0, sp = 0;
    double line_pos = digit_pos / 5.0;

    // ruler_val = ruler_val + 1;
    cairo_set_source_rgb(cr_rular, 0.7, 0.7, 0.7);
    cairo_paint(cr_rular);

    cairo_set_source_rgb(cr_rular, 0.0, 0.0, 1.0);
    cairo_set_font_size(cr_rular, 12.0);

    for (i = 0; i < 51; i++)
    {
        if (i % 5 == 0)
            len = 12;
        else
            len = 6;

        cairo_move_to(cr_rular, sp + (line_pos * i), 0);
        cairo_line_to(cr_rular, sp + (line_pos * i), len);
        cairo_stroke(cr_rular);
    }

    if (time_frame_flag == true)
    {
        time_end = time(NULL);
        time_delta = difftime(time_end, time_beg);

        bsc_total_tm.min = time_delta / 60;
        bsc_total_tm.hour = bsc_total_tm.min / 60;
        bsc_total_tm.sec = time_delta % 60;

        sprintf(time_buf, "Time : %02d:%02d:%02d, Frames : %d", bsc_total_tm.hour, bsc_total_tm.min, bsc_total_tm.sec, ruler_val - 1);
    }
    else if (time_frame_flag == false)
    {
        sprintf(time_buf, "Frames : %d", ruler_val - 1);
    }

    cairo_text_extents(cr_rular, time_buf, &extents);
    cairo_move_to(cr_rular, sp + ((digit_pos * 10) - (extents.width)), 22.0);
    cairo_show_text(cr_rular, time_buf);

    gtk_image_set_from_surface(GTK_IMAGE(surface_rular_image), surface_rular);
}

//*******************************************************************
//************************* RESET VARIABLES**************************
void reset_plot_data(void)
{
    ruler_val = 0;
    cur_idx = 1, prev_idx = 0;
    asc_cur_pos = 1, asc_prev_pos = 1;
    p_prev_idx = 1, p_asc_pos_prev = 0;
}

#endif /* _PLOT_DATA_H */
