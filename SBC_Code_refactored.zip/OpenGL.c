#include "OpenGL.h"
#include "Dav_Sub.h"

#define NUM_OF_VERTICES 256

// extern POINT;      // POINT pntArray_DACM[NUM_OF_VERTICES];

typedef struct tagPOINT
{
    long x;
    long y;
} POINT;

extern POINT pntArray_DACM[NUM_OF_VERTICES];  // Holds data of DAC Curve main curve
extern POINT pntArray_DAC1P[NUM_OF_VERTICES]; // Holds data of DAC Curve Main Curve+dac db
extern POINT pntArray_DAC2P[NUM_OF_VERTICES]; // Holds data of DAC Curve Main Curve+ 2*dac db
extern POINT pntArray_DAC1N[NUM_OF_VERTICES]; // Holds data of DAC Curve Main Curve - dac db
extern POINT pntArray_DAC2N[NUM_OF_VERTICES]; // Holds data of DAC Curve Main Curve - 2*dac db
extern int Dac_crv_dB;
extern double Prb_Near_field, Prb_div_Ht;
extern int All_Ascan_data[1024];

extern int Asc_Max[1024];
extern uint8_t rx_cmd[1024];
extern int Asc_Width;
extern int Asc_Height;
extern int frame_width;
extern int splite_frame_height;
extern int Voff;
extern int Dgs_onoff_v, Dac_v;

extern int splite_win_flg;
extern int Asc_Clr_val;
extern int Clr_leg_sta, Clr_leg_width;
extern int Grid_v;
extern int Rectify_v;
extern int video_val; // IF Video Dynamic is selected
extern gdouble Grid_r[20], Grid_g[20], Grid_b[20];

extern float Red[20];
extern float Green[20];
extern float Blue[20];
extern int recall_read;

extern int Record_Type_val;
extern int dgsdb_crv[15];
extern int Dgs_gain;

extern gboolean Dac_Bscan_flag; // Bscan = true, Dac = false;
extern gboolean Ascan_image_snap;
extern unsigned char *Ascan_image_data; //[741][446][3]; // full Ascan area Width * Height * RGB = 741*446*3

extern int dgs_fromfile;
extern long dgs_pnt[256];
extern void Set_default_val();
extern gboolean DGS_ReadFile; // = false;

float fdiv[120];
GLubyte row_y[NUM_OF_VERTICES];

enum
{
    ATTRIBUTE_POSITION = 0,
    ATTRIBUTE_COLOR
};

GLfloat y_coord[] =
    {
        100.0f,
        100.0f,
        100.0f,
        100.0f,
        100.0f,
        60.0f,
        45.0f,
        55.0f,
        28.0f,
        33.0f,
        12.0f,
        13.0f,
        5.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        13.0f,
        37.0f,
        23.0f,
        62.0f,
        48.0f,
        74.0f,
        80.0f,
        76.0f,
        49.0f,
        54.0f,
        23.0f,
        9.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        3.0f,
        17.0f,
        27.0f,
        20.0f,
        39.0f,
        55.0f,
        43.0f,
        25.0f,
        27.0f,
        13.0f,
        5.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        8.0f,
        12.0f,
        19.0f,
        32.0f,
        40.0f,
        37.0f,
        25.0f,
        16.0f,
        9.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        3.0f,
        9.0f,
        19.0f,
        28.0f,
        20.0f,
        15.0f,
        9.0f,
        5.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
};

const struct wl_registry_listener registry_listener = {
    global_registry_handler,
    global_registry_remover};

int idx_fact = 1;
extern int Rectify_v;
gboolean bflag = true;
bool Color_update = false;

cairo_t *Ascan_cr;
cairo_surface_t *Ascan_surface;
GdkPixbuf *Ascan_pixbuf = NULL;

void select_shape(cairo_t *cr, int *offset);
void write_data_in_bsc_file(GLubyte *data);
extern void WriteDataIntoFile(char *str, int i, float data);

//************************************************************************
// OpenGL initialization function
//************************************************************************
void egl_wayland_initialization(GdkWindow *gdk_window, int width, int height)
{
    EGLint major_version;
    EGLint minor_version;
    EGLint num_configs;

    // Wayland code
    ogl.pw_surface = gdk_wayland_window_get_wl_surface(gdk_window);

    get_server_referance(gdk_window_get_display(gdk_window));

    ogl.cw_surface = wl_compositor_create_surface(ogl.compositor);
    if (ogl.cw_surface == NULL)
        printf("egl_wayland_initialization() Can't create surface.\n");

    ogl.region = wl_compositor_create_region(ogl.compositor);
    wl_surface_set_input_region(ogl.cw_surface, ogl.region);

    ogl.subsurface = wl_subcompositor_get_subsurface(ogl.subcompositor, ogl.cw_surface, ogl.pw_surface);
    wl_subsurface_set_desync(ogl.subsurface);
    wl_subsurface_set_position(ogl.subsurface, ogl_x_position, ogl_y_position);

    ogl.egl_window = wl_egl_window_create(ogl.cw_surface, width, height);

    EGLint attributes[] =
    {
        EGL_SURFACE_TYPE, EGL_WINDOW_BIT,
        EGL_RED_SIZE, 8,
        EGL_GREEN_SIZE, 8,
        EGL_BLUE_SIZE, 8,
        EGL_RENDERABLE_TYPE, EGL_OPENGL_ES2_BIT,
        EGL_NONE
    };

    EGLint context_attribs[] = { EGL_CONTEXT_CLIENT_VERSION, 2, EGL_NONE };

    // Get Display
    ogl.egl_display = eglGetDisplay((EGLNativeDisplayType)ogl.w_display);
    if (ogl.egl_display == EGL_NO_DISPLAY)
        g_print("eglGetDisplay() function is failed.\n");

    // Initialize OpenGL
    if (!eglInitialize(ogl.egl_display, &major_version, &minor_version))
        g_print("eglInitialize() function is failed.\n");
    // g_print("EGL Version : %d:%d\n", major_version, minor_version);

    eglBindAPI(EGL_OPENGL_ES_API);
    eglGetConfigs(ogl.egl_display, NULL, 0, &num_configs);

    // Chooose Config
    if (!eglChooseConfig(ogl.egl_display, attributes, &ogl.egl_config, 1, &num_configs))
        g_print("eglChooseConfig() function is failed.\n");

    // Create a GL context
    ogl.egl_context = eglCreateContext(ogl.egl_display, ogl.egl_config, EGL_NO_CONTEXT, context_attribs);
    if (ogl.egl_context == EGL_NO_CONTEXT)
        g_print("eglCreateContext() function is failed.\n");

    // Create a surface
    ogl.egl_surface = eglCreateWindowSurface(ogl.egl_display, ogl.egl_config, ogl.egl_window, NULL);
    if (ogl.egl_surface == EGL_NO_CONTEXT)
        g_print("eglCreateWindowSurface() function is failed.\n");

    // Make the context current
    if (!eglMakeCurrent(ogl.egl_display, ogl.egl_surface, ogl.egl_surface, ogl.egl_context))
        g_print("eglMakeCurrent() function is failed.\n");

    clr_grd_data_function();
    ogl_initialization(width, height);

    Ascan_pixbuf = gdk_pixbuf_new(GDK_COLORSPACE_RGB, true, 8, width, height); 
    Ascan_surface = cairo_image_surface_create(CAIRO_FORMAT_ARGB32, width, height);
    Ascan_cr = cairo_create (Ascan_surface);
}

void ogl_initialization(int width, int height)
{
    int i = 0;
    GLint iShaderCompileStatus = 0;
    GLint iProgramLinkStatus = 0;
    GLint iInfoLogLength = 0;
    GLchar *szInfoLog = NULL;

    // Create vertex shader
    ogl.vertex_shader = glCreateShader(GL_VERTEX_SHADER);

    // Write vertex shader code
    const GLchar *vssourcecode = 
    {
        "#version 100                                               \n"

        "attribute vec2 vPosition;                                  \n"
        "attribute vec3 vColor;                                     \n"

        "varying vec3 outColor;                                     \n"

        "void main(void)                                            \n"
        "{                                                          \n"
        "  gl_Position = vec4(vPosition.x, vPosition.y, 0.0, 1.0);  \n"
        "  outColor = vColor;                                       \n"
        "}"
    };

    glShaderSource(ogl.vertex_shader, 1, &vssourcecode, NULL);
    glCompileShader(ogl.vertex_shader);

    glGetShaderiv(ogl.vertex_shader, GL_COMPILE_STATUS, &iShaderCompileStatus);
    if (iShaderCompileStatus == GL_FALSE)
    {
        glGetShaderiv(ogl.vertex_shader, GL_INFO_LOG_LENGTH, &iInfoLogLength);
        if (iInfoLogLength > 0)
        {
            szInfoLog = (GLchar *)malloc(iInfoLogLength);
            if (szInfoLog != NULL)
            {
                GLsizei written;
                glGetShaderInfoLog(ogl.vertex_shader, iInfoLogLength, &written, szInfoLog);
                g_print("VS Log :- %s.", szInfoLog);
                free(szInfoLog);
                exit(0);
            }
        }
    }

    // Create fragment shader
    ogl.fragment_shader = glCreateShader(GL_FRAGMENT_SHADER);

    // Write fragmant shader code
    const GLchar *fssourcecode = 
    {
        "#version 100                               \n"

        "precision mediump float;                   \n"

        "varying vec3 outColor;                     \n"

        "void main(void)                            \n"
        "{                                          \n"
        "  gl_FragColor = vec4(outColor, 1.0);      \n"
        "}"
    };

    glShaderSource(ogl.fragment_shader, 1, &fssourcecode, NULL);
    glCompileShader(ogl.fragment_shader);

    glGetShaderiv(ogl.fragment_shader, GL_COMPILE_STATUS, &iShaderCompileStatus);
    if (iShaderCompileStatus == GL_FALSE)
    {
        glGetShaderiv(ogl.fragment_shader, GL_INFO_LOG_LENGTH, &iInfoLogLength);
        if (iInfoLogLength > 0)
        {
            szInfoLog = (GLchar *)malloc(iInfoLogLength);
            if (szInfoLog != NULL)
            {
                GLsizei written;
                glGetShaderInfoLog(ogl.fragment_shader, iInfoLogLength, &written, szInfoLog);
                g_print("FS Log :- %s.", szInfoLog);
                free(szInfoLog);
                exit(0);
            }
        }
    }

    // Create shader program object
    ogl.shader_program_object = glCreateProgram();
    glAttachShader(ogl.shader_program_object, ogl.vertex_shader);
    glAttachShader(ogl.shader_program_object, ogl.fragment_shader);

    glBindAttribLocation(ogl.shader_program_object, ATTRIBUTE_POSITION, "vPosition");
    glBindAttribLocation(ogl.shader_program_object, ATTRIBUTE_COLOR, "vColor");

    // Link shader
    glLinkProgram(ogl.shader_program_object);

    glGetProgramiv(ogl.shader_program_object, GL_LINK_STATUS, &iProgramLinkStatus);
    if (iProgramLinkStatus == GL_FALSE)
    {
        glGetProgramiv(ogl.shader_program_object, GL_INFO_LOG_LENGTH, &iInfoLogLength);
        if (iInfoLogLength)
        {
            szInfoLog = (GLchar *)malloc(iInfoLogLength);
            if (szInfoLog != NULL)
            {
                GLsizei written;
                glGetProgramInfoLog(ogl.shader_program_object, iInfoLogLength, &written, szInfoLog);
                g_print("LS Log :- %s.", szInfoLog);
                free(szInfoLog);
                exit(0);
            }
        }
    }

    for (i = 0; i < 2048; i++)
    {
        ogl.indices[i] = i; // Indices of vertices
    }

    for (i = 0; i < NUM_OF_VERTICES; i++) // Calculate and fill X position for A-Scan
    {
        ogl.vertices_position[(i * 2) + 0] = ((GLfloat)i - 128.0f) / 128.0f; // On x-axis 255 positions co-ordinates
        ogl.vertices_position[(i * 2) + 512] = ogl.vertices_position[(i * 2) + 0];
        ogl.vertices_position[(i * 2) + 1024] = ogl.vertices_position[(i * 2) + 0];

        ogl.vertices_position[(i * 2) + 1] = (y_coord[i] / 50) - 1.0; // 0.0f;
        // ogl.indices[i] = i; // Indices of vertices
    }

    // Vertices color
    // for (i = 0; i < NUM_OF_VERTICES; i++)
    // {
    //     if (i >= 0 && i <= 100)
    //     {
    //         ogl.vertices_color[(i * 3) + 0] = 1.0f;   //  0000 0000 0000 0000
    //         ogl.vertices_color[(i * 3) + 1] = 0.0f;
    // ogl.vertices_color[(i * 3) + 2] = 0.0f;
    //     }
    //     else if (i >= 101 && i <= 200)
    //     {
    //         ogl.vertices_color[(i * 3) + 0] = 0.0f;
    //         ogl.vertices_color[(i * 3) + 1] = 1.0f;
    // ogl.vertices_color[(i * 3) + 2] = 1.0f;
    //     }
    //     else if (i >= 201)
    //     {
    //         ogl.vertices_color[(i * 3) + 0] = 1.0f;
    //         ogl.vertices_color[(i * 3) + 1] = 0.0f;
    // ogl.vertices_color[(i * 3) + 2] = 1.0f;
    //     }
    // }

    for (i = 0; i < 1536; i++) // Verteces  Color 1536  NUM_OF_VERTICES*2 *3 =1536 for Filled Echo Pattern
    {
        ogl.vertices_color[(i * 3) + 0] = 1.0f;
        ogl.vertices_color[(i * 3) + 1] = 1.0f;
        ogl.vertices_color[(i * 3) + 2] = 0.0f;
    }

    // Generate vao buffer
    glGenVertexArrays(1, &ogl.vao);
    // Bind vao buffer
    glBindVertexArray(ogl.vao);
    // Generate vbo buffer
    glGenBuffers(1, &ogl.vbo_position);
    // Bind vbo buffer
    glBindBuffer(GL_ARRAY_BUFFER, ogl.vbo_position);
    glBufferData(GL_ARRAY_BUFFER, (NUM_OF_VERTICES * 2) * sizeof(GL_FLOAT), NULL, GL_DYNAMIC_DRAW);
    glVertexAttribPointer(ATTRIBUTE_POSITION, 2, GL_FLOAT, GL_FALSE, 0, NULL);
    glEnableVertexAttribArray(ATTRIBUTE_POSITION);
    // Generate vbo buffer
    glGenBuffers(1, &ogl.vbo_color);
    // Bind vbo buffer
    glBindBuffer(GL_ARRAY_BUFFER, ogl.vbo_color);
    glBufferData(GL_ARRAY_BUFFER, sizeof(ogl.vertices_color), ogl.vertices_color, GL_DYNAMIC_DRAW);
    glVertexAttribPointer(ATTRIBUTE_COLOR, 3, GL_FLOAT, GL_FALSE, 0, NULL);
    glEnableVertexAttribArray(ATTRIBUTE_COLOR);
    // Unbind vbo buffer
    glBindBuffer(GL_ARRAY_BUFFER, 0);
    // Generate ebo buffer
    glGenBuffers(1, &ogl.ebo);
    // Bind ebo buffer
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ogl.ebo);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(ogl.indices), ogl.indices, GL_STATIC_DRAW);
    // Unbind ebo buffer
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
    // Unbind vao buffer
    glBindVertexArray(0);
    
    // below code for Setref_f
    for (i = 0; i < NUM_OF_VERTICES; i++)
	{
		All_Ascan_peak[(i * 2) + 0] = ogl.vertices_position[(i * 2) + 0];
        All_Ascan_peak[(i * 2) + 1] = 0.0f;
	}

    All_Ascan_peak_index[0] = 0;
    for (i = 1; i < NUM_OF_VERTICES; i++)
	{
        All_Ascan_peak_index[(i * 2) - 1] = i;
        All_Ascan_peak_index[(i * 2) + 0] = i;
	}
    All_Ascan_peak_index[511] = 1.0f;

    glGenVertexArrays(1, &ogl.vao_peak);
    glBindVertexArray(ogl.vao_peak);

    glGenBuffers(1, &ogl.vbo_pos_peak);
    glBindBuffer(GL_ARRAY_BUFFER, ogl.vbo_pos_peak);
    glBufferData(GL_ARRAY_BUFFER, (NUM_OF_VERTICES * 2) * sizeof(GL_FLOAT), NULL, GL_DYNAMIC_DRAW);
    glVertexAttribPointer(ATTRIBUTE_POSITION, 2, GL_FLOAT, GL_FALSE, 0, NULL);
    glEnableVertexAttribArray(ATTRIBUTE_POSITION);

    glGenBuffers(1, &ogl.vbo_clr_peak);
    glBindBuffer(GL_ARRAY_BUFFER, ogl.vbo_clr_peak);
    glBufferData(GL_ARRAY_BUFFER, sizeof(ogl.vertices_color), ogl.vertices_color, GL_DYNAMIC_DRAW);
    glVertexAttribPointer(ATTRIBUTE_COLOR, 3, GL_FLOAT, GL_FALSE, 0, NULL);
    glEnableVertexAttribArray(ATTRIBUTE_COLOR);
    glBindBuffer(GL_ARRAY_BUFFER, 0);
   
    glGenBuffers(1, &ogl.ebo_peak);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ogl.ebo_peak);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(All_Ascan_peak_index), All_Ascan_peak_index, GL_STATIC_DRAW);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);

    glBindVertexArray(0);

    // Used for Background image
    ogl.surface = cairo_image_surface_create(CAIRO_FORMAT_RGB24, width, height);
    // Using surface create memory context
    ogl.cr = cairo_create(ogl.surface);

    // Framebuffer configuration
    glGenFramebuffers(1, &ogl.framebuffer);
    glBindFramebuffer(GL_FRAMEBUFFER, ogl.framebuffer);

    // Create a color attachment texture
    glGenTextures(1, &ogl.textureColorbuffer);
    glBindTexture(GL_TEXTURE_2D, ogl.textureColorbuffer);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, NULL);
    glGenerateMipmap(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, 0);
    
    //  Bind texture buffer with GL_COLOR_ATTACHMENT0 in framebuffer
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, ogl.textureColorbuffer, 0);
    if (glCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE)
        g_print("ERROR::FRAMEBUFFER:: Framebuffer is not complete..!\n");
    // Unbind framebuffer
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
   
    // Call to create background grid
    gl_clear_color_background_data(width, height);
    
    glBindFramebuffer(GL_READ_FRAMEBUFFER, ogl.framebuffer);
    glBindFramebuffer(GL_DRAW_FRAMEBUFFER, 0);
    glBlitFramebuffer(0, 0, width, height, // Source x, y, width and height
                      0, height, width, 0, // Dest x, y, width and height
                      GL_COLOR_BUFFER_BIT, GL_NEAREST);

    // Set view port
    glViewport(0, 0, (GLsizei)width, (GLsizei)height);
}

// OpenGL display function
void ogl_render(int width, int height)
{ 
    if (splite_win_flg > 0) // Window is Split
    {
        height = height / 2;
    } // height=height_sh;

    glBlitFramebuffer(0, 0, width, height, // Source x, y, width and height
                      0, height, width, 0, // Dest x, y, width and height
                      GL_COLOR_BUFFER_BIT, GL_NEAREST);

    // Start using OpenGL shader program object
    glUseProgram(ogl.shader_program_object);

    glLineWidth(2.0f);
    
    if (val_ary[SET_REF_PERA] == 1)
    {
        glBindVertexArray(ogl.vao_peak);
        glBindBuffer(GL_ARRAY_BUFFER, ogl.vbo_pos_peak);
        glBufferData(GL_ARRAY_BUFFER, sizeof(All_Ascan_peak), All_Ascan_peak, GL_DYNAMIC_DRAW);
        glVertexAttribPointer(ATTRIBUTE_POSITION, 2, GL_FLOAT, GL_FALSE, 0, NULL);
        glEnableVertexAttribArray(ATTRIBUTE_POSITION);

        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ogl.ebo_peak);
        glDrawElements(GL_LINE_STRIP, 511, GL_UNSIGNED_SHORT, 0); // All_Ascan_peak_index array size is 510
        glBindVertexArray(0);
    }
    
    // Bind vao
    glBindVertexArray(ogl.vao);
    glBindBuffer(GL_ARRAY_BUFFER, ogl.vbo_position);
    glBufferData(GL_ARRAY_BUFFER, sizeof(ogl.vertices_position), ogl.vertices_position, GL_DYNAMIC_DRAW);
    glVertexAttribPointer(ATTRIBUTE_POSITION, 2, GL_FLOAT, GL_FALSE, 0, NULL);
    glEnableVertexAttribArray(ATTRIBUTE_POSITION);

    if (Color_update == true) // Bind vbo buffer
    {
        Color_update = false;
        glBindBuffer(GL_ARRAY_BUFFER, ogl.vbo_color);
        glBufferData(GL_ARRAY_BUFFER, sizeof(ogl.vertices_color), ogl.vertices_color, GL_DYNAMIC_DRAW);
        glVertexAttribPointer(ATTRIBUTE_COLOR, 3, GL_FLOAT, GL_FALSE, 0, NULL);
        glEnableVertexAttribArray(ATTRIBUTE_COLOR);
    }

    int noof_pnt = NUM_OF_VERTICES;
    if (video_val == 1)
    {
        noof_pnt = 768;
    }
    
    if (video_val == 2) // IF Video Dynamic is selected
    {
        glDrawArrays(GL_LINE_STRIP, 768, NUM_OF_VERTICES);
    } // glDrawArrays(GL_LINE_STRIP,NUM_OF_VERTICES,250); }
    else
    {
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ogl.ebo);
        glDrawElements(GL_LINE_STRIP, noof_pnt, GL_UNSIGNED_INT, (void *)0);
    }

    //  Unbind vao
    glBindVertexArray(0);

    glUseProgram(0);

    eglSwapBuffers(ogl.egl_display, ogl.egl_surface);
    wl_surface_commit(ogl.cw_surface);
}

// OpenGL update function
void ogl_update(void)
{
    int temp, dst;
    GLint idx = 0, rnd = 0, i = 0;
    GLfloat tmpgl;
    bool Randd = true;
    float tfd, offst;
    tfd = (50.0f * ((float)splite_frame_height - 2.0f)) / (float)Asc_Height;
    offst = (50.0f + ((((float)splite_frame_height - 2.0f) - (float)Asc_Height) / 8.0f));

    // if( Randd==true)
    {
        if (rw_flag == -1 || rw_flag == 0)
        {
            if (bflag == true)
            {
                idx_fact++;
                if (idx_fact > 100)
                    bflag = false;
            }
            else if (bflag == false)
            {
                idx_fact--;
                if (idx_fact < 1)
                    bflag = true;
            }
            // i=50; y_coord[i++]=50;y_coord[i++]=50;y_coord[i++]=50;y_coord[i++]=50;y_coord[i++]=50;y_coord[i++]=50;y_coord[i++]=50;y_coord[i++]=50;y_coord[i++]=50;y_coord[i++]=50;
            // i=250; y_coord[i++]=50;y_coord[i++]=50;y_coord[i++]=50;y_coord[i++]=50;y_coord[i++]=50;  //y_coord[i++]=50;y_coord[i++]=50;y_coord[i++]=50;y_coord[i++]=50;y_coord[i++]=50;

            for (i = 0; i < NUM_OF_VERTICES; i++)
            {
                rnd = rand() % 2;
                row_y[i] = (GLubyte)((y_coord[i] / fdiv[idx_fact]) + rnd);
                All_Ascan_data[i] = row_y[i];
                // ogl.vertices_position[(i * 2) + 1] = ((GLfloat)row_y[i] - 50.0f ) / 50.0f;
                // ogl.vertices_position[(i * 2) + 1] = ((GLfloat)test_y_coord3[i] - offst ) / tfd; // 50.0f;
                ogl.vertices_position[(i * 2) + 1] = ((GLfloat)row_y[i] - offst ) / tfd; // 50.0f;
                //ogl.vertices_position[(i * 2) + 1] = ((442.0f - (GLfloat)row_y[i]) * 430 ) / (442/2); // - 50.0f) / 50.0f;
            }

            if ((Record_Type_val == 0 || Record_Type_val == 1 || Record_Type_val == 3) && (rw_flag == 0))
            {
                write_data_in_bsc_file(&row_y[0]);
            }
        }
        else if (rw_flag == 1)
        {
            idx = cur_idx;
            idx = idx & 0x3FF;
            idx = idx << 8;

            for (i = 0; i < num_of_vertices; i++)
            {
                if (Dac_Bscan_flag == true)
                    ogl.vertices_position[(i * 2) + 1] = ((GLfloat)bscfiledata[idx++] - offst) / tfd;
                else if (Dac_Bscan_flag == false)
                    ogl.vertices_position[(i * 2) + 1] = ((GLfloat)row_y[i] - offst) / tfd;   // Ascan And DGS draw read from file and display to user
            }

            /*
            for (i = 0; i < num_of_vertices; i++)
            {
                if (Dac_Bscan_flag == true)
                    ogl.vertices_position[(i * 2) + 1] = ((GLfloat)bscfiledata[idx++] - 50.0f) / 50.0f;
                else if (Dac_Bscan_flag == false)
                    ogl.vertices_position[(i * 2) + 1] = ((GLfloat)row_y[i] - 50.0f) / 50.0f;   // Ascan And DGS draw read from file and display to user
            }
            */
        }

        if (Ascan_peak_flag == true)
        {
            for (i = 0; i < NUM_OF_VERTICES; i++) // Copy Ascan data fro referance
            {
                All_Ascan_peak[(i * 2) + 1] = ogl.vertices_position[(i * 2) + 1];
            }
            Ascan_peak_flag = false;
        }
        
        return;

        if (video_val == 1) // IF Video Mode is Filled selected
        {
            for (i = NUM_OF_VERTICES; i > 0; i--)
            {
                tmpgl = ogl.vertices_position[(i * 2) + 1]; // Get Value of y
                dst = (i * 6) + 1;
                ogl.vertices_position[dst] = tmpgl;
                ogl.vertices_position[dst + 2] = -1; // tmpgl;
                ogl.vertices_position[dst + 4] = tmpgl;
            }
        }
        if (video_val == 2) // IF Video Dynamic is selected
        {
            for (i = 0; i < NUM_OF_VERTICES; i++)
            {
                if (row_y[i] > Asc_Max[i])
                {
                    Asc_Max[i] = row_y[i];
                } // row_y[i] = (GLubyte)temp;
                ogl.vertices_position[(i * 2) + 1 + 1536] = (((GLfloat)Asc_Max[i] - 50.0f) / 50.0f);
            }
        }

        return;
    }

    if (Rectify_v == 3) // IF RF Is selected
    {
        for (i = 0; i < NUM_OF_VERTICES; i++)
        {
            temp = rx_cmd[i];
            if (temp > 127)
            {
                temp = temp - 127;
            }
            else
            {
                temp = temp + 127;
            }
            temp = temp / 2;
            temp = temp - 14;
            if (temp > 100)
            {
                temp = 100;
            }
            if (temp < 0)
            {
                temp = 0;
            }
            row_y[i] = (GLubyte)temp;
            ogl.vertices_position[(i * 2) + 1] = ((GLfloat)row_y[i] - offst) / tfd;
            // ogl.vertices_position[(i * 2) + 1] = ((GLfloat)row_y[i] - 50.0f) / 50.0f;
        }
    }
    else
    { // For +ve. -ve and Envelop
        for (i = 0; i < NUM_OF_VERTICES; i++)
        {
            temp = rx_cmd[i];
            // temp=temp-127;
            if (temp < 0)
            {
                temp = 0;
            };
            if (temp > 100)
            {
                temp = 100;
            }
            row_y[i] = (GLubyte)temp;
            ogl.vertices_position[(i * 2) + 1] = ((GLfloat)row_y[i] - offst) / tfd;
            // ogl.vertices_position[(i * 2) + 1] = ((GLfloat)row_y[i] - 50.0f) / 50.0f;
        }
    }	
}

// OpenGL uninitialization
void ogl_uninitialization(guint signal_id)
{
    if (Ascan_cr)
    {
        cairo_destroy(Ascan_cr);
        Ascan_cr = 0;
    }
    if (Ascan_surface)
    {
        cairo_surface_destroy(Ascan_surface);
        Ascan_surface = 0;
    }
    if (Ascan_pixbuf)
    {
        g_object_unref(Ascan_pixbuf);
        Ascan_pixbuf = NULL;
    }

    if (ogl.cr)
    {
        cairo_destroy(ogl.cr);
        ogl.cr = 0;
    }
    if (ogl.surface)
    {
        cairo_surface_destroy(ogl.surface);
        ogl.surface = 0;
    }
    if (signal_id != 0)
    {
        g_source_remove(signal_id);
        signal_id = 0;
    }
    if (ogl.textureColorbuffer)
    {
        glDeleteTextures(1, &ogl.textureColorbuffer);
        ogl.textureColorbuffer = 0;
    }
    if (ogl.framebuffer)
    {
        glDeleteFramebuffers(1, &ogl.framebuffer);
        ogl.framebuffer = 0;
    }
    if (ogl.vbo_color)
    {
        glDeleteBuffers(1, &ogl.vbo_color);
        ogl.vbo_color = 0;
    }
    if (ogl.vbo_position)
    {
        glDeleteBuffers(1, &ogl.vbo_position);
        ogl.vbo_position = 0;
    }
    if (ogl.ebo)
    {
        glDeleteBuffers(1, &ogl.ebo);
        ogl.ebo = 0;
    }
    if (ogl.vao)
    {
        glDeleteVertexArrays(1, &ogl.vao);
        ogl.vao = 0;
    }
    if (ogl.shader_program_object)
    {
        GLsizei shaderCount;
        GLsizei shaderNumber;

        glUseProgram(ogl.shader_program_object);
        // Ask Program How Many Shaders are Attached to you
        glGetProgramiv(ogl.shader_program_object, GL_ATTACHED_SHADERS, &shaderCount);
        GLuint *pShaders = (GLuint *)malloc(sizeof(GLuint) * shaderCount);
        if (pShaders)
        {
            glGetAttachedShaders(ogl.shader_program_object, shaderCount, &shaderCount, pShaders);
            for (shaderNumber = 0; shaderNumber < shaderCount; shaderNumber++)
            {
                glDetachShader(ogl.shader_program_object, pShaders[shaderNumber]);
                glDeleteShader(pShaders[shaderNumber]);
                pShaders[shaderNumber] = 0;
            }
            free(pShaders);
        }
        glDeleteProgram(ogl.shader_program_object);
        ogl.shader_program_object = 0;
        glUseProgram(0);
    }

    if (ogl.egl_display != EGL_NO_DISPLAY)
    {
        eglMakeCurrent(ogl.egl_display, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
    }
    if (ogl.egl_context != EGL_NO_CONTEXT)
    {
        eglDestroyContext(ogl.egl_display, ogl.egl_context);
        ogl.egl_context = EGL_NO_CONTEXT;
    }
    if (ogl.egl_surface != EGL_NO_SURFACE)
    {
        eglDestroySurface(ogl.egl_display, ogl.egl_surface);
        ogl.egl_surface = EGL_NO_SURFACE;
    }
    if (ogl.egl_window)
    {
        wl_egl_window_destroy(ogl.egl_window);
        ogl.egl_window = NULL;
    }
    if (ogl.egl_display != EGL_NO_DISPLAY)
    {
        eglTerminate(ogl.egl_display);
        ogl.egl_display = EGL_NO_DISPLAY;
    }
    if (ogl.subsurface)
    {
        wl_subsurface_destroy(ogl.subsurface);
        ogl.subsurface = NULL;
    }
    if (ogl.region)
    {
        wl_region_destroy(ogl.region);
        ogl.region = NULL;
    }
    if (ogl.cw_surface)
    {
        wl_surface_destroy(ogl.cw_surface);
        ogl.cw_surface = NULL;
    }
    if (ogl.w_display)
    {
        wl_display_disconnect(ogl.w_display);
        ogl.w_display = 0;
    }
}

//****************************************************************************************
void Cal_vertices() // Re Calculate Verteces for Dynamic/Filled/Envelop
{
    int temp, dst;
    GLint idx = 0, rnd, i = 0;
    GLfloat tmpgl;

    if (video_val == 1) // IF Video Mode is Filled selected
    {
        for (i = 0; i < 768; i++) // Re Calculate Value for X for Filled Echo Pattern
        {
            tmpgl = i;
            tmpgl = (tmpgl - 384.0f) / 384.0f;
            ogl.vertices_position[(i * 2) + 0] = tmpgl;
        }
        // Set Color value of Vertices
        for (i = 0; i < 1536; i++) // Verteces  Color 1536  NUM_OF_VERTICES*2 *3 =1536 for Filled Echo Pattern
        {
            ogl.vertices_color[(i * 3) + 0] = Red[Asc_Clr_val];
            ogl.vertices_color[(i * 3) + 1] = Green[Asc_Clr_val];
            ogl.vertices_color[(i * 3) + 2] = Blue[Asc_Clr_val];
        }
        // ColorLeg_refresh();     // If COlor Leg is ON then fill accordingly
    }
    else // If Video Mode is Envelop or Dynamic selected
    {
        for (i = 0; i < NUM_OF_VERTICES; i++)
        {
            ogl.vertices_position[(i * 2) + 0] = ((GLfloat)i - 128.0f) / 128.0f; // On x-axis 255 positions co-ordinates
            ogl.vertices_position[(i * 2) + 512] = ogl.vertices_position[(i * 2) + 0];
            ogl.vertices_position[(i * 2) + 1024] = ogl.vertices_position[(i * 2) + 0];
            ogl.vertices_position[(i * 2) + 1536] = ogl.vertices_position[(i * 2) + 0];
        }
        //// Set Color value of Vertices
        for (i = 0; i < NUM_OF_VERTICES; i++) // Verteces  Color for Envelop A-Scan
        {
            ogl.vertices_color[(i * 3) + 0] = Red[Asc_Clr_val];
            ogl.vertices_color[(i * 3) + 1] = Green[Asc_Clr_val];
            ogl.vertices_color[(i * 3) + 2] = Blue[Asc_Clr_val];
        }
        for (i = 768; i < 1024; i++) // Verteces  Color For Dynamic A-Scan
        {
            ogl.vertices_color[(i * 3) + 0] = Red[Asc_Clr_val + 1];
            ogl.vertices_color[(i * 3) + 1] = Green[Asc_Clr_val + 1];
            ogl.vertices_color[(i * 3) + 2] = Blue[Asc_Clr_val + 1];
        }
    }
    ColorLeg_refresh(); // If COlor Leg is ON then fill accordingly
    Color_update = true;
}

// Custom data fill in framebuffer
void gl_clear_color_background_data(int width, int height)
{
    gdouble factor;
    int i = 0, j;

    // Set background color
    if (Asc_Clr_val > 7)
    {
        cairo_set_source_rgb(ogl.cr, 1.0, 1.0, 1.0);
    } 
    else
    {
        cairo_set_source_rgb(ogl.cr, 0.0, 0.0, 0.0);
        //cairo_set_source_rgb(ogl.cr, 0.0, 0.2, 0.0);
    } 
    // Paint background
    cairo_paint(ogl.cr);

    // Set line width
    cairo_set_line_width(ogl.cr, 1.0);
    // Set line color
    cairo_set_source_rgb(ogl.cr, Grid_b[Asc_Clr_val], Grid_g[Asc_Clr_val], Grid_r[Asc_Clr_val]);

    Grid_Draw_f(ogl.cr); // Draw Grid as per selection

   // Set font color
    if (Asc_Clr_val > 7)
    {
        cairo_set_source_rgb(ogl.cr, 1.0, 0.0, 0.0);
    }
    else
    {
        cairo_set_source_rgb(ogl.cr, 0.0, 1.0, 1.0);
    }

    // Choice font
    cairo_select_font_face(ogl.cr, "Courier", CAIRO_FONT_SLANT_NORMAL, CAIRO_FONT_WEIGHT_BOLD);
    // Set font size
    cairo_set_font_size(ogl.cr, 20);
    // Set font position
    cairo_move_to(ogl.cr, 620, 38 + 5); // (cr, 620, 38);
    // Draw text
    // if (recall_read == 1)
    // {
    //     cairo_show_text(ogl.cr, "FREEZE");
    // }
    // else
    // {
    //     cairo_show_text(ogl.cr, " ");
    // }
    //cairo_show_text(ogl.cr, "3.14");
    cairo_stroke(ogl.cr);

    // Set doted pattern size
    // cairo_set_dash(cr, dash_value, 0, 0.0);
    cairo_set_dash(ogl.cr, 0, 0, 0.0);

    if (val_ary[GATE1_PERA] == 1 || val_ary[GATE1_PERA] == 2 || val_ary[GATE1_PERA] == 8) // Draw GateA Line
    {
        draw_gate1(ogl.cr);
    }

    if (val_ary[GATE2_PERA] == 1 || val_ary[GATE2_PERA] == 2) // Draw Gateb Line
    {
        draw_gate2(ogl.cr);
    }
    
    if (gdac_flag == true) // Draw DAC Curve  
    {
        draw_curvedac(ogl.cr);
    }

    if (val_ary[BEAM_PROF_PERA] == 2)
    {
        Draw_beamprofile(ogl.cr);
    } // If Beam Profile is ON then Draw it

    // Draw Weld Shape and Object Shape
    if (splite_win_flg == 0 && val_ary[WELD_PROF_PERA] == 2) // Weld Profile Display is ON then Draw on LCD Screen
    {
        // Draw shape
        cairo_set_source_rgb(ogl.cr, 0.0, 1.0, 1.0); // Select Color for Test Object Shape
        select_shape(ogl.cr, &ogl_shape[1]);

        cairo_set_source_rgb(ogl.cr, 0.0, 1.0, 0.0); // Select Color for Profile
        if (val_ary[OBJ_SHAPE_PERA] == 0)
        {
            // Draw profiler and sound path
            select_shape(ogl.cr, &profiler_cntr_line[0]);
            select_shape(ogl.cr, &ogl_profiler[1]);
            cairo_set_source_rgb(ogl.cr, 1.0, 1.0, 1.0); // Select Color for UT Beam
            select_shape(ogl.cr, &ogl_probe[0]);
            cairo_set_source_rgb(ogl.cr, 1.0, 0.0, 1.0); // Select Color for UT Beam rays
            select_shape(ogl.cr, &ogl_rays[1]);
        }
        else if (val_ary[OBJ_SHAPE_PERA] == 1 || val_ary[OBJ_SHAPE_PERA] == 2)
        {
            // Draw profiler and sound path
            select_shape(ogl.cr, &profiler_cntr_line[0]);
            select_shape(ogl.cr, &ogl_profiler[1]);
            cairo_set_source_rgb(ogl.cr, 1.0, 1.0, 1.0); // Select Color for UT Beam
            select_shape(ogl.cr, &ogl_probe[20]);
            cairo_set_source_rgb(ogl.cr, 1.0, 0.0, 1.0); // Select Color for UT Beam rays
            select_shape(ogl.cr, &ogl_rays[11]);
        }
        else if (val_ary[OBJ_SHAPE_PERA] == 3)
        {
            // Draw profiler and sound path
            select_shape(ogl.cr, &profiler_cntr_line[0]);
            select_shape(ogl.cr, &ogl_profiler[1]);
            cairo_set_source_rgb(ogl.cr, 1.0, 1.0, 1.0); // Select Color for UT Beam
            select_shape(ogl.cr, &ogl_probe[20]);
            cairo_set_source_rgb(ogl.cr, 1.0, 0.0, 1.0); // Select Color for UT Beam rays
            select_shape(ogl.cr, &ogl_rays[11]);
        }
    }

    // Copy data
    ogl.data_ptr = cairo_image_surface_get_data(ogl.surface);

    glBindTexture(GL_TEXTURE_2D, ogl.textureColorbuffer);
    glTexSubImage2D(GL_TEXTURE_2D   /* Target */,
                    0               /* Level */,
                    0               /* X */,
                    0               /* Y */,
                    width           /* Width */,
                    height          /* height */,
                    GL_RGBA         /* format */,
                    GL_UNSIGNED_BYTE /* Type */,
                    (GLubyte*)ogl.data_ptr /* Actual data pointer */);
    glBindTexture(GL_TEXTURE_2D, 0);

    // cairo_surface_write_to_png(ogl.surface, "outputImages/1.png");
}

// Wayland function definition
void get_server_referance(GdkDisplay *gdk_display)
{
    // Create native display
    ogl.w_display = gdk_wayland_display_get_wl_display(gdk_display);
    if (ogl.w_display == NULL)
        printf("wl_display_connect() function is failed.\n");

    struct wl_registry *registry = wl_display_get_registry(ogl.w_display);
    wl_registry_add_listener(registry, &registry_listener, NULL);

    wl_display_dispatch(ogl.w_display);
    wl_display_roundtrip(ogl.w_display);

    if (ogl.compositor == NULL || ogl.subcompositor == NULL)
        printf("Can't find compositer or subcompositor.\n");
}

void global_registry_handler(void *data, struct wl_registry *registry, uint32_t id, const char *interface, uint32_t version)
{
    if (strcmp(interface, "wl_compositor") == 0)
        ogl.compositor = (struct wl_compositor *)wl_registry_bind(registry, id, &wl_compositor_interface, 1);
    else if (!strcmp(interface, "wl_subcompositor"))
        ogl.subcompositor = (struct wl_subcompositor *)wl_registry_bind(registry, id, &wl_subcompositor_interface, 1);
}

void global_registry_remover(void *data, struct wl_registry *registry, uint32_t id)
{
    // printf("Got a registry losing event for %d.\n", id);
}

void partial_uninitialize(void)
{
    if (ogl.cr)
    {
        cairo_destroy(ogl.cr);
        ogl.cr = 0;
    }
    if (ogl.surface)
    {
        cairo_surface_destroy(ogl.surface);
        ogl.surface = 0;
    }
    if (ogl.textureColorbuffer)
    {
        glDeleteTextures(1, &ogl.textureColorbuffer);
        ogl.textureColorbuffer = 0;
    }
    if (ogl.framebuffer)
    {
        glDeleteFramebuffers(1, &ogl.framebuffer);
        ogl.framebuffer = 0;
    }
    if (ogl.vbo_position)
    {
        glDeleteBuffers(1, &ogl.vbo_position);
        ogl.vbo_position = 0;
    }
    if (ogl.vbo_color)
    {
        glDeleteBuffers(1, &ogl.vbo_color);
        ogl.vbo_color = 0;
    }
    if (ogl.ebo)
    {
        glDeleteBuffers(1, &ogl.ebo);
        ogl.ebo = 0;
    }
    if (ogl.vao)
    {
        glDeleteVertexArrays(1, &ogl.vao);
        ogl.vao = 0;
    }

    if (ogl.shader_program_object)
    {
        GLsizei shaderCount;
        GLsizei shaderNumber;

        glUseProgram(ogl.shader_program_object);
        // Ask Program How Many Shaders are Attached to you
        glGetProgramiv(ogl.shader_program_object, GL_ATTACHED_SHADERS, &shaderCount);
        GLuint *pShaders = (GLuint *)malloc(sizeof(GLuint) * shaderCount);
        if (pShaders)
        {
            glGetAttachedShaders(ogl.shader_program_object, shaderCount, &shaderCount, pShaders);
            for (shaderNumber = 0; shaderNumber < shaderCount; shaderNumber++)
            {
                glDetachShader(ogl.shader_program_object, pShaders[shaderNumber]);
                glDeleteShader(pShaders[shaderNumber]);
                pShaders[shaderNumber] = 0;
            }
            free(pShaders);
        }
        glDeleteProgram(ogl.shader_program_object);
        ogl.shader_program_object = 0;
        glUseProgram(0);
    }

    if (ogl.egl_display != EGL_NO_DISPLAY)
    {
        eglMakeCurrent(ogl.egl_display, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
    }
    if (ogl.egl_surface != EGL_NO_SURFACE)
    {
        eglDestroySurface(ogl.egl_display, ogl.egl_surface);
        ogl.egl_surface = EGL_NO_SURFACE;
    }
    if (ogl.egl_window)
    {
        wl_egl_window_destroy(ogl.egl_window);
        ogl.egl_window = NULL;
    }
    if (ogl.subsurface)
    {
        wl_subsurface_destroy(ogl.subsurface);
        ogl.subsurface = NULL;
    }
}

void recreate_surface(int width, int height, int xx_pos, int yy_pos) 
{
    int y_pos = 0;

    if (splite_win_flg == 0)
        y_pos = yy_pos;
    else if (splite_win_flg == 1 || splite_win_flg == 2)
        y_pos = yy_pos + (height_sh / 2);

    ogl.subsurface = wl_subcompositor_get_subsurface(ogl.subcompositor, ogl.cw_surface, ogl.pw_surface);
    wl_subsurface_set_desync(ogl.subsurface);
    wl_subsurface_set_position(ogl.subsurface, xx_pos, y_pos);
    ogl.egl_window = wl_egl_window_create(ogl.cw_surface, width, height);

    // Create a surface
    ogl.egl_surface = eglCreateWindowSurface(ogl.egl_display, ogl.egl_config, ogl.egl_window, NULL);
    if (ogl.egl_surface == EGL_NO_CONTEXT)
        g_print("eglCreateWindowSurface() function is failed.\n");

    // Make the context current
    if (!eglMakeCurrent(ogl.egl_display, ogl.egl_surface, ogl.egl_surface, ogl.egl_context))
        g_print("eglMakeCurrent() function is failed.\n");
 
    ogl_initialization(width, height);
}

void clr_grd_data_function(void)
{
    gint i = 0, j = 0;
    gint c_red = 255, c_green = 255, c_blue = 255;
    float k = 0.0f;

    k = 1.0f;
    for (i = 0; i < 120; i++)
    {
        fdiv[i] = k;
    }
    for (i = 0; i < 10; i++)
    {
        k = k + 0.1f;
        fdiv[i] = k;
    }
    for (i = 10; i < 20; i++)
    {
        k = k + 0.2f;
        fdiv[i] = k;
    }
    for (i = 20; i < 30; i++)
    {
        k = k + 0.4f;
        fdiv[i] = k;
    }
    for (i = 30; i < 40; i++)
    {
        k = k + 0.8f;
        fdiv[i] = k;
    }
    for (i = 40; i < 50; i++)
    {
        k = k + 1.6f;
        fdiv[i] = k;
    }
    for (i = 50; i < 110; i++)
    {
        fdiv[i] = k;
    }
}

//*****************************************************************************
//****************************  Refresh Draw Grid  ****************************
//*****************************************************************************

void Grid_Draw_f(cairo_t *cr) // Draw Grid as per selection
{                             
    int i = 0, j, k;
    int st, dps, p;
    const gdouble dash_valueg[] = {4.0, 4.0}; 
    int len1g = sizeof(dash_valueg) / sizeof(dash_valueg[0]);

    if (Asc_Clr_val > 7)
    {
        cairo_set_line_width(cr, 2.0);
    }
    else
    {
        cairo_set_line_width(cr, 1.5);
        //cairo_set_line_width(cr, 1.0);
    }

    if (Grid_v == 0) // Grid Style 10 x 10
    {
        cairo_set_dash(cr, dash_valueg, len1g, 0.0); // cairo_set_dash(cr, dash_valueg, len1g, 0.0); draw dash dot line
        for (i = 0; i < 11; i++)                     // 11  // Horizontal lines    // cairo_set_dash(cr, dash_valueg, 0, 0.0); will Draw Solid line
        {
            j = (i * Asc_Height) / 10;
            j = j + Voff;
            for (p = 0; p < 50; p++)
            {
                dps = ((Asc_Width * p) / 50) - 1;
                cairo_move_to(cr, dps, j);     // start point of line x1, y1 Co-Ordinates
                cairo_line_to(cr, dps + 2, j); // end point of line x2, y2 Co-Ordinates
            }
        }

        for (i = 1; i < 11; i++) // Vertical lines
        {
            j = (i * Asc_Width) / 10;
            for (p = 0; p < 50; p++)
            {
                dps = (((Asc_Height * p) / 50)) + Voff; //  dps= (((Asc_Height*p)/50)-1)+Voff;
                cairo_move_to(cr, j, dps);
                cairo_line_to(cr, j, dps + 2);
            }
        }
        cairo_stroke(cr);
    }

    if (Grid_v == 1) // Grid Style 10 x 10 Dimond
    {
        cairo_set_dash(cr, 0, 0, 0.0); // Draw Solid line
        for (i = 0; i < 11; i++)       // Horizontal lines
        {
            j = (i * Asc_Height) / 10;
            j = j + Voff;
            for (k = 1; k < 11; k++)
            {
                st = ((k * Asc_Width) / 10) - 5;
                cairo_move_to(cr, st, j);      // start point of line x1, y1 Co-Ordinates
                cairo_line_to(cr, st + 10, j); // end point of line x2, y2 Co-Ordinates
            }
        }

        for (i = 0; i < 11; i++) // Vertical lines
        {
            j = (i * Asc_Width) / 10;
            for (k = 0; k < 11; k++)
            {
                st = ((k * Asc_Height) / 10) - 5;
                st = st + Voff;
                cairo_move_to(cr, j, st);
                cairo_line_to(cr, j, st + 10);
            }
        }
        cairo_stroke(cr);
    }

    if (Grid_v == 2) // Grid Style 5 x 5
    {
        cairo_set_dash(cr, dash_valueg, len1g, 0.0); // Draw Dash Dot line
        for (i = 0; i < 11; i++)                     // Horizontal lines
        {
            j = (i * Asc_Height) / 5;
            j = j + Voff;
            for (p = 0; p < 50; p++)
            {
                dps = ((Asc_Width * p) / 50) - 1;
                cairo_move_to(cr, dps, j);     // start point of line x1, y1 Co-Ordinates
                cairo_line_to(cr, dps + 2, j); // end point of line x2, y2 Co-Ordinates
            }
        }

        for (i = 1; i < 11; i++) // Vertical lines
        {
            j = (i * Asc_Width) / 5;
            for (p = 0; p < 50; p++)
            {
                dps = (((Asc_Height * p) / 50) - 1) + Voff;
                cairo_move_to(cr, j, dps);
                cairo_line_to(cr, j, dps + 2);
            }
        }
        cairo_stroke(cr);
    }

    if (Grid_v == 3) // Grid Style 5 x 5 Dimond
    {
        cairo_set_dash(cr, dash_valueg, 0, 0.0); // Draw Solid line
        for (i = 0; i < 6; i++)                  // Horizontal lines
        {
            j = (i * Asc_Height) / 5;
            j = j + Voff;
            for (k = 1; k < 6; k++)
            {
                st = ((k * Asc_Width) / 5) - 5;
                cairo_move_to(cr, st, j);      // start point of line x1, y1 Co-Ordinates
                cairo_line_to(cr, st + 10, j); // end point of line x2, y2 Co-Ordinates
            }
        }

        for (i = 0; i < 6; i++) // Vertical lines
        {
            j = (i * Asc_Width) / 5;
            for (k = 0; k < 6; k++)
            {
                st = ((k * Asc_Height) / 5) - 5;
                st = st + Voff;
                cairo_move_to(cr, j, st);
                cairo_line_to(cr, j, st + 10);
            }
        }
        cairo_stroke(cr);
    }

    if (Grid_v == 4) // Grid Style Thickness Leg
    {
        cairo_set_dash(cr, dash_valueg, len1g, 0.0); // Draw Das Dot Line
        for (i = 0; i < 11; i++)                     // Horizontal lines
        {
            j = (i * Asc_Height) / 5;
            j = j + Voff;
            cairo_move_to(cr, 0, j);         // start point of line x1, y1 Co-Ordinates
            cairo_line_to(cr, Asc_Width, j); // end point of line x2, y2 Co-Ordinates
        }
        if (Clr_leg_width < 5)
        {
            Clr_leg_width = Asc_Width;
        }
        for (i = Clr_leg_sta; i < Asc_Width; i = i + Clr_leg_width) // Vertical lines
        {                                                           // j= (i*Asc_Width)/5;
            for (p = 0; p < 50; p++)
            {
                dps = (((Asc_Height * p) / 50) - 1) + Voff;
                cairo_move_to(cr, i, dps);
                cairo_line_to(cr, i, dps + 2);
            }
        }
        cairo_stroke(cr);
    }
    else
    {
    } // No Grid
}

//*****************************************************************************
//****************************  Refresh Draw Grid  ****************************
//*****************************************************************************
void draw_gate1(cairo_t *cr) // Draw GateA Line
{
    int rng, dly;
    rng = val_ary[RANGE_PERA];
    dly = val_ary[DELAY_PERA] / 10;
    // val_ary[3] = 0;  //  Delay_rv=val_ary[DELAY_PERA];
    s_x11 = val_ary[GSTA1_PERA] - dly;
    s_x11 = (s_x11 * Asc_Width * 10) / rng;
    if (s_x11 > Asc_Width)
    {
        s_x11 = Asc_Width;
    }
    s_x22 = val_ary[GEND1_PERA] - dly;
    s_x22 = (s_x22 * Asc_Width * 10) / rng;
    if (s_x22 > Asc_Width)
    {
        s_x22 = Asc_Width;
    }
    s_y11 = val_ary[GTHE1_PERA];

    if (Rectify_v == 3) // RF
    {
        s_y11 = (s_y11 * Asc_Height) / 200;
        s_y11 = ((Asc_Height / 2) - s_y11) + Voff;
    }
    else
    {
        s_y11 = s_y11 * Asc_Height / 100;
        s_y11 = (Asc_Height - s_y11) + Voff;
    }

    cairo_set_line_width(cr, 2.0);
    // cairo_set_source_rgb(cr, 1.0, 0.0, 0.0);
    cairo_set_source_rgba(cr, 0.0, 0.0, 1.0, 1.0);
    cairo_move_to(cr, s_x11, s_y11);
    cairo_line_to(cr, (s_x11 - 10), (s_y11 - 10));
    cairo_stroke(cr);
    cairo_move_to(cr, s_x11, s_y11);
    cairo_line_to(cr, (s_x11 - 10), (s_y11 + 10));
    cairo_stroke(cr);
    cairo_move_to(cr, s_x11, s_y11); // Start point of line x1, y1 Co-Ordinates
    cairo_line_to(cr, s_x22, s_y11); // End point of line x2, y2 Co-Ordinates
    cairo_stroke(cr);
    cairo_move_to(cr, s_x22, s_y11);
    cairo_line_to(cr, (s_x22 + 10), (s_y11 - 10));
    cairo_stroke(cr);
    cairo_move_to(cr, s_x22, s_y11);
    cairo_line_to(cr, (s_x22 + 10), (s_y11 + 10));
    cairo_stroke(cr);
}

void draw_gate2(cairo_t *cr) // Draw Gateb Line
{
    int rng;
    int dly = val_ary[DELAY_PERA] / 10;
    rng = val_ary[RANGE_PERA];
    // val_ary[3] = 0;
    s_x11 = val_ary[GSTA2_PERA] - dly;
    s_x11 = (s_x11 * Asc_Width * 10) / rng;
    if (s_x11 > Asc_Width)
    {
        s_x11 = Asc_Width;
    }
    s_x22 = val_ary[GEND2_PERA] - dly;
    s_x22 = (s_x22 * Asc_Width * 10) / rng;
    if (s_x22 > Asc_Width)
    {
        s_x22 = Asc_Width;
    }
    s_y11 = val_ary[GTHE2_PERA]; // s_y11=s_y11*Asc_Height/100;s_y11=Asc_Height-s_y11;

    if (Rectify_v == 3) // RF
    {
        s_y11 = (s_y11 * Asc_Height) / 200;
        s_y11 = ((Asc_Height / 2) - s_y11) + Voff;
    }
    else
    {
        s_y11 = s_y11 * Asc_Height / 100;
        s_y11 = (Asc_Height - s_y11) + Voff;
    }

    cairo_set_line_width(cr, 2.0);
    cairo_set_source_rgba(cr, 0.0, 1.0, 1.0, 1.0);
    cairo_move_to(cr, s_x11, s_y11);
    cairo_line_to(cr, (s_x11), (s_y11 - 10)); // create endlines at both ends of the line
    cairo_stroke(cr);
    cairo_move_to(cr, s_x11, s_y11);
    cairo_line_to(cr, (s_x11), (s_y11 + 10)); // create endlines at both ends of the line
    cairo_stroke(cr);
    cairo_move_to(cr, s_x11, s_y11);
    cairo_line_to(cr, s_x22, s_y11);
    cairo_stroke(cr);
    cairo_move_to(cr, s_x22, s_y11);
    cairo_line_to(cr, (s_x22), (s_y11 - 10));
    cairo_stroke(cr);
    cairo_move_to(cr, s_x22, s_y11);
    cairo_line_to(cr, (s_x22), (s_y11 + 10));
    cairo_stroke(cr);
}

//*****************************************************************************************************
void draw_curvedac(cairo_t* cr) // Draw DAC Curve
{
	int x1, x2, y1, y2;
	cairo_set_source_rgba(cr, 1.0, 1.0, 0.0, 1.0); // pntArray_DAC

	for (i = 0; i < 250; i++)
	{
        if (dgs_fromfile == 0) // FOR DGS or DAC DRAWN DIRECTLY without Reading from file
		{
			y1 = pntArray_DACM[i].y;
			y2 = pntArray_DACM[i + 1].y;
			if (y1 > -1 && y2 > -1) // If Y value / Height > 5 then Drwa curve else drawing is not required
			{  
				s_y11 = y1 + Voff; // s_y11 = height_sh - ((y1 * height_sh) / 100);
				s_y22 = y2 + Voff; // s_y22 = height_sh - ((y2 * height_sh) / 100);
                dgs_pnt[i] = s_y11;
				dgs_pnt[i + 1] = s_y22;
				x1 = pntArray_DACM[i].x;
				x2 = pntArray_DACM[i + 1].x;  //Asc_Width
				x1 = (x1 * Asc_Width) / 250;  /// x1 = (x1 * width_sh) / 250;
				x2 = (x2 * Asc_Width) / 250;  //x2 = (x2 * width_sh) / 250;               
				cairo_move_to(cr, x1, s_y11);
				cairo_line_to(cr, x2, s_y22);
			}
		}
		else if (dgs_fromfile == 1) // FOR DGS DRAWN FROM READ FILE
		{
			y1 = dgs_pnt[i];
			y2 = dgs_pnt[i + 1];            
			if (i < 235 && (y1 > -1 && y2 > -1)) // if (y1 > 5 && y2 > 5)
			{
                s_y11 = y1; // + Voff; // s_y11 = height_sh - ((y1 * height_sh) / 100);
                s_y22 = y2; // + Voff;
				x1 = pntArray_DACM[i].x;
				x2 = pntArray_DACM[i + 1].x;
				x1 = (x1 * Asc_Width) / 250; // x1 = (x1 * width_sh) / 250;
				x2 = (x2 * Asc_Width) / 250; // x2 = (x2 * width_sh) / 250;
				cairo_move_to(cr, x1, s_y11);
				cairo_line_to(cr, x2, s_y22);
			}
		}
		/* else
		{
			y1 = pntArray_DACM[i].y;
			y2 = pntArray_DACM[i + 1].y;
			if (y1 > -1 && y2 > -1) // if (y1 > 5 && y2 > 5) // If Y value / Height > 5 then Draw curve else drawing is not required
			{
				s_y11 = y1 + Voff; // s_y11 = height_sh - ((y1 * height_sh) / 100);
				s_y22 = y2 + Voff; // s_y22 = height_sh - ((y2 * height_sh) / 100);
				dgs_pnt[i] = s_y11;
				dgs_pnt[i + 1] = s_y22;
				x1 = pntArray_DACM[i].x;
				x2 = pntArray_DACM[i + 1].x;
				x1 = (x1 * Asc_Width) / 250; // x1 = (x1 * width_sh) / 250;
				x2 = (x2 * Asc_Width) / 250; // x2 = (x2 * width_sh) / 250;
				cairo_move_to(cr, x1, s_y11);
				cairo_line_to(cr, x2, s_y22);
			}
		}*/
	}
	cairo_stroke(cr);

    /****************************************************************************************************************************/
    /*************************  MULTIPLE DAC and DGS CURVE ACCORDING TO DAC CURVE DB VALUE DRAWN BELOW  *********************************/
    /****************************************************************************************************************************/

    if (Dac_crv_dB > 0)
    {
        cairo_set_source_rgba(cr, 0.0, 0.0, 1.0, 1.0);
        for (i = 0; i < 250; i++) // FOR DAC 1 Positive curve
        {
            y1 = pntArray_DAC1P[i].y;
            y2 = pntArray_DAC1P[i + 1].y;
            if (y1 > -1 && y2 > -1) // if (y1 > 5 && y2 > 5) // If Y value / Height > 5 then Drwa curve else drawing is not required
            {
                s_y11 = y1 + Voff; // s_y11 = height_sh - ((y1 * height_sh) / 100);
                s_y22 = y2 + Voff; // s_y22 = height_sh - ((y2 * height_sh) / 100);
                x1 = pntArray_DAC1P[i].x;
                x2 = pntArray_DAC1P[i + 1].x;
                x1 = (x1 * Asc_Width) / 250;    // x1 = (x1 * width_sh) / 250;
                x2 = (x2 * Asc_Width) / 250;    // x2 = (x2 * width_sh) / 250;
                cairo_move_to(cr, x1, s_y11);
                cairo_line_to(cr, x2, s_y22);
            }
        }
        cairo_stroke(cr);
       
        for (i = 0; i < 250; i++) // FOR DAC 2 Positive curve
        {
            y1 = pntArray_DAC2P[i].y;
            y2 = pntArray_DAC2P[i + 1].y;
            if (y1 > -1 && y2 > -1) // if (y1 > 5 && y2 > 5) // If Y value / Height > 5 then Drwa curve else drawing is not required
            {
                s_y11 = y1 + Voff; // s_y11 = height_sh - ((y1 * height_sh) / 100);
                s_y22 = y2 + Voff; // s_y22 = height_sh - ((y2 * height_sh) / 100);
                x1 = pntArray_DAC2P[i].x;
                x2 = pntArray_DAC2P[i + 1].x;
                x1 = (x1 * Asc_Width) / 250;    // x1 = (x1 * width_sh) / 250;
                x2 = (x2 * Asc_Width) / 250;    // x2 = (x2 * width_sh) / 250;
                cairo_move_to(cr, x1, s_y11);
                cairo_line_to(cr, x2, s_y22);
            }
        }
        cairo_stroke(cr);

        cairo_set_source_rgba(cr, 0.0, 1.0, 1.0, 1.0);
        for (i = 0; i < 250; i++) // FOR DAC 1 Negative curve
        {
            y1 = pntArray_DAC1N[i].y;
            y2 = pntArray_DAC1N[i + 1].y;
            if (y1 > -1 && y2 > -1) // if (y1 > 5 && y2 > 5) // If Y value / Height > 5 then Drwa curve else drawing is not required
            {
                s_y11 = y1 + Voff; // s_y11 = height_sh - ((y1 * height_sh) / 100);
                s_y22 = y2 + Voff; // s_y22 = height_sh - ((y2 * height_sh) / 100);
                x1 = pntArray_DAC1N[i].x;
                x2 = pntArray_DAC1N[i + 1].x;
                x1 = (x1 * Asc_Width) / 250;    // x1 = (x1 * width_sh) / 250;
                x2 = (x2 * Asc_Width) / 250;    // x2 = (x2 * width_sh) / 250;
                cairo_move_to(cr, x1, s_y11);
                cairo_line_to(cr, x2, s_y22);
            }
        }
        cairo_stroke(cr);

        for (i = 0; i < 250; i++) // FOR DAC 2 Negative curve
        {
            y1 = pntArray_DAC2N[i].y;
            y2 = pntArray_DAC2N[i + 1].y;
            if (y1 > -1 && y2 > -1) // if (y1 > 5 && y2 > 5) // If Y value / Height > 5 then Drwa curve else drawing is not required
            {
                s_y11 = y1 + Voff; // s_y11 = height_sh - ((y1 * height_sh) / 100);
                s_y22 = y2 + Voff; // s_y22 = height_sh - ((y2 * height_sh) / 100);
                x1 = pntArray_DAC2N[i].x;
                x2 = pntArray_DAC2N[i + 1].x;
                x1 = (x1 * Asc_Width) / 250;    // x1 = (x1 * width_sh) / 250;
                x2 = (x2 * Asc_Width) / 250;    // x2 = (x2 * width_sh) / 250;
                cairo_move_to(cr, x1, s_y11);
                cairo_line_to(cr, x2, s_y22);
             }
        }
        cairo_stroke(cr);                                                                                   
    }
}

//*****************************************************************************************************
//*****************************************************************************************************
void Draw_beamprofile(cairo_t *cr) // If Beam Profile is ON then Draw it
{
    int x3, y1, y2, wd; // ,y3;
    x3 = Asc_Width;
    y1 = 20;
    y2 = 20;
    wd = 20;
    // Prb_div_Ht
    cairo_set_source_rgba(cr, 1.0, 1.0, 0.0, 1.0); //
    y1 = 200 + wd;
    y2 = 200 - wd;
    cairo_move_to(cr, 0, y1);
    cairo_line_to(cr, Prb_Near_field, y1);
    cairo_line_to(cr, x3, y1 + Prb_div_Ht); // cairo_stroke(cr);
    // cairo_set_source_rgba(cr, 1.0, 0.0, 0.0, 1.0);        //
    // cairo_move_to(cr, Prb_Near_field, y1); 	cairo_line_to(cr, x3, y1+Prb_div_Ht);
    // cairo_stroke(cr);
    // cairo_set_source_rgba(cr, 1.0, 1.0, 0.0, 1.0);        //
    cairo_move_to(cr, 0, y2);
    cairo_line_to(cr, Prb_Near_field, y2);
    cairo_line_to(cr, x3, y2 - Prb_div_Ht); // cairo_stroke(cr);
    // cairo_set_source_rgba(cr, 1.0, 0.0, 0.0, 1.0);        //
    cairo_move_to(cr, Prb_Near_field, y1);
    cairo_line_to(cr, Prb_Near_field, y2);

    cairo_stroke(cr);
}

//*****************************************************************************************************
//*****************************************************************************************************
void draw_curvedac_test(cairo_t *cr) // Draw DAC Curve
{
    cairo_set_source_rgba(cr, 1.0, 1.0, 0.0, 1.0);
    for (i = 0; i < NUM_OF_VERTICES; i++)
    {
        s_x11 = (i * width_sh) / 250;
        s_x22 = ((i + 1) * width_sh) / 250;

        if (c_y[i] > 5 && c_y[i + 1] > 5) // If Y value / Height > 5 then Drwa curve else drawing is not required
        {
            s_y11 = height_sh - ((c_y[i] * height_sh) / 100);
            s_y22 = height_sh - ((c_y[i + 1] * height_sh) / 100);
            // cairo_set_source_rgba(cr, 1.0, 1.0, 0.0, 1.0);
            // cairo_set_source_rgb(cr, 1.0, 0.0, 0.0);
            cairo_move_to(cr, s_x11, s_y11);
            cairo_line_to(cr, s_x22, s_y22);
            // cairo_stroke(cr);
        }
    }
    cairo_stroke(cr);
}
//*****************************************************************************************************