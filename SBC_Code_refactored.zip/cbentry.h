﻿#define cal_windoww 745//320 // size for keypad window
#define cal_windowh 200

#define txtview_width 156
#define txtview_height 30

#define keybtn_width 45 // Keypad Button width and height
#define spckeybtn_width 99 // Space button width
#define keybtn_hgth 40
#define nxtprvbtn_width 35 // Nxt and Prv btn width
#define keybtnok_width 62 // Ok and backspace(clear) button width

GtkWidget *p_window, *p_v_box, *p_h_box, *p_h1_box, *p_h2_box, *p_h3_box, *p_entry, *p_h4_box;
GtkWidget *textview, *scrolledwindow;
GtkTextBuffer *buffer;
GtkWidget *btn7, *btn8, *btn9, *btnclr, *btn4, *btn5, *btn6, *btnoff, *btn1, *btn2, *btn3, *btncls, *btn0, *btnem, *btnok, *btndot, *btnmn, *btnspc, *btnnxt;
GtkWidget* btnA, * btnB, * btnC, * btnD, * btnE, * btnF, * btnG, * btnH, * btnI, * btnJ, * btnK, * btnL, * btnM, * btnN, * btnO, * btnP, * btnQ, * btnR, * btnS;
GtkWidget* btnT, * btnU, * btnV, * btnW, * btnX, * btnY, * btnZ, *btndiv, *btnmlp, * btnpls, *btncmma, * btnsmcol, *btnbrc1, *btnbrc2, *btnequal, *btnmprv, * btnmnxt;
GtkWidget* btnescp, * btncarat, *btntab, *btnopnbrck, *btnclsbrck, *btnline, *btncaps, *btnquote, *btnshift,*btnup,*btndwn;
GtkTextIter start, end;
GtkWidget* cblabel_dv[50];

char arry_cal[60][10] = {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "ON", ".", "OK", "CLR", "CLS","A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z","-"," ","/","*","+",";",",","(",")","="};
char smarry_cal[60][10] = { "a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z" };
int cbtn_idx, btn_c;
char calc_values[14][10];
char *text_keypad;
bool flag = true;
char range_txt[40];
int nxt_count = 0;
int caps = 0;
int key_shift = 0;

char spl_char[50][10];

char spl_char_1[10], spl_char_2[10], spl_char_3[10], spl_char_4[10], spl_char_5[10], spl_char_6[10];
char spl_char_7[10], spl_char_8[10], spl_char_9[10], spl_char_10[10], spl_char_11[10], spl_char_12[10];

void OnCBtn0();
void OnCBtn1();
void OnCBtn2();
void OnCBtn3();
void OnCBtn4();
void OnCBtn5();
void OnCBtn6();
void OnCBtn7();
void OnCBtn8();
void OnCBtn9();
void OnCBtnClr();
void OnCBtnCps();
void OnCBtnOk();
void OnCBtnA();
void OnCBtnB();
void OnCBtnC();
void OnCBtnD();
void OnCBtnE();
void OnCBtnF();
void OnCBtnG();
void OnCBtnH();
void OnCBtnI();
void OnCBtnJ();
void OnCBtnK();
void OnCBtnL();
void OnCBtnM();
void OnCBtnN();
void OnCBtnO();
void OnCBtnP();
void OnCBtnQ();
void OnCBtnR();
void OnCBtnS();
void OnCBtnT();
void OnCBtnU();
void OnCBtnV();
void OnCBtnW();
void OnCBtnX();
void OnCBtnY();
void OnCBtnZ();
void OnCBtndot();
void OnCBtnmn();
void OnCBtnspc();
void OnCBtnpls();
void OnCBtndiv();
void OnCBtnmul();
void OnCBtnsmmcol();
void OnCBtncmma();
void OnCBtnbrc1();
void OnCBtnbrc2();
void OnCBtnequal();
void OnCBtnmprv();
void OnCBtnmnxt();
void Cmn_Cbtn(int btn_c);
void Note_ln_fkeypad();
void UpVarTraverse();
static void insert_text(GtkTextBuffer* buffer, GtkTextIter* location, gchar* text, gint len, gpointer user_data);
void OnCBtnShft();
void OnCBtnOpnBrckt();
void OnCBtnClsBrckt();
void OnCBtnLine();
void OnCBtnTab();
void OnCBtnQuote();
void OnCBtnCarat();
void OnCBtnEscp();

void cb_create_entry()
{
	key_flag = true;

	p_window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	//gtk_window_set_decorated(GTK_WINDOW(p_window), true);
	p_v_box = gtk_box_new(GTK_ORIENTATION_VERTICAL, 0);
	gtk_container_add(GTK_CONTAINER(p_window), p_v_box);
	gtk_window_set_title(GTK_WINDOW(p_window), "KEYPAD");
	gtk_window_set_deletable(GTK_WINDOW(p_window), false); // To remove close symbol from the title bar
	//gtk_window_set_deletable(GTK_WINDOW(p_window), true); 
	//gtk_window_set_position(GTK_WINDOW(p_window), GTK_WIN_POS_CENTER);
	gtk_window_set_resizable(GTK_WINDOW(p_window), false);
	gtk_window_set_default_size(GTK_WINDOW(p_window), cal_windoww, cal_windowh);
	gtk_window_set_transient_for(GTK_WINDOW(p_window), GTK_WINDOW(window));


	textview = gtk_text_view_new();
	buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(textview));
	gtk_widget_set_size_request(textview, txtview_width, txtview_height);
	// gtk_text_view_set_wrap_mode (GTK_TEXT_VIEW(textview),GTK_WRAP_CHAR);
	//scrolledwindow = gtk_scrolled_window_new(NULL, NULL);
	//gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(scrolledwindow), GTK_POLICY_ALWAYS, GTK_POLICY_NEVER);
	//gtk_container_add(GTK_CONTAINER(scrolledwindow), textview);
	// gtk_widget_set_size_request(scrolledwindow, txtview_width, 5);
	gtk_box_pack_start(GTK_BOX(p_v_box), textview, false, false, 1);
	// gtk_box_pack_start(GTK_BOX(p_v_box), textview, false, false, 1);
	gtk_widget_set_name(GTK_WIDGET(textview), "TextView");

	sprintf(spl_char[0], "%s", "~");
	sprintf(spl_char[1], "%s", "\n     `");
	strcat(spl_char[0], spl_char[1]);

	sprintf(spl_char[2], "%s", "!");
	sprintf(spl_char[3], "%s", "\n      1");
	strcat(spl_char[2], spl_char[3]);

	sprintf(spl_char[4], "%s", "@");
	sprintf(spl_char[5], "%s", "\n      2");
	strcat(spl_char[4], spl_char[5]);

	sprintf(spl_char[6], "%s", "#");
	sprintf(spl_char[7], "%s", "\n      3");
	strcat(spl_char[6], spl_char[7]);
	
	sprintf(spl_char[8], "%s", "$");
	sprintf(spl_char[9], "%s", "\n      4");
	strcat(spl_char[8], spl_char[9]);

	sprintf(spl_char[10], "%s", "%");
	sprintf(spl_char[11], "%s", "\n     5");
	strcat(spl_char[10], spl_char[11]);

	sprintf(spl_char[12], "%s", "^");
	sprintf(spl_char[13], "%s", "\n     6");
	strcat(spl_char[12], spl_char[13]);

	sprintf(spl_char[14], "%s", "&");
	sprintf(spl_char[15], "%s", "\n     7");
	strcat(spl_char[14], spl_char[15]);

	sprintf(spl_char[16], "%s", "*");
	sprintf(spl_char[17], "%s", "\n     8");
	strcat(spl_char[16], spl_char[17]);

	sprintf(spl_char[18], "%s", "(");
	sprintf(spl_char[19], "%s", "\n     9");
	strcat(spl_char[18], spl_char[19]);

	sprintf(spl_char[20], "%s", ")");
	sprintf(spl_char[21], "%s", "\n     0");
	strcat(spl_char[20], spl_char[21]);

	sprintf(spl_char[22], "%s", "-");
	sprintf(spl_char[23], "%s", "\n     _");
	strcat(spl_char[22], spl_char[23]);

	sprintf(spl_char[24], "%s", "+");
	sprintf(spl_char[25], "%s", "\n     =");
	strcat(spl_char[24], spl_char[25]);

	p_h_box = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
	gtk_box_pack_start(GTK_BOX(p_v_box), p_h_box, false, false, 1);

	btnescp = gtk_button_new_with_label("Cls");
	btncarat = gtk_button_new();
	cblabel_dv[0] = gtk_label_new(spl_char[0]);
	gtk_container_add(GTK_CONTAINER(btncarat), cblabel_dv[0]);

	btn1 = gtk_button_new();
	cblabel_dv[1] = gtk_label_new(spl_char[2]);
	gtk_container_add(GTK_CONTAINER(btn1), cblabel_dv[1]);

	btn2 = gtk_button_new();
	cblabel_dv[2] = gtk_label_new(spl_char[4]);
	gtk_container_add(GTK_CONTAINER(btn2), cblabel_dv[2]);

	btn3 = gtk_button_new();
	cblabel_dv[3] = gtk_label_new(spl_char[6]);
	gtk_container_add(GTK_CONTAINER(btn3), cblabel_dv[3]);

	btn4 = gtk_button_new();
	cblabel_dv[4] = gtk_label_new(spl_char[8]);
	gtk_container_add(GTK_CONTAINER(btn4), cblabel_dv[4]);

	btn5 = gtk_button_new();
	cblabel_dv[5] = gtk_label_new(spl_char[10]);
	gtk_container_add(GTK_CONTAINER(btn5), cblabel_dv[5]);

	btn6 = gtk_button_new();
	cblabel_dv[6] = gtk_label_new(spl_char[12]);
	gtk_container_add(GTK_CONTAINER(btn6), cblabel_dv[6]);

	btn7 = gtk_button_new();
	cblabel_dv[7] = gtk_label_new(spl_char[14]);
	gtk_container_add(GTK_CONTAINER(btn7), cblabel_dv[7]);

	btn8 = gtk_button_new();
	cblabel_dv[8] = gtk_label_new(spl_char[16]);
	gtk_container_add(GTK_CONTAINER(btn8), cblabel_dv[8]);

	btn9 = gtk_button_new();
	cblabel_dv[9] = gtk_label_new(spl_char[18]);
	gtk_container_add(GTK_CONTAINER(btn9), cblabel_dv[9]);

	btn0 = gtk_button_new();
	cblabel_dv[10] = gtk_label_new(spl_char[20]);
	gtk_container_add(GTK_CONTAINER(btn0), cblabel_dv[10]);

	btnmn = gtk_button_new();
	cblabel_dv[11] = gtk_label_new(spl_char[22]);
	gtk_container_add(GTK_CONTAINER(btnmn), cblabel_dv[11]);

	btnpls = gtk_button_new();
	cblabel_dv[12] = gtk_label_new(spl_char[24]);
	gtk_container_add(GTK_CONTAINER(btnpls), cblabel_dv[12]);

	btnclr = gtk_button_new_with_label("←BK"); //← ←BK ◄┘ <̶  // BackSpace Key
	//btnclr = gtk_button_new_with_label("");

	gtk_widget_set_size_request(btnescp, keybtn_width, keybtn_hgth);
	gtk_widget_set_size_request(btncarat, keybtn_width, keybtn_hgth);
	gtk_widget_set_size_request(btn1, keybtn_width, keybtn_hgth);
	gtk_widget_set_size_request(btn2, keybtn_width, keybtn_hgth);
	gtk_widget_set_size_request(btn3, keybtn_width, keybtn_hgth);
	gtk_widget_set_size_request(btn4, keybtn_width, keybtn_hgth);
	gtk_widget_set_size_request(btn5, keybtn_width, keybtn_hgth);
	gtk_widget_set_size_request(btn6, keybtn_width, keybtn_hgth);
	gtk_widget_set_size_request(btn7, keybtn_width, keybtn_hgth);
	gtk_widget_set_size_request(btn8, keybtn_width, keybtn_hgth);
	gtk_widget_set_size_request(btn9, keybtn_width, keybtn_hgth);
	gtk_widget_set_size_request(btn0, keybtn_width, keybtn_hgth);
	gtk_widget_set_size_request(btnmn, keybtn_width, keybtn_hgth);
	gtk_widget_set_size_request(btnpls, keybtn_width, keybtn_hgth);
	gtk_widget_set_size_request(btnclr, keybtnok_width, keybtn_hgth);
	    	
	gtk_widget_set_name(GTK_WIDGET(btnescp), "calbtn7-entry");
	gtk_widget_set_name(GTK_WIDGET(btncarat), "calbtn7-entry");
	gtk_widget_set_name(GTK_WIDGET(btn1), "calbtn7-entry");
	gtk_widget_set_name(GTK_WIDGET(btn2), "calbtn7-entry");
	gtk_widget_set_name(GTK_WIDGET(btn3), "calbtn7-entry");
	gtk_widget_set_name(GTK_WIDGET(btn4), "calbtn7-entry");
	gtk_widget_set_name(GTK_WIDGET(btn5), "calbtn7-entry");
	gtk_widget_set_name(GTK_WIDGET(btn6), "calbtn7-entry");
	gtk_widget_set_name(GTK_WIDGET(btn7), "calbtn7-entry");
	gtk_widget_set_name(GTK_WIDGET(btn8), "calbtn7-entry");
	gtk_widget_set_name(GTK_WIDGET(btn9), "calbtn7-entry");
	gtk_widget_set_name(GTK_WIDGET(btn0), "calbtn7-entry");
	gtk_widget_set_name(GTK_WIDGET(btnmn), "calbtn7-entry");
	gtk_widget_set_name(GTK_WIDGET(btnpls), "calbtn7-entry");
	gtk_widget_set_name(GTK_WIDGET(btnclr), "calbtn18-entry"); // calbtnclr-entry 

	gtk_widget_set_halign(GTK_WIDGET(cblabel_dv[0]), GTK_ALIGN_START);
	gtk_widget_set_halign(GTK_WIDGET(cblabel_dv[1]), GTK_ALIGN_START);
	gtk_widget_set_halign(GTK_WIDGET(cblabel_dv[2]), GTK_ALIGN_START);
	gtk_widget_set_halign(GTK_WIDGET(cblabel_dv[3]), GTK_ALIGN_START);
	gtk_widget_set_halign(GTK_WIDGET(cblabel_dv[4]), GTK_ALIGN_START);
	gtk_widget_set_halign(GTK_WIDGET(cblabel_dv[5]), GTK_ALIGN_START);
	gtk_widget_set_halign(GTK_WIDGET(cblabel_dv[6]), GTK_ALIGN_START);
	gtk_widget_set_halign(GTK_WIDGET(cblabel_dv[7]), GTK_ALIGN_START);
	gtk_widget_set_halign(GTK_WIDGET(cblabel_dv[8]), GTK_ALIGN_START);
	gtk_widget_set_halign(GTK_WIDGET(cblabel_dv[9]), GTK_ALIGN_START);
	gtk_widget_set_halign(GTK_WIDGET(cblabel_dv[10]), GTK_ALIGN_START);
	gtk_widget_set_halign(GTK_WIDGET(cblabel_dv[11]), GTK_ALIGN_START);
	gtk_widget_set_halign(GTK_WIDGET(cblabel_dv[12]), GTK_ALIGN_START);

	gtk_box_pack_start(GTK_BOX(p_h_box), btnescp, false, false, 0);
	gtk_box_pack_start(GTK_BOX(p_h_box), btncarat, false, false, 0);
	gtk_box_pack_start(GTK_BOX(p_h_box), btn1, false, false, 0);
	gtk_box_pack_start(GTK_BOX(p_h_box), btn2, false, false, 0);
	gtk_box_pack_start(GTK_BOX(p_h_box), btn3, false, false, 0);
	gtk_box_pack_start(GTK_BOX(p_h_box), btn4, false, false, 0);
	gtk_box_pack_start(GTK_BOX(p_h_box), btn5, false, false, 0);
	gtk_box_pack_start(GTK_BOX(p_h_box), btn6, false, false, 0);
	gtk_box_pack_start(GTK_BOX(p_h_box), btn7, false, false, 0);
	gtk_box_pack_start(GTK_BOX(p_h_box), btn8, false, false, 0);
	gtk_box_pack_start(GTK_BOX(p_h_box), btn9, false, false, 0);
	gtk_box_pack_start(GTK_BOX(p_h_box), btn0, false, false, 0);
	gtk_box_pack_start(GTK_BOX(p_h_box), btnmn, false, false, 0);
	gtk_box_pack_start(GTK_BOX(p_h_box), btnpls, false, false, 0);
	gtk_box_pack_start(GTK_BOX(p_h_box), btnclr, false, false, 0);


	p_h1_box = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
	gtk_box_pack_start(GTK_BOX(p_v_box), p_h1_box, false, false, 1);

	sprintf(spl_char[26], "%s", "{");
	sprintf(spl_char[27], "%s", "\n     [");
	strcat(spl_char[26], spl_char[27]);

	sprintf(spl_char[28], "%s", "}");
	sprintf(spl_char[29], "%s", "\n     ]");
	strcat(spl_char[28], spl_char[29]);

	sprintf(spl_char[30], "%s", "|");
	sprintf(spl_char[31], "%s", "\n   \\");
	strcat(spl_char[30], spl_char[31]);

	sprintf(spl_char[40], "%s", "?");
	sprintf(spl_char[41], "%s", "\n    /");
	strcat(spl_char[40], spl_char[41]);

	btntab = gtk_button_new_with_label("Tab");
	btnQ = gtk_button_new_with_label("q");
	btnW = gtk_button_new_with_label("w");
	btnE = gtk_button_new_with_label("e");
	btnR = gtk_button_new_with_label("r");
	btnT = gtk_button_new_with_label("t");
	btnY = gtk_button_new_with_label("y");
	btnU = gtk_button_new_with_label("u");
	btnI = gtk_button_new_with_label("i");
	btnO = gtk_button_new_with_label("o");
	btnP = gtk_button_new_with_label("p");
	btnopnbrck = gtk_button_new();
	cblabel_dv[13] = gtk_label_new(spl_char[26]);
	gtk_container_add(GTK_CONTAINER(btnopnbrck), cblabel_dv[13]);
	btnclsbrck = gtk_button_new();
	cblabel_dv[14] = gtk_label_new(spl_char[28]);
	gtk_container_add(GTK_CONTAINER(btnclsbrck), cblabel_dv[14]);
	btnline = gtk_button_new();
	cblabel_dv[15] = gtk_label_new(spl_char[30]);
	gtk_container_add(GTK_CONTAINER(btnline), cblabel_dv[15]);
	/*btnok = gtk_button_new_with_label("OK");*/
	btndiv = gtk_button_new();
	cblabel_dv[20] = gtk_label_new(spl_char[40]);
	gtk_container_add(GTK_CONTAINER(btndiv), cblabel_dv[20]);

	gtk_widget_set_size_request(btntab, keybtn_width + 30, keybtn_hgth);
	gtk_widget_set_size_request(btnQ, keybtn_width, keybtn_hgth);
	gtk_widget_set_size_request(btnW, keybtn_width, keybtn_hgth);
	gtk_widget_set_size_request(btnE, keybtn_width, keybtn_hgth);
	gtk_widget_set_size_request(btnR, keybtn_width, keybtn_hgth);
	gtk_widget_set_size_request(btnT, keybtn_width, keybtn_hgth);
	gtk_widget_set_size_request(btnY, keybtn_width, keybtn_hgth);
	gtk_widget_set_size_request(btnU, keybtn_width, keybtn_hgth);
	gtk_widget_set_size_request(btnI, keybtn_width, keybtn_hgth);
	gtk_widget_set_size_request(btnO, keybtn_width, keybtn_hgth);
	gtk_widget_set_size_request(btnP, keybtn_width, keybtn_hgth);
	gtk_widget_set_size_request(btnclsbrck, keybtn_width, keybtn_hgth);
	gtk_widget_set_size_request(btnopnbrck, keybtn_width, keybtn_hgth);
	gtk_widget_set_size_request(btnline, keybtn_width, keybtn_hgth);
	gtk_widget_set_size_request(btndiv, keybtn_width, keybtn_hgth);
	/*gtk_widget_set_size_request(btnok, keybtnok_width, keybtn_hgth);*/

	gtk_widget_set_name(GTK_WIDGET(btnQ), "calbtn7-entry");
	gtk_widget_set_name(GTK_WIDGET(btnW), "calbtn7-entry");
	gtk_widget_set_name(GTK_WIDGET(btnE), "calbtn7-entry");
	gtk_widget_set_name(GTK_WIDGET(btnR), "calbtn7-entry");
	gtk_widget_set_name(GTK_WIDGET(btnT), "calbtn7-entry");
	gtk_widget_set_name(GTK_WIDGET(btnY), "calbtn7-entry");
	gtk_widget_set_name(GTK_WIDGET(btnU), "calbtn7-entry");
	gtk_widget_set_name(GTK_WIDGET(btnI), "calbtn7-entry");
	gtk_widget_set_name(GTK_WIDGET(btnO), "calbtn7-entry");
	gtk_widget_set_name(GTK_WIDGET(btnP), "calbtn7-entry");
	gtk_widget_set_name(GTK_WIDGET(btntab), "calbtn7-entry");
	gtk_widget_set_name(GTK_WIDGET(btnopnbrck), "calbtn7-entry");
	gtk_widget_set_name(GTK_WIDGET(btnclsbrck), "calbtn7-entry");
	gtk_widget_set_name(GTK_WIDGET(btnline), "calbtn7-entry");
	gtk_widget_set_name(GTK_WIDGET(btndiv), "calbtn7-entry");
	/*gtk_widget_set_name(GTK_WIDGET(btnok), "calbtn7-entry");*/

	gtk_box_pack_start(GTK_BOX(p_h1_box), btntab, false, false, 0);
	gtk_box_pack_start(GTK_BOX(p_h1_box), btnQ, false, false, 0);
	gtk_box_pack_start(GTK_BOX(p_h1_box), btnW, false, false, 0);
	gtk_box_pack_start(GTK_BOX(p_h1_box), btnE, false, false, 0);
	gtk_box_pack_start(GTK_BOX(p_h1_box), btnR, false, false, 0);
	gtk_box_pack_start(GTK_BOX(p_h1_box), btnT, false, false, 0);
	gtk_box_pack_start(GTK_BOX(p_h1_box), btnY, false, false, 0);
	gtk_box_pack_start(GTK_BOX(p_h1_box), btnU, false, false, 0);
	gtk_box_pack_start(GTK_BOX(p_h1_box), btnI, false, false, 0);
	gtk_box_pack_start(GTK_BOX(p_h1_box), btnO, false, false, 0);
	gtk_box_pack_start(GTK_BOX(p_h1_box), btnP, false, false, 0);
	gtk_box_pack_start(GTK_BOX(p_h1_box), btnopnbrck, false, false, 0);
	gtk_box_pack_start(GTK_BOX(p_h1_box), btnclsbrck, false, false, 0);
	gtk_box_pack_start(GTK_BOX(p_h1_box), btnline, false, false, 0);
	gtk_box_pack_start(GTK_BOX(p_h1_box), btndiv, false, false, 0);
	//gtk_box_pack_start(GTK_BOX(p_h1_box), btnok, false, false, 0);

	p_h2_box = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
	gtk_box_pack_start(GTK_BOX(p_v_box), p_h2_box, false, false, 1);

	sprintf(spl_char[32], "%s", ":");
	sprintf(spl_char[33], "%s", "\n   ;");
	strcat(spl_char[32], spl_char[33]);

	sprintf(spl_char[34], "%s", "\"");
	sprintf(spl_char[35], "%s", "\n   \'");
	strcat(spl_char[34], spl_char[35]);

	btncaps = gtk_button_new_with_label("Caps\nLock");
	btnA = gtk_button_new_with_label("a");
	btnS = gtk_button_new_with_label("s");
	btnD = gtk_button_new_with_label("d");
	btnF = gtk_button_new_with_label("f");
	btnG = gtk_button_new_with_label("g");
	btnH = gtk_button_new_with_label("h");
	btnJ = gtk_button_new_with_label("j");
	btnK = gtk_button_new_with_label("k");
	btnL = gtk_button_new_with_label("l");
	btnsmcol = gtk_button_new();
	cblabel_dv[16] = gtk_label_new(spl_char[32]);
	gtk_container_add(GTK_CONTAINER(btnsmcol), cblabel_dv[16]);
	btnquote = gtk_button_new();
	cblabel_dv[17] = gtk_label_new(spl_char[34]);
	gtk_container_add(GTK_CONTAINER(btnquote), cblabel_dv[17]);
	btnup = gtk_button_new_with_label("▲");
	btnspc = gtk_button_new_with_label("SPACE");

	gtk_widget_set_size_request(btnA, keybtn_width, keybtn_hgth);
	gtk_widget_set_size_request(btnS, keybtn_width, keybtn_hgth);
	gtk_widget_set_size_request(btnD, keybtn_width, keybtn_hgth);
	gtk_widget_set_size_request(btnF, keybtn_width, keybtn_hgth);
	gtk_widget_set_size_request(btnG, keybtn_width, keybtn_hgth);
	gtk_widget_set_size_request(btnH, keybtn_width, keybtn_hgth);
	gtk_widget_set_size_request(btnJ, keybtn_width, keybtn_hgth);
	gtk_widget_set_size_request(btnK, keybtn_width, keybtn_hgth);
	gtk_widget_set_size_request(btnL, keybtn_width, keybtn_hgth);
	gtk_widget_set_size_request(btncaps, keybtn_width, keybtn_hgth);
	gtk_widget_set_size_request(btnsmcol, keybtn_width, keybtn_hgth);
	gtk_widget_set_size_request(btnquote, keybtn_width, keybtn_hgth);
	gtk_widget_set_size_request(btnspc, spckeybtn_width, keybtn_hgth);
	gtk_widget_set_size_request(btnup, keybtn_width, keybtn_hgth);

	gtk_widget_set_name(GTK_WIDGET(btnA), "calbtn7-entry");
	gtk_widget_set_name(GTK_WIDGET(btnS), "calbtn7-entry");
	gtk_widget_set_name(GTK_WIDGET(btnD), "calbtn7-entry");
	gtk_widget_set_name(GTK_WIDGET(btnF), "calbtn7-entry");
	gtk_widget_set_name(GTK_WIDGET(btnG), "calbtn7-entry");
	gtk_widget_set_name(GTK_WIDGET(btnH), "calbtn7-entry");
	gtk_widget_set_name(GTK_WIDGET(btnJ), "calbtn7-entry");
	gtk_widget_set_name(GTK_WIDGET(btnK), "calbtn7-entry");
	gtk_widget_set_name(GTK_WIDGET(btnL), "calbtn7-entry");
	gtk_widget_set_name(GTK_WIDGET(btnup), "calbtn7-entry");
	gtk_widget_set_name(GTK_WIDGET(btncaps), "calbtn7-entry");
	gtk_widget_set_name(GTK_WIDGET(btnsmcol), "calbtn7-entry");
	gtk_widget_set_name(GTK_WIDGET(btnquote), "calbtn7-entry");
	gtk_widget_set_name(GTK_WIDGET(btnspc), "calbtn7-entry");

	
	gtk_box_pack_start(GTK_BOX(p_h2_box), btncaps, false, false, 0);
	gtk_box_pack_start(GTK_BOX(p_h2_box), btnA, false, false, 0);
	gtk_box_pack_start(GTK_BOX(p_h2_box), btnS, false, false, 0);
	gtk_box_pack_start(GTK_BOX(p_h2_box), btnD, false, false, 0);
	gtk_box_pack_start(GTK_BOX(p_h2_box), btnF, false, false, 0);
	gtk_box_pack_start(GTK_BOX(p_h2_box), btnG, false, false, 0);
	gtk_box_pack_start(GTK_BOX(p_h2_box), btnH, false, false, 0);
	gtk_box_pack_start(GTK_BOX(p_h2_box), btnJ, false, false, 0);
	gtk_box_pack_start(GTK_BOX(p_h2_box), btnK, false, false, 0);
	gtk_box_pack_start(GTK_BOX(p_h2_box), btnL, false, false, 0);
	gtk_box_pack_start(GTK_BOX(p_h2_box), btnsmcol, false, false, 0);
	gtk_box_pack_start(GTK_BOX(p_h2_box), btnquote, false, false, 0);
	gtk_box_pack_start(GTK_BOX(p_h2_box), btnup, false, false, 0);
	gtk_box_pack_start(GTK_BOX(p_h2_box), btnspc, false, false, 0);

	p_h3_box = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
	gtk_box_pack_start(GTK_BOX(p_v_box), p_h3_box, false, false, 1);

	sprintf(spl_char[36], "%s", "<");
	sprintf(spl_char[37], "%s", "\n   ,");
	strcat(spl_char[36], spl_char[37]);

	sprintf(spl_char[38], "%s", ">");
	sprintf(spl_char[39], "%s", "\n    .");
	strcat(spl_char[38], spl_char[39]);

	btnshift = gtk_button_new_with_label("SHIFT");
	btnZ = gtk_button_new_with_label("z");
	btnX = gtk_button_new_with_label("x");
	btnC = gtk_button_new_with_label("c");
	btnV = gtk_button_new_with_label("v");
	btnB = gtk_button_new_with_label("b");
	btnN = gtk_button_new_with_label("n");
	btnM = gtk_button_new_with_label("m");
	btncmma = gtk_button_new();
	cblabel_dv[18] = gtk_label_new(spl_char[36]);
	gtk_container_add(GTK_CONTAINER(btncmma), cblabel_dv[18]);
	btndot = gtk_button_new();
	cblabel_dv[19] = gtk_label_new(spl_char[38]);
	gtk_container_add(GTK_CONTAINER(btndot), cblabel_dv[19]);
	//btnnxt = gtk_button_new_with_label("");
	btnnxt = gtk_button_new_with_label("◄┘");  //◄┘   ENETR KEY
	btnmprv = gtk_button_new_with_label("◄");
	btnmnxt = gtk_button_new_with_label("►");
	btndwn = gtk_button_new_with_label("▼");

	gtk_widget_set_size_request(btnshift, keybtn_width, keybtn_hgth);
	gtk_widget_set_size_request(btnZ, keybtn_width, keybtn_hgth);
	gtk_widget_set_size_request(btnX, keybtn_width, keybtn_hgth);
	gtk_widget_set_size_request(btnC, keybtn_width, keybtn_hgth);
	gtk_widget_set_size_request(btnV, keybtn_width, keybtn_hgth);
	gtk_widget_set_size_request(btnB, keybtn_width, keybtn_hgth);
	gtk_widget_set_size_request(btnN, keybtn_width, keybtn_hgth);
	gtk_widget_set_size_request(btnM, keybtn_width, keybtn_hgth);
	gtk_widget_set_size_request(btncmma, keybtn_width, keybtn_hgth);
	gtk_widget_set_size_request(btndot, keybtn_width, keybtn_hgth);
	gtk_widget_set_size_request(btnnxt, keybtn_width, keybtn_hgth);
	gtk_widget_set_size_request(btnmprv, keybtn_width, keybtn_hgth);
	gtk_widget_set_size_request(btndwn, keybtn_width, keybtn_hgth);
	gtk_widget_set_size_request(btnmnxt, keybtn_width, keybtn_hgth);


	gtk_widget_set_name(GTK_WIDGET(btnshift), "calbtnshftoff-entry");
	gtk_widget_set_name(GTK_WIDGET(btnZ), "calbtn7-entry");
	gtk_widget_set_name(GTK_WIDGET(btnX), "calbtn7-entry");
	gtk_widget_set_name(GTK_WIDGET(btnC), "calbtn7-entry");
	gtk_widget_set_name(GTK_WIDGET(btnV), "calbtn7-entry");
	gtk_widget_set_name(GTK_WIDGET(btnB), "calbtn7-entry");
	gtk_widget_set_name(GTK_WIDGET(btnN), "calbtn7-entry");
	gtk_widget_set_name(GTK_WIDGET(btnM), "calbtn7-entry");
	gtk_widget_set_name(GTK_WIDGET(btncmma), "calbtn7-entry");
	gtk_widget_set_name(GTK_WIDGET(btndot), "calbtn7-entry");
	//gtk_widget_set_name(GTK_WIDGET(btnnxt), "calbtnnxt-entry");
	gtk_widget_set_name(GTK_WIDGET(btnnxt), "calbtn17-entry");
	gtk_widget_set_name(GTK_WIDGET(btnmprv), "calbtn7-entry");
	gtk_widget_set_name(GTK_WIDGET(btndwn), "calbtn7-entry");
	gtk_widget_set_name(GTK_WIDGET(btnmnxt), "calbtn7-entry");

	gtk_box_pack_start(GTK_BOX(p_h3_box), btnshift, false, false, 0);
	gtk_box_pack_start(GTK_BOX(p_h3_box), btnZ, false, false, 0);
	gtk_box_pack_start(GTK_BOX(p_h3_box), btnX, false, false, 0);
	gtk_box_pack_start(GTK_BOX(p_h3_box), btnC, false, false, 0);
	gtk_box_pack_start(GTK_BOX(p_h3_box), btnV, false, false, 0);
	gtk_box_pack_start(GTK_BOX(p_h3_box), btnB, false, false, 0);
	gtk_box_pack_start(GTK_BOX(p_h3_box), btnN, false, false, 0);
	gtk_box_pack_start(GTK_BOX(p_h3_box), btnM, false, false, 0);
	gtk_box_pack_start(GTK_BOX(p_h3_box), btncmma, false, false, 0);
	gtk_box_pack_start(GTK_BOX(p_h3_box), btndot, false, false, 0);
	gtk_box_pack_start(GTK_BOX(p_h3_box), btnnxt, false, false, 0);
	gtk_box_pack_start(GTK_BOX(p_h3_box), btnmprv, false, false, 0);
	gtk_box_pack_start(GTK_BOX(p_h3_box), btndwn, false, false, 0);
	gtk_box_pack_start(GTK_BOX(p_h3_box), btnmnxt, false, false, 0);

	//p_h4_box = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
	//gtk_box_pack_start(GTK_BOX(p_v_box), p_h4_box, false, false, 1);

	g_signal_connect(btn0, "clicked", G_CALLBACK(OnCBtn0), NULL);
	g_signal_connect(btn1, "clicked", G_CALLBACK(OnCBtn1), NULL);
	g_signal_connect(btn2, "clicked", G_CALLBACK(OnCBtn2), NULL);
	g_signal_connect(btn3, "clicked", G_CALLBACK(OnCBtn3), NULL);
	g_signal_connect(btn4, "clicked", G_CALLBACK(OnCBtn4), NULL);
	g_signal_connect(btn5, "clicked", G_CALLBACK(OnCBtn5), NULL);
	g_signal_connect(btn6, "clicked", G_CALLBACK(OnCBtn6), NULL);
	g_signal_connect(btn7, "clicked", G_CALLBACK(OnCBtn7), NULL);
	g_signal_connect(btn8, "clicked", G_CALLBACK(OnCBtn8), NULL);
	g_signal_connect(btn9, "clicked", G_CALLBACK(OnCBtn9), NULL);
	g_signal_connect(btnclr, "clicked", G_CALLBACK(OnCBtnClr), NULL);
	//g_signal_connect(btnok, "clicked", G_CALLBACK(OnCBtnOk), NULL);
	g_signal_connect(btnnxt, "clicked", G_CALLBACK(OnCBtnOk), NULL); // Enter value to respective variable
	g_signal_connect(btncaps, "clicked", G_CALLBACK(OnCBtnCps), NULL);
	g_signal_connect(btndot, "clicked", G_CALLBACK(OnCBtndot), NULL);
	g_signal_connect(btnA, "clicked", G_CALLBACK(OnCBtnA), NULL);
	g_signal_connect(btnB, "clicked", G_CALLBACK(OnCBtnB), NULL);
	g_signal_connect(btnC, "clicked", G_CALLBACK(OnCBtnC), NULL);
	g_signal_connect(btnD, "clicked", G_CALLBACK(OnCBtnD), NULL);
	g_signal_connect(btnE, "clicked", G_CALLBACK(OnCBtnE), NULL);
	g_signal_connect(btnF, "clicked", G_CALLBACK(OnCBtnF), NULL);
	g_signal_connect(btnG, "clicked", G_CALLBACK(OnCBtnG), NULL);
	g_signal_connect(btnH, "clicked", G_CALLBACK(OnCBtnH), NULL);
	g_signal_connect(btnI, "clicked", G_CALLBACK(OnCBtnI), NULL);
	g_signal_connect(btnJ, "clicked", G_CALLBACK(OnCBtnJ), NULL);
	g_signal_connect(btnK, "clicked", G_CALLBACK(OnCBtnK), NULL);
	g_signal_connect(btnL, "clicked", G_CALLBACK(OnCBtnL), NULL);
	g_signal_connect(btnM, "clicked", G_CALLBACK(OnCBtnM), NULL);
	g_signal_connect(btnN, "clicked", G_CALLBACK(OnCBtnN), NULL);
	g_signal_connect(btnO, "clicked", G_CALLBACK(OnCBtnO), NULL);
	g_signal_connect(btnP, "clicked", G_CALLBACK(OnCBtnP), NULL);
	g_signal_connect(btnQ, "clicked", G_CALLBACK(OnCBtnQ), NULL);
	g_signal_connect(btnR, "clicked", G_CALLBACK(OnCBtnR), NULL);
	g_signal_connect(btnS, "clicked", G_CALLBACK(OnCBtnS), NULL);
	g_signal_connect(btnT, "clicked", G_CALLBACK(OnCBtnT), NULL);
	g_signal_connect(btnU, "clicked", G_CALLBACK(OnCBtnU), NULL);
	g_signal_connect(btnV, "clicked", G_CALLBACK(OnCBtnV), NULL);
	g_signal_connect(btnW, "clicked", G_CALLBACK(OnCBtnW), NULL);
	g_signal_connect(btnX, "clicked", G_CALLBACK(OnCBtnX), NULL);
	g_signal_connect(btnY, "clicked", G_CALLBACK(OnCBtnY), NULL);
	g_signal_connect(btnZ, "clicked", G_CALLBACK(OnCBtnZ), NULL);
	g_signal_connect(btnmn, "clicked", G_CALLBACK(OnCBtnmn), NULL);
	//g_signal_connect(btnnxt, "clicked", G_CALLBACK(Note_ln_fkeypad), NULL); btndwn
	g_signal_connect(btndwn, "clicked", G_CALLBACK(Note_ln_fkeypad), NULL); // 
	g_signal_connect(btnup, "clicked", G_CALLBACK(UpVarTraverse), NULL);
	g_signal_connect(btnspc, "clicked", G_CALLBACK(OnCBtnspc), NULL);
	g_signal_connect(btndiv, "clicked", G_CALLBACK(OnCBtndiv), NULL);
	//g_signal_connect(btnmlp, "clicked", G_CALLBACK(OnCBtnmul), NULL);
	g_signal_connect(btnpls, "clicked", G_CALLBACK(OnCBtnpls), NULL);
	g_signal_connect(btnsmcol, "clicked", G_CALLBACK(OnCBtnsmmcol), NULL);
	g_signal_connect(btncmma, "clicked", G_CALLBACK(OnCBtncmma), NULL);
	g_signal_connect(btnshift, "clicked", G_CALLBACK(OnCBtnShft), NULL);
	//g_signal_connect(btnbrc2, "clicked", G_CALLBACK(OnCBtnbrc2), NULL);
	//g_signal_connect(btnequal, "clicked", G_CALLBACK(OnCBtnequal), NULL);
	g_signal_connect(btnmprv, "clicked", G_CALLBACK(OnCBtnmprv), NULL);
	g_signal_connect(btnmnxt, "clicked", G_CALLBACK(OnCBtnmnxt), NULL);
	g_signal_connect(btnopnbrck, "clicked", G_CALLBACK(OnCBtnOpnBrckt), NULL);
	g_signal_connect(btnclsbrck, "clicked", G_CALLBACK(OnCBtnClsBrckt), NULL);
	g_signal_connect(btnline, "clicked", G_CALLBACK(OnCBtnLine), NULL);
	g_signal_connect(btntab, "clicked", G_CALLBACK(OnCBtnTab), NULL);
	g_signal_connect(btnquote, "clicked", G_CALLBACK(OnCBtnQuote), NULL); 
	g_signal_connect(btncarat, "clicked", G_CALLBACK(OnCBtnCarat), NULL); 
	g_signal_connect(btnescp, "clicked", G_CALLBACK(OnCBtnEscp), NULL); // FOR CLOSE THE KEYPAD WINDOW
	g_signal_connect_after(buffer, "insert-text", G_CALLBACK(insert_text), NULL); 

	gtk_widget_show_all(p_window);
}

void OnCBtn0()
{

	if (key_shift == 1)
		gtk_text_buffer_insert_at_cursor(buffer, ")", 1);

	if (key_shift == 0)
		gtk_text_buffer_insert_at_cursor(buffer, arry_cal[0], 1);
}

void OnCBtn1()
{
	if (key_shift == 1)
		gtk_text_buffer_insert_at_cursor(buffer, "!", 1);

	if (key_shift == 0)
		gtk_text_buffer_insert_at_cursor(buffer, arry_cal[1], 1);
	//Note_ln_f(btn_c);
}

void OnCBtn2()
{
	if (key_shift == 1)
		gtk_text_buffer_insert_at_cursor(buffer, "@", 1);

	if (key_shift == 0)
		gtk_text_buffer_insert_at_cursor(buffer, arry_cal[2], 1);
}

void OnCBtn3()
{
	if (key_shift == 1)
		gtk_text_buffer_insert_at_cursor(buffer, "#", 1);

	if (key_shift == 0)
		gtk_text_buffer_insert_at_cursor(buffer, arry_cal[3], 1);
}

void OnCBtn4()
{
	if (key_shift == 1)
		gtk_text_buffer_insert_at_cursor(buffer, "$", 1);

	if (key_shift == 0)
		gtk_text_buffer_insert_at_cursor(buffer, arry_cal[4], 1);
}

void OnCBtn5()
{
	if (key_shift == 1)
		gtk_text_buffer_insert_at_cursor(buffer, "%", 1);

	if (key_shift == 0)
		gtk_text_buffer_insert_at_cursor(buffer, arry_cal[5], 1);
}

void OnCBtn6()
{
	if (key_shift == 1)
		gtk_text_buffer_insert_at_cursor(buffer, "^", 1);

	if (key_shift == 0)
		gtk_text_buffer_insert_at_cursor(buffer, arry_cal[6], 1);
}

void OnCBtn7()
{
	if (key_shift == 1)
		gtk_text_buffer_insert_at_cursor(buffer, "&", 1);

	if (key_shift == 0)
		gtk_text_buffer_insert_at_cursor(buffer, arry_cal[7], 1);
}

void OnCBtn8()
{
	if (key_shift == 1)
		gtk_text_buffer_insert_at_cursor(buffer, "*", 1);

	if (key_shift == 0)
		gtk_text_buffer_insert_at_cursor(buffer, arry_cal[8], 1);
}

void OnCBtn9()
{
	if (key_shift == 1)
		gtk_text_buffer_insert_at_cursor(buffer, "(", 1);

	if (key_shift == 0)
		gtk_text_buffer_insert_at_cursor(buffer, arry_cal[9], 1);
}

void OnCBtnClr() // Clear buffer 
{
	gtk_text_buffer_set_text(buffer, "", 0);

	//cbtn_idx = 10;
	//btn_c = cbtn_idx;
	//Cmn_Cbtn(btn_c);
	//gtk_text_buffer_get_start_iter(buffer, &start);
	//gtk_text_buffer_get_end_iter(buffer, &end);
	//gtk_text_buffer_backspace(buffer, &end, true, true);
    //gtk_text_buffer_delete(buffer, &start, &end);
}

void OnCBtnCps() // Caps lock on or off
{
	if (capslock_flag == true)
	{
		caps = 0;
		//gtk_button_set_label(GTK_BUTTON(btncls), "CP");
		gtk_widget_set_name(GTK_WIDGET(btncaps), "calbtn7-entry");
		gtk_button_set_label(GTK_BUTTON(btnA), "a");
		gtk_button_set_label(GTK_BUTTON(btnB), "b");
		gtk_button_set_label(GTK_BUTTON(btnC), "c");
		gtk_button_set_label(GTK_BUTTON(btnD), "d");
		gtk_button_set_label(GTK_BUTTON(btnE), "e");
		gtk_button_set_label(GTK_BUTTON(btnF), "f");
		gtk_button_set_label(GTK_BUTTON(btnG), "g");
		gtk_button_set_label(GTK_BUTTON(btnH), "h");
		gtk_button_set_label(GTK_BUTTON(btnI), "i");
		gtk_button_set_label(GTK_BUTTON(btnJ), "j");
		gtk_button_set_label(GTK_BUTTON(btnK), "k");
		gtk_button_set_label(GTK_BUTTON(btnL), "l");
		gtk_button_set_label(GTK_BUTTON(btnM), "m");
		gtk_button_set_label(GTK_BUTTON(btnN), "n");
		gtk_button_set_label(GTK_BUTTON(btnO), "o");
		gtk_button_set_label(GTK_BUTTON(btnP), "p");
		gtk_button_set_label(GTK_BUTTON(btnQ), "q");
		gtk_button_set_label(GTK_BUTTON(btnR), "r");
		gtk_button_set_label(GTK_BUTTON(btnS), "s");
		gtk_button_set_label(GTK_BUTTON(btnT), "t");
		gtk_button_set_label(GTK_BUTTON(btnU), "u");
		gtk_button_set_label(GTK_BUTTON(btnV), "v");
		gtk_button_set_label(GTK_BUTTON(btnW), "w");
		gtk_button_set_label(GTK_BUTTON(btnX), "x");
		gtk_button_set_label(GTK_BUTTON(btnY), "y");
		gtk_button_set_label(GTK_BUTTON(btnZ), "z");
		capslock_flag = false;
	}

	else if (capslock_flag == false)
	{
		caps = 1;
		//gtk_button_set_label(GTK_BUTTON(btncls),"SM");
		gtk_widget_set_name(GTK_WIDGET(btncaps), "calbtn8-entry");
		gtk_button_set_label(GTK_BUTTON(btnA), "A");
		gtk_button_set_label(GTK_BUTTON(btnB), "B");
		gtk_button_set_label(GTK_BUTTON(btnC), "C");
		gtk_button_set_label(GTK_BUTTON(btnD), "D");
		gtk_button_set_label(GTK_BUTTON(btnE), "E");
		gtk_button_set_label(GTK_BUTTON(btnF), "F");
		gtk_button_set_label(GTK_BUTTON(btnG), "G");
		gtk_button_set_label(GTK_BUTTON(btnH), "H");
		gtk_button_set_label(GTK_BUTTON(btnI), "I");
		gtk_button_set_label(GTK_BUTTON(btnJ), "J");
		gtk_button_set_label(GTK_BUTTON(btnK), "K");
		gtk_button_set_label(GTK_BUTTON(btnL), "L");
		gtk_button_set_label(GTK_BUTTON(btnM), "M");
		gtk_button_set_label(GTK_BUTTON(btnN), "N");
		gtk_button_set_label(GTK_BUTTON(btnO), "O");
		gtk_button_set_label(GTK_BUTTON(btnP), "P");
		gtk_button_set_label(GTK_BUTTON(btnQ), "Q");
		gtk_button_set_label(GTK_BUTTON(btnR), "R");
		gtk_button_set_label(GTK_BUTTON(btnS), "S");
		gtk_button_set_label(GTK_BUTTON(btnT), "T");
		gtk_button_set_label(GTK_BUTTON(btnU), "U");
		gtk_button_set_label(GTK_BUTTON(btnV), "V");
		gtk_button_set_label(GTK_BUTTON(btnW), "W");
		gtk_button_set_label(GTK_BUTTON(btnX), "X");
		gtk_button_set_label(GTK_BUTTON(btnY), "Y");
		gtk_button_set_label(GTK_BUTTON(btnZ), "Z");
		capslock_flag = true;
	}
}

void OnCBtndot() // . function
{
	if (key_shift == 1)
		gtk_text_buffer_insert_at_cursor(buffer, ">", 1);

	if (key_shift == 0)
		gtk_text_buffer_insert_at_cursor(buffer, arry_cal[11], 1);
}

void OnCBtnA()
{
	if (caps == 1)
	{
		gtk_text_buffer_insert_at_cursor(buffer, arry_cal[15], 1);
	}
	else
	{
		gtk_text_buffer_insert_at_cursor(buffer, smarry_cal[0], 1);
	}
}

void OnCBtnB()
{
	if (caps == 1)
		gtk_text_buffer_insert_at_cursor(buffer, arry_cal[16], 1);

	else
		gtk_text_buffer_insert_at_cursor(buffer, smarry_cal[1], 1);
}

void OnCBtnC()
{
	if (caps == 1)
		gtk_text_buffer_insert_at_cursor(buffer, arry_cal[17], 1);

	else
		gtk_text_buffer_insert_at_cursor(buffer, smarry_cal[2], 1);
}

void OnCBtnD()
{
	if (caps == 1)
		gtk_text_buffer_insert_at_cursor(buffer, arry_cal[18], 1);

	else
		gtk_text_buffer_insert_at_cursor(buffer, smarry_cal[3], 1);
}

void OnCBtnE()
{
	if (caps == 1)
		gtk_text_buffer_insert_at_cursor(buffer, arry_cal[19], 1);

	else
		gtk_text_buffer_insert_at_cursor(buffer, smarry_cal[4], 1);
}

void OnCBtnF()
{
	if (caps == 1)
		gtk_text_buffer_insert_at_cursor(buffer, arry_cal[20], 1);

	else
		gtk_text_buffer_insert_at_cursor(buffer, smarry_cal[5], 1);
}

void OnCBtnG()
{
	if (caps == 1)
		gtk_text_buffer_insert_at_cursor(buffer, arry_cal[21], 1);

	else
		gtk_text_buffer_insert_at_cursor(buffer, smarry_cal[6], 1);
}

void OnCBtnH()
{
	if (caps == 1)
		gtk_text_buffer_insert_at_cursor(buffer, arry_cal[22], 1);

	else
		gtk_text_buffer_insert_at_cursor(buffer, smarry_cal[7], 1);
}

void OnCBtnI()
{
	if (caps == 1)
		gtk_text_buffer_insert_at_cursor(buffer, arry_cal[23], 1);

	else
		gtk_text_buffer_insert_at_cursor(buffer, smarry_cal[8], 1);
}

void OnCBtnJ()
{
	if (caps == 1)
		gtk_text_buffer_insert_at_cursor(buffer, arry_cal[24], 1);

	else
		gtk_text_buffer_insert_at_cursor(buffer, smarry_cal[9], 1);
}

void OnCBtnK()
{
	if (caps == 1)
		gtk_text_buffer_insert_at_cursor(buffer, arry_cal[25], 1);

	else
		gtk_text_buffer_insert_at_cursor(buffer, smarry_cal[10], 1);
}

void OnCBtnL()
{
	if (caps == 1)
		gtk_text_buffer_insert_at_cursor(buffer, arry_cal[26], 1);

	else
		gtk_text_buffer_insert_at_cursor(buffer, smarry_cal[11], 1);
}

void OnCBtnM()
{
	if (caps == 1)
		gtk_text_buffer_insert_at_cursor(buffer, arry_cal[27], 1);

	else
		gtk_text_buffer_insert_at_cursor(buffer, smarry_cal[12], 1);
}

void OnCBtnN()
{
	if (caps == 1)
		gtk_text_buffer_insert_at_cursor(buffer, arry_cal[28], 1);

	else
		gtk_text_buffer_insert_at_cursor(buffer, smarry_cal[13], 1);
}

void OnCBtnO()
{
	if (caps == 1)
		gtk_text_buffer_insert_at_cursor(buffer, arry_cal[29], 1);

	else
		gtk_text_buffer_insert_at_cursor(buffer, smarry_cal[14], 1);
}

void OnCBtnP()
{
	if (caps == 1)
		gtk_text_buffer_insert_at_cursor(buffer, arry_cal[30], 1);

	else
		gtk_text_buffer_insert_at_cursor(buffer, smarry_cal[15], 1);
}

void OnCBtnQ()
{
	if (caps == 1)
		gtk_text_buffer_insert_at_cursor(buffer, arry_cal[31], 1);

	else
		gtk_text_buffer_insert_at_cursor(buffer, smarry_cal[16], 1);
}

void OnCBtnR()
{
	if (caps == 1)
		gtk_text_buffer_insert_at_cursor(buffer, arry_cal[32], 1);

	else
		gtk_text_buffer_insert_at_cursor(buffer, smarry_cal[17], 1);
}

void OnCBtnS()
{
	if (caps == 1)
		gtk_text_buffer_insert_at_cursor(buffer, arry_cal[33], 1);

	else
		gtk_text_buffer_insert_at_cursor(buffer, smarry_cal[18], 1);
}

void OnCBtnT()
{
	if (caps == 1)
		gtk_text_buffer_insert_at_cursor(buffer, arry_cal[34], 1);

	else
		gtk_text_buffer_insert_at_cursor(buffer, smarry_cal[19], 1);
}

void OnCBtnU()
{
	if (caps == 1)
		gtk_text_buffer_insert_at_cursor(buffer, arry_cal[35], 1);

	else
		gtk_text_buffer_insert_at_cursor(buffer, smarry_cal[20], 1);
}

void OnCBtnV()
{
	if (caps == 1)
		gtk_text_buffer_insert_at_cursor(buffer, arry_cal[36], 1);

	else
		gtk_text_buffer_insert_at_cursor(buffer, smarry_cal[21], 1);
}

void OnCBtnW()
{
	if (caps == 1)
		gtk_text_buffer_insert_at_cursor(buffer, arry_cal[37], 1);

	else
		gtk_text_buffer_insert_at_cursor(buffer, smarry_cal[22], 1);
}

void OnCBtnX()
{
	if (caps == 1)
		gtk_text_buffer_insert_at_cursor(buffer, arry_cal[38], 1);

	else
		gtk_text_buffer_insert_at_cursor(buffer, smarry_cal[23], 1);
}

void OnCBtnY()
{
	if (caps == 1)
		gtk_text_buffer_insert_at_cursor(buffer, arry_cal[39], 1);

	else
		gtk_text_buffer_insert_at_cursor(buffer, smarry_cal[24], 1);
}

void OnCBtnZ()
{
	if (caps == 1)
		gtk_text_buffer_insert_at_cursor(buffer, arry_cal[40], 1);

	else
		gtk_text_buffer_insert_at_cursor(buffer, smarry_cal[25], 1);
}

void OnCBtnmn()
{
	if (key_shift == 1)
		gtk_text_buffer_insert_at_cursor(buffer, "_", 1);

	if (key_shift == 0)
		gtk_text_buffer_insert_at_cursor(buffer, arry_cal[41], 1);
}

void OnCBtnspc()
{
	gtk_text_buffer_insert_at_cursor(buffer, arry_cal[42], 1);
}

void OnCBtnpls()
{
	if (key_shift == 1)
		gtk_text_buffer_insert_at_cursor(buffer, arry_cal[45], 1);

	if (key_shift == 0)
		gtk_text_buffer_insert_at_cursor(buffer, "=", 1);
}
void OnCBtndiv()
{
	if (key_shift == 1)
		gtk_text_buffer_insert_at_cursor(buffer, "?", 1);

	if (key_shift == 0)
		gtk_text_buffer_insert_at_cursor(buffer, arry_cal[43], 1);
}
void OnCBtnmul()
{
	gtk_text_buffer_insert_at_cursor(buffer, arry_cal[44], 1);
}
void OnCBtnsmmcol()
{
	if (key_shift == 1)
		gtk_text_buffer_insert_at_cursor(buffer, ":", 1);

	if (key_shift == 0)
		gtk_text_buffer_insert_at_cursor(buffer, arry_cal[46], 1);
}
void OnCBtncmma()
{
	if (key_shift == 1)
		gtk_text_buffer_insert_at_cursor(buffer, "<", 1);

	if (key_shift == 0)
		gtk_text_buffer_insert_at_cursor(buffer, arry_cal[47], 1);
}
void OnCBtnbrc1()
{
	gtk_text_buffer_insert_at_cursor(buffer, arry_cal[48], 1);
}
void OnCBtnbrc2()
{
	gtk_text_buffer_insert_at_cursor(buffer, arry_cal[49], 1);
}

void OnCBtnequal()
{
	cbtn_idx = 48;
	Cmn_Cbtn(cbtn_idx);
}

void OnCBtnOpnBrckt()
{
	if (key_shift == 1)
		gtk_text_buffer_insert_at_cursor(buffer, "{", 1);

	if (key_shift == 0)
		gtk_text_buffer_insert_at_cursor(buffer, "[", 1);
}

void OnCBtnClsBrckt()
{
	if (key_shift == 1)
		gtk_text_buffer_insert_at_cursor(buffer, "}", 1);

	if (key_shift == 0)
		gtk_text_buffer_insert_at_cursor(buffer, "]", 1);
}

void OnCBtnLine()
{
	if (key_shift == 1)
		gtk_text_buffer_insert_at_cursor(buffer, "|", 1);

	if (key_shift == 0)
		gtk_text_buffer_insert_at_cursor(buffer, "\\", 1);  // "\\" required to show \ sign
}

void OnCBtnTab()
{
	gtk_text_buffer_insert_at_cursor(buffer, "	", 1);
}

void OnCBtnQuote()
{
	if (key_shift == 1)
		gtk_text_buffer_insert_at_cursor(buffer, "\"", 1); // "\"" required to show " 

	if (key_shift == 0)
		gtk_text_buffer_insert_at_cursor(buffer, "'", 1);
}

void OnCBtnCarat() 
{
	if (key_shift == 1)
		gtk_text_buffer_insert_at_cursor(buffer, "~", 1);

	if (key_shift == 0)
		gtk_text_buffer_insert_at_cursor(buffer, "`", 1);
}

void OnCBtnEscp()
{
	//gtk_widget_destroy(GTK_WIDGET(p_window));
	gtk_window_close(GTK_WINDOW(p_window));
	key_flag = true;
}

void OnCBtnmprv()
{
	Menu_f(-1);
}
void OnCBtnmnxt()
{
	Menu_f(1);
}

void OnCBtnOk()
{
	//char text_values[28][40];
	char buffer_1[40];

	if (note_dsp == 1)
	{
		gtk_text_buffer_get_bounds(buffer, &start, &end);
		text_keypad = gtk_text_buffer_get_text(buffer, &start, &end, false);

		sprintf(range_txt, "%s", text_keypad);
		sprintf(text_valueskpd[ln_no], "%s", range_txt);
	
		gtk_entry_set_text(GTK_ENTRY(text_h[ln_no]), text_valueskpd[ln_no]);
		strcpy(text_values[ln_no], text_valueskpd[ln_no]);
		Update_Note();
	}
	else
	{
		float tempscr_val = 0.0;
		key_scr = 2;
		prev_val = val_ary[(menu_v * 5) + btn_idx];
		gtk_text_buffer_get_bounds(buffer, &start, &end);
		text_keypad = gtk_text_buffer_get_text(buffer, &start, &end, false);
		pos = menu_v * 10;
		sprintf(range_txt, " %s ", text_keypad);

		scr_val = atoi(range_txt);

		val_ary[(menu_v * 5) + btn_idx] = scr_val;
		int btn_clk = (menu_v * 5) + btn_idx;
		tempscr_val = atof(range_txt);

	    key_array[(menu_v * 5) + btn_idx] = tempscr_val;
		
		AllProcess(0);
		Menu_Refresh();
		btn_flag == true;
	}
}

// gtk_text_view_set_overwrite (GTK_TEXT_VIEW(textview), true);
// gtk_text_view_set_wrap_mode (GTK_TEXT_VIEW(textview),GTK_WRAP_CHAR);
// gtk_text_view_set_right_margin (GTK_TEXT_VIEW(textview),r_margin);
// gtk_text_view_set_bottom_margin (GTK_TEXT_VIEW(textview),r_margin);

void Cmn_Cbtn(int btn_c)
{
	if (btn_c == 0)  // 0 and )
	{
		if(key_shift == 1)
			gtk_text_buffer_insert_at_cursor(buffer, ")", 1);

		if(key_shift == 0)
			gtk_text_buffer_insert_at_cursor(buffer, arry_cal[0], 1);
	}
	if (btn_c == 1)  // 1 and (!)
	{
		if(key_shift == 1)
			gtk_text_buffer_insert_at_cursor(buffer, "!", 1);

		if(key_shift == 0)
			gtk_text_buffer_insert_at_cursor(buffer, arry_cal[1], 1);
	}
	if (btn_c == 2)  // 2 and (@)
	{
		if(key_shift == 1)
			gtk_text_buffer_insert_at_cursor(buffer, "@", 1);
		
		if(key_shift == 0)
			gtk_text_buffer_insert_at_cursor(buffer, arry_cal[2], 1);
	}
	if (btn_c == 3) // 3 and (#)
	{
		if(key_shift == 1)
			gtk_text_buffer_insert_at_cursor(buffer, "#", 1);

		if(key_shift == 0)
			gtk_text_buffer_insert_at_cursor(buffer, arry_cal[3], 1);
	}
	if (btn_c == 4)  // 4 and ($)
	{
		if (key_shift == 1)
			gtk_text_buffer_insert_at_cursor(buffer, "$", 1);

		if (key_shift == 0)
			gtk_text_buffer_insert_at_cursor(buffer, arry_cal[4], 1);
	}
	if (btn_c == 5) // 5 and (%)
	{
		if (key_shift == 1)
			gtk_text_buffer_insert_at_cursor(buffer, "%", 1);

		if (key_shift == 0)
			gtk_text_buffer_insert_at_cursor(buffer, arry_cal[5], 1);
	}
	if (btn_c == 6) // 6 and (^)
	{
		if (key_shift == 1)
			gtk_text_buffer_insert_at_cursor(buffer, "^", 1);

		if (key_shift == 0)
			gtk_text_buffer_insert_at_cursor(buffer, arry_cal[6], 1);
	}
	if (btn_c == 7) // 7 and (&)
	{
		if (key_shift == 1)
			gtk_text_buffer_insert_at_cursor(buffer, "&", 1);

		if (key_shift == 0)
			gtk_text_buffer_insert_at_cursor(buffer, arry_cal[7], 1);
	}
	if (btn_c == 8) // 8 and (*)
	{
		if (key_shift == 1)
			gtk_text_buffer_insert_at_cursor(buffer, "*", 1);

		if (key_shift == 0)
			gtk_text_buffer_insert_at_cursor(buffer, arry_cal[8], 1);
	}
	if (btn_c == 9) // 9 and (
	{
		if (key_shift == 1)
			gtk_text_buffer_insert_at_cursor(buffer, "(", 1);

		if (key_shift == 0)
			gtk_text_buffer_insert_at_cursor(buffer, arry_cal[9], 1);
	}
	if (btn_c == 10) 
	{
		gtk_text_buffer_set_text(buffer, "", 0);
	}
	if (btn_c == 11)  // Caps lock or small(Not Used)
	{
		//gtk_widget_destroy(GTK_WIDGET(p_window));
		//if (capslock_flag == true)
		//{
		//	caps = 0;
		//	//gtk_button_set_label(GTK_BUTTON(btncls), "CP");
		//	gtk_widget_set_name(GTK_WIDGET(btncaps), "calbtn7-entry");
		//	capslock_flag = false;
		//}
		//else if (capslock_flag == false)
		//{
		//	caps = 1;
		//	//gtk_button_set_label(GTK_BUTTON(btncls),"SM");
		//	gtk_widget_set_name(GTK_WIDGET(btncaps), "calbtn8-entry");
		//	capslock_flag = true;
		//}
	}
	if (btn_c == 12) // . Dot and (>)
	{
		if (key_shift == 1)
			gtk_text_buffer_insert_at_cursor(buffer, ">", 1);

		if (key_shift == 0)
			gtk_text_buffer_insert_at_cursor(buffer, arry_cal[11], 1);
	}
	if (btn_c == 13) // A
	{
		if (caps == 1)
		{
			gtk_text_buffer_insert_at_cursor(buffer, arry_cal[15], 1);
		}
		else
		{
			gtk_text_buffer_insert_at_cursor(buffer, smarry_cal[0], 1);
		}	
	}
	if (btn_c == 14) // B
	{
		if (caps == 1)
			gtk_text_buffer_insert_at_cursor(buffer, arry_cal[16], 1);
		
		else
			gtk_text_buffer_insert_at_cursor(buffer, smarry_cal[1], 1);	
	}
	if (btn_c == 15)  // C
	{
		if(caps == 1)
			gtk_text_buffer_insert_at_cursor(buffer, arry_cal[17], 1);

		else
			gtk_text_buffer_insert_at_cursor(buffer, smarry_cal[2], 1);
	}
	if (btn_c == 16) // D
	{
		if(caps == 1)
			gtk_text_buffer_insert_at_cursor(buffer, arry_cal[18], 1);

		else
			gtk_text_buffer_insert_at_cursor(buffer, smarry_cal[3], 1);
	}
	if (btn_c == 17)  // E
	{
		if(caps == 1)
			gtk_text_buffer_insert_at_cursor(buffer, arry_cal[19], 1);

		else
			gtk_text_buffer_insert_at_cursor(buffer, smarry_cal[4], 1);
	}
	if (btn_c == 18) // F
	{
		if(caps == 1)
			gtk_text_buffer_insert_at_cursor(buffer, arry_cal[20], 1);

		else
			gtk_text_buffer_insert_at_cursor(buffer, smarry_cal[5], 1);
	}
	if (btn_c == 19) // G
	{
		if(caps == 1)
			gtk_text_buffer_insert_at_cursor(buffer, arry_cal[21], 1);

		else
			gtk_text_buffer_insert_at_cursor(buffer, smarry_cal[6], 1);
	}
	if (btn_c == 20) // H
	{
		if(caps == 1)
			gtk_text_buffer_insert_at_cursor(buffer, arry_cal[22], 1);

		else
			gtk_text_buffer_insert_at_cursor(buffer, smarry_cal[7], 1);
	}
	if (btn_c == 21) // I
	{
		if(caps == 1)
			gtk_text_buffer_insert_at_cursor(buffer, arry_cal[23], 1);

		else
			gtk_text_buffer_insert_at_cursor(buffer, smarry_cal[8], 1);
	}
	if (btn_c == 22) // J
	{
		if(caps == 1)
			gtk_text_buffer_insert_at_cursor(buffer, arry_cal[24], 1);

		else
			gtk_text_buffer_insert_at_cursor(buffer, smarry_cal[9], 1);
	}
	if (btn_c == 23) // K
	{
		if(caps == 1)
			gtk_text_buffer_insert_at_cursor(buffer, arry_cal[25], 1);

	    else
			gtk_text_buffer_insert_at_cursor(buffer, smarry_cal[10], 1);
	}
	if (btn_c == 24) // L
	{
		if(caps == 1)
			gtk_text_buffer_insert_at_cursor(buffer, arry_cal[26], 1);

		else
			gtk_text_buffer_insert_at_cursor(buffer, smarry_cal[11], 1);
	}
	if (btn_c == 25) // M
	{
		if (caps == 1)
			gtk_text_buffer_insert_at_cursor(buffer, arry_cal[27], 1);

		else
			gtk_text_buffer_insert_at_cursor(buffer, smarry_cal[12], 1);
	}
	if (btn_c == 26)  // N
	{
		if(caps == 1)
			gtk_text_buffer_insert_at_cursor(buffer, arry_cal[28], 1);

		else
			gtk_text_buffer_insert_at_cursor(buffer, smarry_cal[13], 1);
	}
	if (btn_c == 27) // O
	{
		if (caps == 1)
			gtk_text_buffer_insert_at_cursor(buffer, arry_cal[29], 1);

		else
			gtk_text_buffer_insert_at_cursor(buffer, smarry_cal[14], 1);
	}
	if (btn_c == 28) // P
	{
		if(caps == 1)
			gtk_text_buffer_insert_at_cursor(buffer, arry_cal[30], 1);

		else
			gtk_text_buffer_insert_at_cursor(buffer, smarry_cal[15], 1);
	}
	if (btn_c == 29) // Q
	{
		if(caps == 1)
			gtk_text_buffer_insert_at_cursor(buffer, arry_cal[31], 1);

		else
			gtk_text_buffer_insert_at_cursor(buffer, smarry_cal[16], 1);
	}
	if (btn_c == 30) // R
	{
		if(caps == 1)
			gtk_text_buffer_insert_at_cursor(buffer, arry_cal[32], 1);

		else
			gtk_text_buffer_insert_at_cursor(buffer, smarry_cal[17], 1);
	}
	if (btn_c == 31) // S
	{
		if(caps == 1)
			gtk_text_buffer_insert_at_cursor(buffer, arry_cal[33], 1);

		else
			gtk_text_buffer_insert_at_cursor(buffer, smarry_cal[18], 1);
	}
	if (btn_c == 32) // T
	{
		if(caps == 1)
			gtk_text_buffer_insert_at_cursor(buffer, arry_cal[34], 1);

		else
			gtk_text_buffer_insert_at_cursor(buffer, smarry_cal[19], 1);
	}
	if (btn_c == 33) // U
	{
		if(caps == 1)
			gtk_text_buffer_insert_at_cursor(buffer, arry_cal[35], 1);

		else
			gtk_text_buffer_insert_at_cursor(buffer, smarry_cal[20], 1);
	}
	if (btn_c == 34) // V
	{
		if(caps == 1)
			gtk_text_buffer_insert_at_cursor(buffer, arry_cal[36], 1);

		else
			gtk_text_buffer_insert_at_cursor(buffer, smarry_cal[21], 1);
	}
	if (btn_c == 35) // W
	{
		if(caps == 1)
			gtk_text_buffer_insert_at_cursor(buffer, arry_cal[37], 1);

		else
			gtk_text_buffer_insert_at_cursor(buffer, smarry_cal[22], 1);
	}
	if (btn_c == 36) // X
	{
		if(caps == 1)
			gtk_text_buffer_insert_at_cursor(buffer, arry_cal[38], 1);

		else
			gtk_text_buffer_insert_at_cursor(buffer, smarry_cal[23], 1);
	}
	if (btn_c == 37)  // Y
	{
		if(caps == 1)
			gtk_text_buffer_insert_at_cursor(buffer, arry_cal[39], 1);

		else
			gtk_text_buffer_insert_at_cursor(buffer, smarry_cal[24], 1);
	}
	if (btn_c == 38)   // Z
	{
		if(caps == 1)
			gtk_text_buffer_insert_at_cursor(buffer, arry_cal[40], 1);

		else
			gtk_text_buffer_insert_at_cursor(buffer, smarry_cal[25], 1);
	}
	if (btn_c == 39)  // - Minus or underscore _
	{
		if (key_shift == 1)
			gtk_text_buffer_insert_at_cursor(buffer, "_", 1);

		if (key_shift == 0)
			gtk_text_buffer_insert_at_cursor(buffer, arry_cal[41], 1);
	}
	if (btn_c == 40)// " " Space
	{
		gtk_text_buffer_insert_at_cursor(buffer, arry_cal[42], 1);
	}
	if (btn_c == 41)// / Divison and (?)
	{
		if (key_shift == 1)
			gtk_text_buffer_insert_at_cursor(buffer, "?", 1);

		if (key_shift == 0)
			gtk_text_buffer_insert_at_cursor(buffer, arry_cal[43], 1);
	}
	if (btn_c == 42) // * Multiplication (Not Used)
	{
		gtk_text_buffer_insert_at_cursor(buffer, arry_cal[44], 1);
	}
	if (btn_c == 43) // + = Plus or equal to
	{
		if (key_shift == 1)
			gtk_text_buffer_insert_at_cursor(buffer, arry_cal[45], 1);

		if (key_shift == 0)
			gtk_text_buffer_insert_at_cursor(buffer, "=", 1);
	}
	if (btn_c == 44) // ; Semicolon and (:)
	{
		if (key_shift == 1)
			gtk_text_buffer_insert_at_cursor(buffer, ":", 1);

		if (key_shift == 0)
			gtk_text_buffer_insert_at_cursor(buffer, arry_cal[46], 1);
	}
	if (btn_c == 45) // , Comma and (<)
	{
		if (key_shift == 1)
			gtk_text_buffer_insert_at_cursor(buffer, "<", 1);

		if (key_shift == 0)
			gtk_text_buffer_insert_at_cursor(buffer, arry_cal[47], 1);
	}
	if (btn_c == 46)  // ( (Opening Bracket)(Not used)
	{
		gtk_text_buffer_insert_at_cursor(buffer, arry_cal[48], 1);
	}
	if (btn_c == 47) // ) (Closing Bracket)(Not Used)
	{
		gtk_text_buffer_insert_at_cursor(buffer, arry_cal[49], 1);
	}
	if (btn_c == 48) // = Equal to and (+)
	{
		/*if (key_shift == 1)
			gtk_text_buffer_insert_at_cursor(buffer, "+", 1);

		if (key_shift == 0)
			gtk_text_buffer_insert_at_cursor(buffer, arry_cal[50], 1);*/
	}
	if (btn_c == 49) // {[ opening square or curly bracket
	{
		if (key_shift == 1)
			gtk_text_buffer_insert_at_cursor(buffer, "{", 1);

		if (key_shift == 0)
			gtk_text_buffer_insert_at_cursor(buffer, "[", 1);
	}
	if (btn_c == 50) // }] Closing square or curly bracket
	{
		if (key_shift == 1)
			gtk_text_buffer_insert_at_cursor(buffer, "}", 1);

		if (key_shift == 0)
			gtk_text_buffer_insert_at_cursor(buffer, "]", 1);
	}
	if (btn_c == 51) // | \ Line
	{
		if (key_shift == 1)
			gtk_text_buffer_insert_at_cursor(buffer, "|", 1);

		if (key_shift == 0)
			gtk_text_buffer_insert_at_cursor(buffer, "\\", 1);  // "\\" required to show \ sign
	}
	if (btn_c == 52) // Tab
	{
		gtk_text_buffer_insert_at_cursor(buffer, "	", 1);
	}
	if (btn_c == 53) // " ' opening Quote
	{
		if (key_shift == 1)
			gtk_text_buffer_insert_at_cursor(buffer, "\"", 1); // "\"" required to show " 

		if (key_shift == 0)
			gtk_text_buffer_insert_at_cursor(buffer, "'", 1);
	}
	if (btn_c == 54) // " ' closing Quote
	{
		if (key_shift == 1)
			gtk_text_buffer_insert_at_cursor(buffer, "~", 1);

		if (key_shift == 0)
			gtk_text_buffer_insert_at_cursor(buffer, "`", 1);
	}
}

void Range_Key()
{
	cb_create_entry();
	text_keypad = gtk_text_buffer_get_text(buffer, &start, &end, false);
	sprintf(range_txt, " %s ", text_keypad);
	scr_val = atoi(range_txt);
	val_ary[(menu_v * 5) + btn_idx] = scr_val;
}

static void insert_text(GtkTextBuffer* buffer, GtkTextIter* location, gchar* text, gint len, gpointer user_data)
{
	static int i = 1;
	gint count_key = gtk_text_buffer_get_char_count(buffer);
	
	if (count_key > 20)
	{
		GtkTextIter offset, end;
		gtk_text_buffer_get_iter_at_offset(buffer, &offset, 20);
		gtk_text_buffer_get_end_iter(buffer, &end);

		gtk_text_buffer_delete(buffer, &offset, &end);
		gtk_text_iter_assign(location, &offset);
	}
}

void Note_ln_fkeypad()
{
	if (note_dsp == 1)
	{
		ln_no = ln_no + 1; // For traversing textbox directly
		if (ln_no > temp_count)
		{
			ln_no = 0;
		}
		if (ln_no < 0)
		{
			ln_no = temp_count;
		}
		nxt_count = ln_no;

		gtk_widget_set_can_focus(GTK_WIDGET(text_h[ln_no]), true);
		gtk_widget_grab_focus(GTK_WIDGET(text_h[ln_no]));
		// chr_pos = 0;
		//OntString(0);
	}
	else
	{
		btn_idx = btn_idx + 1;
		if (btn_idx < 0)
		{
			btn_idx = 0;
		}
		if (btn_idx > 4)
		{
			btn_idx = 0;
		}
		key_btn();
	}
}

void UpVarTraverse()
{
	if (note_dsp == 1)
	{
		ln_no = ln_no - 1; // For traversing textbox directly
		if (ln_no > temp_count)
		{
			ln_no = 0;
		}
		if (ln_no < 0)
		{
			ln_no = 0;
		}
		nxt_count = ln_no;

		gtk_widget_set_can_focus(GTK_WIDGET(text_h[ln_no]), true);
		gtk_widget_grab_focus(GTK_WIDGET(text_h[ln_no]));
		// chr_pos = 0;
		//OntString(0);
	}
	else
	{
		btn_idx = btn_idx - 1;
		if (btn_idx < 0)
		{
			btn_idx = 0;
		}
		if (btn_idx > 4)
		{
			btn_idx = 0;
		}
		key_btn();
	}
}

void OnCBtnShft()
{
	if (shift_flag == true)
	{
		key_shift = 0;
		gtk_widget_set_name(GTK_WIDGET(btnshift), "calbtnshftoff-entry");
		shift_flag = false;
		
	}

	else if (shift_flag == false)
	{
		key_shift = 1;
		gtk_widget_set_name(GTK_WIDGET(btnshift), "calbtnshfton-entry");
		shift_flag = true;
	}
}