# Project Refactor (First Pass)

This refactor consolidates all images into a single top-level `/Images/` folder and updates source code references accordingly, improving consistency and discoverability.

## What changed
- All image assets were moved to: `/Images/`
- References in source files were updated to the new paths where possible (best effort, both full relative paths and unique basenames).
- Empty asset directories were removed if they became empty after moves.
- A detailed change log is available in `refactor_report.txt`.

## Suggested Structure (non-breaking)
To keep this pass non-disruptive to your build, only images were reorganized. For a fuller modularization, consider adopting the following structure (future step if desired):

```
/
├── src/            # source code (.c/.cpp/.py/.qml etc.)
├── include/        # headers for C/C++
├── qml/            # QML UI (if applicable)
├── scripts/        # tooling scripts (build, deploy, etc.)
├── Images/      # image assets (moved in this pass)
├── assets/         # other static assets (fonts, icons, etc.)
├── docs/           # documentation
├── tests/          # unit/integration tests
├── CMakeLists.txt  # or meson.build / qmake *.pro file
└── README.md
```

## Notes & Caveats
- If multiple images originally had the same filename in different folders, the refactor avoids collisions by prefixing with parent directory names or adding a numeric suffix. See `refactor_report.txt` for exact renames.
- Some image references might be constructed dynamically in code (e.g., by joining folder + filename at runtime). These patterns are harder to rewrite automatically. If you notice missing images at runtime, search the relevant source file for `Images/` and confirm.
- If your project uses resource systems (e.g., Qt `.qrc` or GTK resource bundles), double-check that the resource manifests still include the new paths.

## Next Steps (recommended)
1. Build and run the project to verify UI screens load images correctly.
2. If any paths are still broken, search for the original filename in the codebase and adjust to `/Images/<file>`.
3. Decide whether to proceed with a deeper modularization:
   - Group code into `src/`, `include/`, and `qml/` (if Qt) and update the build system.
   - Create a `docs/ARCHITECTURE.md` that explains modules and data flow.
   - Add lint/format config (e.g., clang-format, prettier) for consistent style.

See `refactor_report.txt` for the full list of moves and replacements.
