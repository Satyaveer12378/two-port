#ifndef _SHP_PRF_H
#define _SHP_PRF_H

#define LINE 1
#define RECTANGLE 2
#define ARC 3
#define CIRCLE 4
#define CURVE 5

#define LOOP_BREAK 0x7ff

const int Asc_WidthC = 720;
const int profiler_drawing_area_width = 275;
const int profiler_drawing_area_height = 275;

#define RECT_X_POS 37
#define RECT_Y_POS 37

const int gtk_shape_origin_x_pos = (profiler_drawing_area_width / 2);
const int gtk_shape_origin_y_pos = (profiler_drawing_area_height / 2);

const int ogl_shape_win_x_pos = Asc_WidthC - profiler_drawing_area_width; // X = 451, Width = 275
const int ogl_shape_win_y_pos = 0;                                        // Y = 0, Height = 275

const int ogl_shape_origin_x_pos = ogl_shape_win_x_pos + gtk_shape_origin_x_pos;
const int ogl_shape_origin_y_pos = ogl_shape_win_y_pos + gtk_shape_origin_y_pos;

// Shape variables
int orignal_gtk_shape[7];
int gtk_shape[101]; // index zero is reserved
int ogl_shape[51];  // index zero is reserved

// Profiler variables
int profiler_cntr_line[11];
int profiler_data[9];
int gtk_profiler[201]; // index zero is reserved
int ogl_profiler[101]; // index zero is reserved

// used for gtk_profiler index values, pick data from gtk_shape[101] array.
int X1_idx = 2;
int Y1_idx = 3;
int X2_idx = 0;
int Y2_idx = 0;
int rw_idx = 4;
int rh_idx = 5;

// Probe variables
int gtk_probe[101];
int ogl_probe[101];

// Rays varibales
int ray_data[8];
int gtk_rays[101];
int ogl_rays[101];

extern double zoom_ratio;

void draw_Beamprofile(cairo_t *cr); // Draw Beam Profile

//*********************************************************************************************
// Calculate and display Objects like 1) Flat plate, 2) Hollow Circle, 3) Solid rod
//*********************************************************************************************
void init_shape_value(void)
{
    // Object variables values initialization
    memset(orignal_gtk_shape, 0, sizeof(orignal_gtk_shape));
    memset(gtk_shape, 0, sizeof(gtk_shape));
    memset(ogl_shape, 0, sizeof(ogl_shape));

    orignal_gtk_shape[0] = val_ary[OBJ_WIDTH_PERA];
    orignal_gtk_shape[1] = val_ary[OBJ_THICK_PERA];
    orignal_gtk_shape[2] = 100;
    orignal_gtk_shape[3] = 60;
    orignal_gtk_shape[4] = 100;
    orignal_gtk_shape[5] = 60;
    orignal_gtk_shape[6] = 100;

    // opengl background drawing object rectangle
    ogl_shape[0] = 0; // reserve for on / off

    ogl_shape[1] = RECTANGLE;
    ogl_shape[2] = ogl_shape_win_x_pos;         // Rectangle x
    ogl_shape[3] = 50;                          // Rectangle y
    ogl_shape[4] = val_ary[OBJ_WIDTH_PERA];     // Rectangle width
    ogl_shape[5] = val_ary[OBJ_THICK_PERA];     // Rectangle height
    ogl_shape[11] = LOOP_BREAK;                 // break condition

    gtk_shape[0] = 0; // reserve for on / off

    // Rectangle shape
    gtk_shape[1] = RECTANGLE;
    gtk_shape[2] = RECT_X_POS;              // Rectangle x
    gtk_shape[3] = RECT_Y_POS;              // Rectangle y
    gtk_shape[4] = val_ary[OBJ_WIDTH_PERA]; //  200;             // Rectangle width
    gtk_shape[5] = val_ary[OBJ_THICK_PERA]; //  100;             // Rectangle height
    gtk_shape[11] = LOOP_BREAK;             // break condition

    // Circle shape
    gtk_shape[21] = CIRCLE;                 // Circle
    gtk_shape[22] = gtk_shape_origin_x_pos; // Circle x Origin co-ordinates
    gtk_shape[23] = gtk_shape_origin_y_pos; // Circle y Origin co-ordinates
    gtk_shape[24] = 100;                    // Circle radius
    gtk_shape[31] = CIRCLE;                 // Circle
    gtk_shape[32] = gtk_shape_origin_x_pos; // Circle x Origin co-ordinates
    gtk_shape[33] = gtk_shape_origin_y_pos; // Circle y Origin co-ordinates
    gtk_shape[34] = 60;                     // Circle radius
    gtk_shape[41] = LOOP_BREAK;             // break condition

    // Circle shape
    gtk_shape[51] = CIRCLE;                 // Circle
    gtk_shape[52] = gtk_shape_origin_x_pos; // Circle x Origin co-ordinates
    gtk_shape[53] = gtk_shape_origin_y_pos; // Circle y Origin co-ordinates
    gtk_shape[54] = 100;                    // Circle radius
    gtk_shape[61] = CIRCLE;                 // Circle
    gtk_shape[62] = gtk_shape_origin_x_pos; // Circle x Origin co-ordinates
    gtk_shape[63] = gtk_shape_origin_y_pos; // Circle y Origin co-ordinates
    gtk_shape[64] = 60;                     // Circle radius
    gtk_shape[71] = LOOP_BREAK;             // break condition

    // Circle shape
    gtk_shape[81] = CIRCLE;                 // Circle
    gtk_shape[82] = gtk_shape_origin_x_pos; // Circle x Origin co-ordinates
    gtk_shape[83] = gtk_shape_origin_y_pos; // Circle y Origin co-ordinates
    gtk_shape[84] = 100;                    // Circle radius
    gtk_shape[91] = LOOP_BREAK;             // break condition
}

void copy_shape_data(void)
{
    memset(ogl_shape, 0, sizeof(ogl_shape));

    if (val_ary[OBJ_SHAPE_PERA] == 0)
    {
        ogl_shape[1] = gtk_shape[1];
        ogl_shape[2] = ogl_shape_win_x_pos;
        ogl_shape[3] = 50;
        ogl_shape[4] = gtk_shape[rw_idx];
        ogl_shape[5] = gtk_shape[rh_idx];

        ogl_shape[11] = LOOP_BREAK;
    }
    else if (val_ary[OBJ_SHAPE_PERA] == 1)
    {
        ogl_shape[1] = gtk_shape[21];
        ogl_shape[2] = ogl_shape_origin_x_pos;
        ogl_shape[3] = ogl_shape_origin_y_pos;
        ogl_shape[4] = gtk_shape[rw_idx];

        ogl_shape[11] = gtk_shape[31];
        ogl_shape[12] = ogl_shape_origin_x_pos;
        ogl_shape[13] = ogl_shape_origin_y_pos;
        ogl_shape[14] = gtk_shape[rh_idx];

        ogl_shape[21] = LOOP_BREAK;
    }
    else if (val_ary[OBJ_SHAPE_PERA] == 2)
    {
        ogl_shape[1] = gtk_shape[51];
        ogl_shape[2] = ogl_shape_origin_x_pos;
        ogl_shape[3] = ogl_shape_origin_y_pos;
        ogl_shape[4] = gtk_shape[rw_idx];

        ogl_shape[11] = gtk_shape[61];
        ogl_shape[12] = ogl_shape_origin_x_pos;
        ogl_shape[13] = ogl_shape_origin_y_pos;
        ogl_shape[14] = gtk_shape[rh_idx];

        ogl_shape[21] = LOOP_BREAK;
    }
    else if (val_ary[OBJ_SHAPE_PERA] == 3)
    {
        ogl_shape[1] = gtk_shape[81];
        ogl_shape[2] = ogl_shape_origin_x_pos;
        ogl_shape[3] = ogl_shape_origin_y_pos;
        ogl_shape[4] = gtk_shape[rw_idx];

        ogl_shape[11] = LOOP_BREAK;
    }
}

//*********************************************************************************************
// Calculate and display weld profiler like 1) V type, 2) Double v type
//*********************************************************************************************
void initialize_profiler_data(void)
{
    // V type
    profiler_data[0] = val_ary[TOP_WIDTH_PERA];
    profiler_data[1] = val_ary[TOP_HEIGHT_PERA];
    profiler_data[2] = val_ary[ROOT_WIDTH_PERA];
    // Double V type
    profiler_data[3] = val_ary[TOP_WIDTH_PERA];
    profiler_data[4] = val_ary[TOP_HEIGHT_PERA];
    profiler_data[5] = val_ary[ROOT_WIDTH_PERA];
    // J type
    profiler_data[6] = val_ary[TOP_WIDTH_PERA];
    profiler_data[7] = val_ary[TOP_HEIGHT_PERA];
    profiler_data[8] = val_ary[ROOT_WIDTH_PERA];
}

void gtk_profiler_for_flat_plate(void)
{
    double top_width, top_height, root_width;

    memset(gtk_profiler, 0, sizeof(gtk_profiler));

    // ********** Center line **********************
    gtk_profiler[1] = LINE;
    gtk_profiler[2] = gtk_shape[2] + val_ary[WPROF_POS_PERA];
    gtk_profiler[3] = gtk_shape[3];
    gtk_profiler[4] = gtk_shape[2] + val_ary[WPROF_POS_PERA];
    gtk_profiler[5] = gtk_shape[3] + gtk_shape[5];

    gtk_profiler[11] = LOOP_BREAK;

    if (val_ary[WELD_TYPE_PERA] == 0)
    {
        top_width = profiler_data[0];
        top_height = profiler_data[1];
        root_width = profiler_data[2];

        // ********** V shape profiler ***********************************
        // Right top side
        gtk_profiler[21] = LINE;
        gtk_profiler[22] = gtk_profiler[2] + val_ary[TOP_WIDTH_PERA];
        gtk_profiler[23] = gtk_profiler[3];
        gtk_profiler[24] = gtk_profiler[2] + val_ary[ROOT_WIDTH_PERA];
        gtk_profiler[25] = gtk_profiler[3] + val_ary[TOP_HEIGHT_PERA];
        // Right bottom side
        gtk_profiler[31] = LINE;
        gtk_profiler[32] = gtk_profiler[2] + val_ary[ROOT_WIDTH_PERA];
        gtk_profiler[33] = gtk_profiler[3] + val_ary[TOP_HEIGHT_PERA];
        gtk_profiler[34] = gtk_profiler[4] + val_ary[ROOT_WIDTH_PERA];
        gtk_profiler[35] = gtk_profiler[5];
        // Left top side
        gtk_profiler[41] = LINE;
        gtk_profiler[42] = gtk_profiler[2] - val_ary[TOP_WIDTH_PERA];
        gtk_profiler[43] = gtk_profiler[3];
        gtk_profiler[44] = gtk_profiler[2] - val_ary[ROOT_WIDTH_PERA];
        gtk_profiler[45] = gtk_profiler[3] + val_ary[TOP_HEIGHT_PERA];
        // Left bottom side
        gtk_profiler[51] = LINE;
        gtk_profiler[52] = gtk_profiler[2] - val_ary[ROOT_WIDTH_PERA];
        gtk_profiler[53] = gtk_profiler[3] + val_ary[TOP_HEIGHT_PERA];
        gtk_profiler[54] = gtk_profiler[4] - val_ary[ROOT_WIDTH_PERA];
        gtk_profiler[55] = gtk_profiler[5];

        gtk_profiler[61] = LOOP_BREAK;
    }
    else if (val_ary[WELD_TYPE_PERA] == 1)
    {
        top_width = profiler_data[3];
        top_height = profiler_data[4];
        root_width = profiler_data[5];

        // ********** Double V shape profiler ****************************
        // Right top side
        gtk_profiler[21] = LINE;
        gtk_profiler[22] = gtk_profiler[2] + val_ary[TOP_WIDTH_PERA];
        gtk_profiler[23] = gtk_profiler[3];
        gtk_profiler[24] = gtk_profiler[2] + val_ary[ROOT_WIDTH_PERA];
        gtk_profiler[25] = gtk_profiler[3] + val_ary[TOP_HEIGHT_PERA];
        // Right middle side
        gtk_profiler[31] = LINE;
        gtk_profiler[32] = gtk_profiler[2] + val_ary[ROOT_WIDTH_PERA];
        gtk_profiler[33] = gtk_profiler[3] + val_ary[TOP_HEIGHT_PERA];
        gtk_profiler[34] = gtk_profiler[4] + val_ary[ROOT_WIDTH_PERA];
        gtk_profiler[35] = gtk_profiler[5] - val_ary[TOP_HEIGHT_PERA];
        // Right bottom side
        gtk_profiler[41] = LINE;
        gtk_profiler[42] = gtk_profiler[4] + val_ary[ROOT_WIDTH_PERA];
        gtk_profiler[43] = gtk_profiler[5] - val_ary[TOP_HEIGHT_PERA];
        gtk_profiler[44] = gtk_profiler[2] + val_ary[TOP_WIDTH_PERA];
        gtk_profiler[45] = gtk_profiler[5];
        // Left top side
        gtk_profiler[51] = LINE;
        gtk_profiler[52] = gtk_profiler[2] - val_ary[TOP_WIDTH_PERA];
        gtk_profiler[53] = gtk_profiler[3];
        gtk_profiler[54] = gtk_profiler[2] - val_ary[ROOT_WIDTH_PERA];
        gtk_profiler[55] = gtk_profiler[3] + val_ary[TOP_HEIGHT_PERA];
        // Left middle side
        gtk_profiler[61] = LINE;
        gtk_profiler[62] = gtk_profiler[2] - val_ary[ROOT_WIDTH_PERA];
        gtk_profiler[63] = gtk_profiler[3] + val_ary[TOP_HEIGHT_PERA];
        gtk_profiler[64] = gtk_profiler[4] - val_ary[ROOT_WIDTH_PERA];
        gtk_profiler[65] = gtk_profiler[5] - val_ary[TOP_HEIGHT_PERA];
        // Left bottom side
        gtk_profiler[71] = LINE;
        gtk_profiler[72] = gtk_profiler[4] - val_ary[ROOT_WIDTH_PERA];
        gtk_profiler[73] = gtk_profiler[5] - val_ary[TOP_HEIGHT_PERA];
        gtk_profiler[74] = gtk_profiler[2] - val_ary[TOP_WIDTH_PERA];
        gtk_profiler[75] = gtk_profiler[5];

        gtk_profiler[81] = LOOP_BREAK;
    }
    else if (val_ary[WELD_TYPE_PERA] == 2)
    {
        top_width = profiler_data[6];
        top_height = profiler_data[7];
        root_width = profiler_data[8];
        // ********** J shape profiler ***********************************
        gtk_profiler[21] = LINE;
        gtk_profiler[22] = gtk_profiler[2] + top_width;
        gtk_profiler[23] = gtk_profiler[3];
        gtk_profiler[24] = gtk_profiler[2] + top_width;
        gtk_profiler[25] = gtk_profiler[3] + top_height;

        gtk_profiler[31] = CURVE;
        gtk_profiler[32] = gtk_profiler[2] + top_width;
        gtk_profiler[33] = gtk_profiler[3] + top_height;
        gtk_profiler[34] = gtk_profiler[2] + top_width - 5;
        gtk_profiler[35] = gtk_profiler[3] + top_height + 5;
        gtk_profiler[36] = gtk_profiler[4] + root_width;
        gtk_profiler[37] = gtk_profiler[5] - (gtk_shape[5] - top_height);

        gtk_profiler[41] = LINE;
        gtk_profiler[42] = gtk_profiler[4] + root_width;
        gtk_profiler[43] = gtk_profiler[5] - (gtk_shape[5] - top_height);
        gtk_profiler[44] = gtk_profiler[4] + root_width;
        gtk_profiler[45] = gtk_profiler[5];

        // ********** J shape profiler ***********************************
        gtk_profiler[51] = LINE;
        gtk_profiler[52] = gtk_profiler[2] - top_width;
        gtk_profiler[53] = gtk_profiler[3];
        gtk_profiler[54] = gtk_profiler[2] - top_width;
        gtk_profiler[55] = gtk_profiler[3] + top_height;

        gtk_profiler[61] = CURVE;
        gtk_profiler[62] = gtk_profiler[2] - top_width;
        gtk_profiler[63] = gtk_profiler[3] + top_height;
        gtk_profiler[64] = gtk_profiler[2] - top_width + 5;
        gtk_profiler[65] = gtk_profiler[3] + top_height + 5;
        gtk_profiler[66] = gtk_profiler[4] - root_width;
        gtk_profiler[67] = gtk_profiler[5] - (gtk_shape[5] - top_height);

        gtk_profiler[71] = LINE;
        gtk_profiler[72] = gtk_profiler[4] - root_width;
        gtk_profiler[73] = gtk_profiler[5] - (gtk_shape[5] - top_height);
        gtk_profiler[74] = gtk_profiler[4] - root_width;
        gtk_profiler[75] = gtk_profiler[5];

        gtk_profiler[81] = LOOP_BREAK;
    }
}

void gtk_profiler_for_hollow_circle(void)
{
    double top_width, top_height, root_width, prf_pos;

    memset(gtk_profiler, 0, sizeof(gtk_profiler));

    // ********** Center line **********************
    prf_pos = ((val_ary[WPROF_POS_PERA] * M_PI) / 180);

    gtk_profiler[1] = LINE;
    gtk_profiler[2] = gtk_shape[X1_idx] - gtk_shape[rw_idx] * sin(prf_pos);
    gtk_profiler[3] = gtk_shape[Y1_idx] - gtk_shape[rw_idx] * cos(prf_pos);
    gtk_profiler[4] = gtk_shape[X2_idx] - gtk_shape[rh_idx] * sin(prf_pos);
    gtk_profiler[5] = gtk_shape[Y2_idx] - gtk_shape[rh_idx] * cos(prf_pos);

    gtk_profiler[11] = LOOP_BREAK;

    if (val_ary[WELD_TYPE_PERA] == 0)
    {
        top_width = ((profiler_data[0] * M_PI) / 180);
        top_height = profiler_data[1];
        root_width = ((profiler_data[2] * M_PI) / 180);

        // ********** V shape profiler ***********************************
        // Right top side
        gtk_profiler[21] = LINE;
        gtk_profiler[22] = gtk_shape[X1_idx] - gtk_shape[rw_idx] * sin(prf_pos - top_width);
        gtk_profiler[23] = gtk_shape[Y1_idx] - gtk_shape[rw_idx] * cos(prf_pos - top_width);
        gtk_profiler[24] = gtk_shape[X2_idx] - (gtk_shape[rw_idx] - top_height) * sin(prf_pos - root_width);
        gtk_profiler[25] = gtk_shape[Y2_idx] - (gtk_shape[rw_idx] - top_height) * cos(prf_pos - root_width);
        // Right bottom side
        gtk_profiler[31] = LINE;
        gtk_profiler[32] = gtk_shape[X2_idx] - (gtk_shape[rw_idx] - top_height) * sin(prf_pos - root_width);
        gtk_profiler[33] = gtk_shape[Y2_idx] - (gtk_shape[rw_idx] - top_height) * cos(prf_pos - root_width);
        gtk_profiler[34] = gtk_shape[X2_idx] - gtk_shape[rh_idx] * sin(prf_pos - root_width);
        gtk_profiler[35] = gtk_shape[Y2_idx] - gtk_shape[rh_idx] * cos(prf_pos - root_width);
        // Left top side
        gtk_profiler[41] = LINE;
        gtk_profiler[42] = gtk_shape[X1_idx] - gtk_shape[rw_idx] * sin(prf_pos + top_width);
        gtk_profiler[43] = gtk_shape[Y1_idx] - gtk_shape[rw_idx] * cos(prf_pos + top_width);
        gtk_profiler[44] = gtk_shape[X2_idx] - (gtk_shape[rw_idx] - top_height) * sin(prf_pos + root_width);
        gtk_profiler[45] = gtk_shape[Y2_idx] - (gtk_shape[rw_idx] - top_height) * cos(prf_pos + root_width);
        // Left bottom side
        gtk_profiler[51] = LINE;
        gtk_profiler[52] = gtk_shape[X2_idx] - (gtk_shape[rw_idx] - top_height) * sin(prf_pos + root_width);
        gtk_profiler[53] = gtk_shape[Y2_idx] - (gtk_shape[rw_idx] - top_height) * cos(prf_pos + root_width);
        gtk_profiler[54] = gtk_shape[X2_idx] - gtk_shape[rh_idx] * sin(prf_pos + root_width);
        gtk_profiler[55] = gtk_shape[Y2_idx] - gtk_shape[rh_idx] * cos(prf_pos + root_width);
        gtk_profiler[61] = LOOP_BREAK;
    }
    else if (val_ary[WELD_TYPE_PERA] == 1)
    {
        top_width = ((profiler_data[3] * M_PI) / 180);
        top_height = profiler_data[4];
        root_width = ((profiler_data[5] * M_PI) / 180);


        // ********** Double V shape profiler ****************************
        // Right top side
        gtk_profiler[21] = LINE;
        gtk_profiler[22] = gtk_shape[X1_idx] - gtk_shape[rw_idx] * sin(prf_pos - top_width);
        gtk_profiler[23] = gtk_shape[Y1_idx] - gtk_shape[rw_idx] * cos(prf_pos - top_width);
        gtk_profiler[24] = gtk_shape[X1_idx] - (gtk_shape[rw_idx] - top_height) * sin(prf_pos - root_width);
        gtk_profiler[25] = gtk_shape[Y1_idx] - (gtk_shape[rw_idx] - top_height) * cos(prf_pos - root_width);
        // // Right middle side
        gtk_profiler[31] = LINE;
        gtk_profiler[32] = gtk_shape[X1_idx] - (gtk_shape[rw_idx] - top_height) * sin(prf_pos - root_width);
        gtk_profiler[33] = gtk_shape[Y1_idx] - (gtk_shape[rw_idx] - top_height) * cos(prf_pos - root_width);
        gtk_profiler[34] = gtk_shape[X2_idx] - (gtk_shape[rh_idx] + top_height) * sin(prf_pos - root_width);
        gtk_profiler[35] = gtk_shape[Y2_idx] - (gtk_shape[rh_idx] + top_height) * cos(prf_pos - root_width);
        // Right middle side
        gtk_profiler[41] = LINE;
        gtk_profiler[42] = gtk_shape[X2_idx] - (gtk_shape[rh_idx] + top_height) * sin(prf_pos - root_width);
        gtk_profiler[43] = gtk_shape[Y2_idx] - (gtk_shape[rh_idx] + top_height) * cos(prf_pos - root_width);
        gtk_profiler[44] = gtk_shape[X2_idx] - gtk_shape[rh_idx] * sin(prf_pos - top_width);
        gtk_profiler[45] = gtk_shape[Y2_idx] - gtk_shape[rh_idx] * cos(prf_pos - top_width);
        // Left top side
        gtk_profiler[51] = LINE;
        gtk_profiler[52] = gtk_shape[X1_idx] - gtk_shape[rw_idx] * sin(prf_pos + top_width);
        gtk_profiler[53] = gtk_shape[Y1_idx] - gtk_shape[rw_idx] * cos(prf_pos + top_width);
        gtk_profiler[54] = gtk_shape[X1_idx] - (gtk_shape[rw_idx] - top_height) * sin(prf_pos + root_width);
        gtk_profiler[55] = gtk_shape[Y1_idx] - (gtk_shape[rw_idx] - top_height) * cos(prf_pos + root_width);
        // Left middle side
        gtk_profiler[61] = LINE;
        gtk_profiler[62] = gtk_shape[X1_idx] - (gtk_shape[rw_idx] - top_height) * sin(prf_pos + root_width);
        gtk_profiler[63] = gtk_shape[Y1_idx] - (gtk_shape[rw_idx] - top_height) * cos(prf_pos + root_width);
        gtk_profiler[64] = gtk_shape[X2_idx] - (gtk_shape[rh_idx] + top_height) * sin(prf_pos + root_width);
        gtk_profiler[65] = gtk_shape[Y2_idx] - (gtk_shape[rh_idx] + top_height) * cos(prf_pos + root_width);
        // Left bottom side
        gtk_profiler[71] = LINE;
        gtk_profiler[72] = gtk_shape[X2_idx] - (gtk_shape[rh_idx] + top_height) * sin(prf_pos + root_width);
        gtk_profiler[73] = gtk_shape[Y2_idx] - (gtk_shape[rh_idx] + top_height) * cos(prf_pos + root_width);
        gtk_profiler[74] = gtk_shape[X2_idx] - gtk_shape[rh_idx] * sin(prf_pos + top_width);
        gtk_profiler[75] = gtk_shape[Y2_idx] - gtk_shape[rh_idx] * cos(prf_pos + top_width);
        gtk_profiler[81] = LOOP_BREAK;
    }
    else if (val_ary[WELD_TYPE_PERA] == 2)
    {
        top_width = ((profiler_data[6] * M_PI) / 180);
        top_height = profiler_data[7];
        root_width = ((profiler_data[8] * M_PI) / 180);

        // ********** J shape profiler ***********************************
        // Right top side
        gtk_profiler[21] = LINE;
        gtk_profiler[22] = gtk_shape[X1_idx] - gtk_shape[rw_idx] * sin(prf_pos - top_width);
        gtk_profiler[23] = gtk_shape[Y1_idx] - gtk_shape[rw_idx] * cos(prf_pos - top_width);
        gtk_profiler[24] = gtk_profiler[22] + top_height * sin(0 + prf_pos);
        gtk_profiler[25] = gtk_profiler[23] + top_height * cos(0 + prf_pos);
        // Right bottom side
        gtk_profiler[31] = LINE;
        gtk_profiler[32] = gtk_shape[X2_idx] - gtk_shape[rh_idx] * sin(prf_pos - root_width);
        gtk_profiler[33] = gtk_shape[Y2_idx] - gtk_shape[rh_idx] * cos(prf_pos - root_width);
        gtk_profiler[34] = gtk_profiler[32] - ((gtk_shape[rw_idx] - gtk_shape[rh_idx]) - top_height) * sin(0 + prf_pos);
        gtk_profiler[35] = gtk_profiler[33] - ((gtk_shape[rw_idx] - gtk_shape[rh_idx]) - top_height) * cos(0 + prf_pos);
        // Right middle side
        gtk_profiler[41] = CURVE;
        gtk_profiler[42] = gtk_profiler[24];
        gtk_profiler[43] = gtk_profiler[25];
        gtk_profiler[44] = gtk_profiler[34] + 5 * sin(0 + ((45 * M_PI) / 180));
        gtk_profiler[45] = gtk_profiler[35] + 5 * cos(0 + ((45 * M_PI) / 180));
        gtk_profiler[46] = gtk_profiler[34];
        gtk_profiler[47] = gtk_profiler[35];

        // Left top side
        gtk_profiler[51] = LINE;
        gtk_profiler[52] = gtk_shape[X1_idx] - gtk_shape[rw_idx] * sin(prf_pos + top_width);
        gtk_profiler[53] = gtk_shape[Y1_idx] - gtk_shape[rw_idx] * cos(prf_pos + top_width);
        gtk_profiler[54] = gtk_profiler[52] + top_height * sin(0 + prf_pos);
        gtk_profiler[55] = gtk_profiler[53] + top_height * cos(0 + prf_pos);
        // Left bottom side
        gtk_profiler[61] = LINE;
        gtk_profiler[62] = gtk_shape[X2_idx] - gtk_shape[rh_idx] * sin(prf_pos + root_width);
        gtk_profiler[63] = gtk_shape[Y2_idx] - gtk_shape[rh_idx] * cos(prf_pos + root_width);
        gtk_profiler[64] = gtk_profiler[62] - ((gtk_shape[rw_idx] - gtk_shape[rh_idx]) - top_height) * sin(0 + prf_pos);
        gtk_profiler[65] = gtk_profiler[63] - ((gtk_shape[rw_idx] - gtk_shape[rh_idx]) - top_height) * cos(0 + prf_pos);
        // Left middle side
        gtk_profiler[71] = CURVE;
        gtk_profiler[72] = gtk_profiler[54];
        gtk_profiler[73] = gtk_profiler[55];
        gtk_profiler[74] = gtk_profiler[64] + 5 * sin(0 + ((45 * M_PI) / 180));
        gtk_profiler[75] = gtk_profiler[65] + 5 * cos(0 + ((45 * M_PI) / 180));
        gtk_profiler[76] = gtk_profiler[64];
        gtk_profiler[77] = gtk_profiler[65];

        gtk_profiler[81] = LOOP_BREAK;
    }
}

void gtk_profiler_for_solid_rod(void)
{
    double top_width, top_height, root_width, prf_pos;

    memset(gtk_profiler, 0, sizeof(gtk_profiler));

    // ********** Center line **********************
    prf_pos = ((val_ary[WPROF_POS_PERA] * M_PI) / 180);

    gtk_profiler[1] = LINE;
    gtk_profiler[2] = gtk_shape[X1_idx] - gtk_shape[rw_idx] * sin(prf_pos);
    gtk_profiler[3] = gtk_shape[Y1_idx] - gtk_shape[rw_idx] * cos(prf_pos);
    gtk_profiler[4] = gtk_shape[X1_idx] + gtk_shape[rw_idx] * sin(prf_pos);
    gtk_profiler[5] = gtk_shape[Y1_idx] + gtk_shape[rw_idx] * cos(prf_pos);

    gtk_profiler[11] = LOOP_BREAK;

    if (val_ary[WELD_TYPE_PERA] == 0)
    {
        top_width = ((profiler_data[0] * M_PI) / 180);
        root_width = ((profiler_data[2] * M_PI) / 180);
        top_height = profiler_data[1];

        // ********** V shape profiler ***********************************
        gtk_profiler[21] = LINE;
        gtk_profiler[22] = gtk_shape[X1_idx] - gtk_shape[rw_idx] * sin(prf_pos - top_width);
        gtk_profiler[23] = gtk_shape[Y1_idx] - gtk_shape[rw_idx] * cos(prf_pos - top_width);
        gtk_profiler[24] = gtk_profiler[2] + (gtk_shape[rw_idx] - top_height) * sin(prf_pos + root_width);
        gtk_profiler[25] = gtk_profiler[3] + (gtk_shape[rw_idx] - top_height) * cos(prf_pos + root_width);
        // Right bottom side
        gtk_profiler[31] = LINE;
        gtk_profiler[32] = gtk_profiler[2] + (gtk_shape[rw_idx] - top_height) * sin(prf_pos + root_width);
        gtk_profiler[33] = gtk_profiler[3] + (gtk_shape[rw_idx] - top_height) * cos(prf_pos + root_width);
        gtk_profiler[34] = gtk_shape[X1_idx] + gtk_shape[rw_idx] * sin(prf_pos + root_width);
        gtk_profiler[35] = gtk_shape[Y1_idx] + gtk_shape[rw_idx] * cos(prf_pos + root_width);
        // Left top side
        gtk_profiler[41] = LINE;
        gtk_profiler[42] = gtk_shape[X1_idx] - gtk_shape[rw_idx] * sin(prf_pos + top_width);
        gtk_profiler[43] = gtk_shape[Y1_idx] - gtk_shape[rw_idx] * cos(prf_pos + top_width);
        gtk_profiler[44] = gtk_profiler[2] + (gtk_shape[rw_idx] - top_height) * sin(prf_pos - root_width);
        gtk_profiler[45] = gtk_profiler[3] + (gtk_shape[rw_idx] - top_height) * cos(prf_pos - root_width);
        // Left bottom side
        gtk_profiler[51] = LINE;
        gtk_profiler[52] = gtk_profiler[2] + (gtk_shape[rw_idx] - top_height) * sin(prf_pos - root_width);
        gtk_profiler[53] = gtk_profiler[3] + (gtk_shape[rw_idx] - top_height) * cos(prf_pos - root_width);
        gtk_profiler[54] = gtk_shape[X1_idx] + gtk_shape[rw_idx] * sin(prf_pos - root_width);
        gtk_profiler[55] = gtk_shape[Y1_idx] + gtk_shape[rw_idx] * cos(prf_pos - root_width);
        gtk_profiler[61] = LOOP_BREAK;
    }
    else if (val_ary[WELD_TYPE_PERA] == 1)
    {
        // ********** Double V shape profiler ****************************
        top_width = ((profiler_data[3] * M_PI) / 180);
        root_width = ((profiler_data[5] * M_PI) / 180);
        top_height = profiler_data[4];

        // ********** V shape profiler ***********************************
        // Right top side
        gtk_profiler[21] = LINE;
        gtk_profiler[22] = gtk_shape[X1_idx] - gtk_shape[rw_idx] * sin(prf_pos - top_width);
        gtk_profiler[23] = gtk_shape[Y1_idx] - gtk_shape[rw_idx] * cos(prf_pos - top_width);
        gtk_profiler[24] = gtk_profiler[2] + (gtk_shape[rw_idx] - top_height) * sin(prf_pos + root_width);
        gtk_profiler[25] = gtk_profiler[3] + (gtk_shape[rw_idx] - top_height) * cos(prf_pos + root_width);
        // Right middle side
        gtk_profiler[31] = LINE;
        gtk_profiler[32] = gtk_profiler[2] + (gtk_shape[rw_idx] - top_height) * sin(prf_pos + root_width);
        gtk_profiler[33] = gtk_profiler[3] + (gtk_shape[rw_idx] - top_height) * cos(prf_pos + root_width);
        gtk_profiler[34] = gtk_profiler[4] - (gtk_shape[rw_idx] - top_height) * sin(prf_pos - root_width);
        gtk_profiler[35] = gtk_profiler[5] - (gtk_shape[rw_idx] - top_height) * cos(prf_pos - root_width);
        // Right bottom side
        gtk_profiler[41] = LINE;
        gtk_profiler[42] = gtk_profiler[4] - (gtk_shape[rw_idx] - top_height) * sin(prf_pos - root_width);
        gtk_profiler[43] = gtk_profiler[5] - (gtk_shape[rw_idx] - top_height) * cos(prf_pos - root_width);
        gtk_profiler[44] = gtk_shape[X1_idx] + gtk_shape[rw_idx] * sin(prf_pos + top_width);
        gtk_profiler[45] = gtk_shape[Y1_idx] + gtk_shape[rw_idx] * cos(prf_pos + top_width);

        // Left top side
        gtk_profiler[51] = LINE;
        gtk_profiler[52] = gtk_shape[X1_idx] - gtk_shape[rw_idx] * sin(prf_pos + top_width);
        gtk_profiler[53] = gtk_shape[Y1_idx] - gtk_shape[rw_idx] * cos(prf_pos + top_width);
        gtk_profiler[54] = gtk_profiler[2] + (gtk_shape[rw_idx] - top_height) * sin(prf_pos - root_width);
        gtk_profiler[55] = gtk_profiler[3] + (gtk_shape[rw_idx] - top_height) * cos(prf_pos - root_width);
        // Left middle side
        gtk_profiler[61] = LINE;
        gtk_profiler[62] = gtk_profiler[2] + (gtk_shape[rw_idx] - top_height) * sin(prf_pos - root_width);
        gtk_profiler[63] = gtk_profiler[3] + (gtk_shape[rw_idx] - top_height) * cos(prf_pos - root_width);
        gtk_profiler[64] = gtk_profiler[4] - (gtk_shape[rw_idx] - top_height) * sin(prf_pos + root_width);
        gtk_profiler[65] = gtk_profiler[5] - (gtk_shape[rw_idx] - top_height) * cos(prf_pos + root_width);
        // Left bottom side
        gtk_profiler[71] = LINE;
        gtk_profiler[72] = gtk_profiler[4] - (gtk_shape[rw_idx] - top_height) * sin(prf_pos + root_width);
        gtk_profiler[73] = gtk_profiler[5] - (gtk_shape[rw_idx] - top_height) * cos(prf_pos + root_width);
        gtk_profiler[74] = gtk_shape[X1_idx] + gtk_shape[rw_idx] * sin(prf_pos - top_width);
        gtk_profiler[75] = gtk_shape[Y1_idx] + gtk_shape[rw_idx] * cos(prf_pos - top_width);
        gtk_profiler[81] = LOOP_BREAK;
    }
    else if (val_ary[WELD_TYPE_PERA] == 2)
    {
        top_width = ((profiler_data[6] * M_PI) / 180);
        root_width = ((profiler_data[8] * M_PI) / 180);
        top_height = profiler_data[7];
    
        // ********** J shape profiler ***********************************
        // Right top side
        gtk_profiler[21] = LINE;
        gtk_profiler[22] = gtk_shape[X1_idx] - gtk_shape[rw_idx] * sin(prf_pos - top_width);
        gtk_profiler[23] = gtk_shape[Y1_idx] - gtk_shape[rw_idx] * cos(prf_pos - top_width);
        gtk_profiler[24] = gtk_profiler[2] + (gtk_shape[rw_idx] - top_height) * sin(prf_pos + top_width);
        gtk_profiler[25] = gtk_profiler[3] + (gtk_shape[rw_idx] - top_height) * cos(prf_pos + top_width);
        // Right middle side
        gtk_profiler[31] = CURVE;
        gtk_profiler[32] = gtk_profiler[24];
        gtk_profiler[33] = gtk_profiler[25];
        gtk_profiler[34] = gtk_profiler[24] +  5 * sin(top_width);
        gtk_profiler[35] = gtk_profiler[25] +  5 * cos(top_width);
        gtk_profiler[36] = gtk_profiler[2] + (gtk_shape[rw_idx] - top_height) * sin(prf_pos + root_width);
        gtk_profiler[37] = gtk_profiler[3] + (gtk_shape[rw_idx] - top_height) * cos(prf_pos + root_width);
        // Right bottom side
        gtk_profiler[41] = LINE;
        gtk_profiler[42] = gtk_profiler[2] + (gtk_shape[rw_idx] - top_height) * sin(prf_pos + root_width);
        gtk_profiler[43] = gtk_profiler[3] + (gtk_shape[rw_idx] - top_height) * cos(prf_pos + root_width);
        gtk_profiler[44] = gtk_shape[X1_idx] + gtk_shape[rw_idx] * sin(prf_pos + root_width);
        gtk_profiler[45] = gtk_shape[Y1_idx] + gtk_shape[rw_idx] * cos(prf_pos + root_width);

        // Left top side
        gtk_profiler[51] = LINE;
        gtk_profiler[52] = gtk_shape[X1_idx] - gtk_shape[rw_idx] * sin(prf_pos + top_width);
        gtk_profiler[53] = gtk_shape[Y1_idx] - gtk_shape[rw_idx] * cos(prf_pos + top_width);
        gtk_profiler[54] = gtk_profiler[2] + (gtk_shape[rw_idx] - top_height) * sin(prf_pos - top_width);
        gtk_profiler[55] = gtk_profiler[3] + (gtk_shape[rw_idx] - top_height) * cos(prf_pos - top_width);
        // Left middle side
        gtk_profiler[61] = CURVE;
        gtk_profiler[62] = gtk_profiler[54];
        gtk_profiler[63] = gtk_profiler[55];
        gtk_profiler[64] = gtk_profiler[54] +  5 * sin(top_width);
        gtk_profiler[65] = gtk_profiler[55] +  5 * cos(top_width);
        gtk_profiler[66] = gtk_profiler[2] + (gtk_shape[rw_idx] - top_height) * sin(prf_pos - root_width);
        gtk_profiler[67] = gtk_profiler[3] + (gtk_shape[rw_idx] - top_height) * cos(prf_pos - root_width);
        // Left bottom side
        gtk_profiler[71] = LINE;
        gtk_profiler[72] = gtk_profiler[2] + (gtk_shape[rw_idx] - top_height) * sin(prf_pos - root_width);
        gtk_profiler[73] = gtk_profiler[3] + (gtk_shape[rw_idx] - top_height) * cos(prf_pos - root_width);
        gtk_profiler[74] = gtk_shape[X1_idx] + gtk_shape[rw_idx] * sin(prf_pos - root_width);
        gtk_profiler[75] = gtk_shape[Y1_idx] + gtk_shape[rw_idx] * cos(prf_pos - root_width);

        gtk_profiler[81] = LOOP_BREAK;
    }
}

void init_profiler_value(void)
{
    if (val_ary[WELD_TYPE_PERA] == 0)
    {
        profiler_data[0] = val_ary[TOP_WIDTH_PERA];
        profiler_data[1] = val_ary[TOP_HEIGHT_PERA];
        profiler_data[2] = val_ary[ROOT_WIDTH_PERA];
    }
    else if (val_ary[WELD_TYPE_PERA] == 1)
    {
        profiler_data[3] = val_ary[TOP_WIDTH_PERA];
        profiler_data[4] = val_ary[TOP_HEIGHT_PERA];
        profiler_data[5] = val_ary[ROOT_WIDTH_PERA];
    }
    else if (val_ary[WELD_TYPE_PERA] == 2)
    {
        profiler_data[6] = val_ary[TOP_WIDTH_PERA];
        profiler_data[7] = val_ary[TOP_HEIGHT_PERA];
        profiler_data[8] = val_ary[ROOT_WIDTH_PERA];
    }

    //*****************************************************************************************
    memset(gtk_profiler, 0, sizeof(gtk_profiler));
    memset(profiler_cntr_line, 0, sizeof(profiler_cntr_line));

    // ********** OprnGL Center line **********************
    profiler_cntr_line[0] = LINE;
    profiler_cntr_line[1] = ogl_shape[2] + val_ary[WPROF_POS_PERA];
    profiler_cntr_line[2] = ogl_shape[3];
    profiler_cntr_line[3] = ogl_shape[2] + val_ary[WPROF_POS_PERA];
    profiler_cntr_line[4] = ogl_shape[3] + ogl_shape[5];
    profiler_cntr_line[10] = LOOP_BREAK;

    if (val_ary[OBJ_SHAPE_PERA] == 0)
        gtk_profiler_for_flat_plate();
    else if (val_ary[OBJ_SHAPE_PERA] == 1 || val_ary[OBJ_SHAPE_PERA] == 2)
        gtk_profiler_for_hollow_circle();
    else if (val_ary[OBJ_SHAPE_PERA] == 3)
        gtk_profiler_for_solid_rod();
}

void ogl_profiler_for_flat_plate(void)
{
    memset(profiler_cntr_line, 0, sizeof(profiler_cntr_line));

    //************* Center line **********************************
    profiler_cntr_line[0] = LINE;
    profiler_cntr_line[1] = ogl_shape[2] + val_ary[WPROF_POS_PERA];
    profiler_cntr_line[2] = ogl_shape[3];
    profiler_cntr_line[3] = ogl_shape[2] + val_ary[WPROF_POS_PERA];
    profiler_cntr_line[4] = ogl_shape[3] + ogl_shape[5];

    profiler_cntr_line[10] = LOOP_BREAK;

    if (val_ary[WELD_TYPE_PERA] == 0)
    {
        memset(ogl_profiler, 0, sizeof(ogl_profiler));
        // ********** V shape profiler ***********************************
        // Right top side
        ogl_profiler[1] = LINE;
        ogl_profiler[2] = profiler_cntr_line[1] + val_ary[TOP_WIDTH_PERA];
        ogl_profiler[3] = profiler_cntr_line[2];
        ogl_profiler[4] = profiler_cntr_line[1] + val_ary[ROOT_WIDTH_PERA];
        ogl_profiler[5] = profiler_cntr_line[2] + val_ary[TOP_HEIGHT_PERA];
        // Right bottom side
        ogl_profiler[11] = LINE;
        ogl_profiler[12] = profiler_cntr_line[1] + val_ary[ROOT_WIDTH_PERA];
        ogl_profiler[13] = profiler_cntr_line[2] + val_ary[TOP_HEIGHT_PERA];
        ogl_profiler[14] = profiler_cntr_line[3] + val_ary[ROOT_WIDTH_PERA];
        ogl_profiler[15] = profiler_cntr_line[4];
        // Left top side
        ogl_profiler[21] = LINE;
        ogl_profiler[22] = profiler_cntr_line[1] - val_ary[TOP_WIDTH_PERA];
        ogl_profiler[23] = profiler_cntr_line[2];
        ogl_profiler[24] = profiler_cntr_line[1] - val_ary[ROOT_WIDTH_PERA];
        ogl_profiler[25] = profiler_cntr_line[2] + val_ary[TOP_HEIGHT_PERA];
        // Left bottom side
        ogl_profiler[31] = LINE;
        ogl_profiler[32] = profiler_cntr_line[1] - val_ary[ROOT_WIDTH_PERA];
        ogl_profiler[33] = profiler_cntr_line[2] + val_ary[TOP_HEIGHT_PERA];
        ogl_profiler[34] = profiler_cntr_line[3] - val_ary[ROOT_WIDTH_PERA];
        ogl_profiler[35] = profiler_cntr_line[4];
        // loop break
        ogl_profiler[41] = LOOP_BREAK;
    }
    else if (val_ary[WELD_TYPE_PERA] == 1)
    {
        memset(ogl_profiler, 0, sizeof(ogl_profiler));
        // ********** Double V shape profiler ***********************************
        // Right top side
        ogl_profiler[1] = LINE;
        ogl_profiler[2] = profiler_cntr_line[1] + val_ary[TOP_WIDTH_PERA];
        ogl_profiler[3] = profiler_cntr_line[2];
        ogl_profiler[4] = profiler_cntr_line[1] + val_ary[ROOT_WIDTH_PERA];
        ogl_profiler[5] = profiler_cntr_line[2] + val_ary[TOP_HEIGHT_PERA];
        // Right middle side
        ogl_profiler[11] = LINE;
        ogl_profiler[12] = profiler_cntr_line[1] + val_ary[ROOT_WIDTH_PERA];
        ogl_profiler[13] = profiler_cntr_line[2] + val_ary[TOP_HEIGHT_PERA];
        ogl_profiler[14] = profiler_cntr_line[3] + val_ary[ROOT_WIDTH_PERA];
        ogl_profiler[15] = profiler_cntr_line[4] - val_ary[TOP_HEIGHT_PERA];
        // Right bottom side
        ogl_profiler[21] = LINE;
        ogl_profiler[22] = profiler_cntr_line[3] + val_ary[ROOT_WIDTH_PERA];
        ogl_profiler[23] = profiler_cntr_line[4] - val_ary[TOP_HEIGHT_PERA];
        ogl_profiler[24] = profiler_cntr_line[1] + val_ary[TOP_WIDTH_PERA];
        ogl_profiler[25] = profiler_cntr_line[4];

        // Left top side
        ogl_profiler[31] = LINE;
        ogl_profiler[32] = profiler_cntr_line[1] - val_ary[TOP_WIDTH_PERA];
        ogl_profiler[33] = profiler_cntr_line[2];
        ogl_profiler[34] = profiler_cntr_line[1] - val_ary[ROOT_WIDTH_PERA];
        ogl_profiler[35] = profiler_cntr_line[2] + val_ary[TOP_HEIGHT_PERA];
        // Left middle side
        ogl_profiler[41] = LINE;
        ogl_profiler[42] = profiler_cntr_line[1] - val_ary[ROOT_WIDTH_PERA];
        ogl_profiler[43] = profiler_cntr_line[2] + val_ary[TOP_HEIGHT_PERA];
        ogl_profiler[44] = profiler_cntr_line[3] - val_ary[ROOT_WIDTH_PERA];
        ogl_profiler[45] = profiler_cntr_line[4] - val_ary[TOP_HEIGHT_PERA];
        // Left bottom side
        ogl_profiler[51] = LINE;
        ogl_profiler[52] = profiler_cntr_line[3] - val_ary[ROOT_WIDTH_PERA];
        ogl_profiler[53] = profiler_cntr_line[4] - val_ary[TOP_HEIGHT_PERA];
        ogl_profiler[54] = profiler_cntr_line[1] - val_ary[TOP_WIDTH_PERA];
        ogl_profiler[55] = profiler_cntr_line[4];
        // loop break
        ogl_profiler[61] = LOOP_BREAK;
    }
    else if (val_ary[WELD_TYPE_PERA] == 2)
    {
        memset(ogl_profiler, 0, sizeof(ogl_profiler));
        // ********** J shape profiler ***********************************
        ogl_profiler[1] = LINE;
        ogl_profiler[2] = profiler_cntr_line[1] + val_ary[TOP_WIDTH_PERA];
        ogl_profiler[3] = profiler_cntr_line[2];
        ogl_profiler[4] = profiler_cntr_line[1] + val_ary[TOP_WIDTH_PERA];
        ogl_profiler[5] = profiler_cntr_line[2] + val_ary[TOP_HEIGHT_PERA];

        ogl_profiler[11] = CURVE;
        ogl_profiler[12] = profiler_cntr_line[1] + val_ary[TOP_WIDTH_PERA];
        ogl_profiler[13] = profiler_cntr_line[2] + val_ary[TOP_HEIGHT_PERA];
        ogl_profiler[14] = profiler_cntr_line[1] + val_ary[TOP_WIDTH_PERA] - 5;
        ogl_profiler[15] = profiler_cntr_line[2] + val_ary[TOP_HEIGHT_PERA] + 5;
        ogl_profiler[16] = profiler_cntr_line[3] + val_ary[ROOT_WIDTH_PERA];
        ogl_profiler[17] = profiler_cntr_line[4] - (ogl_shape[5] - val_ary[TOP_HEIGHT_PERA]);

        ogl_profiler[21] = LINE;
        ogl_profiler[22] = profiler_cntr_line[3] + val_ary[ROOT_WIDTH_PERA];
        ogl_profiler[23] = profiler_cntr_line[4] - (ogl_shape[5] - val_ary[TOP_HEIGHT_PERA]);
        ogl_profiler[24] = profiler_cntr_line[3] + val_ary[ROOT_WIDTH_PERA];
        ogl_profiler[25] = profiler_cntr_line[4];

        // ********** J shape profiler ***********************************
        ogl_profiler[31] = LINE;
        ogl_profiler[32] = profiler_cntr_line[1] - val_ary[TOP_WIDTH_PERA];
        ogl_profiler[33] = profiler_cntr_line[2];
        ogl_profiler[34] = profiler_cntr_line[1] - val_ary[TOP_WIDTH_PERA];
        ogl_profiler[35] = profiler_cntr_line[2] + val_ary[TOP_HEIGHT_PERA];

        ogl_profiler[41] = CURVE;
        ogl_profiler[42] = profiler_cntr_line[1] - val_ary[TOP_WIDTH_PERA];
        ogl_profiler[43] = profiler_cntr_line[2] + val_ary[TOP_HEIGHT_PERA];
        ogl_profiler[44] = profiler_cntr_line[1] - val_ary[TOP_WIDTH_PERA] + 5;
        ogl_profiler[45] = profiler_cntr_line[2] + val_ary[TOP_HEIGHT_PERA] + 5;
        ogl_profiler[46] = profiler_cntr_line[3] - val_ary[ROOT_WIDTH_PERA];
        ogl_profiler[47] = profiler_cntr_line[4] - (ogl_shape[5] - val_ary[TOP_HEIGHT_PERA]);

        ogl_profiler[51] = LINE;
        ogl_profiler[52] = profiler_cntr_line[3] - val_ary[ROOT_WIDTH_PERA];
        ogl_profiler[53] = profiler_cntr_line[4] - (ogl_shape[5] - val_ary[TOP_HEIGHT_PERA]);
        ogl_profiler[54] = profiler_cntr_line[3] - val_ary[ROOT_WIDTH_PERA];
        ogl_profiler[55] = profiler_cntr_line[4];

        ogl_profiler[61] = LOOP_BREAK;
    }
}

void ogl_profiler_for_hollow_circle(void)
{
    memset(profiler_cntr_line, 0, sizeof(profiler_cntr_line));
    memset(ogl_profiler, 0, sizeof(ogl_profiler));

    double prf_pos = (val_ary[WPROF_POS_PERA] * M_PI) / 180.0;
    double top_width = ((val_ary[TOP_WIDTH_PERA] * M_PI) / 180);
    double root_width = ((val_ary[ROOT_WIDTH_PERA] * M_PI) / 180);
    double top_height = val_ary[TOP_HEIGHT_PERA];

    //************* Center line **********************************
    profiler_cntr_line[0] = LINE;
    profiler_cntr_line[1] = ogl_shape[2] - ogl_shape[4] * sin(prf_pos);
    profiler_cntr_line[2] = ogl_shape[3] - ogl_shape[4] * cos(prf_pos);
    profiler_cntr_line[3] = ogl_shape[12] - ogl_shape[14] * sin(prf_pos);
    profiler_cntr_line[4] = ogl_shape[13] - ogl_shape[14] * cos(prf_pos);

    profiler_cntr_line[10] = LOOP_BREAK;

    if (val_ary[WELD_TYPE_PERA] == 0)
    {
        // ********** V shape profiler ***********************************
        // Right top side
        ogl_profiler[1] = LINE;
        ogl_profiler[2] = ogl_shape[2] - ogl_shape[4] * sin(prf_pos - top_width);
        ogl_profiler[3] = ogl_shape[3] - ogl_shape[4] * cos(prf_pos - top_width);
        ogl_profiler[4] = ogl_shape[12] - (ogl_shape[4] - top_height) * sin(prf_pos - root_width);
        ogl_profiler[5] = ogl_shape[13] - (ogl_shape[4] - top_height) * cos(prf_pos - root_width);
        // Right bottom side
        ogl_profiler[11] = LINE;
        ogl_profiler[12] = ogl_shape[12] - (ogl_shape[4] - top_height) * sin(prf_pos - root_width);
        ogl_profiler[13] = ogl_shape[13] - (ogl_shape[4] - top_height) * cos(prf_pos - root_width);
        ogl_profiler[14] = ogl_shape[12] - ogl_shape[14] * sin(prf_pos - root_width);
        ogl_profiler[15] = ogl_shape[13] - ogl_shape[14] * cos(prf_pos - root_width);

        // Left top side
        ogl_profiler[21] = LINE;
        ogl_profiler[22] = ogl_shape[2] - ogl_shape[4] * sin(prf_pos + top_width);
        ogl_profiler[23] = ogl_shape[3] - ogl_shape[4] * cos(prf_pos + top_width);
        ogl_profiler[24] = ogl_shape[12] - (ogl_shape[4] - top_height) * sin(prf_pos + root_width);
        ogl_profiler[25] = ogl_shape[13] - (ogl_shape[4] - top_height) * cos(prf_pos + root_width);
        // Left bottom side
        ogl_profiler[31] = LINE;
        ogl_profiler[32] = ogl_shape[12] - (ogl_shape[4] - top_height) * sin(prf_pos + root_width);
        ogl_profiler[33] = ogl_shape[13] - (ogl_shape[4] - top_height) * cos(prf_pos + root_width);
        ogl_profiler[34] = ogl_shape[12] - ogl_shape[14] * sin(prf_pos + root_width);
        ogl_profiler[35] = ogl_shape[13] - ogl_shape[14] * cos(prf_pos + root_width);
        // loop break
        ogl_profiler[41] = LOOP_BREAK;
    }
    else if (val_ary[WELD_TYPE_PERA] == 1)
    {
        // ********** Double V shape profiler ***********************************
        // Right top side
        ogl_profiler[1] = LINE;
        ogl_profiler[2] = ogl_shape[2] - ogl_shape[4] * sin(prf_pos - top_width);
        ogl_profiler[3] = ogl_shape[3] - ogl_shape[4] * cos(prf_pos - top_width);
        ogl_profiler[4] = ogl_shape[2] - (ogl_shape[4] - top_height) * sin(prf_pos - root_width);
        ogl_profiler[5] = ogl_shape[3] - (ogl_shape[4] - top_height) * cos(prf_pos - root_width);
        // Right middle side
        ogl_profiler[11] = LINE;
        ogl_profiler[12] = ogl_shape[2] - (ogl_shape[4] - top_height) * sin(prf_pos - root_width);
        ogl_profiler[13] = ogl_shape[3] - (ogl_shape[4] - top_height) * cos(prf_pos - root_width);
        ogl_profiler[14] = ogl_shape[12] - (ogl_shape[14] + top_height) * sin(prf_pos - root_width);
        ogl_profiler[15] = ogl_shape[13] - (ogl_shape[14] + top_height) * cos(prf_pos - root_width);
        // Right bottom side
        ogl_profiler[21] = LINE;
        ogl_profiler[22] = ogl_shape[12] - (ogl_shape[14] + top_height) * sin(prf_pos - root_width);
        ogl_profiler[23] = ogl_shape[13] - (ogl_shape[14] + top_height) * cos(prf_pos - root_width);
        ogl_profiler[24] = ogl_shape[12] - ogl_shape[14] * sin(prf_pos - top_width);
        ogl_profiler[25] = ogl_shape[13] - ogl_shape[14] * cos(prf_pos - top_width);

        // Left top side
        ogl_profiler[31] = LINE;
        ogl_profiler[32] = ogl_shape[2] - ogl_shape[4] * sin(prf_pos + top_width);
        ogl_profiler[33] = ogl_shape[3] - ogl_shape[4] * cos(prf_pos + top_width);
        ogl_profiler[34] = ogl_shape[2] - (ogl_shape[4] - top_height) * sin(prf_pos + root_width);
        ogl_profiler[35] = ogl_shape[3] - (ogl_shape[4] - top_height) * cos(prf_pos + root_width);
        // Left middle side
        ogl_profiler[41] = LINE;
        ogl_profiler[42] = ogl_shape[2] - (ogl_shape[4] - top_height) * sin(prf_pos + root_width);
        ogl_profiler[43] = ogl_shape[3] - (ogl_shape[4] - top_height) * cos(prf_pos + root_width);
        ogl_profiler[44] = ogl_shape[12] - (ogl_shape[14] + top_height) * sin(prf_pos + root_width);
        ogl_profiler[45] = ogl_shape[13] - (ogl_shape[14] + top_height) * cos(prf_pos + root_width);
        // Left bottom side
        ogl_profiler[51] = LINE;
        ogl_profiler[52] = ogl_shape[12] - (ogl_shape[14] + top_height) * sin(prf_pos + root_width);
        ogl_profiler[53] = ogl_shape[13] - (ogl_shape[14] + top_height) * cos(prf_pos + root_width);
        ogl_profiler[54] = ogl_shape[12] - ogl_shape[14] * sin(prf_pos + top_width);
        ogl_profiler[55] = ogl_shape[13] - ogl_shape[14] * cos(prf_pos + top_width);
        // loop break
        ogl_profiler[61] = LOOP_BREAK;
    }
    else if (val_ary[WELD_TYPE_PERA] == 2)
    {
        // ********** J shape profiler ***********************************
        // Right top side
        ogl_profiler[1] = LINE;
        ogl_profiler[2] = ogl_shape[2] - ogl_shape[4] * sin(prf_pos - top_width);
        ogl_profiler[3] = ogl_shape[3] - ogl_shape[4] * cos(prf_pos - top_width);
        ogl_profiler[4] = ogl_profiler[2] + top_height * sin(0 + prf_pos);
        ogl_profiler[5] = ogl_profiler[3] + top_height * cos(0 + prf_pos);
        // Right bottom side
        ogl_profiler[11] = LINE;
        ogl_profiler[12] = ogl_shape[12] - ogl_shape[14] * sin(prf_pos - root_width);
        ogl_profiler[13] = ogl_shape[13] - ogl_shape[14] * cos(prf_pos - root_width);
        ogl_profiler[14] = ogl_profiler[12] - ((ogl_shape[4] - ogl_shape[14]) - top_height) * sin(0 + prf_pos);
        ogl_profiler[15] = ogl_profiler[13] - ((ogl_shape[4] - ogl_shape[14]) - top_height) * cos(0 + prf_pos);
        // Right middle side
        ogl_profiler[21] = CURVE;
        ogl_profiler[22] = ogl_profiler[4];
        ogl_profiler[23] = ogl_profiler[5];
        ogl_profiler[24] = ogl_profiler[14] + 5 * sin(0 + ((45 * M_PI) / 180));
        ogl_profiler[25] = ogl_profiler[15] + 5 * cos(0 + ((45 * M_PI) / 180));
        ogl_profiler[26] = ogl_profiler[14];
        ogl_profiler[27] = ogl_profiler[15];

        // Left top side
        ogl_profiler[31] = LINE;
        ogl_profiler[32] = ogl_shape[2] - ogl_shape[4] * sin(prf_pos + top_width);
        ogl_profiler[33] = ogl_shape[3] - ogl_shape[4] * cos(prf_pos + top_width);
        ogl_profiler[34] = ogl_profiler[32] + top_height * sin(0 + prf_pos);
        ogl_profiler[35] = ogl_profiler[33] + top_height * cos(0 + prf_pos);
        // Left bottom side
        ogl_profiler[41] = LINE;
        ogl_profiler[42] = ogl_shape[12] - ogl_shape[14] * sin(prf_pos + root_width);
        ogl_profiler[43] = ogl_shape[13] - ogl_shape[14] * cos(prf_pos + root_width);
        ogl_profiler[44] = ogl_profiler[42] - ((ogl_shape[4] - ogl_shape[14]) - top_height) * sin(0 + prf_pos);
        ogl_profiler[45] = ogl_profiler[43] - ((ogl_shape[4] - ogl_shape[14]) - top_height) * cos(0 + prf_pos);
        // Left middle side
        ogl_profiler[51] = CURVE;
        ogl_profiler[52] = ogl_profiler[34];
        ogl_profiler[53] = ogl_profiler[35];
        ogl_profiler[54] = ogl_profiler[44] + 5 * sin(0 + ((45 * M_PI) / 180));
        ogl_profiler[55] = ogl_profiler[45] + 5 * cos(0 + ((45 * M_PI) / 180));
        ogl_profiler[56] = ogl_profiler[44];
        ogl_profiler[57] = ogl_profiler[45];
        // loop break
        ogl_profiler[61] = LOOP_BREAK;
    }
}

void ogl_profiler_for_solid_rod(void)
{
    memset(profiler_cntr_line, 0, sizeof(profiler_cntr_line));
    memset(ogl_profiler, 0, sizeof(ogl_profiler));

    double top_height;
    double prf_pos = (val_ary[WPROF_POS_PERA] * M_PI) / 180.0;
    double top_width = ((val_ary[TOP_WIDTH_PERA] * M_PI) / 180);
    double root_width = ((val_ary[ROOT_WIDTH_PERA] * M_PI) / 180);

    //************* Center line **********************************
    profiler_cntr_line[0] = LINE;
    profiler_cntr_line[1] = ogl_shape[2] - ogl_shape[4] * sin(prf_pos);
    profiler_cntr_line[2] = ogl_shape[3] - ogl_shape[4] * cos(prf_pos);
    profiler_cntr_line[3] = ogl_shape[2] + ogl_shape[4] * sin(prf_pos);
    profiler_cntr_line[4] = ogl_shape[3] + ogl_shape[4] * cos(prf_pos);

    profiler_cntr_line[10] = LOOP_BREAK;

    if (val_ary[WELD_TYPE_PERA] == 0)
    {
        top_height = profiler_data[1];
        // ********** V shape profiler ***********************************
        ogl_profiler[1] = LINE;
        ogl_profiler[2] = ogl_shape[2] - ogl_shape[4] * sin(prf_pos - top_width);
        ogl_profiler[3] = ogl_shape[3] - ogl_shape[4] * cos(prf_pos - top_width);
        ogl_profiler[4] = profiler_cntr_line[1] + (ogl_shape[4] - top_height) * sin(prf_pos + root_width);
        ogl_profiler[5] = profiler_cntr_line[2] + (ogl_shape[4] - top_height) * cos(prf_pos + root_width);
        // Right bottom side
        ogl_profiler[11] = LINE;
        ogl_profiler[12] = profiler_cntr_line[1] + (ogl_shape[4] - top_height) * sin(prf_pos + root_width);
        ogl_profiler[13] = profiler_cntr_line[2] + (ogl_shape[4] - top_height) * cos(prf_pos + root_width);
        ogl_profiler[14] = ogl_shape[2] + ogl_shape[4] * sin(prf_pos + root_width);
        ogl_profiler[15] = ogl_shape[3] + ogl_shape[4] * cos(prf_pos + root_width);
        // Left top side
        ogl_profiler[21] = LINE;
        ogl_profiler[22] = ogl_shape[2] - ogl_shape[4] * sin(prf_pos + top_width);
        ogl_profiler[23] = ogl_shape[3] - ogl_shape[4] * cos(prf_pos + top_width);
        ogl_profiler[24] = profiler_cntr_line[1] + (ogl_shape[4] - top_height) * sin(prf_pos - root_width);
        ogl_profiler[25] = profiler_cntr_line[2] + (ogl_shape[4] - top_height) * cos(prf_pos - root_width);
        // Left bottom side
        ogl_profiler[31] = LINE;
        ogl_profiler[32] = profiler_cntr_line[1] + (ogl_shape[4] - top_height) * sin(prf_pos - root_width);
        ogl_profiler[33] = profiler_cntr_line[2] + (ogl_shape[4] - top_height) * cos(prf_pos - root_width);
        ogl_profiler[34] = ogl_shape[2] + ogl_shape[4] * sin(prf_pos - root_width);
        ogl_profiler[35] = ogl_shape[3] + ogl_shape[4] * cos(prf_pos - root_width);
        ogl_profiler[41] = LOOP_BREAK;
    }
    else if (val_ary[WELD_TYPE_PERA] == 1)
    {
        top_height = profiler_data[4];
        // ********** Double V shape profiler ****************************
        // Right top side
        ogl_profiler[1] = LINE;
        ogl_profiler[2] = ogl_shape[2] - ogl_shape[4] * sin(prf_pos - top_width);
        ogl_profiler[3] = ogl_shape[3] - ogl_shape[4] * cos(prf_pos - top_width);
        ogl_profiler[4] = profiler_cntr_line[1] + (ogl_shape[4] - top_height) * sin(prf_pos + root_width);
        ogl_profiler[5] = profiler_cntr_line[2] + (ogl_shape[4] - top_height) * cos(prf_pos + root_width);
        // Right middle side
        ogl_profiler[11] = LINE;
        ogl_profiler[12] = profiler_cntr_line[1] + (ogl_shape[4] - top_height) * sin(prf_pos + root_width);
        ogl_profiler[13] = profiler_cntr_line[2] + (ogl_shape[4] - top_height) * cos(prf_pos + root_width);
        ogl_profiler[14] = profiler_cntr_line[3] - (ogl_shape[4] - top_height) * sin(prf_pos - root_width);
        ogl_profiler[15] = profiler_cntr_line[4] - (ogl_shape[4] - top_height) * cos(prf_pos - root_width);
        // Right bottom side
        ogl_profiler[21] = LINE;
        ogl_profiler[22] = profiler_cntr_line[3] - (ogl_shape[4] - top_height) * sin(prf_pos - root_width);
        ogl_profiler[23] = profiler_cntr_line[4] - (ogl_shape[4] - top_height) * cos(prf_pos - root_width);
        ogl_profiler[24] = ogl_shape[2] + ogl_shape[4] * sin(prf_pos + top_width);
        ogl_profiler[25] = ogl_shape[3] + ogl_shape[4] * cos(prf_pos + top_width);

        // Left top side
        ogl_profiler[31] = LINE;
        ogl_profiler[32] = ogl_shape[2] - ogl_shape[4] * sin(prf_pos + top_width);
        ogl_profiler[33] = ogl_shape[3] - ogl_shape[4] * cos(prf_pos + top_width);
        ogl_profiler[34] = profiler_cntr_line[1] + (ogl_shape[4] - top_height) * sin(prf_pos - root_width);
        ogl_profiler[35] = profiler_cntr_line[2] + (ogl_shape[4] - top_height) * cos(prf_pos - root_width);
        // Left middle side
        ogl_profiler[41] = LINE;
        ogl_profiler[42] = profiler_cntr_line[1] + (ogl_shape[4] - top_height) * sin(prf_pos - root_width);
        ogl_profiler[43] = profiler_cntr_line[2] + (ogl_shape[4] - top_height) * cos(prf_pos - root_width);
        ogl_profiler[44] = profiler_cntr_line[3] - (ogl_shape[4] - top_height) * sin(prf_pos + root_width);
        ogl_profiler[45] = profiler_cntr_line[4] - (ogl_shape[4] - top_height) * cos(prf_pos + root_width);
        // Left bottom side
        ogl_profiler[51] = LINE;
        ogl_profiler[52] = profiler_cntr_line[3] - (ogl_shape[4] - top_height) * sin(prf_pos + root_width);
        ogl_profiler[53] = profiler_cntr_line[4] - (ogl_shape[4] - top_height) * cos(prf_pos + root_width);
        ogl_profiler[54] = ogl_shape[2] + ogl_shape[4] * sin(prf_pos - top_width);
        ogl_profiler[55] = ogl_shape[3] + ogl_shape[4] * cos(prf_pos - top_width);
        ogl_profiler[61] = LOOP_BREAK;
    }
    else if (val_ary[WELD_TYPE_PERA] == 2)
    {
        top_height = profiler_data[7];
        // ********** J shape profiler ***********************************
        // Right top side
        ogl_profiler[1] = LINE;
        ogl_profiler[2] = ogl_shape[2] - ogl_shape[4] * sin(prf_pos - top_width);
        ogl_profiler[3] = ogl_shape[3] - ogl_shape[4] * cos(prf_pos - top_width);
        ogl_profiler[4] = profiler_cntr_line[1] + (ogl_shape[4] - top_height) * sin(prf_pos + top_width);
        ogl_profiler[5] = profiler_cntr_line[2] + (ogl_shape[4] - top_height) * cos(prf_pos + top_width);
        // Right middle side
        ogl_profiler[11] = CURVE;
        ogl_profiler[12] = ogl_profiler[4];
        ogl_profiler[13] = ogl_profiler[5];
        ogl_profiler[14] = ogl_profiler[4] +  5 * sin(top_width);
        ogl_profiler[15] = ogl_profiler[5] +  5 * cos(top_width);
        ogl_profiler[16] = profiler_cntr_line[1] + (ogl_shape[4] - top_height) * sin(prf_pos + root_width);
        ogl_profiler[17] = profiler_cntr_line[2] + (ogl_shape[4] - top_height) * cos(prf_pos + root_width);
        // // Right bottom side
        ogl_profiler[21] = LINE;
        ogl_profiler[22] = profiler_cntr_line[1] + (ogl_shape[4] - top_height) * sin(prf_pos + root_width);
        ogl_profiler[23] = profiler_cntr_line[2] + (ogl_shape[4] - top_height) * cos(prf_pos + root_width);
        ogl_profiler[24] = ogl_shape[2] + ogl_shape[4] * sin(prf_pos + root_width);
        ogl_profiler[25] = ogl_shape[3] + ogl_shape[4] * cos(prf_pos + root_width);

        // Left top side
        ogl_profiler[31] = LINE;
        ogl_profiler[32] = ogl_shape[2] - ogl_shape[4] * sin(prf_pos + top_width);
        ogl_profiler[33] = ogl_shape[3] - ogl_shape[4] * cos(prf_pos + top_width);
        ogl_profiler[34] = profiler_cntr_line[1] + (ogl_shape[4] - top_height) * sin(prf_pos - top_width);
        ogl_profiler[35] = profiler_cntr_line[2] + (ogl_shape[4] - top_height) * cos(prf_pos - top_width);
        // Left middle side
        ogl_profiler[41] = CURVE;
        ogl_profiler[42] = ogl_profiler[34];
        ogl_profiler[43] = ogl_profiler[35];
        ogl_profiler[44] = ogl_profiler[34] +  5 * sin(top_width);
        ogl_profiler[45] = ogl_profiler[35] +  5 * cos(top_width);
        ogl_profiler[46] = profiler_cntr_line[1] + (ogl_shape[4] - top_height) * sin(prf_pos - root_width);
        ogl_profiler[47] = profiler_cntr_line[2] + (ogl_shape[4] - top_height) * cos(prf_pos - root_width);
        // Left bottom side
        ogl_profiler[51] = LINE;
        ogl_profiler[52] = profiler_cntr_line[1] + (ogl_shape[4] - top_height) * sin(prf_pos - root_width);
        ogl_profiler[53] = profiler_cntr_line[2] + (ogl_shape[4] - top_height) * cos(prf_pos - root_width);
        ogl_profiler[54] = ogl_shape[2] + ogl_shape[4] * sin(prf_pos - root_width);
        ogl_profiler[55] = ogl_shape[3] + ogl_shape[4] * cos(prf_pos - root_width);

        ogl_profiler[61] = LOOP_BREAK;
    }
}

void copy_profiler_data(void)
{
    if (val_ary[OBJ_SHAPE_PERA] == 0)
        ogl_profiler_for_flat_plate();
    else if (val_ary[OBJ_SHAPE_PERA] == 1 || val_ary[OBJ_SHAPE_PERA] == 2)
        ogl_profiler_for_hollow_circle();
    else if (val_ary[OBJ_SHAPE_PERA] == 3)
        ogl_profiler_for_solid_rod();
}

struct GeomertyValues
{
    int leg;
    double sound_path;
    double depth;
    double surface_distance;
    double Bmax;
};

//*********************************************************************************************
// Calculate and display sound path to user
//*********************************************************************************************
void initialize_ray_data(void)
{
    // flat plate
    ray_data[0] = val_ary[PROB_POS_PERA];
    ray_data[1] = val_ary[PROBE_ANGLE_PERA];
    // Hollow circle
    ray_data[2] = val_ary[PROB_POS_PERA];
    ray_data[3] = val_ary[PROBE_ANGLE_PERA];
    // circle
    ray_data[4] = val_ary[PROB_POS_PERA];
    ray_data[5] = val_ary[PROBE_ANGLE_PERA];
    // circle
    ray_data[6] = val_ary[PROB_POS_PERA];
    ray_data[7] = val_ary[PROBE_ANGLE_PERA];
}

void gtk_rays_for_flat_plate(void)
{
    double x = gtk_shape[2];
    double y = gtk_shape[3];
    double thickness = gtk_shape[5];
    double angle_pos = ray_data[0];
    double angle_prb = ray_data[1];
    int probe_width = 30;
    int probe_height = 15;

    int i = 0;
    struct GeomertyValues gv;
    double dtor, flsp, pang, len, size;

    memset(&gv, 0, sizeof(gv));
    memset(&gtk_rays, 0, sizeof(gtk_rays));
    memset(&gtk_probe, 0, sizeof(gtk_probe));

    // calculate probe points
    gtk_probe[0] = RECTANGLE;
    gtk_probe[1] = (x + angle_pos) - (probe_width/2);
    gtk_probe[2] = y - probe_height;
    gtk_probe[3] = probe_width;
    gtk_probe[4] = probe_height;
    gtk_probe[10] = LOOP_BREAK;

    // dtor = Degree to Radian value
    dtor = (angle_prb * M_PI) / 180.0;
    // flsp = First leg sound path
    flsp = thickness / cos(dtor);

    for (i = 0; i < val_ary[NOOF_LEGv_PERA]; i++)
    {
        gv.leg = (i + 1);
        gv.sound_path = 0.0;
        gv.depth = 0.0;
        gv.surface_distance = 0.0;

        // Total sound path
        gv.sound_path = flsp * (i + 1);
        // Surface distance S
        gv.surface_distance = gv.sound_path * sin(dtor);
        // Depth
        if (i == 0 || i == 2 || i == 4)
            gv.depth = (gv.sound_path * cos(dtor)) - (i * thickness);
        else if (i == 1 || i == 3 || i == 5)
            gv.depth = ((i + 1) * thickness) - (gv.sound_path * cos(dtor));

        gtk_rays[(i * 10) + 1] = LINE;
        if (i == 0)
        {
            // Beam point position (X, Y) Co-Ordinates
            gtk_rays[2] = x + angle_pos;
            gtk_rays[3] = y;
        }
        else
        {
            gtk_rays[(i * 10) + 2] = gtk_rays[(i * 10) - 6];
            gtk_rays[(i * 10) + 3] = gtk_rays[(i * 10) - 5];
        }

        gtk_rays[(i * 10) + 4] = gtk_rays[2] + gv.surface_distance;
        gtk_rays[(i * 10) + 5] = gtk_rays[3] + gv.depth;
        gtk_rays[((i + 1) * 10) + 1] = LOOP_BREAK;
    }

    if (i == 0)
        gtk_rays[1] = LOOP_BREAK;
}

// sound_path_values2 value used at OD = 100, ID = 60 and angle = 45 degree
double concave_sound_path[6] = {48.11, 96.25, 144.38, 192.50, 240.63, 288.76};

void gtk_rays_for_concave(void)
{
    double angleOfB, dtor, sp, d, sin_inverse;
    int idx = 0;

    double x = gtk_shape[22];
    double y = gtk_shape[23];
    double OD = gtk_shape[24];
    double ID = gtk_shape[34];
    double angle_pos = ray_data[2];
    double angle_prb = ray_data[3];
    int probe_width = 20;
    int probe_height = 500;

    // position angle
    angle_pos = 180.0 - angle_pos;
    angle_pos = (angle_pos * M_PI) / 180.0;

    // probe angle
    angle_prb = 180.0 - angle_prb;
    angle_prb = (angle_prb * M_PI) / 180.0;

    sp = concave_sound_path[0];
    d = sqrt(((sp * sp) + (ID * ID)) - (2 * ID * sp * cos(angle_prb)));
    // Surface distance S
    sin_inverse = asin(sp * sin(angle_prb) / d);

    memset(gtk_rays, 0, sizeof(gtk_rays));
    memset(gtk_probe, 0, sizeof(gtk_probe));

    gtk_rays[1] = LINE;
    gtk_rays[2] = x;
    gtk_rays[3] = y;
    gtk_rays[4] = gtk_rays[2] - ID * sin(angle_pos - (0 * sin_inverse));
    gtk_rays[5] = gtk_rays[3] - ID * cos(angle_pos - (0 * sin_inverse));

    gtk_probe[5] = gtk_rays[2];
    gtk_probe[6] = gtk_rays[3];
    gtk_probe[7] = gtk_rays[2] - ID * sin((angle_pos - (0 * sin_inverse)) - ((5.0 * M_PI) / 180.0));
    gtk_probe[8] = gtk_rays[3] - ID * cos((angle_pos - (0 * sin_inverse)) - ((5.0 * M_PI) / 180.0));

    gtk_probe[20] = LINE;
    gtk_probe[21] = gtk_probe[7];
    gtk_probe[22] = gtk_probe[8];
    gtk_probe[23] = gtk_probe[7] - 10 * sin((angle_pos - (0 * sin_inverse)) - ((180.0 * M_PI) / 180.0));
    gtk_probe[24] = gtk_probe[8] - 10 * cos((angle_pos - (0 * sin_inverse)) - ((180.0 * M_PI) / 180.0));

    gtk_probe[25] = gtk_rays[2];
    gtk_probe[26] = gtk_rays[3];
    gtk_probe[27] = gtk_rays[2] - ID * sin((angle_pos - (0 * sin_inverse)) + ((5.0 * M_PI) / 180.0));
    gtk_probe[28] = gtk_rays[3] - ID * cos((angle_pos - (0 * sin_inverse)) + ((5.0 * M_PI) / 180.0));

    gtk_probe[30] = LINE;
    gtk_probe[31] = gtk_probe[27];
    gtk_probe[32] = gtk_probe[28];
    gtk_probe[33] = gtk_probe[27] - 10 * sin((angle_pos - (0 * sin_inverse)) + ((180.0 * M_PI) / 180.0));
    gtk_probe[34] = gtk_probe[28] - 10 * cos((angle_pos - (0 * sin_inverse)) + ((180.0 * M_PI) / 180.0));

    gtk_probe[40] = LINE;
    gtk_probe[41] = gtk_probe[23];
    gtk_probe[42] = gtk_probe[24];
    gtk_probe[43] = gtk_probe[33];
    gtk_probe[44] = gtk_probe[34];
    gtk_probe[50] = LOOP_BREAK;

    for (int i = 0; i < val_ary[NOOF_LEGv_PERA]; i++)
    {
        if (i % 2 == 0)
        {
            OD = gtk_shape[24];
            ID = gtk_shape[34];
        }
        else
        {
            OD = gtk_shape[34];
            ID = gtk_shape[24];
        }

        idx = (i + 1) * 10;
        gtk_rays[idx + 1] = LINE;
        gtk_rays[idx + 2] = gtk_rays[2] - ID * sin(angle_pos - (i * sin_inverse));
        gtk_rays[idx + 3] = gtk_rays[3] - ID * cos(angle_pos - (i * sin_inverse));
        gtk_rays[idx + 4] = gtk_rays[2] - OD * sin(angle_pos - ((i + 1) * sin_inverse));
        gtk_rays[idx + 5] = gtk_rays[3] - OD * cos(angle_pos - ((i + 1) * sin_inverse));

        gtk_rays[(idx + 10 + 1)] = LOOP_BREAK;
    }

    if (idx == 0)
        gtk_rays[11] = LOOP_BREAK;
}

/*
int outerDia [20] = { 90, 190, 175, 395, 315, 275, 795, 643, 563, 483, 1555, 1431, 1313, 1165, 3150, 2865, 2950, 2411, 7500, 4711 };
int innerDia [20] = { 50, 150, 95, 175, 135, 225, 95, 461, 259, 391, 131, 483, 773, 481, 200, 1061, 2110, 1023, 1200, 2329 };

void find_max_angle(void)
{
    float OD = 45, ID = 10, thick, SinTheta, SinInverse, theta;

    for (int i = 0; i < 20; i++)
    {
        OD = outerDia[i];
        ID = innerDia[i];

        thick = OD - ID;

        SinTheta = 1 - (thick/OD);

        SinInverse = asin(SinTheta);

        theta = (SinInverse * 180.0) / M_PI;
        g_print("  %f - %f  = %f\n", OD, ID, theta);
    }
}
*/

float find_max_angle(int OD, int ID)
{
    float thick, SinTheta, SinInverse, theta;

    thick = OD - ID;
    SinTheta = 1 - (thick/OD);
    SinInverse = asin(SinTheta);
    theta = (SinInverse * 180.0) / M_PI;
}

void gtk_rays_for_convex(void)
{
    int idx = 0;
    double ratio, dtor, sinA, phi, diff;

    double x = gtk_shape[52];
    double y = gtk_shape[53];
    double OD = gtk_shape[54];
    double ID = gtk_shape[64];
    double angle_pos = ray_data[4];
    double angle_prb = ray_data[5];

    // Position angle
    angle_pos = (angle_pos * M_PI) / 180.0; // Radian = ((angleInDegree * M_PI) / 180.0)

    dtor = ((angle_prb * M_PI) / 180);
    sinA = sin(dtor);

    // Projection angle at ID (first leg)
    ratio = OD / ID;
    phi = asin(ratio * sinA);

    // Note :- This(diff variable) value is not verified please check before use, Why this value is ?
    diff = phi - dtor;

    gtk_rays[1] = LINE;
    gtk_rays[2] = x;
    gtk_rays[3] = y;
    gtk_rays[4] = gtk_rays[2] - OD * sin(angle_pos);
    gtk_rays[5] = gtk_rays[3] - OD * cos(angle_pos);

    gtk_probe[5] = gtk_rays[2];
    gtk_probe[6] = gtk_rays[3];
    gtk_probe[7] = gtk_rays[2] - OD * sin(angle_pos - ((5.0 * M_PI) / 180.0));
    gtk_probe[8] = gtk_rays[3] - OD * cos(angle_pos  - ((5.0 * M_PI) / 180.0));

    gtk_probe[20] = LINE;
    gtk_probe[21] = gtk_probe[7];
    gtk_probe[22] = gtk_probe[8];
    gtk_probe[23] = gtk_probe[7] + 10 * sin(angle_pos - ((180.0 * M_PI) / 180.0));
    gtk_probe[24] = gtk_probe[8] + 10 * cos(angle_pos - ((180.0 * M_PI) / 180.0));

    gtk_probe[25] = gtk_rays[2];
    gtk_probe[26] = gtk_rays[3];
    gtk_probe[27] = gtk_rays[2] - OD * sin(angle_pos + ((5.0 * M_PI) / 180.0));
    gtk_probe[28] = gtk_rays[3] - OD * cos(angle_pos + ((5.0 * M_PI) / 180.0));

    gtk_probe[30] = LINE;
    gtk_probe[31] = gtk_probe[27];
    gtk_probe[32] = gtk_probe[28];
    gtk_probe[33] = gtk_probe[27] + 10 * sin(angle_pos + ((180.0 * M_PI) / 180.0));
    gtk_probe[34] = gtk_probe[28] + 10 * cos(angle_pos + ((180.0 * M_PI) / 180.0));

    gtk_probe[40] = LINE;
    gtk_probe[41] = gtk_probe[23];
    gtk_probe[42] = gtk_probe[24];
    gtk_probe[43] = gtk_probe[33];
    gtk_probe[44] = gtk_probe[34];
    gtk_probe[50] = LOOP_BREAK;

    for (int i = 0; i < val_ary[NOOF_LEGv_PERA]; i++)
    {
        if (i % 2 == 0)
        {
            OD = gtk_shape[54];
            ID = gtk_shape[64];
        }
        else
        {
            OD = gtk_shape[64];
            ID = gtk_shape[54];
        }

        idx = (i + 1) * 10;

        gtk_rays[idx + 1] = LINE;
        gtk_rays[idx + 2] = gtk_rays[2] - OD * sin(angle_pos - (diff * i));
        gtk_rays[idx + 3] = gtk_rays[3] - OD * cos(angle_pos - (diff * i));
        gtk_rays[idx + 4] = gtk_rays[2] - ID * sin(angle_pos - (diff * (i + 1)));
        gtk_rays[idx + 5] = gtk_rays[3] - ID * cos(angle_pos - (diff * (i + 1)));

        gtk_rays[(idx + 10 + 1)] = LOOP_BREAK;
    }

    if (idx == 0)
        gtk_rays[11] = LOOP_BREAK;
}

void gtk_rays_for_solid_rod(void)
{
    double x = gtk_shape[82];
    double y = gtk_shape[83];
    double radius = gtk_shape[84];
    double angle_pos = ray_data[6];
    double angle_prb = ray_data[7];

    struct GeomertyValues gv;
    double dtor, sinA, sinC;
    double sinP, sinQ, spath = 0.0;
    double deg, SP, D, half;
    double flsp, fld, flsd;

    if (val_ary[OBJ_SHAPE_PERA] == 2)
    {
        x = gtk_shape[82];
        y = gtk_shape[83];
        radius = gtk_shape[54];
        angle_pos = ray_data[4];
        angle_prb = ray_data[5];
    }
    else
    {
        x = gtk_shape[82];
        y = gtk_shape[83];
        radius = gtk_shape[84];
        angle_pos = ray_data[6];
        angle_prb = ray_data[7];
    }
    
    angle_pos = (angle_pos * M_PI) / 180.0;
    dtor = (angle_prb * M_PI) / 180.0;
    sinA = sin(dtor);

    gv.leg = 0;
    gv.Bmax = 0.0;
    gv.depth = 0.0;
    gv.sound_path = 0.0; // solid_circle_sound_path_60d[0];
    gv.surface_distance = 0.0;

    gv.Bmax = 180 - (angle_prb * 2);
    // flsp = first leg sound path
    flsp = (radius * sin((gv.Bmax * M_PI) / 180.0)) / sinA;
    // fld = first leg depth
    D = sqrt(((flsp * flsp) + (radius * radius)) - (2 * radius * flsp * cos(dtor)));
    fld = radius - D;
    // flsd = first leg surface distance
    flsd = gv.Bmax * (radius * (M_PI / 180.0));

    /*
    g_print("1st Leg Sound_path = %.2lf\n", flsp);
    g_print("1st Leg Depth = %.2lf, %.2lf\n", D, fld);
    g_print("1st Leg Surface Distance = %.2lf\n", flsd);
    g_print("Bmax = %.2lf\n\n", gv.Bmax);
    */
   
    half = flsp * 0.50;

    sinP = ((radius * dtor) / radius);
    sinQ = ((180.0 * M_PI) / 180.0) - (dtor + sinP);

    spath = ((radius * radius) + (radius * radius)) - (2 * radius * radius * cos(sinQ));
    spath = sqrt(spath);

    memset(gtk_rays, 0, sizeof(gtk_rays));
    // First point on circle (point[1].X, point[1].Y) Co-Ordinates
    gtk_rays[1] = LINE;
    gtk_rays[2] = x;
    gtk_rays[3] = y;
    gtk_rays[4] = gtk_rays[2] - radius * sin(angle_pos);
    gtk_rays[5] = gtk_rays[3] - radius * cos(angle_pos);

    gtk_probe[5] = gtk_rays[2];
    gtk_probe[6] = gtk_rays[3];
    gtk_probe[7] = gtk_rays[2] - radius * sin(angle_pos - ((5.0 * M_PI) / 180.0));
    gtk_probe[8] = gtk_rays[3] - radius * cos(angle_pos  - ((5.0 * M_PI) / 180.0));

    gtk_probe[20] = LINE;
    gtk_probe[21] = gtk_probe[7];
    gtk_probe[22] = gtk_probe[8];
    gtk_probe[23] = gtk_probe[7] + 10 * sin(angle_pos - ((180.0 * M_PI) / 180.0));
    gtk_probe[24] = gtk_probe[8] + 10 * cos(angle_pos - ((180.0 * M_PI) / 180.0));

    gtk_probe[25] = gtk_rays[2];
    gtk_probe[26] = gtk_rays[3];
    gtk_probe[27] = gtk_rays[2] - radius * sin(angle_pos + ((5.0 * M_PI) / 180.0));
    gtk_probe[28] = gtk_rays[3] - radius * cos(angle_pos + ((5.0 * M_PI) / 180.0));

    gtk_probe[30] = LINE;
    gtk_probe[31] = gtk_probe[27];
    gtk_probe[32] = gtk_probe[28];
    gtk_probe[33] = gtk_probe[27] + 10 * sin(angle_pos + ((180.0 * M_PI) / 180.0));
    gtk_probe[34] = gtk_probe[28] + 10 * cos(angle_pos + ((180.0 * M_PI) / 180.0));

    gtk_probe[40] = LINE;
    gtk_probe[41] = gtk_probe[23];
    gtk_probe[42] = gtk_probe[24];
    gtk_probe[43] = gtk_probe[33];
    gtk_probe[44] = gtk_probe[34];
    gtk_probe[50] = LOOP_BREAK;

    for (int i = 0; i < val_ary[NOOF_LEGv_PERA]; i++)
    {
        gv.leg = 0;
        gv.depth = 0;
        gv.surface_distance = 0;

        gv.leg = i + 1;
        gv.sound_path = (spath * gv.leg);
        SP = (spath * gv.leg) - (i * flsp);
        D = sqrt(((SP * SP) + (radius * radius)) - (2 * radius * SP * cos(dtor)));
        gv.depth = radius - D;

        // Projection angle at ID (first leg)
        sinC = asin((SP * sinA) / D);
        if (gv.Bmax > 90.0 && gv.sound_path > half)
        {
            deg = (sinC * 180) / M_PI;
            sinC = 180 - deg;
            sinC = (sinC * M_PI) / 180;
        }

        // Surface distance
        gv.surface_distance = sinC * radius;
        if (i > 0)
            gv.surface_distance = gv.surface_distance + (i * flsd);

        gtk_rays[(gv.leg * 10) + 1] = LINE;
        gtk_rays[(gv.leg * 10) + 2] = gtk_rays[(gv.leg * 10) - 6];
        gtk_rays[(gv.leg * 10) + 3] = gtk_rays[(gv.leg * 10) - 5];
        gtk_rays[(gv.leg * 10) + 4] = gtk_rays[2] - radius * sin(angle_pos - (sinQ * gv.leg));
        gtk_rays[(gv.leg * 10) + 5] = gtk_rays[3] - radius * cos(angle_pos - (sinQ * gv.leg));
        gtk_rays[((gv.leg + 1) * 10) + 1] = LOOP_BREAK;
    }

    if (gv.leg == 0)
        gtk_rays[1] = LOOP_BREAK;
}

void init_rays_value(void)
{
    double OD, ID, theta;

    if (val_ary[OBJ_SHAPE_PERA] == 0)
    {
		ray_data[0] = val_ary[PROB_POS_PERA] / zoom_ratio;
        ray_data[1] = val_ary[PROBE_ANGLE_PERA];
        gtk_rays_for_flat_plate();
    }
    else if (val_ary[OBJ_SHAPE_PERA] == 1)
    {
        ray_data[2] = val_ary[PROB_POS_PERA];
        ray_data[3] = val_ary[PROBE_ANGLE_PERA];
        gtk_rays_for_concave();
    }
    else if (val_ary[OBJ_SHAPE_PERA] == 2)
    {
        OD = gtk_shape[54];
        ID = gtk_shape[64];
        ray_data[4] = val_ary[PROB_POS_PERA];
        ray_data[5] = val_ary[PROBE_ANGLE_PERA];

        theta = find_max_angle(OD, ID);
        
        if(val_ary[PROBE_ANGLE_PERA] < theta)
            gtk_rays_for_convex();
        else if(val_ary[PROBE_ANGLE_PERA] >= theta)
            gtk_rays_for_solid_rod();
    }
    else if (val_ary[OBJ_SHAPE_PERA] == 3)
    {
        ray_data[6] = val_ary[PROB_POS_PERA];
        ray_data[7] = val_ary[PROBE_ANGLE_PERA];
        gtk_rays_for_solid_rod();
    }
}

void ogl_rays_for_flat_plate(void)
{
    double x = ogl_shape[2];
    double y = ogl_shape[3];
    double thickness = ogl_shape[5];
    double angle_pos = ray_data[0];
    double angle_prb = ray_data[1];
    int probe_width = 30;
    int probe_height = 15;

    struct GeomertyValues gv;
    double dtor, flsp, pang, len, size;

    gv.leg = 0;
    memset(&gv, 0, sizeof(gv));
    memset(&ogl_rays, 0, sizeof(ogl_rays));

    // calculate probe points
    ogl_probe[0] = RECTANGLE;
    ogl_probe[1] = (x + angle_pos) - (probe_width/2);
    ogl_probe[2] = y - probe_height;
    ogl_probe[3] = probe_width;
    ogl_probe[4] = probe_height;
    ogl_probe[10] = LOOP_BREAK;

    // dtor = Degree to Radian value
    dtor = (angle_prb * M_PI) / 180.0;
    // flsp = First leg sound path
    flsp = thickness / cos(dtor);

    for (int i = 0; i < val_ary[NOOF_LEGv_PERA]; i++)
    {
        gv.leg = (i + 1);
        gv.sound_path = 0.0;
        gv.depth = 0.0;
        gv.surface_distance = 0.0;

        // Total sound path
        gv.sound_path = flsp * (i + 1);
        // Surface distance S
        gv.surface_distance = gv.sound_path * sin(dtor);
        // Depth
        if (i == 0 || i == 2 || i == 4)
            gv.depth = (gv.sound_path * cos(dtor)) - (i * thickness);
        else if (i == 1 || i == 3 || i == 5)
            gv.depth = ((i + 1) * thickness) - (gv.sound_path * cos(dtor));

        ogl_rays[(i * 10) + 1] = LINE;
        if (i == 0)
        {
            // Beam point position (X, Y) Co-Ordinates
            ogl_rays[2] = x + angle_pos;
            ogl_rays[3] = y;
        }
        else
        {
            ogl_rays[(i * 10) + 2] = ogl_rays[(i * 10) - 6];
            ogl_rays[(i * 10) + 3] = ogl_rays[(i * 10) - 5];
        }

        ogl_rays[(i * 10) + 4] = ogl_rays[2] + gv.surface_distance;
        ogl_rays[(i * 10) + 5] = ogl_rays[3] + gv.depth;
        ogl_rays[((i + 1) * 10) + 1] = LOOP_BREAK;
    }

    if (gv.leg == 0)
        ogl_rays[1] = LOOP_BREAK;
}

void ogl_rays_for_concave(void)
{
    double angleOfB, dtor, sp, d, sin_inverse;
    int idx = 0;

    double x = ogl_shape[2];
    double y = ogl_shape[3];
    double OD = ogl_shape[4];
    double ID = ogl_shape[14];
    double angle_pos = ray_data[2];
    double angle_prb = ray_data[3];

    // position angle
    angle_pos = 180.0 - angle_pos;
    angle_pos = (angle_pos * M_PI) / 180.0;

    // probe angle
    angle_prb = 180.0 - angle_prb;
    angle_prb = (angle_prb * M_PI) / 180.0;

    sp = concave_sound_path[0];
    d = sqrt(((sp * sp) + (ID * ID)) - (2 * ID * sp * cos(angle_prb)));
    // Surface distance S
    sin_inverse = asin(sp * sin(angle_prb) / d);

    memset(ogl_rays, 0, sizeof(ogl_rays));

    ogl_rays[1] = LINE;
    ogl_rays[2] = x;
    ogl_rays[3] = y;
    ogl_rays[4] = ogl_rays[2] - ID * sin(angle_pos - (0 * sin_inverse));
    ogl_rays[5] = ogl_rays[3] - ID * cos(angle_pos - (0 * sin_inverse));

    ogl_probe[5] = ogl_rays[2];
    ogl_probe[6] = ogl_rays[3];
    ogl_probe[7] = ogl_rays[2] - ID * sin((angle_pos - (0 * sin_inverse)) - ((5.0 * M_PI) / 180.0));
    ogl_probe[8] = ogl_rays[3] - ID * cos((angle_pos - (0 * sin_inverse)) - ((5.0 * M_PI) / 180.0));

    ogl_probe[20] = LINE;
    ogl_probe[21] = ogl_probe[7];
    ogl_probe[22] = ogl_probe[8];
    ogl_probe[23] = ogl_probe[7] - 10 * sin((angle_pos - (0 * sin_inverse)) - ((180.0 * M_PI) / 180.0));
    ogl_probe[24] = ogl_probe[8] - 10 * cos((angle_pos - (0 * sin_inverse)) - ((180.0 * M_PI) / 180.0));

    ogl_probe[25] = ogl_rays[2];
    ogl_probe[26] = ogl_rays[3];
    ogl_probe[27] = ogl_rays[2] - ID * sin((angle_pos - (0 * sin_inverse)) + ((5.0 * M_PI) / 180.0));
    ogl_probe[28] = ogl_rays[3] - ID * cos((angle_pos - (0 * sin_inverse)) + ((5.0 * M_PI) / 180.0));

    ogl_probe[30] = LINE;
    ogl_probe[31] = ogl_probe[27];
    ogl_probe[32] = ogl_probe[28];
    ogl_probe[33] = ogl_probe[27] - 10 * sin((angle_pos - (0 * sin_inverse)) + ((180.0 * M_PI) / 180.0));
    ogl_probe[34] = ogl_probe[28] - 10 * cos((angle_pos - (0 * sin_inverse)) + ((180.0 * M_PI) / 180.0));

    ogl_probe[40] = LINE;
    ogl_probe[41] = ogl_probe[23];
    ogl_probe[42] = ogl_probe[24];
    ogl_probe[43] = ogl_probe[33];
    ogl_probe[44] = ogl_probe[34];
    ogl_probe[50] = LOOP_BREAK;

    for (int i = 0; i < val_ary[NOOF_LEGv_PERA]; i++)
    {
        if (i % 2 == 0)
        {
            OD = gtk_shape[24];
            ID = gtk_shape[34];
        }
        else
        {
            OD = gtk_shape[34];
            ID = gtk_shape[24];
        }

        idx = (i + 1) * 10;
        ogl_rays[idx + 1] = LINE;
        ogl_rays[idx + 2] = ogl_rays[2] - ID * sin(angle_pos - (i * sin_inverse));
        ogl_rays[idx + 3] = ogl_rays[3] - ID * cos(angle_pos - (i * sin_inverse));
        ogl_rays[idx + 4] = ogl_rays[2] - OD * sin(angle_pos - ((i + 1) * sin_inverse));
        ogl_rays[idx + 5] = ogl_rays[3] - OD * cos(angle_pos - ((i + 1) * sin_inverse));

        ogl_rays[(idx + 10 + 1)] = LOOP_BREAK;
    }

    if (idx == 0)
        ogl_rays[11] = LOOP_BREAK;
}

void ogl_rays_for_convex(void)
{
    int idx = 0;
    double ratio, dtor, sinA, phi, diff;

    double x = ogl_shape[2];
    double y = ogl_shape[3];
    double OD = ogl_shape[4];
    double ID = ogl_shape[14];
    double angle_pos = ray_data[4];
    double angle_prb = ray_data[5];
    
    // Position angle
    angle_pos = (angle_pos * M_PI) / 180.0; // Radian = ((angleInDegree * M_PI) / 180.0)

    dtor = ((angle_prb * M_PI) / 180);
    sinA = sin(dtor);

    // Projection angle at ID (first leg)
    ratio = OD / ID;
    phi = asin(ratio * sinA);

    // Note :- This(diff variable) value is not verified please check before use, Why this value is ?
    diff = phi - dtor;

    ogl_rays[1] = LINE;
    ogl_rays[2] = x;
    ogl_rays[3] = y;
    ogl_rays[4] = ogl_rays[2] - OD * sin(angle_pos);
    ogl_rays[5] = ogl_rays[3] - OD * cos(angle_pos);

    ogl_probe[5] = ogl_rays[2];
    ogl_probe[6] = ogl_rays[3];
    ogl_probe[7] = ogl_rays[2] - OD * sin(angle_pos - ((5.0 * M_PI) / 180.0));
    ogl_probe[8] = ogl_rays[3] - OD * cos(angle_pos - ((5.0 * M_PI) / 180.0));

    ogl_probe[20] = LINE;
    ogl_probe[21] = ogl_probe[7];
    ogl_probe[22] = ogl_probe[8];
    ogl_probe[23] = ogl_probe[7] + 10 * sin(angle_pos - ((180.0 * M_PI) / 180.0));
    ogl_probe[24] = ogl_probe[8] + 10 * cos(angle_pos - ((180.0 * M_PI) / 180.0));

    ogl_probe[25] = ogl_rays[2];
    ogl_probe[26] = ogl_rays[3];
    ogl_probe[27] = ogl_rays[2] - OD * sin(angle_pos + ((5.0 * M_PI) / 180.0));
    ogl_probe[28] = ogl_rays[3] - OD * cos(angle_pos + ((5.0 * M_PI) / 180.0));

    ogl_probe[30] = LINE;
    ogl_probe[31] = ogl_probe[27];
    ogl_probe[32] = ogl_probe[28];
    ogl_probe[33] = ogl_probe[27] + 10 * sin(angle_pos + ((180.0 * M_PI) / 180.0));
    ogl_probe[34] = ogl_probe[28] + 10 * cos(angle_pos + ((180.0 * M_PI) / 180.0));

    ogl_probe[40] = LINE;
    ogl_probe[41] = ogl_probe[23];
    ogl_probe[42] = ogl_probe[24];
    ogl_probe[43] = ogl_probe[33];
    ogl_probe[44] = ogl_probe[34];
    ogl_probe[50] = LOOP_BREAK;

    for (int i = 0; i < val_ary[NOOF_LEGv_PERA]; i++)
    {
        if (i % 2 == 0)
        {
            OD = ogl_shape[4];
            ID = ogl_shape[14];
        }
        else
        {
            OD = ogl_shape[14];
            ID = ogl_shape[4];
        }

        idx = (i + 1) * 10;

        ogl_rays[idx + 1] = LINE;
        ogl_rays[idx + 2] = ogl_rays[2] - OD * sin(angle_pos - (diff * i));
        ogl_rays[idx + 3] = ogl_rays[3] - OD * cos(angle_pos - (diff * i));
        // Note :- This(diff variable) value is not verified please check before use, Why this value is ?
        ogl_rays[idx + 4] = ogl_rays[2] - ID * sin(angle_pos - (diff * (i + 1)));
        ogl_rays[idx + 5] = ogl_rays[3] - ID * cos(angle_pos - (diff * (i + 1)));

        ogl_rays[(idx + 10 + 1)] = LOOP_BREAK;
    }

    if (idx == 0)
        ogl_rays[11] = LOOP_BREAK;
}

void ogl_rays_for_solid_rod(void)
{
    double x = ogl_shape[2];
    double y = ogl_shape[3];
    double radius = ogl_shape[4];
    double angle_pos = ray_data[6];
    double angle_prb = ray_data[7];

    struct GeomertyValues gv;
    double dtor, sinA, sinC;
    double sinP, sinQ, spath = 0.0;
    double deg, SP, D, half;
    double flsp, fld, flsd;

    if (val_ary[OBJ_SHAPE_PERA] == 2)
    {
        x = ogl_shape[2];
        y = ogl_shape[3];
        radius = ogl_shape[4];
        angle_pos = ray_data[4];
        angle_prb = ray_data[5];
    }
    else if (val_ary[OBJ_SHAPE_PERA] == 3)
    {
        x = ogl_shape[2];
        y = ogl_shape[3];
        radius = ogl_shape[4];
        angle_pos = ray_data[6];
        angle_prb = ray_data[7];
    }

    angle_pos = (angle_pos * M_PI) / 180.0;
    dtor = (angle_prb * M_PI) / 180.0;
    sinA = sin(dtor);

    gv.leg = 0;
    gv.Bmax = 0.0;
    gv.depth = 0.0;
    gv.sound_path = 0.0; // solid_circle_sound_path_60d[0];
    gv.surface_distance = 0.0;

    gv.Bmax = 180 - (angle_prb * 2);
    // flsp = first leg sound path
    flsp = (radius * sin((gv.Bmax * M_PI) / 180.0)) / sinA;
    // fld = first leg depth
    D = sqrt(((flsp * flsp) + (radius * radius)) - (2 * radius * flsp * cos(dtor)));
    fld = radius - D;
    // flsd = first leg surface distance
    flsd = gv.Bmax * (radius * (M_PI / 180.0));

    /*
    g_print("1st Leg Sound_path = %.2lf\n", flsp);
    g_print("1st Leg Depth = %.2lf, %.2lf\n", D, fld);
    g_print("1st Leg Surface Distance = %.2lf\n", flsd);
    g_print("Bmax = %.2lf\n\n", gv.Bmax);
    */

    half = flsp * 0.50;

    sinP = ((radius * dtor) / radius);
    sinQ = ((180.0 * M_PI) / 180.0) - (dtor + sinP);

    spath = ((radius * radius) + (radius * radius)) - (2 * radius * radius * cos(sinQ));
    spath = sqrt(spath);

    memset(ogl_rays, 0, sizeof(ogl_rays));
    // First point on circle (point[1].X, point[1].Y) Co-Ordinates
    ogl_rays[1] = LINE;
    ogl_rays[2] = x;
    ogl_rays[3] = y;
    ogl_rays[4] = ogl_rays[2] - radius * sin(angle_pos);
    ogl_rays[5] = ogl_rays[3] - radius * cos(angle_pos);

    ogl_probe[5] = ogl_rays[2];
    ogl_probe[6] = ogl_rays[3];
    ogl_probe[7] = ogl_rays[2] - radius * sin(angle_pos - ((5.0 * M_PI) / 180.0));
    ogl_probe[8] = ogl_rays[3] - radius * cos(angle_pos - ((5.0 * M_PI) / 180.0));

    ogl_probe[20] = LINE;
    ogl_probe[21] = ogl_probe[7];
    ogl_probe[22] = ogl_probe[8];
    ogl_probe[23] = ogl_probe[7] + 10 * sin(angle_pos - ((180.0 * M_PI) / 180.0));
    ogl_probe[24] = ogl_probe[8] + 10 * cos(angle_pos - ((180.0 * M_PI) / 180.0));

    ogl_probe[25] = ogl_rays[2];
    ogl_probe[26] = ogl_rays[3];
    ogl_probe[27] = ogl_rays[2] - radius * sin(angle_pos + ((5.0 * M_PI) / 180.0));
    ogl_probe[28] = ogl_rays[3] - radius * cos(angle_pos + ((5.0 * M_PI) / 180.0));

    ogl_probe[30] = LINE;
    ogl_probe[31] = ogl_probe[27];
    ogl_probe[32] = ogl_probe[28];
    ogl_probe[33] = ogl_probe[27] + 10 * sin(angle_pos + ((180.0 * M_PI) / 180.0));
    ogl_probe[34] = ogl_probe[28] + 10 * cos(angle_pos + ((180.0 * M_PI) / 180.0));

    ogl_probe[40] = LINE;
    ogl_probe[41] = ogl_probe[23];
    ogl_probe[42] = ogl_probe[24];
    ogl_probe[43] = ogl_probe[33];
    ogl_probe[44] = ogl_probe[34];
    ogl_probe[50] = LOOP_BREAK;

    for (int i = 0; i < val_ary[NOOF_LEGv_PERA]; i++)
    {
        gv.leg = 0;
        gv.depth = 0;
        gv.surface_distance = 0;

        gv.leg = i + 1;
        gv.sound_path = (spath * gv.leg);
        SP = (spath * gv.leg) - (i * flsp);
        D = sqrt(((SP * SP) + (radius * radius)) - (2 * radius * SP * cos(dtor)));
        gv.depth = radius - D;

        // Projection angle at ID (first leg)
        sinC = asin((SP * sinA) / D);
        if (gv.Bmax > 90.0 && gv.sound_path > half)
        {
            deg = (sinC * 180) / M_PI;
            sinC = 180 - deg;
            sinC = (sinC * M_PI) / 180;
        }

        // Surface distance
        gv.surface_distance = sinC * radius;
        if (i > 0)
            gv.surface_distance = gv.surface_distance + (i * flsd);

        ogl_rays[(gv.leg * 10) + 1] = LINE;
        ogl_rays[(gv.leg * 10) + 2] = ogl_rays[(gv.leg * 10) - 6];
        ogl_rays[(gv.leg * 10) + 3] = ogl_rays[(gv.leg * 10) - 5];
        ogl_rays[(gv.leg * 10) + 4] = ogl_rays[2] - radius * sin(angle_pos - (sinQ * gv.leg));
        ogl_rays[(gv.leg * 10) + 5] = ogl_rays[3] - radius * cos(angle_pos - (sinQ * gv.leg));
        ogl_rays[((gv.leg + 1) * 10) + 1] = LOOP_BREAK;
    }

    if (gv.leg == 0)
        ogl_rays[1] = LOOP_BREAK;
}

void copy_rays_data(void)
{
    float OD, ID, theta;

    if (val_ary[OBJ_SHAPE_PERA] == 0)
    {
        ray_data[0] = val_ary[PROB_POS_PERA] / zoom_ratio;
        ogl_rays_for_flat_plate();
    }
    else if (val_ary[OBJ_SHAPE_PERA] == 1)
    {
        ray_data[2] = val_ary[PROB_POS_PERA];
        ogl_rays_for_concave();
    }
    else if (val_ary[OBJ_SHAPE_PERA] == 2)
    {
        OD = ogl_shape[4];
        ID = ogl_shape[14];
        ray_data[4] = val_ary[PROB_POS_PERA];
        ray_data[5] = val_ary[PROBE_ANGLE_PERA];

        theta = find_max_angle(OD, ID);
        
        if(ray_data[5] < theta)
            ogl_rays_for_convex();
        else if(ray_data[5] >= theta)
            ogl_rays_for_solid_rod();
    }
    else if (val_ary[OBJ_SHAPE_PERA] == 3)
    {
        ray_data[6] = val_ary[PROB_POS_PERA];
        ogl_rays_for_solid_rod();
    }
}

//**********************************************************************************************
// Below functions are used for display shapes as per stored index at 1, 11, 21, .... so on.
//**********************************************************************************************
void draw_line(cairo_t *cr, int *offset)
{
    cairo_move_to(cr, *(offset + 1), *(offset + 2)); // Flat plate
    cairo_line_to(cr, *(offset + 3), *(offset + 4)); // Flat plate
    cairo_stroke(cr);
}

void draw_arc(cairo_t *cr, int *offset)
{
    cairo_arc(cr, *(offset + 1), *(offset + 2), *(offset + 3), 0, G_PI * 0.5); // Solid rod
    cairo_stroke(cr);
}

void draw_rectangle(cairo_t *cr, int *offset)
{
    cairo_rectangle(cr, *(offset + 1), *(offset + 2), *(offset + 3), *(offset + 4)); // Flat plate
    cairo_stroke(cr);
}

void draw_circle(cairo_t *cr, int *offset)
{
    cairo_arc(cr, *(offset + 1), *(offset + 2), *(offset + 3), 0, 2 * G_PI);
    cairo_stroke(cr);
}

void draw_curve(cairo_t *cr, int *offset)
{
    cairo_curve_to(cr, *(offset + 1), *(offset + 2), *(offset + 3), *(offset + 4), *(offset + 5), *(offset + 6));
    cairo_stroke(cr);
}

void select_shape(cairo_t *cr, int *offset)
{
    int type = *offset;

    while (1)
    {
        type = *offset;
        // g_print("1 type = %d \n", type);
        if (type == LOOP_BREAK)
            break;

        switch (type)
        {
        case LINE:
            draw_line(cr, offset);
            break;

        case RECTANGLE:
            draw_rectangle(cr, offset);
            break;

        case ARC:
            draw_arc(cr, offset);
            break;

        case CIRCLE:
            draw_circle(cr, offset);
            break;

        case CURVE:
            draw_curve(cr, offset);
            break;

        default:
            break;
        }

        offset = offset + 10;
    }
}

void draw_function(void)
{
    int *offset;
    cairo_t *cr = shape_profiler_rays_cr;

    // Set background color
    cairo_set_source_rgb(cr, 0.0, 0.0, 0.0);
    // Paint background
    cairo_paint(cr);
    // Set line width
    cairo_set_line_width(cr, 1.0);
    // Set Color for drawing
    // cairo_set_source_rgb(cr, 0.0, 0.0, 1.0);
    if (Nearfield == true)
    {
        draw_Beamprofile(cr);
        return;
    }

    cairo_set_source_rgb(cr, 1.0, 1.0, 0.0); // Select Color for Test Object Shape
    // Draw shape object
    if (val_ary[OBJ_SHAPE_PERA] == 0) // Rectangle
        offset = &gtk_shape[1];
    else if (val_ary[OBJ_SHAPE_PERA] == 1) // Hollow Circle
        offset = &gtk_shape[21];
    else if (val_ary[OBJ_SHAPE_PERA] == 2) // Hollow Circle
        offset = &gtk_shape[51];
    else if (val_ary[OBJ_SHAPE_PERA] == 3) // Solid Circle
        offset = &gtk_shape[81];
    select_shape(cr, offset);

    cairo_set_source_rgb(cr, 0.0, 1.0, 0.0); // Select Color for Profile

    // Draw gtk_profiler
    offset = &gtk_profiler[1]; // Draw Center line for profiler
    select_shape(cr, offset);
    offset = &gtk_profiler[21];
    select_shape(cr, offset);

    //// Draw Beam
    cairo_set_source_rgb(cr, 1.0, 1.0, 1.0); // Select Color for UT Beam
    if (val_ary[OBJ_SHAPE_PERA] == 0)
        select_shape(cr, &gtk_probe[0]);
    if (val_ary[OBJ_SHAPE_PERA] == 1 || val_ary[OBJ_SHAPE_PERA] == 2 || val_ary[OBJ_SHAPE_PERA] == 3)
        select_shape(cr, &gtk_probe[20]);

    //// Draw rays
    cairo_set_source_rgb(cr, 1.0, 0.0, 1.0); // Select Color for UT Beam rays
    if (val_ary[OBJ_SHAPE_PERA] == 0)
        select_shape(cr, &gtk_rays[1]);
    else if (val_ary[OBJ_SHAPE_PERA] == 1)
        select_shape(cr, &gtk_rays[11]);
    else if (val_ary[OBJ_SHAPE_PERA] == 2)
        select_shape(cr, &gtk_rays[11]);
    else if (val_ary[OBJ_SHAPE_PERA] == 3)
        select_shape(cr, &gtk_rays[11]);

    cairo_fill(cr);

    // refresh call
    gtk_image_set_from_surface(GTK_IMAGE(shape_profiler_rays_image), shape_profiler_rays_surface);
}

//****************************************************************
void draw_Beamprofile(cairo_t *cr) // Draw Beam Profile
{
    gchar strd[30];
    double Draw_width = 200, data, Adif;
    // Prb_Near_field=100,Prb_div_Ht=50
    double Nf_pos, Yh, Offset = 130;
    Nf_pos = Prb_Near_field;
    Yh = Prb_div_Ht;

    data = Asc_Width - Nf_pos;
    if (data < 1)
    {
        data = 1;
    }

    Nf_pos = (250 * Nf_pos) / Asc_Width; // Postion for 250 pix width area

    Adif = 250 - Nf_pos;
    if (Adif < 1)
    {
        Adif = 1;
    }

    Yh = Prb_div_Ht; // if(Yh<1){Yh=1;}

    Yh = (Adif * Yh) / data; // if(Yh<0) {Yh=0;}

    cairo_set_source_rgb(cr, 1.0, 1.0, 0.0); // Select Color for Test Object Shape

    cairo_move_to(cr, 0, Offset + 30);
    cairo_line_to(cr, Nf_pos, Offset + 30);
    cairo_line_to(cr, 250, Offset + (30 + Yh));

    cairo_move_to(cr, 0, Offset - 30);
    cairo_line_to(cr, Nf_pos, Offset - 30);
    cairo_line_to(cr, 250, Offset - (30 + Yh));

    cairo_move_to(cr, Nf_pos, Offset + 30);
    cairo_line_to(cr, Nf_pos, Offset - 30);

    cairo_set_font_size(cr, 12);
    cairo_move_to(cr, 10, 270); // Set font position
    sprintf(strd, "Nf=%0.2f  D Angle=%0.2f", Prb_Near_field_v, Beam_dv_angle_v);
    cairo_show_text(cr, strd); // Draw text

    // double Beam_dv_angle_v,Prb_Near_field_v;

    cairo_stroke(cr);
    Nearfield = false;
}

///****************************************************************
/// @brief
/// @param x         == x is origin co-ordinate of the circle
/// @param y         == y is origin co-ordinate of the circle
/// @param OD        == Outer Diameter
/// @param ID        == Inner Diameter
/// @param angle_pos == probe position
/// @param angle_prb == probe angle
/// @return ==  group of struct (Sound path, Depth and Surface distance)
///****************************************************************

// sound_path_values2 value used at OD = 100, ID = 60 and angle = 45 degree
// double concave_sound_path[6] = {48.11, 96.25, 144.38, 192.50, 240.63, 288.76};

void ConcaveCalculations(cairo_t *cr, double x, double y, double OD, double ID, double angle_pos, double angle_prb)
{
    struct GeomertyValues gv;
    double sinA, sinB, sinC, angleOfB, dtor;
    double d, sp, sd, sin_inverse, cmp;
    double flsp, fld, flsd;

    gv.leg = 0;
    gv.Bmax = 0;
    gv.depth = 0;
    gv.sound_path = 0;
    gv.surface_distance = 0;

    // Circle origin point (X, Y) Co-Ordinates
    gtk_rays[1] = LINE;
    gtk_rays[2] = x;
    gtk_rays[3] = y;

    // position angle
    angle_pos = 180.0 - angle_pos;
    angle_pos = (angle_pos * M_PI) / 180.0;

    // probe angle
    angleOfB = 180.0 - angle_prb;
    dtor = (angleOfB * M_PI) / 180.0;

    sinB = sin(dtor);
    sinC = asin((sinB * ID) / OD);
    sinA = 180 - (angleOfB + ((sinC * 180) / M_PI));
    sinA = (sinA * M_PI) / 180.0;

    /*
    printf("concave **************\n\n");
    printf("angleOfB = %lf\n", angleOfB);
    printf("dtor = %lf\n", dtor);
    printf("sinB = %lf\n", sinB);
    printf("sinC = %lf\n", sinC);
    printf("sinA = %lf\n", sinA);
    printf("**************\n\n");
    */

    // flsp = first leg sound path
    flsp = sqrt((((ID * ID) + (OD * OD)) - (2 * OD * ID * cos(sinA))));
    sd = sqrt(((flsp * flsp) + (ID * ID)) - (2 * ID * flsp * cos(dtor)));
    // fld = first leg depth
    fld = sd - ID;
    // flsd = first leg surface distance
    flsd = OD * asin((flsp * sin(dtor)) / sd);

    /*
    printf("first leg sound path = %lf\n", flsp);
    printf("first leg depth = %lf\n", fld);
    printf("first leg surface distance = %lf\n", flsd);
    */

    {
        // Depth of reflector D
        // gv.sound_path = flsp;
        gv.sound_path = concave_sound_path[0];
        d = sqrt(((gv.sound_path * gv.sound_path) + (ID * ID)) - (2 * ID * gv.sound_path * cos(dtor)));
        // Surface distance S
        sin_inverse = asin(gv.sound_path * sin(dtor) / d);

        gtk_rays[4] = gtk_rays[2] - ID * sin(angle_pos);
        gtk_rays[5] = gtk_rays[3] - ID * cos(angle_pos);
        gtk_rays[6] = gtk_rays[2] - OD * sin(angle_pos - sin_inverse);
        gtk_rays[7] = gtk_rays[3] - OD * cos(angle_pos - sin_inverse);
        gtk_rays[8] = gtk_rays[2] - ID * sin(angle_pos - (sin_inverse * 2));
        gtk_rays[9] = gtk_rays[3] - ID * cos(angle_pos - (sin_inverse * 2));
        gtk_rays[10] = gtk_rays[2] - OD * sin(angle_pos - (sin_inverse * 3));
        gtk_rays[11] = gtk_rays[3] - OD * cos(angle_pos - (sin_inverse * 3));
        gtk_rays[12] = gtk_rays[2] - ID * sin(angle_pos - (sin_inverse * 4));
        gtk_rays[13] = gtk_rays[3] - ID * cos(angle_pos - (sin_inverse * 4));
        gtk_rays[14] = gtk_rays[2] - OD * sin(angle_pos - (sin_inverse * 5));
        gtk_rays[15] = gtk_rays[3] - OD * cos(angle_pos - (sin_inverse * 5));
        gtk_rays[16] = gtk_rays[2] - ID * sin(angle_pos - (sin_inverse * 6));
        gtk_rays[17] = gtk_rays[3] - ID * cos(angle_pos - (sin_inverse * 6));
    }

    for (int i = 0; i < val_ary[NOOF_LEGv_PERA]; i++)
    {
        // gv.sound_path = flsp * (i + 1);
        gv.sound_path = concave_sound_path[i];

        if (i == 0)
        {
            gv.leg = 1;
            sp = gv.sound_path;
            // Depth of reflector D
            d = sqrt(((sp * sp) + (ID * ID)) - (2 * ID * sp * cos(dtor)));
            gv.depth = d - ID;

            // Surface distance S
            sin_inverse = asin(sp * sin(dtor) / d);
            sd = OD * sin_inverse;
            gv.surface_distance = sd;

            cairo_move_to(cr, gtk_rays[4], gtk_rays[5]);
            cairo_line_to(cr, gtk_rays[6], gtk_rays[7]);
        }
        else if (i == 1)
        {
            gv.leg = 2;
            // Depth of reflector D
            sp = (2 * flsp) - gv.sound_path;
            d = sqrt(((sp * sp) + (ID * ID)) - (2 * ID * sp * cos(dtor)));
            gv.depth = d - ID;

            // Surface distance S
            sin_inverse = asin(sp * sin(dtor) / d);
            sd = OD * sin_inverse;
            gv.surface_distance = (2 * flsd) - sd;

            cairo_line_to(cr, gtk_rays[8], gtk_rays[9]);
        }
        else if (i == 2)
        {
            gv.leg = 3;
            // Depth of reflector D
            sp = gv.sound_path - (2 * flsp);
            d = sqrt(((sp * sp) + (ID * ID)) - (2 * ID * sp * cos(dtor)));
            gv.depth = d - ID;

            // Surface distance S
            sin_inverse = asin(sp * sin(dtor) / d);
            sd = OD * sin_inverse;
            gv.surface_distance = (2 * flsd) + sd;

            cairo_line_to(cr, gtk_rays[10], gtk_rays[11]);
        }
        else if (i == 3)
        {
            gv.leg = 4;
            // Depth of reflector D
            sp = (4 * flsp) - gv.sound_path;
            d = sqrt(((sp * sp) + (ID * ID)) - (2 * ID * sp * cos(dtor)));
            gv.depth = d - ID;

            // Surface distance S
            sin_inverse = asin(sp * sin(dtor) / d);
            sd = OD * sin_inverse;
            gv.surface_distance = (4 * flsd) - sd;

            cairo_line_to(cr, gtk_rays[12], gtk_rays[13]);
        }
        else
        {
            gv.leg = 0;
        }

        /*
        g_print("Leg = %d\n", gv.leg);
        g_print("Sound Path = %lf\n", gv.sound_path);
        g_print("Depth = %lf\n", gv.depth);
        g_print("Surface Distance = %lf\n\n", gv.surface_distance);
        */
    }
    cairo_stroke(cr);
}

///****************************************************************
/// @brief
/// @param x         == x is origin co-ordinate of the circle
/// @param y         == y is origin co-ordinate of the circle
/// @param OD        == Outer Diameter
/// @param ID        == Inner Diameter
/// @param angle_pos == probe position
/// @param angle_prb == probe angle
/// @return == group of struct (Sound path, Depth and Surface distance)
///****************************************************************

// sound_path_values value used at OD = 100, ID = 60 and angle = 30 degree
double sound_path_values[6] = {53.41, 106.82, 160.23, 213.64, 267.05, 320.46};

void ConvexCalculations(cairo_t *cr, double x, double y, double OD, double ID, double angle_pos, double angle_prb)
{
    struct GeomertyValues gv;
    double ratio, dtor, sinA;
    double phi, flsp, fld, flsd;
    double sp, sd, diff;
    double len, size;
    double Aprof, root_width, top_width;

    double r_w = val_ary[ROOT_WIDTH_PERA], t_w = val_ary[TOP_WIDTH_PERA], t_h = val_ary[TOP_HEIGHT_PERA], p_pa = val_ary[WPROF_POS_PERA];

    gtk_rays[1] = LINE;
    gtk_rays[2] = x;
    gtk_rays[3] = y;

    gv.Bmax = 0;
    gv.depth = 0;
    gv.sound_path = 0;
    gv.surface_distance = 0;

    // Position angle
    angle_pos = (angle_pos * M_PI) / 180.0; // Radian = ((angleInDegree * M_PI) / 180.0)

    ratio = OD / ID;
    dtor = ((angle_prb * M_PI) / 180);
    sinA = sin(dtor);

    // Projection angle at ID (first leg)
    phi = asin(ratio * sinA);
    diff = phi - dtor;
    // flsp = first leg sound path
    flsp = ID * (sin(diff) / sinA);
    // fld = first leg depth
    fld = OD - sqrt(((flsp * flsp) + (OD * OD)) - (2 * OD * flsp * cos(dtor)));
    // flsd = first leg surface distance
    flsd = (((M_PI * OD) / 180) * ((diff * 180) / M_PI));
    // Maximum angle of refraction for a given wall thickness (angle of impingement)
    gv.Bmax = (((asin((double)ID / (double)OD)) * M_PI) / 180.0);

    /*
    g_print("Phi = %lf, dtor = %lf, diff = %lf\n", phi, dtor, diff);
    g_print("1st Leg Sound_path = %lf\n", flsp);
    g_print("1st Leg Depth = %lf\n", fld);
    g_print("1st Leg Surface Distance = %lf\n", flsd);
    g_print("Bmax = %lf\n\n", gv.Bmax);
    */

    // Note :- This(diff variable) value is not verified please check before use, Why this value is ?
    diff = phi - dtor;
    Aprof = ((p_pa * M_PI) / 180);
    root_width = ((r_w * M_PI) / 180);
    top_width = ((t_w * M_PI) / 180);

    {
        // point[1].x = point[0].x - OD * sin(angle_pos);
        // point[1].y = point[0].y - OD * cos(angle_pos);
        // // Note :- This(diff variable) value is not verified please check before use, Why this value is ?
        // point[2].x = point[0].x - ID * sin(angle_pos - diff);
        // point[2].y = point[0].y - ID * cos(angle_pos - diff);
        // // Note :- This(diff variable) value is not verified please check before use, Why this value is ?
        // point[3].x = point[0].x - OD * sin(angle_pos - (diff * 2));
        // point[3].y = point[0].y - OD * cos(angle_pos - (diff * 2));
        // // Note :- This(diff variable) value is not verified please check before use, Why this value is ?
        // point[4].x = point[0].x - ID * sin(angle_pos - (diff * 3));
        // point[4].y = point[0].y - ID * cos(angle_pos - (diff * 3));
        // // Note :- This(diff variable) value is not verified please check before use, Why this value is ?
        // point[5].x = point[0].x - OD * sin(angle_pos - (diff * 4));
        // point[5].y = point[0].y - OD * cos(angle_pos - (diff * 4));
        // // Note :- This(diff variable) value is not verified please check before use, Why this value is ?
        // point[6].x = point[0].x - ID * sin(angle_pos - (diff * 5));
        // point[6].y = point[0].y - ID * cos(angle_pos - (diff * 5));
        // // Note :- This(diff variable) value is not verified please check before use, Why this value is ?
        // point[7].x = point[0].x - OD * sin(angle_pos - (diff * 6));
        // point[7].y = point[0].y - OD * cos(angle_pos - (diff * 6));

        /*
        cairo_move_to(cr, point[1].X, point[1].Y);
        cairo_line_to(cr, point[2].X, point[2].Y);
        cairo_line_to(cr, point[3].X, point[3].Y);
        cairo_line_to(cr, point[4].X, point[4].Y);
        cairo_line_to(cr, point[5].X, point[5].Y);
        cairo_line_to(cr, point[6].X, point[6].Y);
        cairo_line_to(cr, point[7].X, point[7].Y);
        cairo_stroke(cr);
        */
    } {
        gtk_rays[4] = gtk_rays[2] - OD * sin(angle_pos);
        gtk_rays[5] = gtk_rays[3] - OD * cos(angle_pos);
        // Note :- This(diff variable) value is not verified please check before use, Why this value is ?
        gtk_rays[6] = gtk_rays[2] - ID * sin(angle_pos - diff);
        gtk_rays[7] = gtk_rays[3] - ID * cos(angle_pos - diff);
        // Note :- This(diff variable) value is not verified please check before use, Why this value is ?
        gtk_rays[8] = gtk_rays[2] - OD * sin(angle_pos - (diff * 2));
        gtk_rays[9] = gtk_rays[3] - OD * cos(angle_pos - (diff * 2));
        // Note :- This(diff variable) value is not verified please check before use, Why this value is ?
        gtk_rays[10] = gtk_rays[2] - ID * sin(angle_pos - (diff * 3));
        gtk_rays[11] = gtk_rays[3] - ID * cos(angle_pos - (diff * 3));
        // Note :- This(diff variable) value is not verified please check before use, Why this value is ?
        gtk_rays[12] = gtk_rays[2] - OD * sin(angle_pos - (diff * 4));
        gtk_rays[13] = gtk_rays[3] - OD * cos(angle_pos - (diff * 4));
        // Note :- This(diff variable) value is not verified please check before use, Why this value is ?
        gtk_rays[14] = gtk_rays[2] - ID * sin(angle_pos - (diff * 5));
        gtk_rays[15] = gtk_rays[3] - ID * cos(angle_pos - (diff * 5));
        // Note :- This(diff variable) value is not verified please check before use, Why this value is ?
        gtk_rays[16] = gtk_rays[2] - OD * sin(angle_pos - (diff * 6));
        gtk_rays[17] = gtk_rays[3] - OD * cos(angle_pos - (diff * 6));

        /*
        cairo_move_to(cr, point[1].X, point[1].Y);
        cairo_line_to(cr, point[2].X, point[2].Y);
        cairo_line_to(cr, point[3].X, point[3].Y);
        cairo_line_to(cr, point[4].X, point[4].Y);
        cairo_line_to(cr, point[5].X, point[5].Y);
        cairo_line_to(cr, point[6].X, point[6].Y);
        cairo_line_to(cr, point[7].X, point[7].Y);
        cairo_stroke(cr);
        */
    }

    for (int i = 0; i < val_ary[NOOF_LEGv_PERA]; i++)
    {
        // gv.sound_path = flsp * (i + 1);
        gv.sound_path = sound_path_values[i];

        if (i == 0)
        {
            gv.leg = 1;
            // Depth of reflector
            sp = gv.sound_path;
            gv.depth = OD - sqrt(((sp * sp) + (OD * OD)) - (2 * OD * sp * cos(dtor)));

            // Surface distance
            sd = OD - gv.depth;
            sd = asin((sp / sd) * sinA);
            gv.surface_distance = OD * sd;

            cairo_move_to(cr, gtk_rays[4], gtk_rays[5]);
            cairo_line_to(cr, gtk_rays[6], gtk_rays[7]);
        }
        else if (i == 1)
        {
            gv.leg = 2;
            // Depth of reflector
            sp = (2 * flsp) - gv.sound_path;
            gv.depth = OD - sqrt(((sp * sp) + (OD * OD)) - (2 * OD * sp * cos(dtor)));

            // Surface distance
            sd = OD - gv.depth;
            sd = OD * asin((sp / sd) * sinA);
            gv.surface_distance = (2 * flsd) - sd;

            cairo_line_to(cr, gtk_rays[8], gtk_rays[9]);
        }
        else if (i == 2)
        {
            gv.leg = 3;
            // Depth of reflector
            sp = gv.sound_path - (2 * flsp);
            gv.depth = OD - sqrt(((sp * sp) + (OD * OD)) - (2 * OD * sp * cos(dtor)));

            // Surface distance
            sd = OD - gv.depth;
            sd = OD * asin((sp / sd) * sinA);
            gv.surface_distance = (2 * flsd) + sd;

            cairo_line_to(cr, gtk_rays[10], gtk_rays[11]);
        }
        else if (i == 3)
        {
            gv.leg = 4;
            // Depth of reflector
            sp = (4 * flsp) - gv.sound_path;
            gv.depth = OD - sqrt(((sp * sp) + (OD * OD)) - (2 * OD * sp * cos(dtor)));

            // Surface distance
            sd = OD - gv.depth;
            sd = OD * asin((sp / sd) * sinA);
            gv.surface_distance = (4 * flsd) - sd;

            cairo_line_to(cr, gtk_rays[12], gtk_rays[13]);
        }
        else
        {
            gv.leg = 0;
        }

        // g_print("Leg = %d\n", gv.leg);
        // g_print("Sound Path = %lf\n", gv.sound_path);
        // g_print("Depth = %lf\n", gv.depth);
        // g_print("Surface Distance = %lf\n\n", gv.surface_distance);
    }
    cairo_stroke(cr);
}

#endif /* _SHP_PRF_H */
