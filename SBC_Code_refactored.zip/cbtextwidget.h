#define text_windoww 625 // Size for text boxes window
// #define text_windoww 542
#define text_windowh 550

#define text_height 25 // Size of text box in textbox window
#define text_width 310

#define textbox_width 20
#define textbox_height 20

char o_name[14][41] = {"ZEROAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQ", "OFFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQ", "GATEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQ",
					   "SAVEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQ", "ACTONAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQ", "HORNAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQ",
					   "BEEPAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQ", "CLOCKAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQ", "GAINAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQ",
					   "DACAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQ", "COLORAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQ", "RAILAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQ",
					   "CALAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQ", "WHITEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQ"};

char heading_name[24][41] = {"Opt Name                                ", "Division                                ",
							 "Block Section                           ", "Line Up/Dn/SL                           ",
							 "Km. Post of Start of Testing            ", "Rail-LH/RH                              ",
							 "Location of Defect                      ", "Rolling Mark                            ",
							 "Probe Type                              ", "Flaw Code                               ",
							 "Peak details Hor/Ver                    ", "Classification of defect                ",
							 "Previous Classification                 ", "Jogged plate provided (Y/N)             ",
							 "                                        ", "                                        ",
							 "                                        ", "                                        ",
							 "                                        ", "                                        ",
							 "                                        ", "                                        ",
							 "                                        ", "                                        "};

char o_name_o[574] = "ZEROAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQOFFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQGATEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQSAVEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQACTONAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQHORNAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQBEEPAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQCLOCKAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQGAINAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQDACAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQCOLORAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQRAILAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQCALAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQWHITEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQ";
char stringbox[40];
char *text_prefix[14];
char text_values[14][41];
GtkWidget *t_window, *txtbox, *txtbox1, *txtbox2, *txtbox3, *txtbox4;
GtkWidget *text_h[14], *t_btnok, *t_btncls;
GtkWidget *txtlabel[14];
int i = 0, k = 0, key_scr, ln_no = 0, ary_idx = 0;
long chr_pos = 0;
char as_c;
gboolean my_keypress_function(GtkWidget *widget, GdkEventKey *event, gpointer data);
void OntString(int k_tnt);
void OnTxtBtnOk();
void OnTxtBtnClosed();

void cb_text_widget()
{
	note_flag = true;
	t_window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	gtk_window_set_default_size(GTK_WINDOW(t_window), text_windoww, text_windowh);
	gtk_window_set_decorated(GTK_WINDOW(t_window), false);
	gtk_window_set_position(GTK_WINDOW(t_window), GTK_WIN_POS_CENTER);

	txtbox = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
	gtk_container_add(GTK_CONTAINER(t_window), txtbox);

	/*DEVELOP TEXTBOX AND GIVE IT'S SIZE*/
	for (i = 0; i < 14; i++)
	{
		text_h[i] = gtk_entry_new();
		gtk_widget_set_size_request(text_h[i], text_width, text_height);
		gtk_widget_add_events(text_h[i], GDK_KEY_PRESS_MASK);
		gtk_widget_set_name(text_h[i], "text-entry");
	}

	txtbox1 = gtk_box_new(GTK_ORIENTATION_VERTICAL, 0);
	gtk_box_pack_start(GTK_BOX(txtbox), txtbox1, false, false, 1);

	for (i = 0; i < 14; i++)
	{
		gtk_box_pack_start(GTK_BOX(txtbox1), text_h[i], false, false, 1);
	}

	txtbox3 = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
	gtk_box_pack_start(GTK_BOX(txtbox1), txtbox3, false, false, 1);
	t_btnok = gtk_button_new_with_label("OK");
	gtk_widget_set_halign(GTK_WIDGET(t_btnok), GTK_ALIGN_END);
	gtk_widget_set_size_request(t_btnok, textbox_width, textbox_height);
	gtk_widget_set_name(t_btnok, "tbtn1-entry");
	gtk_box_pack_start(GTK_BOX(txtbox3), t_btnok, false, false, 1);

	/*CREATE READ ONLY TEXT ENTRIES AND CLOSE BUTTON*/

	txtbox2 = gtk_box_new(GTK_ORIENTATION_VERTICAL, 0);
	gtk_box_pack_start(GTK_BOX(txtbox), txtbox2, false, false, 1);

	for (i = 0; i < 14; i++)
	{
		txtlabel[i] = gtk_entry_new();
		gtk_widget_set_size_request(txtlabel[i], text_width, 34);
	}

	for (i = 0; i < 14; i++)
	{
		gtk_box_pack_start(GTK_BOX(txtbox2), txtlabel[i], false, false, 1);
	}

	txtbox4 = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
	gtk_box_pack_start(GTK_BOX(txtbox2), txtbox4, false, false, 1);

	t_btncls = gtk_button_new_with_label("CLOSE");
	gtk_widget_set_halign(GTK_WIDGET(t_btncls), GTK_ALIGN_END);
	gtk_widget_set_size_request(t_btncls, textbox_width, textbox_height);
	gtk_widget_set_name(t_btncls, "tbtn1-entry");
	gtk_box_pack_start(GTK_BOX(txtbox4), t_btncls, false, false, 1);

	for (i = 0; i < 14; i++)
	{
		gtk_entry_set_text(GTK_ENTRY(text_h[i]), o_name[i]);
		gtk_widget_set_can_focus(text_h[i], false);
		gtk_entry_grab_focus_without_selecting(GTK_ENTRY(text_h[i]));
		gtk_widget_set_sensitive(GTK_WIDGET(txtlabel[i]), false);
		gtk_entry_set_text(GTK_ENTRY(txtlabel[i]), heading_name[i]);
		gtk_widget_set_halign(GTK_WIDGET(txtlabel[i]), GTK_ALIGN_START);
		gtk_widget_set_name(txtlabel[i], "labeltext-entry");
	}

	g_signal_connect(t_btncls, "clicked", G_CALLBACK(OnTxtBtnClosed), NULL);
	g_signal_connect(t_btnok, "clicked", G_CALLBACK(OnTxtBtnOk), NULL);
	g_signal_connect(t_window, "key_press_event", G_CALLBACK(my_keypress_function), NULL);
	gtk_widget_show_all(t_window);
	printf("\nTextWSize %d \n", gtk_widget_get_allocated_width(t_window));
	printf("TextHSize %d", gtk_widget_get_allocated_height(t_window));
}

gboolean my_keypress_function(GtkWidget *widget, GdkEventKey *event, gpointer data)
{
	gchar *key;
	const int keycodet = event->keyval;

	switch (event->keyval)
	{
	case GDK_KEY_Tab:
		key = "Tab";
		ln_no = ln_no + 1;
		if (ln_no > 13)
		{
			ln_no = 0;
		}
		chr_pos = 0;
		OntString(0);
		break;

	case GDK_KEY_space:
		key = "space";
		break;

	case GDK_KEY_Left:
		key = "Left";
		chr_pos = chr_pos - 1;
		gtk_widget_set_can_focus(GTK_WIDGET(text_h[ln_no]), true);
		OntString(0);
		break;

	case GDK_KEY_Right:
		key = "Right";
		chr_pos = chr_pos + 1;
		gtk_widget_set_can_focus(GTK_WIDGET(text_h[ln_no]), true);
		OntString(0);
		break;

	case GDK_KEY_Up:
		key = "Up";
		chr_pos;
		gtk_widget_set_can_focus(GTK_WIDGET(text_h[ln_no]), true);
		OntString(1);
		break;

	case GDK_KEY_Down:
		key = "Down";
		chr_pos;
		gtk_widget_set_can_focus(GTK_WIDGET(text_h[ln_no]), true);
		OntString(-1);
		break;

	case GDK_KEY_BackSpace:
		key = "BackSpace";
	case GDK_KEY_Escape:
		key = "Escape";
		break;

	default:
		break;
	}
	return false;
}

void OntString(int k_tnt)
{
	if (chr_pos < 0)
	{
		chr_pos = 0;
	}
	if (chr_pos > 39)
	{
		chr_pos = 39;
	}

	ary_idx = (ln_no * 40) + chr_pos;
	as_c = o_name_o[ary_idx];
	as_c = as_c + k_tnt;
	if (as_c < 65)
	{
		as_c = 65 + 26;
	}
	if (as_c > 90)
	{
		as_c = 65;
	}
	o_name_o[ary_idx] = as_c;

	i = ln_no * 40;
	for (k = 0; k < 40; k++)
	{
		stringbox[k] = o_name_o[i++];
	}

	gchar *ret = g_locale_to_utf8(stringbox, 40, NULL, NULL, NULL);
	gtk_entry_set_text(GTK_ENTRY(text_h[ln_no]), ret);
	// gtk_widget_set_can_focus (text_h[ln_no],true);

	for (i = 0; i < 14; i++)
	{
		gtk_entry_grab_focus_without_selecting(GTK_ENTRY(text_h[i]));
		gtk_widget_set_can_focus(GTK_WIDGET(text_h[i]), false);
		gtk_editable_set_position(GTK_EDITABLE(text_h[i]), chr_pos);
	}
}

void OnTxtBtnOk()
{
	for (i = 0; i < 14; i++)
	{
		text_prefix[i] = (char *)gtk_entry_get_text(GTK_ENTRY(text_h[i]));
		sprintf(text_values[i], "%s", text_prefix[i]);
	}
}

void OnTxtBtnClosed()
{
	gtk_widget_destroy(GTK_WIDGET(t_window));
	note_flag = true;
}