#ifndef _FILE_IO_H
#define _FILE_IO_H

#include <sys/stat.h>

extern int menu_v;
extern int memory_val;


#endif /* _FILE_IO_H  */
