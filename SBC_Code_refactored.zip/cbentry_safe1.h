#define N_cal_windoww 320 // size for keypad window
#define N_cal_windowh 254

#define N_txtview_width 100
#define N_txtview_height 44

#define N_keybtn_width 80 // Keypad Button width and height
#define N_keybtn_hgth 50

GtkWidget *cp_window, *p_v_box, *p_h_box, *p_h1_box, *p_h2_box, *p_h3_box, *p_entry;
GtkWidget *textview, *scrolledwindow;
GtkTextBuffer *buffer;
GtkWidget *btn7, *btn8, *btn9, *btnclr, *btn4, *btn5, *btn6, *btnoff, *btn1, *btn2, *btn3, *btncls, *btn0, *btnem, *btnok, *btn_dot, *btnminus;
GtkTextIter start, end;
                                                                                                             //15
char N_arry_cal[20][10] = {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "ON", "OFF", "OK", "CLR", "CLS",".","-"};
int N_cbtn_idx, N_btn_c;
char N_calc_values[14][10];
char *N_text_keypad;
bool N_flag = true;
char N_range_txt[40];

void N_OnCBtn0(GtkWidget *widget, gpointer data);
void N_OnCBtn1(GtkWidget *widget, gpointer data);
void N_OnCBtn2(GtkWidget *widget, gpointer data);
void N_OnCBtn3(GtkWidget *widget, gpointer data);
void N_OnCBtn4(GtkWidget *widget, gpointer data);
void N_OnCBtn5(GtkWidget *widget, gpointer data);
void N_OnCBtn6(GtkWidget *widget, gpointer data);
void N_OnCBtn7(GtkWidget *widget, gpointer data);
void N_OnCBtn8(GtkWidget *widget, gpointer data);
void N_OnCBtn9(GtkWidget *widget, gpointer data);
void N_OnCBtnClr(GtkWidget *widget, gpointer data);
void N_OnCBtnCls(GtkWidget *widget, gpointer data);
void N_OnCBtnOk(GtkWidget *widget, gpointer data);
void N_OnCBtnDot(GtkWidget* widget, gpointer data); 
void N_OnCBtnMinus(GtkWidget* widget, gpointer data);
void N_Cmn_Cbtn(int btn_c);
static void N_insert_text(GtkTextBuffer* buffer, GtkTextIter* location, gchar* text, gint len, gpointer user_data);

void N_cb_create_entry()
{
	key_flag = true;

	cp_window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	//gtk_window_set_decorated(GTK_WINDOW(cp_window), false);
	p_v_box = gtk_box_new(GTK_ORIENTATION_VERTICAL, 0);
	gtk_container_add(GTK_CONTAINER(cp_window), p_v_box);
	//gtk_window_set_position(GTK_WINDOW(cp_window), GTK_WIN_POS_CENTER);
	//gtk_window_set_titlebar(GTK_WINDOW(cp_window), NULL);
	gtk_window_set_title(GTK_WINDOW(cp_window), "KEYPAD                         ");
	gtk_window_set_deletable(GTK_WINDOW(cp_window), false); // To remove close symbol from the title bar
	//gtk_window_set_position(GTK_WINDOW(cp_window), GTK_WIN_POS_CENTER);
	gtk_window_set_resizable(GTK_WINDOW(cp_window), false);
	gtk_window_set_default_size(GTK_WINDOW(cp_window), N_cal_windoww, N_cal_windowh);
	gtk_window_set_transient_for(GTK_WINDOW(cp_window), GTK_WINDOW(window));
	//gtk_window_set_position(GTK_WINDOW(cp_window), GTK_WIN_POS_CENTER);

	textview = gtk_text_view_new();
	buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(textview));
	gtk_widget_set_size_request(textview, N_txtview_width, N_txtview_height);
	// gtk_text_view_set_wrap_mode (GTK_TEXT_VIEW(textview),GTK_WRAP_CHAR);
	//scrolledwindow = gtk_scrolled_window_new(NULL, NULL);
	//gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(scrolledwindow), GTK_POLICY_ALWAYS, GTK_POLICY_NEVER);
	//gtk_container_add(GTK_CONTAINER(scrolledwindow), textview);
	// gtk_widget_set_size_request(scrolledwindow, txtview_width, 5);
	gtk_box_pack_start(GTK_BOX(p_v_box), textview, false, false, 1);
	// gtk_box_pack_start(GTK_BOX(p_v_box), textview, false, false, 1);
	gtk_widget_set_name(GTK_WIDGET(textview), "TextView");

	p_h_box = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
	gtk_box_pack_start(GTK_BOX(p_v_box), p_h_box, false, false, 1);

	btn7 = gtk_button_new_with_label("7");
	btn8 = gtk_button_new_with_label("8");
	btn9 = gtk_button_new_with_label("9");
	btnclr = gtk_button_new_with_label("CLR");
	gtk_widget_set_size_request(btn7, N_keybtn_width, N_keybtn_hgth);
	gtk_widget_set_size_request(btn8, N_keybtn_width, N_keybtn_hgth);
	gtk_widget_set_size_request(btn9, N_keybtn_width, N_keybtn_hgth);
	gtk_widget_set_size_request(btnclr, N_keybtn_width, N_keybtn_hgth);
	gtk_widget_set_name(GTK_WIDGET(btn7), "calbtn0-entry");
	gtk_widget_set_name(GTK_WIDGET(btn8), "calbtn0-entry");
	gtk_widget_set_name(GTK_WIDGET(btn9), "calbtn0-entry");
	gtk_widget_set_name(GTK_WIDGET(btnclr), "calbtn0-entry");
	gtk_box_pack_start(GTK_BOX(p_h_box), btn7, false, false, 0);
	gtk_box_pack_start(GTK_BOX(p_h_box), btn8, false, false, 0);
	gtk_box_pack_start(GTK_BOX(p_h_box), btn9, false, false, 0);
	gtk_box_pack_start(GTK_BOX(p_h_box), btnclr, false, false, 0);

	p_h1_box = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
	gtk_box_pack_start(GTK_BOX(p_v_box), p_h1_box, false, false, 1);

	btn4 = gtk_button_new_with_label("4");
	btn5 = gtk_button_new_with_label("5");
	btn6 = gtk_button_new_with_label("6");
	btnminus = gtk_button_new_with_label("-");
	gtk_widget_set_size_request(btn4, N_keybtn_width, N_keybtn_hgth);
	gtk_widget_set_size_request(btn5, N_keybtn_width, N_keybtn_hgth);
	gtk_widget_set_size_request(btn6, N_keybtn_width, N_keybtn_hgth);
	gtk_widget_set_size_request(btnminus, N_keybtn_width, N_keybtn_hgth);
	gtk_widget_set_name(GTK_WIDGET(btn4), "calbtn0-entry");
	gtk_widget_set_name(GTK_WIDGET(btn5), "calbtn0-entry");
	gtk_widget_set_name(GTK_WIDGET(btn6), "calbtn0-entry");
	gtk_widget_set_name(GTK_WIDGET(btnminus), "calbtn0-entry");
	gtk_box_pack_start(GTK_BOX(p_h1_box), btn4, false, false, 0);
	gtk_box_pack_start(GTK_BOX(p_h1_box), btn5, false, false, 0);
	gtk_box_pack_start(GTK_BOX(p_h1_box), btn6, false, false, 0);
	gtk_box_pack_start(GTK_BOX(p_h1_box), btnminus, false, false, 0);

	p_h2_box = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
	gtk_box_pack_start(GTK_BOX(p_v_box), p_h2_box, false, false, 1);

	btn1 = gtk_button_new_with_label("1");
	btn2 = gtk_button_new_with_label("2");
	btn3 = gtk_button_new_with_label("3");
	btncls = gtk_button_new_with_label("CLS");
	gtk_widget_set_size_request(btn1, N_keybtn_width, N_keybtn_hgth);
	gtk_widget_set_size_request(btn2, N_keybtn_width, N_keybtn_hgth);
	gtk_widget_set_size_request(btn3, N_keybtn_width, N_keybtn_hgth);
	gtk_widget_set_size_request(btncls, N_keybtn_width, N_keybtn_hgth);
	gtk_widget_set_name(GTK_WIDGET(btn1), "calbtn0-entry");
	gtk_widget_set_name(GTK_WIDGET(btn2), "calbtn0-entry");
	gtk_widget_set_name(GTK_WIDGET(btn3), "calbtn0-entry");
	gtk_widget_set_name(GTK_WIDGET(btncls), "calbtn0-entry");
	gtk_box_pack_start(GTK_BOX(p_h2_box), btn1, false, false, 0);
	gtk_box_pack_start(GTK_BOX(p_h2_box), btn2, false, false, 0);
	gtk_box_pack_start(GTK_BOX(p_h2_box), btn3, false, false, 0);
	gtk_box_pack_start(GTK_BOX(p_h2_box), btncls, false, false, 0);

	p_h3_box = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
	gtk_box_pack_start(GTK_BOX(p_v_box), p_h3_box, false, false, 1);

	btn0 = gtk_button_new_with_label("0");
	btnem = gtk_button_new_with_label(" ");
	btnok = gtk_button_new_with_label("SET");
	btn_dot = gtk_button_new_with_label(".");
	gtk_widget_set_size_request(btn0, N_keybtn_width, N_keybtn_hgth);
	gtk_widget_set_size_request(btnem, N_keybtn_width, N_keybtn_hgth);
	gtk_widget_set_size_request(btnok, N_keybtn_width, N_keybtn_hgth);
	gtk_widget_set_size_request(btn_dot, N_keybtn_width, N_keybtn_hgth);
	gtk_widget_set_name(GTK_WIDGET(btn0), "calbtn0-entry");
	gtk_widget_set_name(GTK_WIDGET(btnem), "calbtn0-entry");
	gtk_widget_set_name(GTK_WIDGET(btnok), "calbtn0-entry");
	gtk_widget_set_name(GTK_WIDGET(btn_dot), "calbtn0-entry");
	gtk_box_pack_start(GTK_BOX(p_h3_box), btn0, false, false, 0);
	gtk_box_pack_start(GTK_BOX(p_h3_box), btnem, false, false, 0);
	gtk_box_pack_start(GTK_BOX(p_h3_box), btnok, false, false, 0);
	gtk_box_pack_start(GTK_BOX(p_h3_box), btn_dot, false, false, 0);

	g_signal_connect(btn0, "clicked", G_CALLBACK(N_OnCBtn0), NULL);
	g_signal_connect(btn1, "clicked", G_CALLBACK(N_OnCBtn1), NULL);
	g_signal_connect(btn2, "clicked", G_CALLBACK(N_OnCBtn2), NULL);
	g_signal_connect(btn3, "clicked", G_CALLBACK(N_OnCBtn3), NULL);
	g_signal_connect(btn4, "clicked", G_CALLBACK(N_OnCBtn4), NULL);
	g_signal_connect(btn5, "clicked", G_CALLBACK(N_OnCBtn5), NULL);
	g_signal_connect(btn6, "clicked", G_CALLBACK(N_OnCBtn6), NULL);
	g_signal_connect(btn7, "clicked", G_CALLBACK(N_OnCBtn7), NULL);
	g_signal_connect(btn8, "clicked", G_CALLBACK(N_OnCBtn8), NULL);
	g_signal_connect(btn9, "clicked", G_CALLBACK(N_OnCBtn9), NULL);
	g_signal_connect(btnminus, "clicked", G_CALLBACK(N_OnCBtnMinus), NULL);
	g_signal_connect(btn_dot, "clicked", G_CALLBACK(N_OnCBtnDot), NULL);
	g_signal_connect(btnclr, "clicked", G_CALLBACK(N_OnCBtnClr), NULL);
	g_signal_connect(btnok, "clicked", G_CALLBACK(N_OnCBtnOk), NULL);
	g_signal_connect(btncls, "clicked", G_CALLBACK(N_OnCBtnCls), NULL);
	g_signal_connect_after(buffer, "insert-text", G_CALLBACK(N_insert_text), NULL);

	gtk_widget_show_all(cp_window);
}

void N_OnCBtn0(GtkWidget *widget, gpointer data)
{
	gtk_text_buffer_insert_at_cursor(buffer, N_arry_cal[0], 1);
}

void N_OnCBtn1(GtkWidget *widget, gpointer data)
{
	gtk_text_buffer_insert_at_cursor(buffer, N_arry_cal[1], 1);
}

void N_OnCBtn2(GtkWidget *widget, gpointer data)
{
	gtk_text_buffer_insert_at_cursor(buffer, N_arry_cal[2], 1);
}

void N_OnCBtn3(GtkWidget *widget, gpointer data)
{
	gtk_text_buffer_insert_at_cursor(buffer, N_arry_cal[3], 1);
}

void N_OnCBtn4(GtkWidget *widget, gpointer data)
{
	gtk_text_buffer_insert_at_cursor(buffer, N_arry_cal[4], 1);
}

void N_OnCBtn5(GtkWidget *widget, gpointer data)
{
	gtk_text_buffer_insert_at_cursor(buffer, N_arry_cal[5], 1);
}

void N_OnCBtn6(GtkWidget *widget, gpointer data)
{
	gtk_text_buffer_insert_at_cursor(buffer, N_arry_cal[6], 1);
}

void N_OnCBtn7(GtkWidget *widget, gpointer data)
{
	gtk_text_buffer_insert_at_cursor(buffer, N_arry_cal[7], 1);
}

void N_OnCBtn8(GtkWidget *widget, gpointer data)
{
	gtk_text_buffer_insert_at_cursor(buffer, N_arry_cal[8], 1);
}

void N_OnCBtn9(GtkWidget *widget, gpointer data)
{
	gtk_text_buffer_insert_at_cursor(buffer, N_arry_cal[9], 1);
}

void N_OnCBtnClr(GtkWidget *widget, gpointer data)
{
	gtk_text_buffer_set_text(buffer, "", 0);
}

void N_OnCBtnCls(GtkWidget *widget, gpointer data)
{
	gtk_widget_destroy(GTK_WIDGET(cp_window));
	key_flag = true;
}

void N_OnCBtnDot(GtkWidget* widget, gpointer data)
{
	gtk_text_buffer_insert_at_cursor(buffer, N_arry_cal[15], 1);
}
void N_OnCBtnMinus(GtkWidget* widget, gpointer data)
{
	gtk_text_buffer_insert_at_cursor(buffer, N_arry_cal[16], 1);
}

void N_OnCBtnOk(GtkWidget *widget, gpointer data)
{
	float tempscr_val = 0.0;
	key_scr = 2;
	prev_val = val_ary[(menu_v * 5) + btn_idx];
	gtk_text_buffer_get_bounds(buffer, &start, &end);
	N_text_keypad = gtk_text_buffer_get_text(buffer, &start, &end, false);
	pos = menu_v * 10;
	sprintf(N_range_txt, " %s ", N_text_keypad);
	
	scr_val = atoi(N_range_txt);
	
	//if (scr_val == 0) { scr_val = prev_val; }
	//if (scr_val > max_value) { scr_val = prev_val; }
	val_ary[(menu_v * 5) + btn_idx] = scr_val;
	int btn_clk = (menu_v * 5) + btn_idx;
	tempscr_val = atof(N_range_txt);
	
	key_array[(menu_v * 5) + btn_idx] = tempscr_val;
	
	AllProcess(0);
	Menu_Refresh();
	btn_flag == true;
}

// gtk_text_view_set_overwrite (GTK_TEXT_VIEW(textview), true);
// gtk_text_view_set_wrap_mode (GTK_TEXT_VIEW(textview),GTK_WRAP_CHAR);
// gtk_text_view_set_right_margin (GTK_TEXT_VIEW(textview),r_margin);
// gtk_text_view_set_bottom_margin (GTK_TEXT_VIEW(textview),r_margin);

void N_Cmn_Cbtn(int btn_c)
{
	gint r_margin = 10.0;
	if (btn_c == 0)
	{
		gtk_text_buffer_insert_at_cursor(buffer, N_arry_cal[0], 1);
	}
	if (btn_c == 1)
	{
		gtk_text_buffer_insert_at_cursor(buffer, N_arry_cal[1], 1);
	}
	if (btn_c == 2)
	{
		gtk_text_buffer_insert_at_cursor(buffer, N_arry_cal[2], 1);
	}
	if (btn_c == 3)
	{
		gtk_text_buffer_insert_at_cursor(buffer, N_arry_cal[3], 1);
	}
	if (btn_c == 4)
	{
		gtk_text_buffer_insert_at_cursor(buffer, N_arry_cal[4], 1);
	}
	if (btn_c == 5)
	{
		gtk_text_buffer_insert_at_cursor(buffer, N_arry_cal[5], 1);
	}
	if (btn_c == 6)
	{
		gtk_text_buffer_insert_at_cursor(buffer, N_arry_cal[6], 1);
	}
	if (btn_c == 7)
	{
		gtk_text_buffer_insert_at_cursor(buffer, N_arry_cal[7], 1);
	}
	if (btn_c == 8)
	{
		gtk_text_buffer_insert_at_cursor(buffer, N_arry_cal[8], 1);
	}
	if (btn_c == 9)
	{
		gtk_text_buffer_insert_at_cursor(buffer, N_arry_cal[9], 1);
	}
	if (btn_c == 10)
	{
		gtk_text_buffer_set_text(buffer, "", 0);
	}
	if (btn_c == 11)
	{
		gtk_widget_destroy(GTK_WIDGET(cp_window));
	}
	if (btn_c == 12)
	{
		gtk_text_buffer_insert_at_cursor(buffer, N_arry_cal[15], 1);
	}
	if (btn_c == 13)
	{
		gtk_text_buffer_insert_at_cursor(buffer, N_arry_cal[16], 1);
	}
}

void N_Range_Key()
{
	N_cb_create_entry();
	N_text_keypad = gtk_text_buffer_get_text(buffer, &start, &end, false);
	sprintf(N_range_txt, " %s ", N_text_keypad);
	scr_val = atoi(N_range_txt);
	val_ary[(menu_v * 5) + btn_idx] = scr_val;
}

static void N_insert_text(GtkTextBuffer* buffer, GtkTextIter* location, gchar* text, gint len, gpointer user_data)
{
	static int i = 1;
	gint count_key = gtk_text_buffer_get_char_count(buffer);

	if (count_key > 5)
	{
		GtkTextIter offset, end;
		gtk_text_buffer_get_iter_at_offset(buffer, &offset, 10);
		gtk_text_buffer_get_end_iter(buffer, &end);

		gtk_text_buffer_delete(buffer, &offset, &end);
		gtk_text_iter_assign(location, &offset);
	}
}