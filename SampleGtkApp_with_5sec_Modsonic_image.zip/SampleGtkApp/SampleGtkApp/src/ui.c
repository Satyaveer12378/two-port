#include <gtk/gtk.h>
#include "ui.h"

// Button callbacks
static void on_zero_clicked(GtkWidget *widget, gpointer data) {
    g_print("ZERO button clicked!\n");
}
static void on_range_clicked(GtkWidget *widget, gpointer data) {
    g_print("RANGE button clicked!\n");
}

static gboolean switch_to_homepage_cb(gpointer data) {
	GtkWidget **widgets = (GtkWidget **)data;
	GtkWidget *splash = widgets[0];
	GtkWidget *homepage = widgets[1];

	gtk_widget_hide(splash);
	gtk_widget_show_all(homepage);



	return FALSE;
}




void build_ui(GtkApplication *app) {
    GtkWidget *window;
    GtkWidget *container;
    GtkWidget *splash;
    GtkWidget *homepage;
    GtkWidget *hbox;
    GtkWidget *vbox;
    GtkWidget *btn_zero;
    GtkWidget *btn_range;
    GtkWidget *label;

    // Create main window
    window = gtk_application_window_new(app);
    gtk_window_set_title(GTK_WINDOW(window), "Sample GTK App");
    gtk_window_set_default_size(GTK_WINDOW(window), 1024, 600);

   //Overlay lets us stack widgets on top of each other
    container = gtk_box_new(GTK_ORIENTATION_VERTICAL,0 );
    gtk_container_add(GTK_CONTAINER(window),container);

    //------ Screen 1: Image-----
    splash = gtk_image_new_from_file("assets/St_Scrn.png");
    gtk_box_pack_start(GTK_BOX(container), splash, TRUE, TRUE, 0);

    //--------Screen 2: Image-----
    hbox = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 5);

    //left  side vertical label
    label = gtk_label_new("Homepage");
    gtk_box_pack_start(GTK_BOX(hbox), label, TRUE, TRUE, 10);


    // Right side vertical layout
    vbox = gtk_box_new(GTK_ORIENTATION_VERTICAL, 10);
    gtk_box_pack_end(GTK_BOX(hbox), vbox, FALSE, FALSE, 10);

    // Buttons
    btn_zero = gtk_button_new_with_label("ZERO");
    g_signal_connect(btn_zero, "clicked", G_CALLBACK(on_zero_clicked), NULL);
    gtk_box_pack_start(GTK_BOX(vbox), btn_zero, FALSE, FALSE, 5);

    btn_range = gtk_button_new_with_label("RANGE");
    g_signal_connect(btn_range, "clicked", G_CALLBACK(on_range_clicked), NULL);
    gtk_box_pack_start(GTK_BOX(vbox), btn_range, FALSE, FALSE, 5);

    homepage = hbox;
    gtk_box_pack_start(GTK_BOX(container), homepage, TRUE, TRUE, 0);
    gtk_widget_hide(homepage);


    gtk_widget_show_all(window);
    gtk_widget_hide(homepage);


    GtkWidget **widgets = g_new(GtkWidget*, 2);
    widgets[0] = splash;
    widgets[1] = homepage;

    g_timeout_add(5000,switch_to_homepage_cb, widgets);



}
