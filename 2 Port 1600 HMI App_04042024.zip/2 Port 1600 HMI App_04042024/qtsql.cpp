#include "qtsql.h"




void qtsql::createDB (void) {

    db = QSqlDatabase::addDatabase ("QSQLITE");
    db.setDatabaseName ("profile.db");
     if (db.open () == false) {
     QMessageBox::critical (this, "Database open error", db.lastError ().text ());
    }
}

void qtsql::createTable (void) {
    QString str ("CREATE TABLE Profile(id INT PRIMARY KEY NOT NULL, name TEXT NOT NULL, score REAL NOT NULL)");
    QSqlQuery query;
    query.exec (str);
}

void qtsql::queryTable (void) {

    QString str ("SELECT * FROM Profile");
    model.setQuery (str);
//ui->tableView->setModel (&model);
}
