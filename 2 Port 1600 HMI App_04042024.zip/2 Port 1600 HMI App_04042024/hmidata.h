#ifndef HMIDATA_H
#define HMIDATA_H

#include <QObject>
#include <QtCore/QCoreApplication>
#include <QObject>
#include <QtSql>
#include <QDebug>
#include <QFile>
#include "QTableView"

//#include </opt/poky/2.2.2/sysroots/cortexa9hf-neon-poky-linux-gnueabi/usr/include/stdio.h>
//#include
//#include </opt/poky/2.2.2/sysroots/cortexa9hf-neon-poky-linux-gnueabi/usr/include/fcntl.h>
//#include </opt/poky/2.2.2/sysroots/cortexa9hf-neon-poky-linux-gnueabi/usr/include/unistd.h>
//#include </opt/poky/2.2.2/sysroots/cortexa9hf-neon-poky-linux-gnueabi/usr/include/string.h>
//#include </opt/poky/2.2.2/sysroots/cortexa9hf-neon-poky-linux-gnueabi/usr/include/stdlib.h>
//#include </opt/poky/2.2.2/sysroots/cortexa9hf-neon-poky-linux-gnueabi/usr/include/errno.h>



class Hmidata : public QObject
{
    Q_OBJECT

public:
    explicit Hmidata(QObject *parent = 0);



    Q_INVOKABLE int job_ID;

    Q_INVOKABLE void savejobID(QString job);

    /* Sqlite Database create */
    Q_INVOKABLE QSqlDatabase  sql_create();
    /* Sqlite Database open */
    Q_INVOKABLE void  sql_open();
    /* Sqlite Database close */
    Q_INVOKABLE void sql_close(QSqlDatabase DatabaseName);
    /* Sqlite Database Table create */
    Q_INVOKABLE QSqlQuery sql_create_table(QString sql_table_keys);
    /* Sqlite Database data insert */
    Q_INVOKABLE int sql_insert_data(QSqlQuery sql_table, QString insertDataSql);
    /* Sqlite Database data update */
    Q_INVOKABLE void hmiDataupdate(QString name);
    /* Sqlite Database data delete */
    Q_INVOKABLE int sql_delete_data(QSqlQuery sql_table, QString delete_string, int id);
    /* Sqlite Database Table clear */
    Q_INVOKABLE int sql_clear_table(QSqlQuery sql_table, QString clear_string);
    /* Sqlite database Table current max id select */
    Q_INVOKABLE int sql_select_maxid(QSqlQuery sql_table, QString select_string);
    // update Data
    //Q_INVOKABLE void on_Add_Data(int JobID,QString Stud,int Count);
    /* Get Weld count*/
    Q_INVOKABLE int stud_weld_count(QSqlQuery sql_table, QString select_string);
    Q_INVOKABLE int getjobIds();
    Q_INVOKABLE int getjobId(int index);
    Q_INVOKABLE int getstudnames(int id);
    Q_INVOKABLE    QString getstudname(int index);
    Q_INVOKABLE int   getstudcounts(int id, QString name);
    Q_INVOKABLE int getstudcount(int index);

    Q_INVOKABLE QSqlDatabase MyDataBase;
    Q_INVOKABLE QString data_string;

     QSqlQuery Hmi_Weldrecs;
    //QString sql_table_set = "CREATE TABLE IF NOT EXISTS Stud_Weldcount_table (one varchar(10), two smallint , three int)";
    //primary key
    QString sql_table_set = "CREATE TABLE IF NOT EXISTS Weld_table (sno int primary key, id int, name varchar(10), count int)";
    QString select_string_set = "select max (sno) from Weld_table";
    QString delete_string_set = "DELETE FROM Weld_table WHERE id IS ";
    QString clear_string_set = "DELETE FROM Weld_table";
    QString select_weld_count= "select (count) from Weld_table";
    QString select_id_no= "select distinct (id) from Weld_table";
    QString select_count_no= "select (name) and (count) from Weld_table WHERE id is";
    //QString select_stud_name= "select (name)from Weld_table WHERE id is";
    int max_id = 0;
    int weld_count=0;
    QList<int> jIds;
    QList<int> studcounts;
    QList<QString> studnames;
    enum Hmidata_Reports

    {
        Hmidata_Reports_JobID
    };





};
#endif // SQLITESET_H
