#include <QCoreApplication>
#include <QGuiApplication>
#include <QKeyEvent>
#include <QQuickItem>
#include "key_emitter.h"

KeyEmitter::KeyEmitter()
{
}

KeyEmitter::~KeyEmitter()
{
}

void KeyEmitter::emitKey1(Qt::Key key, int shift)
{
     Qt::KeyboardModifier keyBoardModifier;
     QString keyname = QKeySequence(key).toString();
     QChar keyChar;

    QQuickItem* receiver = qobject_cast<QQuickItem*>(QGuiApplication::focusObject());
    if(!receiver) {
        return;
    }
    if (keyname[0].unicode() >= 'A' && keyname[0].unicode() <= 'Z')
    {
        if(!shift)
        {
            qDebug() << keyname;
            key = (Qt::Key)(Qt::Key_A + keyname[0].unicode() - 'a');
            keyname[0] = (('a' - 'A' )+ keyname.at(0).unicode());
            qDebug() << keyname;
        }
    }
    if(shift) {
       keyBoardModifier = Qt::ShiftModifier;
    }
    else
    {
       keyBoardModifier = Qt::NoModifier;
    }
    QKeyEvent pressEvent = QKeyEvent(QEvent::KeyPress, key,keyBoardModifier, keyname);
    QKeyEvent releaseEvent = QKeyEvent(QEvent::KeyRelease, key, keyBoardModifier);
    QCoreApplication::sendEvent(receiver, &pressEvent);
    QCoreApplication::sendEvent(receiver, &releaseEvent);
}


void KeyEmitter::emitKey(QString keyName)
{
    Qt::Key keycode = getKeyCodeFromName(keyName);

    QQuickItem* receiver = qobject_cast<QQuickItem*>(QGuiApplication::focusObject());
    if(!receiver) {
        return;
    }

    if (keycode == Qt::Key_unknown)
        return;

    //A-Z
    if (keyName.length() == 1 && keyName[0].unicode() >= 'A' && keyName[0].unicode() <= 'Z')
    {
        QKeyEvent pressEvent = QKeyEvent(QEvent::KeyPress, keycode,Qt::ShiftModifier, keyName);
        QKeyEvent releaseEvent = QKeyEvent(QEvent::KeyRelease, keycode, Qt::ShiftModifier);
        QCoreApplication::sendEvent(receiver, &pressEvent);
        QCoreApplication::sendEvent(receiver, &releaseEvent);
    }
    else
    {
        QKeyEvent pressEvent = QKeyEvent(QEvent::KeyPress, keycode,Qt::NoModifier, keyName);
        QKeyEvent releaseEvent = QKeyEvent(QEvent::KeyRelease, keycode, Qt::NoModifier);
        QCoreApplication::sendEvent(receiver, &pressEvent);
        QCoreApplication::sendEvent(receiver, &releaseEvent);
    }

    qDebug("Simulating key: %s", qPrintable(keyName));
}

Qt::Key KeyEmitter::getKeyCodeFromName(QString keyname)
{
    keyname = keyname.toLower();
    if (keyname.length() < 1)
        return Qt::Key_unknown;

    if (keyname == "left")              return Qt::Key_Left;
    else if (keyname == "right")        return Qt::Key_Right;
    else if (keyname == "up")           return Qt::Key_Up;
    else if (keyname == "down")         return Qt::Key_Down;
    else if (keyname == "center")       return Qt::Key_Enter;
    else if (keyname == "enter")        return Qt::Key_Enter;
    else if (keyname == "tab")          return Qt::Key_Tab;
    else if (keyname == "\n")           return Qt::Key_Enter;
    else if (keyname == "cpanel")       return Qt::Key_PageUp;
    else if (keyname == "widget")       return Qt::Key_PageDown;
    else if (keyname == "pgup")         return Qt::Key_PageUp;
    else if (keyname == "pgdown")       return Qt::Key_PageDown;
    else if (keyname == "pageup")       return Qt::Key_PageUp;
    else if (keyname == "pagedown")     return Qt::Key_PageDown;

    else if (keyname == "esc")          return Qt::Key_Escape;
    else if (keyname == "del")          return Qt::Key_Delete;
    else if (keyname == "delete")       return Qt::Key_Delete;
    else if (keyname == "backspace")    return Qt::Key_Backspace;
    else if (keyname == "space")        return Qt::Key_Space;
    else if (keyname == " ")            return Qt::Key_Space;
    else if (keyname == "+")            return Qt::Key_Plus;
    else if (keyname == "-")            return Qt::Key_Minus;
    else if (keyname == "*")            return Qt::Key_Asterisk;
    else if (keyname == "/")            return Qt::Key_Slash;
    else if (keyname == "\\")           return Qt::Key_Backslash;
    else if (keyname == ".")            return Qt::Key_Period;
    else if (keyname == ",")            return Qt::Key_Comma;
    else if (keyname == "?")            return Qt::Key_Question;
    else if (keyname == "<")            return Qt::Key_Less;
    else if (keyname == ">")            return Qt::Key_Greater;
    else if (keyname == "=")            return Qt::Key_Equal;
    else if (keyname == "@")            return Qt::Key_At;
    else if (keyname == "!")            return Qt::Key_Exclam;
    else if (keyname == "%")            return Qt::Key_Percent;
    else if (keyname == "$")            return Qt::Key_Dollar;
    else if (keyname == ":")            return Qt::Key_Colon;
    else if (keyname == ";")            return Qt::Key_Semicolon;
    else if (keyname == "(")            return Qt::Key_BracketLeft;
    else if (keyname == ")")            return Qt::Key_BracketRight;
    else if (keyname == "{")            return Qt::Key_BraceLeft;
    //else if (keyname =&&&&= "}")            return Qt::Key_BraceRight;
    else if (keyname == "\"")           return Qt::Key_QuoteDbl;
    else if (keyname == "volup")        return Qt::Key_VolumeUp;
    else if (keyname == "voldown")      return Qt::Key_VolumeDown;
    else if (keyname == "mute")         return Qt::Key_VolumeMute;
    else if (keyname == "search")       return Qt::Key_Search;
    else if (keyname == "menu")         return Qt::Key_Menu;
    else if (keyname == "return")         return Qt::Key_Return;

    else if (keyname.length() >= 2)
    {
        if (keyname.startsWith('f'))
        {
            bool convertOK = false;
            keyname = keyname.right(keyname.length()-1);
            int findex = keyname.toInt(&convertOK);
            if (convertOK)
                return (Qt::Key)(Qt::Key_F1 + (findex-1));
        }
    }
    else
    {
        //a-z
        if (keyname[0].unicode() >= 'a' && keyname[0].unicode() <= 'z')
            return (Qt::Key)(Qt::Key_A + keyname[0].unicode() - 'a');

        //A-Z
        if (keyname[0].unicode() >= 'A' && keyname[0].unicode() <= 'Z')
            return (Qt::Key)(Qt::Key_A + keyname[0].unicode() - 'A');

        if (keyname[0].unicode() >= '0' && keyname[0].unicode() <= '9')
            return (Qt::Key)(Qt::Key_0 + keyname[0].unicode() - 'a');
    }

    return Qt::Key_unknown;
}
