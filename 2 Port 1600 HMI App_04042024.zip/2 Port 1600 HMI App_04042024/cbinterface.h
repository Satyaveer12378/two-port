#ifndef CBInterface_H
#define CBInterface_H

#include <QObject>
#include <QThread>
#include <QDateTime>
#include <QFile>
#include <QFileInfo>
#include <QtSerialPort/qserialport.h>


#define TIME 0x0
#define TEMPERATURE 0x1
#define PRESSURE 0x2
#define SPEED 0x3
#define STOP 0x4


#define PKT_SIZE 128
#define GET_WP_CMD 0xE1
#define GET_WP_RESP 0xE2
#define WELD_STATUS 0xE3
#define CONTACT_STATUS 0xE4
#define RESET_WELD_CNT 0xE5
#define STATUS_MSG 0xE6
#define CURRENT_PROF 0xE7
#define FW_UPGRADE_START 0xE8
#define FW_UPGRADE_WRITE 0xEA
#define FW_UPGRADE_END 0xEC

#define ACK 0xA0

#define DLEESC 0x10
#define STX 0x02
#define ETX 0x03

#define FW_START 0x1
#define FW_START_ACK 0xE9
#define FW_DATA 0x3
#define FW_DATA_ACK 0xEB
#define FW_END 0x5
#define FW_END_ACK 0xED

#define FW_VER 0xEE
#define FW_VER_ACK 0xEF




enum TestState {
    CMD_IDLE,
    SEND_TEST_CMD,
    SEND_CMD
};



class CBInterface  : public QThread
{
    Q_OBJECT
public:
    CBInterface(QObject *parent=0);
    ~CBInterface();
    QObject *mParent;


private:

    bool cmdSent;
    char cmdBuffer[PKT_SIZE];

    unsigned char addressBytes[3];


    int cmdSize;
    int cmdResend;
    qint64 sendTimeStamp;
    int startTimeStamp;

    qint64 fwUpdateCheck;

    QDateTime cTime;

    quint16 sum;
    quint16 psum;



    bool DLEFlag;
    bool STXFlag;
    bool ETXFlag;
    char recvBuffer[PKT_SIZE];
    int recvPos;
    bool fwUpdate;
    bool fwEndrecived;
    bool fwVer;
    int fwstatus;
    int lineCount=0;

    float FVer;

    FILE *wFile;
    QFile rFile;

    // Communication status flags
    void sendCommand(char *packet, int cnt);
    void prepareCommand(bool test);

public:


    void run();
    void close();
    void sendWeldParam(int gun);
    void sendResetCount(int gun);
    void sendPackets(QSerialPort *port);
    void ackReceived(int cmd);
    void receiveCommands(QSerialPort *port);
    void processPacket(unsigned char *packet);
    void checkFileCount(int gun);

    void sendFWUpgradeStart();
    void startFWUpdate();
    void sendFWUpdate(QString data);
    void sendFWUpgradeEnd();
    void queryFWVersion();
    void updateFW();
    void getFWVersion();
    unsigned char ascii_to_bcd(char ascii0, char ascii1);

    TestState CBInterfaceState;
    bool testCompleted;
    QByteArray currentVals;
    int ErrorType;
    int FWVersion;

signals:
    void currentStatus(int);

};

#endif // CBInterface_H
