#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <dataoperations.h>
#include <key_emitter.h>
#include <QFile>
#include <QDir>
#include <QtWidgets/QApplication>
#include <QtQuick>
#include<users.h>
#include<hmidata.h>
#include<datetimeedit.h>
//#include <dynamicModel.h>



void createFolders();

int main(int argc, char *argv[])
{
    //QCoreApplication::setAttribute();

    QApplication app(argc, argv);
    createFolders();
    qmlRegisterType<DataOperations>("DataOperations", 1, 0, "DataOperations");
    qmlRegisterType<CurrentGraph>("CurrentGraph", 1, 0, "CurrentGraph");
    qmlRegisterType<Users>("Users", 1, 0, "Users");
    qmlRegisterType<KeyEmitter>("KeyEmitter", 1, 0, "KeyEmitter");
    qmlRegisterType<Hmidata>("Hmidata", 1, 0, "Hmidata");


    QQmlApplicationEngine engine;
    const QUrl url(QStringLiteral("qrc:/main.qml"));
    QObject::connect(&engine, &QQmlApplicationEngine::objectCreated,
                     &app, [url](QObject *obj, const QUrl &objUrl) {
        if (!obj && url == objUrl)
            QCoreApplication::exit(-1);
    }, Qt::QueuedConnection);
    engine.load(url);

    return app.exec();
}


void createFolders() {

    QString temp = DATAPATH;
    if(!QDir(temp.toLatin1().data()).exists()) {
        QDir().mkdir(temp.toLatin1().data());
    }

    temp = DATAPATH;
    temp = temp+"Profiles";
    if(!QDir(temp.toLatin1().data()).exists()) {
        QDir().mkdir(temp.toLatin1().data());
    }

    temp = DATAPATH;
    temp=temp+"Current";
    if(!QDir(temp.toLatin1().data()).exists()) {
        QDir().mkdir(temp.toLatin1().data());
    }
    temp = DATAPATH;
    temp = temp+"Images";
    if(!QDir(temp.toLatin1().data()).exists()) {
        QDir().mkdir(temp.toLatin1().data());
    }

    temp = "/home/Images";
    if(!QDir(temp.toLatin1().data()).exists()) {
        QDir().mkdir(temp.toLatin1().data());
    }
    temp = DATAPATH;
    temp=temp+"Current/G1/";
    if(!QDir(temp.toLatin1().data()).exists()) {
        QDir().mkdir(temp.toLatin1().data());
    }
    temp = DATAPATH;
    temp=temp+"Current/G2/";
    if(!QDir(temp.toLatin1().data()).exists()) {
        QDir().mkdir(temp.toLatin1().data());
    }
    temp = DATAPATH;
    temp=temp+"Users";
    if(!QDir(temp.toLatin1().data()).exists()) {
        QDir().mkdir(temp.toLatin1().data());
    }
    temp = DATAPATH;
    temp=temp+"Count";
    if(!QDir(temp.toLatin1().data()).exists()) {
        QDir().mkdir(temp.toLatin1().data());
    }
    temp = DATAPATH;
    temp=temp+"PCount";
    if(!QDir(temp.toLatin1().data()).exists()) {
        QDir().mkdir(temp.toLatin1().data());
    }
    temp = DATAPATH;
    temp=temp+"Count/G1/";
    if(!QDir(temp.toLatin1().data()).exists()) {
        QDir().mkdir(temp.toLatin1().data());
    }
    temp = DATAPATH;
    temp=temp+"Count/G2/";
    if(!QDir(temp.toLatin1().data()).exists()) {
        QDir().mkdir(temp.toLatin1().data());
    }
    temp = DATAPATH;
    temp=temp+"PCount/G2/";
    if(!QDir(temp.toLatin1().data()).exists()) {
        QDir().mkdir(temp.toLatin1().data());
    }
    temp = DATAPATH;
    temp=temp+"PCount/G1/";
    if(!QDir(temp.toLatin1().data()).exists()) {
        QDir().mkdir(temp.toLatin1().data());
    }
}
