/***********************************************************************
* FILENAME : CBInterface.cpp
*
* DESCRIPTION : CBInterface class provides the communication interface to the
* controller board. Sending comamnds and receiveing the status updates from
* controller board.
*
************************************************************************/

#include <QDateTime>
#include <QFile>
#include <QDebug>
#include "cbinterface.h"
#include "dataoperations.h"



CBInterface::CBInterface(QObject *parent) : QThread(parent)
{
    mParent = parent;
    cmdSent = 0;
    CBInterfaceState = CMD_IDLE;
    qDebug() << "Test Run Init";
    currentVals.append('a');
    currentVals.clear();
    fwUpdate = false;
    fwEndrecived = false;
    fwVer = false;
    fwUpdateCheck = 0;
    sum= 0;
}

CBInterface::~CBInterface()
{

}

void CBInterface::sendPackets(QSerialPort *port) {

    QDateTime dTime = QDateTime::currentDateTime();

    switch(CBInterfaceState) {

    case SEND_CMD:
        sendTimeStamp = 0;
        CBInterfaceState = SEND_TEST_CMD;
        break;

    case SEND_TEST_CMD:
        if(cmdSent) {
            CBInterfaceState = CMD_IDLE;
            break;
        }
        if((dTime.toMSecsSinceEpoch() - sendTimeStamp) < 5000) {
            break;
        }
        if(cmdResend >= 3) {
            CBInterfaceState = CMD_IDLE;
            cmdSent=true;
            if(fwUpdate == true)
            {
                ErrorType = 1;
                fwUpdate = false;
            }

            qDebug() << "Error while sending command ";
            break;
        }
        qDebug() << dTime.toMSecsSinceEpoch();

        /////////////////////////////To check the packet data sent/////////////////////////

        /*for(int i = 0;i<cmdSize;i++)
        {
            qDebug() << "Command data: " << QString("%1").arg(cmdBuffer[i], 0, 16);
        }*/

        port->write(cmdBuffer, cmdSize);
        port->waitForBytesWritten(1);
        sendTimeStamp = dTime.toMSecsSinceEpoch();
        cmdResend++;
        break;

    case CMD_IDLE:
        break;
    }
}


void CBInterface::close() {
    testCompleted = true;
    qDebug() << "Test quit";
}


void CBInterface::run() {
    QSerialPort serialPort;  // QSerialPort();
    serialPort.setPortName("ttymxc1");// serialPort.setPortName("ttyMAX2");
    serialPort.setBaudRate(QSerialPort::Baud57600);
    serialPort.setDataBits(QSerialPort::Data8);
    serialPort.setStopBits(QSerialPort::OneStop);
    serialPort.setParity(QSerialPort::NoParity);
    serialPort.setFlowControl(QSerialPort::NoFlowControl);
    serialPort.waitForBytesWritten(10);
    qDebug()<<"opening serial port";
    if(serialPort.open(QIODevice::ReadWrite))
    {

        DLEFlag = false;
        STXFlag = false;
        ETXFlag =  false;
        serialPort.waitForBytesWritten(1);
        qDebug()<<"started serial port";
        while(1) {

            sendPackets(&serialPort);
            receiveCommands(&serialPort);

            if(fwUpdate)
                updateFW();
            else if (fwEndrecived)
            {
                qDebug() << "End receviced";
                cTime = QDateTime::currentDateTime();
                if((cTime.toMSecsSinceEpoch() - fwUpdateCheck) > 15000) {

                    qDebug() << "wait time:" << (cTime.toMSecsSinceEpoch() - fwUpdateCheck);
                    ErrorType = 4;

                }
            }
        }
    }

    qDebug()<<"closing serial port";
    serialPort.close();
    testCompleted = false;
}

void CBInterface::sendWeldParam(int gun) {

    unsigned char packet[PKT_SIZE];
    int iValue = 0;
    unsigned char *cptr =  (unsigned char *)&iValue;
    int tcnt = 0;
    unsigned char cVal = 0;
    DataOperations *dataop = (DataOperations *)mParent;

    qDebug() << "Preparing test command";

    packet[tcnt++] = GET_WP_RESP;
    if(gun == 1) {
        packet[tcnt++] = 1;
        cVal = dataop->readDatap(1,1).toFloat() * 10;
        packet[tcnt++] = cVal;
        cVal = dataop->readDatap(1,2).toFloat() * 10;
        packet[tcnt++] = cVal;
        cVal = dataop->readDatap(1,3).toInt();
        packet[tcnt++] = cVal;
        cVal = dataop->readDatap(1,4).toInt();
        packet[tcnt++] = cVal;
        iValue = dataop->readDatap(1,5).toInt();
        packet[tcnt++] = *(cptr+1);
        packet[tcnt++] = *(cptr+0);
        iValue = dataop->readDatap(1,6).toInt();
        packet[tcnt++] = *(cptr+1);
        packet[tcnt++] = *(cptr+0);
        iValue = dataop->readDatap(1,7).toInt();
        packet[tcnt++] = *(cptr+1);
        packet[tcnt++] = *(cptr+0);
        cVal = dataop->readDatap(1,10).toFloat() * 10;
        packet[tcnt++] = cVal;
        cVal = dataop->readDatap(1,11).toInt();
        packet[tcnt++] = cVal;
        cVal = dataop->readDatap(1,12).toInt();
        packet[tcnt++] = cVal;
    }

    else {
        packet[tcnt++] = 2;//1;
        cVal = dataop->readDatap(2,1).toFloat() * 10;
        packet[tcnt++] = cVal;
        cVal = dataop->readDatap(2,2).toFloat() * 10;
        packet[tcnt++] = cVal;
        cVal = dataop->readDatap(2,3).toInt();
        packet[tcnt++] = cVal;
        cVal = dataop->readDatap(2,4).toInt();
        packet[tcnt++] = cVal;
        iValue = dataop->readDatap(2,5).toInt();
        packet[tcnt++] = *(cptr+1);
        packet[tcnt++] = *(cptr+0);
        iValue = dataop->readDatap(2,6).toInt();
        packet[tcnt++] = *(cptr+1);
        packet[tcnt++] = *(cptr+0);
        iValue = dataop->readDatap(2,7).toInt();
        packet[tcnt++] = *(cptr+1);
        packet[tcnt++] = *(cptr+0);
        cVal = dataop->readDatap(2,10).toFloat() * 10;
        packet[tcnt++] = cVal;
        cVal = dataop->readDatap(2,11).toInt();
        packet[tcnt++] = cVal;
        cVal = dataop->readDatap(2,12).toInt();
        packet[tcnt++] = cVal;
    }

    int csum = 0;
    cmdSize = 0;
    cmdBuffer[cmdSize++] = 0x10;
    cmdBuffer[cmdSize++] = 0x02;
    cmdBuffer[cmdSize++] = tcnt + 1;   // lenght data length  + checksum byte
    csum = tcnt+1;
    if((tcnt+1) == 0x10) {
        cmdBuffer[cmdSize++] = 0x10;
    }

    for(int i=0; i<tcnt; i++ ) {
        cmdBuffer[cmdSize++] = packet[i];
        csum+= packet[i];
        if(packet[i] == 0x10) {
            cmdBuffer[cmdSize++] = 0x10;
        }
    }

    cmdBuffer[cmdSize++] = csum & 0xff;
    if(cmdBuffer[cmdSize-1]== 0x10)
    {
        cmdBuffer[cmdSize++] = 0x10;
    }
    cmdBuffer[cmdSize++] = 0x10;
    cmdBuffer[cmdSize++] = 0x03;
    qDebug() << "Preparing test command for Weld Parameters";
    cmdResend = 0;
    cmdSent = false;
    CBInterfaceState = SEND_CMD;
}


void CBInterface::sendResetCount(int gun) {

    unsigned char packet[PKT_SIZE];
    int tcnt = 0;
    qDebug() << "Preparing Reset Count Command";

    packet[tcnt++] = RESET_WELD_CNT;
    if(gun == 1)
        packet[tcnt++] = 1;
    else
        packet[tcnt++] = 2;

    int csum = 0;
    cmdSize = 0;
    cmdBuffer[cmdSize++] = 0x10;
    cmdBuffer[cmdSize++] = 0x02;
    cmdBuffer[cmdSize++] = tcnt + 1;   // lenght data length  + checksum byte
    csum = tcnt+1;
    if((tcnt+1) == 0x10) {
        cmdBuffer[cmdSize++] = 0x10;
    }

    for(int i=0; i<tcnt; i++ ) {
        cmdBuffer[cmdSize++] = packet[i];
        csum+= packet[i];
        if(packet[i] == 0x10) {
            cmdBuffer[cmdSize++] = 0x10;
        }
    }

    cmdBuffer[cmdSize++] = csum & 0xff;
    if(cmdBuffer[cmdSize-1]== 0x10)
    {
        cmdBuffer[cmdSize++] = 0x10;
    }
    cmdBuffer[cmdSize++] = 0x10;
    cmdBuffer[cmdSize++] = 0x03;
    qDebug() << "Preparing test command333";
    cmdResend = 0;
    cmdSent = false;
    CBInterfaceState = SEND_CMD;
}

///////////////////////////////// Receive process methods /////////////////////////////////////

void CBInterface::ackReceived(int) {
    cmdSent = true;
}

void CBInterface::receiveCommands(QSerialPort *port) {

    QByteArray bData;
    char data;
    //int iBytesRead = 1;
    int tsum = 0;
    int cnt = 0;
    //while(iBytesRead) {
    if(!port->waitForReadyRead(50)) {
        //iBytesRead=0;
        return;
    }
    //iBytesRead = port->read(&data, 1);
    //ErrorType = 0;
    bData = port->readAll();
    for(cnt=0;cnt<bData.size();cnt++)
    {
        //iBytesRead = port->read(&data, 1);
        data = bData.at(cnt);
        //if(iBytesRead)
        {
            switch(data)
            {
            case DLEESC:
                if(DLEFlag == 1)
                {
                    if(STXFlag)
                        recvBuffer[recvPos++] = data;
                    DLEFlag = 0;
                }
                else if(DLEFlag == 0)
                    DLEFlag = 1;
                break;

            case STX:
                if(DLEFlag == 1)
                {
                    STXFlag = 1;
                    DLEFlag = 0;
                    recvPos = 0;
                }
                else  if(STXFlag == 1)
                    recvBuffer[recvPos++] = data;
                break;

            case ETX:
                if(DLEFlag == 1)
                {
                    if(STXFlag == 1)
                        ETXFlag = 1;
                    DLEFlag = 0;
                }
                else if(STXFlag == 1)
                    recvBuffer[recvPos++] = data;
                break;

            default :
                if(STXFlag == 1)
                    recvBuffer[recvPos++] = data;
                break;
            }
        }

        // Process received packet
        if(ETXFlag)
        {
            DLEFlag = 0;
            STXFlag = 0;
            ETXFlag = 0;
            for(int i=0; i<(recvPos-1); i++)
                tsum = tsum + recvBuffer[i];
            tsum = tsum & 0xff;
            processPacket((unsigned char *)recvBuffer);
            /*for(int i=0; i<(recvPos-1); i++)
            {
                qDebug() << QChar(recvBuffer[i]);
            }*/

            if((unsigned char)tsum != (unsigned char) recvBuffer[recvPos-1])
            {

            }
            recvPos = 0;
        }
    }
}

void CBInterface::processPacket(unsigned char *packet) {

    int current = 0;
    int count = 0;
    long int permntCount1 = 0;
    long int permntCount2 = 0;
    qint16 btemp = 0;
    qint16 ttemp = 0;

    DataOperations *dataop = (DataOperations *)mParent;

    switch((unsigned char)packet[1]) {

    case ACK:
        qDebug() << "ACK Received ";
        cmdSent = true;
        break;

    case FW_START_ACK:
        qDebug() << "FW Start ACK Received ";
        cmdSent = true;

        for(int i=0; i<=PKT_SIZE;i++)
        {
            qDebug() << "Received Packet data:"<< QString("%1").arg(packet[i], 0, 16);
        }

        if(packet[2] == 1)
        {
            qDebug() << "Start success";
            fwstatus = FW_START_ACK;
            ErrorType = 0;
        }
        else if(packet[2] == 2)
        {
            qDebug() << "Internal Error";
            ErrorType = 2;
        }
        else if(packet[2] == 3)
        {
            qDebug() << "Weld Operation in progress";
            ErrorType = 3;
        }
        else {
            qDebug() << "Internal Error";
            ErrorType = 2;
        }
        break;

    case FW_DATA_ACK:
        qDebug() << "FW DATA ACK Received ";
        cmdSent = true;
        lineCount++;

        /////////////////////////////Use to check the packet data received/////////////////////////

        /*for(int i=0; i<=PKT_SIZE;i++)
        {
            qDebug() << "Received Packet data:"<< QString("%1").arg(packet[i], 0, 16);
        }


        qDebug() << "Address received is:"<< packet[2] << packet[3] << packet[4];
        qDebug() << "Address expected is:"  << addressBytes[0] << addressBytes[1] << addressBytes[2];*/

        if(addressBytes[0] == packet[2] && addressBytes[1] == packet[3] && addressBytes[2] == packet[4])
        {
            qDebug() << "Address matching";
            qDebug() << "Status:" <<packet[5];

            if(packet[5] == 1)
            {
                qDebug() << "Data sent success";
                fwstatus = FW_DATA_ACK;
                ErrorType = 0;
            }
            else if(packet[5] == 2)
            {
                qDebug() << "Internal Error";
                ErrorType = 2;
            }
        }
        else {
            qDebug() << "Address not matching";
            qDebug() << "Internal Error";
            ErrorType = 2;
        }
        break;

    case FW_END_ACK:
        qDebug() << "FW END ACK Received ";
        sum=0;
        cmdSent = true;
        if(packet[2] == 1)
        {
            qDebug() << "FW END Success ";
            fwstatus = FW_END_ACK;
            ErrorType = 0;
            fwEndrecived = true;
            lineCount = 0;
            cTime = QDateTime::currentDateTime();
            fwUpdateCheck = cTime.toMSecsSinceEpoch();
        }
        else if(packet[2] == 2)
        {
            qDebug() << "Internal Error";
            ErrorType = 2;
        }
        else {
            qDebug() << "Internal Error";
            ErrorType = 2;
        }
        break;

    case FW_VER_ACK:
        qDebug() << "FW Version received";
        if(fwVer) {

            cmdSent = true;
            fwVer = false;
        }
        FWVersion = packet[2] << 8;
        FWVersion = FWVersion + packet[3];
        qDebug() << "FW Version is:" << FWVersion;

        if(fwEndrecived && FVer!=FWVersion) {
            fwEndrecived = false;
            dataop->updateFwDone();
        }
        else if(FVer == FWVersion)
        {
            ErrorType = 4;
        }
        FVer = float(FWVersion)/100;
        dataop->createFWVerFile(QString::number(FVer, 'f', 2));
        break;


    case GET_WP_CMD:
        qDebug() << "Weld Param Command Received";
        qDebug() << "Weld Status" << (dataop->getLoginStatus());
        qDebug() << fwUpdate ;
        if(!fwUpdate && (dataop->getLoginStatus()))
            sendWeldParam(packet[2]);
        break;

    case WELD_STATUS:
        qDebug() << "Wled Status Received";
        count = packet[3] << 8;
        count = count + packet[4];
        current = packet[5] << 8;
        current = current + packet[6];
        dataop->updateWeldStatus(packet[2],count,current,packet[7]);
        break;

    case CONTACT_STATUS:
        qDebug() << "Contact Status Received";
        dataop->contactStatus(packet[2]);
        break;

    case STATUS_MSG:
        if(fwEndrecived)
            ErrorType = 2;
        qDebug() << "Status Message Received";
        btemp = packet[2] << 8;
        btemp = btemp + packet[3];
        ttemp = packet[4] << 8;
        ttemp = ttemp + packet[5];
        count = packet[8] << 8;         //Gun1
        count = count + packet[9];
        current = packet[10] << 8;       //Gun2
        current = current + packet[11];
        permntCount1 = packet[12] << 24;
        permntCount1 = (permntCount1 + packet[13]) << 16 ;
        permntCount1 = (permntCount1 + packet[14]) << 8 ;
        permntCount1 = permntCount1 + packet[15];

        permntCount2 = packet[16] << 24;
        permntCount2 = (permntCount2 + packet[17]) << 16 ;
        permntCount2 = (permntCount2 + packet[18]) << 8 ;
        permntCount2 = permntCount2 + packet[19];


        dataop->updateStatus(btemp,ttemp,count,current,permntCount1,permntCount2,packet[6],packet[7]);
        break;

    case RESET_WELD_CNT:
        qDebug() << "Reset Wled count Message Received";
        cmdSent = true;

        count = packet[3] << 8;
        count = count + packet[4];
        dataop->updateWeldCount(packet[2], count);
        break;

    case CURRENT_PROF:
        qDebug() << "Current Profile 1 Received";
        qDebug() << QChar(packet[3]);
        if(packet[3] == 0x0)
            currentVals.clear();
        for(int i=4;i<packet[0];i++)
            currentVals.append(packet[i]);
        if((unsigned char)packet[3] == 0xFF)
        {
            qDebug() << "Current Profile FF Received";
            QString temp;
            temp = DATAPATH;
            if(packet[2]==1)
            {
                temp = temp + "Current/G1/" + dataop->getGunCount(1) + "-" + dataop->getGunCurrent(1) + " A";
            }
            else
            {
                temp = temp + "Current/G2/" + dataop->getGunCount(2) + "-" + dataop->getGunCurrent(2) + " A";
            }
            wFile = fopen(temp.toLatin1().data(), "w");
            if(wFile == NULL) {
                qDebug() << "Error while savin current profile..";
                return;
            }
            for(int i=0; i < currentVals.length(); i+=2)
            {
                unsigned int cval= (unsigned char)currentVals[i]*0x100 + (unsigned char)currentVals[i+1];
                //qDebug() << cval;
                fprintf(wFile, "%d\n", cval);
            }
            fclose(wFile);
            currentVals.clear();
            if(packet[2]==1)
            {
                checkFileCount(1);
            }
            else
            {
                checkFileCount(2);
            }
        }
        break;
    }
}

void CBInterface::checkFileCount(int gun)
{
    // Maintain only last 50 current profiles
    QString path = DATAPATH;
    if (gun == 1)
    {
        path = path = path + "Current/G1/";
    }
    else
    {
        path = path = path + "Current/G2/";
    }

    QDir dir(path);
    dir.setFilter(QDir::Files | QDir::NoDotAndDotDot);
    int count = dir.count(); // count of files

    if (count >= 50)
    {
        QFileInfoList dirList;
        dirList = dir.entryInfoList(QDir::Files | QDir::NoDotAndDotDot, QDir::Time); //results the oldest file on top
        dir.remove(dirList.last().fileName()); // removing oldest file
    }
}

////////////////////////////////////////////////////////////////////////////////////////////////////////


void CBInterface::startFWUpdate() {
    fwUpdate = true;
    ErrorType = 0;
    fwstatus = FW_START;
}

void CBInterface::getFWVersion() {
    qDebug() << "Getting FW Version";
    queryFWVersion();
}

void CBInterface::updateFW() {
    QString data;

    QString path="/home/RFWSHMI/API/temp/FWUpdate/";

    QDir dir(path);

    QDirIterator iterator(dir.absolutePath(), QDir::Files);

    QFile file (iterator.next());

    QString fileName = QFileInfo(file).fileName();

    fileName = path+fileName;
    DataOperations *dataop = (DataOperations *)mParent;
    switch(fwstatus) {
    case FW_START:
        sendFWUpgradeStart();
        fwstatus = false;
        //fwstatus = FW_START_ACK;
        break;
    case FW_START_ACK:
        if(cmdSent == true) {
            rFile.setFileName(fileName.toLatin1().data());
            if(!rFile.open(QIODevice::ReadOnly))
            {
                qDebug() << "Unable to open FW file";
                fwstatus = false;
            }
            else
            {
                fwstatus = FW_DATA;
            }
        }
        break;
    case FW_DATA:
        data = rFile.readLine();
        if(!rFile.atEnd()) {
            data=data.trimmed();
            qDebug() << "####: " + data;
            if(data[0]=='S' && data[1] == '2') {
                qDebug() << "Send FW data";
                sendFWUpdate(data);
                //fwstatus = FW_DATA_ACK;
                fwstatus = false;
            }
            else {
                dataop->incFwProgress();
            }
        }
        else {
            fwstatus = FW_END;
        }
        break;
    case FW_DATA_ACK:
        //if(cmdSent == true) {
        fwstatus = FW_DATA;
        qDebug() << "Increase FW count";
        dataop->incFwProgress();
        //}
        break;
    case FW_END:
        sendFWUpgradeEnd();
        //fwstatus = FW_END_ACK;
        fwstatus = false;
        break;
    case FW_END_ACK:
        if(cmdSent == true) {
            fwUpdate = false;
        }
        break;

    }
}

void CBInterface::sendFWUpgradeStart() {

    unsigned char packet[PKT_SIZE];
    int tcnt = 0;

    packet[tcnt++] = FW_UPGRADE_START;

    int csum = 0;
    cmdSize = 0;
    cmdBuffer[cmdSize++] = 0x10;
    cmdBuffer[cmdSize++] = 0x02;
    cmdBuffer[cmdSize++] = tcnt + 1;   // lenght data length  + checksum byte
    csum = tcnt+1;
    if((tcnt+1) == 0x10) {
        cmdBuffer[cmdSize++] = 0x10;
    }

    for(int i=0; i<tcnt; i++ ) {
        cmdBuffer[cmdSize++] = packet[i];
        csum+= packet[i];
        if(packet[i] == 0x10) {
            cmdBuffer[cmdSize++] = 0x10;
        }
    }

    cmdBuffer[cmdSize++] = csum & 0xff;
    if(cmdBuffer[cmdSize-1]== 0x10)
    {
        cmdBuffer[cmdSize++] = 0x10;
    }
    cmdBuffer[cmdSize++] = 0x10;
    cmdBuffer[cmdSize++] = 0x03;
    qDebug() << "Prepared FW Start command";
    cmdResend = 0;
    cmdSent = false;
    CBInterfaceState = SEND_CMD;
}

void CBInterface::sendFWUpdate(QString fwds)
{
    unsigned char packet[PKT_SIZE];
    unsigned char dcSum[2];
    int tcnt = 0;
    int bc = 0;
    unsigned char rlineDataLength;
    QByteArray data = fwds.toUtf8();
    packet[tcnt++] = FW_UPGRADE_WRITE;

    addressBytes[0] = ascii_to_bcd(data[4],data[5]);
    packet[tcnt++] = addressBytes[0];
    addressBytes[1] = ascii_to_bcd(data[6],data[7]);
    packet[tcnt++] = addressBytes[1];
    addressBytes[2] = ascii_to_bcd(data[8],data[9]);
    packet[tcnt++] = addressBytes[2];
    bc = (ascii_to_bcd(data[2],data[3]) & 0xF0) >> 4;
    bc = bc * 16  +  (ascii_to_bcd(data[2],data[3]) & 0xF) - 3;
    packet[tcnt++] = bc;
    //qDebug() << bc;

    for(bc=10; bc < data.size(); bc+=2) {
        packet[tcnt++] = ascii_to_bcd(data[bc],data[bc+1]);
    }


    packet[tcnt-1] = ~ packet[tcnt-1];
    rlineDataLength = ascii_to_bcd(data[2],data[3]);
    packet[tcnt-1] = packet[tcnt-1] - addressBytes[0] - addressBytes[1] - addressBytes[2] - rlineDataLength;

    qDebug() << "Data checkSum: " <<QString("%1").arg( packet[tcnt-1], 0, 16);

    int csum = 0;
    cmdSize = 0;
    cmdBuffer[cmdSize++] = 0x10;
    cmdBuffer[cmdSize++] = 0x02;
    cmdBuffer[cmdSize++] = tcnt + 1;   // lenght data length  + checksum byte
    csum = tcnt+1;
    if((tcnt+1) == 0x10) {
        cmdBuffer[cmdSize++] = 0x10;
    }

    for(int i=0; i<tcnt; i++ ) {
        cmdBuffer[cmdSize++] = packet[i];
        if(packet[i] == 0x10) {
            cmdBuffer[cmdSize++] = 0x10;
        }

        if(i>=5 && i<=tcnt-2)
        {
            sum +=packet[i];
            qDebug() << "Sum is:" <<sum;
            if(i==tcnt-2)
            {
                dcSum[0] = sum >> 8;
                dcSum[1] = sum;


                if(dcSum[0] == 0x10) {
                    cmdBuffer[cmdSize++] = 0x10;
                }
                cmdBuffer[cmdSize++] = dcSum[0];
                if(dcSum[1] == 0x10) {
                    cmdBuffer[cmdSize++] = 0x10;
                }
                cmdBuffer[cmdSize++] = dcSum[1] ;
                csum+= dcSum[0];
                csum+= dcSum[1];
            }
        }
        qDebug() << "Packet Input: " <<QString("%1").arg( packet[i], 0, 16);
        csum+= packet[i];
    }

    cmdBuffer[cmdSize++] = csum & 0xff;
    if(cmdBuffer[cmdSize-1]== 0x10)
    {
        cmdBuffer[cmdSize++] = 0x10;
    }

    qDebug() << "Packet Check sum:" << QString("%1").arg((csum & 0xff), 0, 16);
    cmdBuffer[cmdSize++] = 0x10;
    cmdBuffer[cmdSize++] = 0x03;
    qDebug() << "Prepared FW Data Command";
    cmdResend = 0;
    cmdSent = false;
    CBInterfaceState = SEND_CMD;

}

void CBInterface::sendFWUpgradeEnd() {

    unsigned char packet[PKT_SIZE];
    int tcnt = 0;

    packet[tcnt++] = FW_UPGRADE_END;

    int csum = 0;
    cmdSize = 0;
    cmdBuffer[cmdSize++] = 0x10;
    cmdBuffer[cmdSize++] = 0x02;
    cmdBuffer[cmdSize++] = tcnt + 1;   // lenght data length  + checksum byte
    csum = tcnt+1;
    if((tcnt+1) == 0x10) {
        cmdBuffer[cmdSize++] = 0x10;
    }

    for(int i=0; i<tcnt; i++ ) {
        cmdBuffer[cmdSize++] = packet[i];
        csum+= packet[i];
        if(packet[i] == 0x10) {
            cmdBuffer[cmdSize++] = 0x10;
        }
    }

    cmdBuffer[cmdSize++] = csum & 0xff;
    if(cmdBuffer[cmdSize-1]== 0x10)
    {
        cmdBuffer[cmdSize++] = 0x10;
    }
    cmdBuffer[cmdSize++] = 0x10;
    cmdBuffer[cmdSize++] = 0x03;
    qDebug() << "Prepared FW End command";
    cmdResend = 0;
    cmdSent = false;
    CBInterfaceState = SEND_CMD;
}

void CBInterface::queryFWVersion()
{
    unsigned char packet[PKT_SIZE];
    int tcnt = 0;
    fwVer = true;

    packet[tcnt++] = FW_VER;

    int csum = 0;
    cmdSize = 0;
    cmdBuffer[cmdSize++] = 0x10;
    cmdBuffer[cmdSize++] = 0x02;
    cmdBuffer[cmdSize++] = tcnt+1;
    csum = tcnt+1;
    if((tcnt+1) == 0x10) {
        cmdBuffer[cmdSize++] = 0x10;
    }

    for(int i=0; i<tcnt; i++ ) {
        cmdBuffer[cmdSize++] = packet[i];
        csum+= packet[i];
        if(packet[i] == 0x10) {
            cmdBuffer[cmdSize++] = 0x10;
        }
    }

    cmdBuffer[cmdSize++] = csum & 0xff;
    if(cmdBuffer[cmdSize-1]== 0x10)
    {
        cmdBuffer[cmdSize++] = 0x10;
    }
    cmdBuffer[cmdSize++] = 0x10;
    cmdBuffer[cmdSize++] = 0x03;
    qDebug() << "Prepared FW Version query command";
    cmdResend = 0;
    cmdSent = false;
    CBInterfaceState = SEND_CMD;
}

unsigned char CBInterface::ascii_to_bcd(char ascii0, char ascii1)
{
    unsigned char bcd_value = 0;
    //qDebug() << ascii0;
    //qDebug() << ascii1;
    // left side
    if(ascii0 >= '0' && ascii0 <= '9')  // 0-9 range
    {
        bcd_value = ( ascii0 - 48)  << 4 ; // 48 for '0' ASCII offset
    }
    else if (ascii0 >= 'A' && ascii0 <= 'F') // A-F range
    {
        bcd_value = ( 10 + ascii0 - 65 )  << 4 ; // 65 for 'A' ASCII offset
    }
    else if (ascii0 >= 'a' && ascii0 <= 'f') // a-f range
    {
        bcd_value = ( 10 + ascii0 - 97)  << 4 ; // 97 for 'a'  ASCII offset
    }

    // right side
    if(ascii1 >= '0' && ascii1 <= '9')  // 0-9 range
    {
        bcd_value |= ( ascii1 - 48); // 48 for '0' ASCII offset
    }
    else if (ascii1 >= 'A' && ascii1 <= 'F') // A-F range
    {
        bcd_value |= ( 10 + ascii1 - 65)   ; // 65 for 'A' ASCII offset
    }
    else if (ascii1 >= 'a' && ascii1 <= 'f') // a-f range
    {
        bcd_value |= ( 10 + ascii1 - 97 ) ; // 97 for 'a' ASCII offset
    }

    return bcd_value;
}

