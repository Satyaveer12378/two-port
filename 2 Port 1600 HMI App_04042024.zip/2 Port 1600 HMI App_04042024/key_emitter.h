#ifndef KEY_EMITTER_H
#define KEY_EMITTER_H

#include <QObject>

class KeyEmitter : public QObject
{
    Q_OBJECT

public:
    KeyEmitter();
    ~KeyEmitter();

    Q_INVOKABLE void emitKey(QString keyName);

public slots:
    void emitKey1(Qt::Key key, int shift);
    Qt::Key getKeyCodeFromName(QString keyname);
};

#endif // KEY_EMITTER_H
