/****************************************************************************
** Meta object code from reading C++ file 'dataoperations.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.7.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "dataoperations.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'dataoperations.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.7.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_DataOperations_t {
    QByteArrayData data[68];
    char stringdata0[772];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_DataOperations_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_DataOperations_t qt_meta_stringdata_DataOperations = {
    {
QT_MOC_LITERAL(0, 0, 14), // "DataOperations"
QT_MOC_LITERAL(1, 15, 11), // "weldSuccess"
QT_MOC_LITERAL(2, 27, 0), // ""
QT_MOC_LITERAL(3, 28, 10), // "writeDatap"
QT_MOC_LITERAL(4, 39, 5), // "gunno"
QT_MOC_LITERAL(5, 45, 5), // "index"
QT_MOC_LITERAL(6, 51, 5), // "value"
QT_MOC_LITERAL(7, 57, 9), // "readDatap"
QT_MOC_LITERAL(8, 67, 11), // "saveProfile"
QT_MOC_LITERAL(9, 79, 5), // "pname"
QT_MOC_LITERAL(10, 85, 17), // "saveSystemProfile"
QT_MOC_LITERAL(11, 103, 4), // "type"
QT_MOC_LITERAL(12, 108, 15), // "saveWeldDetails"
QT_MOC_LITERAL(13, 124, 5), // "jobID"
QT_MOC_LITERAL(14, 130, 5), // "sname"
QT_MOC_LITERAL(15, 136, 5), // "count"
QT_MOC_LITERAL(16, 142, 11), // "loadProfile"
QT_MOC_LITERAL(17, 154, 8), // "copyFile"
QT_MOC_LITERAL(18, 163, 10), // "sourceFile"
QT_MOC_LITERAL(19, 174, 14), // "destinationDir"
QT_MOC_LITERAL(20, 189, 11), // "getGunCount"
QT_MOC_LITERAL(21, 201, 3), // "gun"
QT_MOC_LITERAL(22, 205, 13), // "getGunCurrent"
QT_MOC_LITERAL(23, 219, 13), // "getWeldStatus"
QT_MOC_LITERAL(24, 233, 19), // "getGunContactStatus"
QT_MOC_LITERAL(25, 253, 9), // "getBrTemp"
QT_MOC_LITERAL(26, 263, 9), // "getTrTemp"
QT_MOC_LITERAL(27, 273, 12), // "getIpVoltage"
QT_MOC_LITERAL(28, 286, 18), // "getGndDetectStatus"
QT_MOC_LITERAL(29, 305, 17), // "getGunPermntCount"
QT_MOC_LITERAL(30, 323, 14), // "resetWeldCount"
QT_MOC_LITERAL(31, 338, 17), // "getCurrentProfile"
QT_MOC_LITERAL(32, 356, 9), // "getjobIds"
QT_MOC_LITERAL(33, 366, 8), // "getjobId"
QT_MOC_LITERAL(34, 375, 12), // "getstudnames"
QT_MOC_LITERAL(35, 388, 2), // "id"
QT_MOC_LITERAL(36, 391, 11), // "getstudname"
QT_MOC_LITERAL(37, 403, 13), // "getstudcounts"
QT_MOC_LITERAL(38, 417, 4), // "name"
QT_MOC_LITERAL(39, 422, 12), // "getstudcount"
QT_MOC_LITERAL(40, 435, 9), // "savejobID"
QT_MOC_LITERAL(41, 445, 3), // "job"
QT_MOC_LITERAL(42, 449, 11), // "saveJobData"
QT_MOC_LITERAL(43, 461, 10), // "updateDate"
QT_MOC_LITERAL(44, 472, 4), // "date"
QT_MOC_LITERAL(45, 477, 11), // "getDateTime"
QT_MOC_LITERAL(46, 489, 13), // "getFwProgress"
QT_MOC_LITERAL(47, 503, 12), // "initupdateFW"
QT_MOC_LITERAL(48, 516, 12), // "getErrorType"
QT_MOC_LITERAL(49, 529, 7), // "ifError"
QT_MOC_LITERAL(50, 537, 12), // "getFWVersion"
QT_MOC_LITERAL(51, 550, 10), // "qFWVersion"
QT_MOC_LITERAL(52, 561, 18), // "fwUpdateFileExists"
QT_MOC_LITERAL(53, 580, 22), // "hmiAppUpdateFileExists"
QT_MOC_LITERAL(54, 603, 12), // "removeFWFile"
QT_MOC_LITERAL(55, 616, 13), // "removeHMIFile"
QT_MOC_LITERAL(56, 630, 9), // "setCustom"
QT_MOC_LITERAL(57, 640, 7), // "saveApn"
QT_MOC_LITERAL(58, 648, 7), // "readApn"
QT_MOC_LITERAL(59, 656, 11), // "setProfData"
QT_MOC_LITERAL(60, 668, 11), // "getProfData"
QT_MOC_LITERAL(61, 680, 13), // "writeProfiles"
QT_MOC_LITERAL(62, 694, 12), // "readProfiles"
QT_MOC_LITERAL(63, 707, 14), // "deleteProfiles"
QT_MOC_LITERAL(64, 722, 14), // "setLoginStatus"
QT_MOC_LITERAL(65, 737, 6), // "status"
QT_MOC_LITERAL(66, 744, 18), // "createServerIPFile"
QT_MOC_LITERAL(67, 763, 8) // "filename"

    },
    "DataOperations\0weldSuccess\0\0writeDatap\0"
    "gunno\0index\0value\0readDatap\0saveProfile\0"
    "pname\0saveSystemProfile\0type\0"
    "saveWeldDetails\0jobID\0sname\0count\0"
    "loadProfile\0copyFile\0sourceFile\0"
    "destinationDir\0getGunCount\0gun\0"
    "getGunCurrent\0getWeldStatus\0"
    "getGunContactStatus\0getBrTemp\0getTrTemp\0"
    "getIpVoltage\0getGndDetectStatus\0"
    "getGunPermntCount\0resetWeldCount\0"
    "getCurrentProfile\0getjobIds\0getjobId\0"
    "getstudnames\0id\0getstudname\0getstudcounts\0"
    "name\0getstudcount\0savejobID\0job\0"
    "saveJobData\0updateDate\0date\0getDateTime\0"
    "getFwProgress\0initupdateFW\0getErrorType\0"
    "ifError\0getFWVersion\0qFWVersion\0"
    "fwUpdateFileExists\0hmiAppUpdateFileExists\0"
    "removeFWFile\0removeHMIFile\0setCustom\0"
    "saveApn\0readApn\0setProfData\0getProfData\0"
    "writeProfiles\0readProfiles\0deleteProfiles\0"
    "setLoginStatus\0status\0createServerIPFile\0"
    "filename"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_DataOperations[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      49,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,  259,    2, 0x06 /* Public */,

 // methods: name, argc, parameters, tag, flags
       3,    3,  260,    2, 0x02 /* Public */,
       7,    2,  267,    2, 0x02 /* Public */,
       8,    2,  272,    2, 0x02 /* Public */,
      10,    3,  277,    2, 0x02 /* Public */,
      12,    3,  284,    2, 0x02 /* Public */,
      16,    2,  291,    2, 0x02 /* Public */,
      17,    2,  296,    2, 0x02 /* Public */,
      20,    1,  301,    2, 0x02 /* Public */,
      22,    1,  304,    2, 0x02 /* Public */,
      23,    1,  307,    2, 0x02 /* Public */,
      24,    1,  310,    2, 0x02 /* Public */,
      25,    0,  313,    2, 0x02 /* Public */,
      26,    0,  314,    2, 0x02 /* Public */,
      27,    0,  315,    2, 0x02 /* Public */,
      28,    0,  316,    2, 0x02 /* Public */,
      29,    1,  317,    2, 0x02 /* Public */,
      30,    1,  320,    2, 0x02 /* Public */,
      31,    1,  323,    2, 0x02 /* Public */,
      32,    0,  326,    2, 0x02 /* Public */,
      33,    1,  327,    2, 0x02 /* Public */,
      34,    1,  330,    2, 0x02 /* Public */,
      36,    1,  333,    2, 0x02 /* Public */,
      37,    2,  336,    2, 0x02 /* Public */,
      39,    1,  341,    2, 0x02 /* Public */,
      40,    1,  344,    2, 0x02 /* Public */,
      42,    1,  347,    2, 0x02 /* Public */,
      43,    1,  350,    2, 0x02 /* Public */,
      45,    0,  353,    2, 0x02 /* Public */,
      46,    0,  354,    2, 0x02 /* Public */,
      47,    0,  355,    2, 0x02 /* Public */,
      48,    0,  356,    2, 0x02 /* Public */,
      49,    0,  357,    2, 0x02 /* Public */,
      50,    0,  358,    2, 0x02 /* Public */,
      51,    0,  359,    2, 0x02 /* Public */,
      52,    0,  360,    2, 0x02 /* Public */,
      53,    0,  361,    2, 0x02 /* Public */,
      54,    0,  362,    2, 0x02 /* Public */,
      55,    0,  363,    2, 0x02 /* Public */,
      56,    1,  364,    2, 0x02 /* Public */,
      57,    1,  367,    2, 0x02 /* Public */,
      58,    0,  370,    2, 0x02 /* Public */,
      59,    3,  371,    2, 0x02 /* Public */,
      60,    2,  378,    2, 0x02 /* Public */,
      61,    1,  383,    2, 0x02 /* Public */,
      62,    1,  386,    2, 0x02 /* Public */,
      63,    1,  389,    2, 0x02 /* Public */,
      64,    1,  392,    2, 0x02 /* Public */,
      66,    1,  395,    2, 0x02 /* Public */,

 // signals: parameters
    QMetaType::Void,

 // methods: parameters
    QMetaType::Void, QMetaType::Int, QMetaType::Int, QMetaType::QString,    4,    5,    6,
    QMetaType::QString, QMetaType::Int, QMetaType::Int,    4,    5,
    QMetaType::Void, QMetaType::Int, QMetaType::QString,    4,    9,
    QMetaType::Void, QMetaType::Int, QMetaType::QString, QMetaType::Int,    4,    9,   11,
    QMetaType::Void, QMetaType::Int, QMetaType::QString, QMetaType::Int,   13,   14,   15,
    QMetaType::Void, QMetaType::Int, QMetaType::QString,    4,    9,
    QMetaType::Bool, QMetaType::QString, QMetaType::QString,   18,   19,
    QMetaType::QString, QMetaType::Int,   21,
    QMetaType::QString, QMetaType::Int,   21,
    QMetaType::QString, QMetaType::Int,   21,
    QMetaType::QString, QMetaType::Int,   21,
    QMetaType::Int,
    QMetaType::Int,
    QMetaType::Int,
    QMetaType::Int,
    QMetaType::QString, QMetaType::Int,   21,
    QMetaType::Void, QMetaType::Int,   21,
    QMetaType::QString, QMetaType::Int,   21,
    QMetaType::Int,
    QMetaType::Int, QMetaType::Int,    5,
    QMetaType::Int, QMetaType::Int,   35,
    QMetaType::QString, QMetaType::Int,    5,
    QMetaType::Int, QMetaType::Int, QMetaType::QString,   35,   38,
    QMetaType::Int, QMetaType::Int,    5,
    QMetaType::Void, QMetaType::QString,   41,
    QMetaType::Void, QMetaType::Int,   41,
    QMetaType::Void, QMetaType::QString,   44,
    QMetaType::QString,
    QMetaType::Int,
    QMetaType::Int,
    QMetaType::Int,
    QMetaType::Bool,
    QMetaType::Int,
    QMetaType::Void,
    QMetaType::Bool,
    QMetaType::Bool,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   21,
    QMetaType::Void, QMetaType::QString,   38,
    QMetaType::QString,
    QMetaType::Void, QMetaType::Int, QMetaType::Int, QMetaType::QString,    4,    5,    6,
    QMetaType::QString, QMetaType::Int, QMetaType::Int,    4,    5,
    QMetaType::Void, QMetaType::QString,    9,
    QMetaType::Void, QMetaType::QString,    9,
    QMetaType::Void, QMetaType::QString,    9,
    QMetaType::Void, QMetaType::Bool,   65,
    QMetaType::Void, QMetaType::QString,   67,

       0        // eod
};

void DataOperations::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        DataOperations *_t = static_cast<DataOperations *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->weldSuccess(); break;
        case 1: _t->writeDatap((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3]))); break;
        case 2: { QString _r = _t->readDatap((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = _r; }  break;
        case 3: _t->saveProfile((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 4: _t->saveSystemProfile((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3]))); break;
        case 5: _t->saveWeldDetails((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3]))); break;
        case 6: _t->loadProfile((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 7: { bool _r = _t->copyFile((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 8: { QString _r = _t->getGunCount((*reinterpret_cast< int(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = _r; }  break;
        case 9: { QString _r = _t->getGunCurrent((*reinterpret_cast< int(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = _r; }  break;
        case 10: { QString _r = _t->getWeldStatus((*reinterpret_cast< int(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = _r; }  break;
        case 11: { QString _r = _t->getGunContactStatus((*reinterpret_cast< int(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = _r; }  break;
        case 12: { int _r = _t->getBrTemp();
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = _r; }  break;
        case 13: { int _r = _t->getTrTemp();
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = _r; }  break;
        case 14: { int _r = _t->getIpVoltage();
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = _r; }  break;
        case 15: { int _r = _t->getGndDetectStatus();
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = _r; }  break;
        case 16: { QString _r = _t->getGunPermntCount((*reinterpret_cast< int(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = _r; }  break;
        case 17: _t->resetWeldCount((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 18: { QString _r = _t->getCurrentProfile((*reinterpret_cast< int(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = _r; }  break;
        case 19: { int _r = _t->getjobIds();
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = _r; }  break;
        case 20: { int _r = _t->getjobId((*reinterpret_cast< int(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = _r; }  break;
        case 21: { int _r = _t->getstudnames((*reinterpret_cast< int(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = _r; }  break;
        case 22: { QString _r = _t->getstudname((*reinterpret_cast< int(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = _r; }  break;
        case 23: { int _r = _t->getstudcounts((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = _r; }  break;
        case 24: { int _r = _t->getstudcount((*reinterpret_cast< int(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = _r; }  break;
        case 25: _t->savejobID((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 26: _t->saveJobData((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 27: _t->updateDate((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 28: { QString _r = _t->getDateTime();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = _r; }  break;
        case 29: { int _r = _t->getFwProgress();
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = _r; }  break;
        case 30: { int _r = _t->initupdateFW();
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = _r; }  break;
        case 31: { int _r = _t->getErrorType();
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = _r; }  break;
        case 32: { bool _r = _t->ifError();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 33: { int _r = _t->getFWVersion();
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = _r; }  break;
        case 34: _t->qFWVersion(); break;
        case 35: { bool _r = _t->fwUpdateFileExists();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 36: { bool _r = _t->hmiAppUpdateFileExists();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 37: _t->removeFWFile(); break;
        case 38: _t->removeHMIFile(); break;
        case 39: _t->setCustom((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 40: _t->saveApn((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 41: { QString _r = _t->readApn();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = _r; }  break;
        case 42: _t->setProfData((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3]))); break;
        case 43: { QString _r = _t->getProfData((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = _r; }  break;
        case 44: _t->writeProfiles((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 45: _t->readProfiles((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 46: _t->deleteProfiles((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 47: _t->setLoginStatus((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 48: _t->createServerIPFile((*reinterpret_cast< QString(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (DataOperations::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&DataOperations::weldSuccess)) {
                *result = 0;
                return;
            }
        }
    }
}

const QMetaObject DataOperations::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_DataOperations.data,
      qt_meta_data_DataOperations,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *DataOperations::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *DataOperations::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_DataOperations.stringdata0))
        return static_cast<void*>(const_cast< DataOperations*>(this));
    return QObject::qt_metacast(_clname);
}

int DataOperations::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 49)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 49;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 49)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 49;
    }
    return _id;
}

// SIGNAL 0
void DataOperations::weldSuccess()
{
    QMetaObject::activate(this, &staticMetaObject, 0, Q_NULLPTR);
}
QT_END_MOC_NAMESPACE
