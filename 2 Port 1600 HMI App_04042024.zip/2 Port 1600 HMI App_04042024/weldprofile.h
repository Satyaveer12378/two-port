#ifndef WELDPROFILE_H
#define WELDPROFILE_H

#include <QObject>
#include <QFile>

#define DATAPATH "/home/RFWSHMI/"
//#define DATAPATH "C:/RFWSHMI/"

struct WeldParams {
    QString uphgt;
    QString dwnhgt;
    QString upvel;
    QString dwnvel;
    QString time;
    QString counter;
    QString amps;
    QString loadprg;
    QString saveprg;
    QString csrthgt;
    QString cstophgt;
    QString cerror;
    QString currentLoadedProfile;
    QString prftype;
};

class WeldProfile
{

    struct WeldParams gun1;
    struct WeldParams gun2;



    FILE *wFile;
    QFile rFile;

public:
    WeldProfile();
    void updateUpHeight(int gun , QString val);
    void updateDownHeight(int gun , QString val);
    void updateUpVelocity(int gun , QString val);
    void updateDownVelocity(int gun , QString val);
    void updateWeldTime(int gun , QString val);
    void updateCounter(int gun , QString val);
	void updatePermeanentWeldCount(int gun , QString val);
    void updateCurrent(int gun , QString val);
    void updateCurrentStartHeight(int gun , QString val);
    void updateCurrentStopHeight(int gun , QString val);
    void updateCurrentErrorAllow(int gun , QString val);

    QString readUpHeight(int gun);
    QString readDownHeight(int gun);
    QString readUpVelocity(int gun);
    QString readDownVelocity(int gun);
    QString readWeldTime(int gun);
    QString readCounter(int gun);
	QString readPermeanentWeldCount(int gun);
    QString readCurrent(int gun);
    QString readCurrentStartHeight(int gun);
    QString readCurrentStopHeight(int gun);
    QString readCurrentErrorAllow(int gun);


    void setDefaultValues(int gun);
    void loadProfile(int gun, QString prof);
    void saveProfile(int gun, QString prof);
    void saveWeldDetails(int jobID, QString sName,int count);
    void setCurrentProfile(int gun, QString prof);
    QString getCurrentProfile(int gun);
    void loadSystemProfile();
    void saveSystemProfile();
    void writeDatap(int pvalue,int index, QString value);
    QString readDatap(int pvalue, int index);
    //Hmidata Whmidata;
};

#endif // WELDPROFILE_H
