#include "datetimeedit.h"

DateTimeEdit::DateTimeEdit(QObject *parent) : QObject(parent)
{

}

void DateTimeEdit::setDate(int y, int m, int d)
{
    if(QDate::isValid(y,m,d))
    {
      date.setDate(y,m,d);
    }
}

void DateTimeEdit::setTime(int hrs, int mins, int secs, int ms)
{
    if(QTime::isValid(hrs,mins,secs))
    {
        time.setHMS(hrs,mins,secs,ms);
    }

}

QString DateTimeEdit::getDate()
{
    date.getDate(year,month,day);
    CDate =  QString::number(*year)+QString::number(*month)+QString::number(*day);
    return CDate;
}

QString DateTimeEdit::getTime()
{
   CTime = QTime::currentTime().toString("hh:mm:ss");
   return CTime;

}

