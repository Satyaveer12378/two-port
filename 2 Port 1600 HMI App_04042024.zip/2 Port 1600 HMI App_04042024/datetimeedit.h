#ifndef DATETIMEEDIT_H
#define DATETIMEEDIT_H

#include <QObject>
#include <QDate>
#include <QTime>
#include <QTimer>

class DateTimeEdit : public QObject
{
    Q_OBJECT
public:
    explicit DateTimeEdit(QObject *parent = 0);

    QDate date;
    QTime time;

    Q_INVOKABLE void setDate(int y,int m, int d);
    Q_INVOKABLE void setTime(int hrs, int mins, int secs,int ms=0);

    Q_INVOKABLE QString getDate();
    Q_INVOKABLE QString getTime();

    int *year;
    int *month;
    int *day;

    QString CDate;
    QString CTime;

signals:

public slots:
};

#endif // DATETIMEEDIT_H
