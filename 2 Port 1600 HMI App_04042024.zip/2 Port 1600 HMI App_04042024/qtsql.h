#ifndef QTSQL_H
#define QTSQL_H

#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlQueryModel>
#include <QSqlError>
#include <QDebug>
#include <QMessageBox>



    //Create Database
    void createDB (void);
    // Create Table
    void createTable (void);
    // Query Data
    void queryTable (void);
    QSqlDatabase db; // Data Connection With QT
    //QSqlQueryModel model; //


#endif // QTSQL_H
