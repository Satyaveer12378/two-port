#include "datetimeeditwindow.h"

DateTimeEditWindow::DateTimeEditWindow(QWidget *parent) : QWidget(parent)
{

}

