#include <QDebug>
#include <QString>
#include <QSqlDatabase>
#include <QSqlError>
#include <QSqlQuery>
#include "hmidata.h"
#include "weldprofile.h"


QSqlDatabase database;


WeldProfile::WeldProfile()
{
    loadSystemProfile();
}


///////////////// Load & Save Profile /////////////////////////
void WeldProfile::setDefaultValues(int gun) {

    if(gun==1) {
        gun1.csrthgt = "0.2";
        gun1.cstophgt = "3";
        gun1.cerror = "10";
        gun1.uphgt = "2.5";
        gun1.dwnhgt = "3.0";
        gun1.upvel = "120";
        gun1.dwnvel = "120";
        gun1.counter = "0";
        gun1.time = "250";
        gun1.amps = "300";
    }
    else {
        gun2.csrthgt = "0.2";
        gun2.cstophgt = "3";
        gun2.cerror = "10";
        gun2.uphgt = "2.5";
        gun2.dwnhgt = "3.0";
        gun2.upvel = "120";
        gun2.dwnvel = "120";
        gun2.counter = "0";
        gun2.time = "250";
        gun2.amps = "300";
    }
}

void WeldProfile::loadSystemProfile() {
    QList<QString> wordList;
    QString pdata;
    QString temp;

    setDefaultValues(1);
    setDefaultValues(2);

    temp = DATAPATH;
    temp = temp + "SystemProfile.prf";
    rFile.setFileName(temp.toLatin1().data());
    rFile.open(QIODevice::ReadOnly);
    if(!rFile.atEnd()) {
        pdata = rFile.readLine();
        wordList = pdata.split(",");
        if(wordList.count() < 10) {
            qDebug() << "System Profile corrupted";
            rFile.close();
            return;
        }
        gun1.loadprg = wordList[0].toLatin1().data();
        gun1.prftype = wordList[1].toLatin1().data();
        gun1.csrthgt = wordList[3].toLatin1().data();
        gun1.cstophgt = wordList[4].toLatin1().data();
        gun1.cerror = wordList[2].toLatin1().data();

        gun2.loadprg = wordList[5].toLatin1().data();
        gun2.prftype = wordList[6].toLatin1().data();
        gun2.csrthgt = wordList[8].toLatin1().data();
        gun2.cstophgt = wordList[9].toLatin1().data();
        gun2.cerror = wordList[7].toLatin1().data();
        qDebug() << "G1 Prof Type: " << gun1.prftype;
        qDebug() << "G2 Prof Type: " << gun2.prftype;
        if(gun1.prftype.toInt() == 0)
             loadProfile(1,gun1.loadprg+"_Stainless"); // loadProfile(1,gun1.loadprg+"_High");
        /*else if(gun1.prftype.toInt() == 2)
            loadProfile(1,gun1.loadprg+"_Carbon"); // loadProfile(1,gun1.loadprg+"_Low");*/
        else
            loadProfile(1,gun1.loadprg);
        qDebug() << "Profile is: " << gun1.loadprg;
        if(gun2.prftype.toInt() == 0)
             loadProfile(2,gun2.loadprg+"_Stainless"); //loadProfile(2,gun2.loadprg+"_High");
        /*else if(gun2.prftype.toInt() == 2)
            loadProfile(2,gun2.loadprg+"_Carbon"); //loadProfile(2,gun2.loadprg+"_Low");*/
        else
            loadProfile(2,gun2.loadprg);
        qDebug() << "Profile is: " << gun2.loadprg;
    }
    rFile.close();
}

void WeldProfile::saveSystemProfile() {

    QString temp;
    temp = DATAPATH;
    temp = temp + "SystemProfile.prf";
    wFile = fopen(temp.toLatin1().data(), "w");

    if(wFile == NULL) {
        qDebug() << "Error while saving system profile..";
        return;
    }
    else {
        fprintf(wFile, "%s,%s,%s,%s,%s,%s,%s,%s,%s,%s", gun1.loadprg.toLatin1().data(),gun1.prftype.toLatin1().data(),
                gun1.csrthgt.toLatin1().data(),gun1.cstophgt.toLatin1().data(),gun1.cerror.toLatin1().data(),
                gun2.loadprg.toLatin1().data(),gun2.prftype.toLatin1().data(),gun2.csrthgt.toLatin1().data(),
                gun2.cstophgt.toLatin1().data(), gun2.cerror.toLatin1().data());
    }
    fclose(wFile);
}



void WeldProfile::loadProfile(int gun, QString prof) {

    QString pdata;
    QString temp;
    QString pName;

    pName = prof;

    setDefaultValues(gun);
    wFile = NULL;
    setCurrentProfile(gun,prof);
    prof = "Profiles/"+prof;
    temp = DATAPATH+prof+".prf";
    rFile.setFileName(temp.toLatin1().data());
    QList<QString> wordList;
    rFile.open(QIODevice::ReadOnly);

    if(!rFile.atEnd()) {

        pdata = rFile.readLine();
        qDebug() << pdata;
        wordList = pdata.split(",");
        if(wordList.count() < 7) {
            qDebug() << "Profile corrupted";
        }
        qDebug() << wordList[0];
        if(gun == 1){
            gun1.uphgt = wordList[0].toLatin1().data();
            gun1.dwnhgt = wordList[1].toLatin1().data();
            gun1.upvel = wordList[2].toLatin1().data();
            gun1.dwnvel = wordList[3].toLatin1().data();
            gun1.time = wordList[4].toLatin1().data();
            gun1.counter = wordList[5].toLatin1().data();
            gun1.amps = wordList[6].toLatin1().data();
            qDebug() << "@@@ " << gun1.uphgt;

            QString temp;
            temp= DATAPATH;
            temp = temp + "P1Anchor.prf";

            wFile = fopen(temp.toLatin1().data(), "w");

            if(wFile == NULL) {
                qDebug() << "Error while saving count file..";
                return;
            }
            else {
                fprintf(wFile, "%s,%s,%s,%s,%s,%s,%s,%s",pName.toLatin1().data(),gun1.uphgt.toLatin1().data(),gun1.dwnhgt.toLatin1().data(),
                        gun1.upvel.toLatin1().data(),gun1.dwnvel.toLatin1().data(),gun1.time.toLatin1().data(),
                        gun1.counter.toLatin1().data(),gun1.amps.toLatin1().data());
            }
            fclose(wFile);
        }
        else{
            gun2.uphgt = wordList[0].toLatin1().data();
            gun2.dwnhgt = wordList[1].toLatin1().data();
            gun2.upvel = wordList[2].toLatin1().data();
            gun2.dwnvel = wordList[3].toLatin1().data();
            gun2.time = wordList[4].toLatin1().data();
            gun2.counter = wordList[5].toLatin1().data();
            gun2.amps = wordList[6].toLatin1().data();

            QString temp;
            temp= DATAPATH;
            temp = temp + "P2Anchor.prf";

            wFile = fopen(temp.toLatin1().data(), "w");

            if(wFile == NULL) {
                qDebug() << "Error while saving count file..";
                return;
            }
            else {
                fprintf(wFile, "%s,%s,%s,%s,%s,%s,%s,%s", pName.toLatin1().data(),gun2.uphgt.toLatin1().data(),gun2.dwnhgt.toLatin1().data(),
                        gun2.upvel.toLatin1().data(),gun2.dwnvel.toLatin1().data(),gun2.time.toLatin1().data(),
                        gun2.counter.toLatin1().data(),gun2.amps.toLatin1().data());
            }
            fclose(wFile);
        }
        rFile.close();


    }
}

void WeldProfile::saveProfile(int gun, QString prof) {

    wFile = NULL;
    prof = "Profiles/"+prof;
    QString temp = DATAPATH+prof+".prf";
    wFile = fopen(temp.toLatin1().data(),"w");
    qDebug() << temp;

    if(wFile == NULL) {
        qDebug() << "Error while saving profile..";
        return;
    }

    if(gun == 1){

        fprintf(wFile, "%s,%s,%s,%s,%s,%s,%s",gun1.uphgt.toLatin1().data(),gun1.dwnhgt.toLatin1().data(),
                gun1.upvel.toLatin1().data(),gun1.dwnvel.toLatin1().data(),gun1.time.toLatin1().data(),
                gun1.counter.toLatin1().data(),gun1.amps.toLatin1().data());
    }
    else {
        fprintf(wFile, "%s,%s,%s,%s,%s,%s,%s", gun2.uphgt.toLatin1().data(),gun2.dwnhgt.toLatin1().data(),
                gun2.upvel.toLatin1().data(),gun2.dwnvel.toLatin1().data(),gun2.time.toLatin1().data(),
                gun2.counter.toLatin1().data(),gun2.amps.toLatin1().data());

    }
    fclose(wFile);
}

void WeldProfile::saveWeldDetails(int jobID, QString sName, int count)
{
    wFile = NULL;
    QString prof = "Profiles/"+jobID;
    QString temp = DATAPATH+prof+".prf";
    wFile = fopen(temp.toLatin1().data(),"w");
    qDebug() << temp;

    if(wFile == NULL) {
        qDebug() << "Error while saving profile..";
        return;
    }

    fprintf(wFile, "%d,%s,%d", jobID,sName.toLatin1().data(),count);

    fclose(wFile);
}

void WeldProfile::setCurrentProfile(int gun, QString prof)
{
    if(gun == 1)
    {
        gun1.currentLoadedProfile = prof;
    }
    if (gun == 2)
    {
        gun2.currentLoadedProfile = prof;
    }
}

QString WeldProfile::getCurrentProfile(int gun)
{
    if(gun == 1)
    {
        return  gun1.currentLoadedProfile;
    }
    else if (gun == 2)
    {
        return gun2.currentLoadedProfile;
    }
    return 0;
}

void WeldProfile::writeDatap(int pvalue,int index, QString value)
{
    qDebug() << "New:: " << pvalue << " " << index << " " << value;
    if(pvalue==1){
        if(index==1){
            gun1.uphgt =value;
        }
        if(index==2){

            gun1.dwnhgt=value;
        }
        if(index==3){
            gun1.upvel=value;
        }
        if(index==4){
            gun1.dwnvel=value;
        }
        if(index==5){
            gun1.time=value;
        }
        if(index==6){
            gun1.counter=value;
        }
        if(index==7){
            gun1.amps=value;
        }
        if(index==8){
            gun1.loadprg=value;
        }
        if(index==9){
            gun1.saveprg=value;
        }
        if(index==10){
            gun1.csrthgt=value;
        }
        if(index==11){
            gun1.cstophgt=value;
        }
        if(index==12){

            gun1.cerror=value;
        }
        if(index==13){
            gun1.loadprg=value;
        }
        if(index==14){
            gun1.prftype=value;
        }
    }
    else{
        if(index==1){
            gun2.uphgt =value;
        }
        if(index==2){
            gun2.dwnhgt=value;
        }
        if(index==3){
            gun2.upvel=value;
        }
        if(index==4){
            gun2.dwnvel=value;
        }
        if(index==5){
            gun2.time=value;
        }
        if(index==6){
            gun2.counter=value;
        }
        if(index==7){
            gun2.amps=value;
        }
        if(index==8){
            gun2.loadprg=value;
        }
        if(index==9){
            gun2.saveprg=value;
        }
        if(index==10){
            gun2.csrthgt=value;
        }
        if(index==11){
            gun2.cstophgt=value;
        }
        if(index==12){
            gun2.cerror=value;
        }
        if(index==13){
            gun2.loadprg=value;
        }
        if(index==14){
            gun2.prftype=value;
        }

    }
}

QString WeldProfile::readDatap(int pvalue, int index){
    QString value;
    if(pvalue==1){
        if(index==1){
            value = gun1.uphgt.trimmed();
        }
        else if(index==2){
            value = gun1.dwnhgt.trimmed();
        }
        else if(index==3){
            value = gun1.upvel.trimmed();
        }
        else if(index==4){
            value = gun1.dwnvel.trimmed();
        }
        else if(index==5){
            value = gun1.time.trimmed();
        }
        else if(index==6){
            value = gun1.counter.trimmed();
        }
        else if(index==7){
            value = gun1.amps.trimmed();
        }
        else if(index==8){
            value = gun1.loadprg.trimmed();
        }
        else if(index==9){
            value = gun1.saveprg.trimmed();
        }
        else if(index==10){
            value = gun1.csrthgt.trimmed();
        }
        else if(index==11){
            value = gun1.cstophgt.trimmed();
        }
        else if(index==12){
            value = gun1.cerror.trimmed();
        }
        else if(index==13){
            value = gun1.loadprg.trimmed();
        }
        else if(index==14){
            value = gun1.prftype.trimmed();
        }
    }
    else if (pvalue==2){
        if(index==1){
            value = gun2.uphgt.trimmed();
        }
        else if(index==2){
            value = gun2.dwnhgt.trimmed();
        }
        else if(index==3){
            value = gun2.upvel.trimmed();
        }
        else if(index==4){
            value = gun2.dwnvel.trimmed();
        }
        else if(index==5){
            value = gun2.time.trimmed();
        }
        else if(index==6){
            value = gun2.counter.trimmed();
        }
        else if(index==7){
            value = gun2.amps.trimmed();
        }
        else if(index==8){
            value = gun2.loadprg.trimmed();
        }
        else if(index==9){
            value = gun2.saveprg.trimmed();
        }
        else if(index==10){
            value = gun2.csrthgt.trimmed();
        }
        else if(index==11){
            value = gun2.cstophgt.trimmed();
        }
        else if(index==12){
            value = gun2.cerror.trimmed();
        }
        else if(index==13){
            value = gun2.loadprg.trimmed();
        }
        else if(index==14){
            value = gun2.prftype.trimmed();
        }
    }
    return value;
}



