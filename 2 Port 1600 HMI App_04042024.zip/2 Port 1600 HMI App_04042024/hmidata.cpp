#include <hmidata.h>




Hmidata::Hmidata(QObject *parent) : QObject(parent)
{

    MyDataBase = sql_create();
    sql_open();

    if(!MyDataBase.open())
    {
        qDebug() << "Error: Failed to connect database." << MyDataBase.lastError();

    }
    else
    {
        // create table if it's not available
        Hmi_Weldrecs = sql_create_table(sql_table_set);
        // get max id
        max_id = sql_select_maxid(Hmi_Weldrecs, select_string_set);
        // if table data is available do
        //         if(max_id>0)
        //         {
        //             // query max_id corresponding data
        //             QString select_all = "SELECT * from Weld_table WHERE id IS "+QString::number(max_id)+"";

        //             if(!sql_table.exec(select_all))
        //             {
        //                 qDebug()<<sql_table.lastError();
        //             }
        //             else
        //             {
        //                 while(sql_table.next())
        //                 {
        //                     QString Time_string = sql_table.value(0).toString();
        //                     QString Stud_string = sql_table.value(1).toString();
        //                     QString Temp_string = sql_table.value(2).toString();
        //                     qDebug() << Time_string;
        //                     qDebug() << Stud_string;
        //                     qDebug() << Temp_string;
        //                 }
        //             }

        //         }
    }
    // close MyDataBase
    //sql_close(MyDataBase);

}

void Hmidata::savejobID(QString job)
{
    job_ID = job.toInt();
}


QSqlDatabase Hmidata::sql_create()
{
    QSqlDatabase database;
    if (QSqlDatabase::contains("qt_sql_default_connection"))
    {
        database = QSqlDatabase::database("qt_sql_default_connection");
    }
    else
    {
        database = QSqlDatabase::addDatabase("QSQLITE");
        database.setDatabaseName("Hmidata.db");
        database.setUserName("BrandSafe");
        database.setPassword("123456");
        qDebug() << "Id Created";
    }
    return database;
}



void Hmidata::sql_open()
{
    MyDataBase.open();
}

void Hmidata::sql_close(QSqlDatabase DatabaseName)
{
    DatabaseName.close();
}

QSqlQuery Hmidata::sql_create_table(QString sql_table_keys)
{
    QSqlQuery Hmi_Datarecs;

    //sql_table.prepare(sql_table_keys);
    if(!Hmi_Datarecs.exec(sql_table_keys))
    {
        qDebug() << "Error: Fail to create table." << Hmi_Datarecs.lastError();
    }
    else
    {
        qDebug() << "SqlTable created!";
    }
    return Hmi_Datarecs;
}





int Hmidata::sql_delete_data(QSqlQuery sql_table, QString delete_string, int id)
{
    QString delete_string_set = delete_string + QString::number(id);
    qDebug() << delete_string_set;
    if(!sql_table.exec(delete_string_set))
    {
        qDebug()<<sql_table.lastError();
        return -1;
    }
    else
    {
        qDebug()<<"deleted!";
        return 0;
    }
}

int Hmidata::sql_clear_table(QSqlQuery sql_table, QString clear_string)
{
    if(!sql_table.exec(clear_string))
    {
        qDebug() << sql_table.lastError();
        return -1;
    }
    else
    {
        qDebug() << "table cleared";
        return 0;
    }
}

int Hmidata::sql_select_maxid(QSqlQuery sql_table, QString select_string)
{
    int max_id = 0;
    if(!sql_table.exec(select_string))
    {
        qDebug() << sql_table.lastError();
        return -1;
    }
    else
    {
        while(sql_table.next())
        {
            max_id = sql_table.value(0).toInt();
        }
        return max_id;
    }
}


int Hmidata::stud_weld_count(QSqlQuery sql_table, QString select_string)
{
    int weld_count = 0;
    if(!sql_table.exec(select_string))
    {
        qDebug() << sql_table.lastError();
        return -1;
    }
    else
    {
        while(sql_table.next())
        {
            weld_count = sql_table.value(0).toInt();
        }
        return weld_count;
    }
}


void Hmidata::hmiDataupdate( QString name)
{

    qDebug() << "<<<<<<<<WeldData";

    QSqlQuery Hmi_Weldrecs;
    int count=1;

    if(!MyDataBase.open())
    {
        qDebug() << "Error: Failed to connect database." << MyDataBase.lastError();
    }

    else
    {
        max_id = sql_select_maxid(Hmi_Weldrecs, select_string_set);
        QString hmirec = "select * from Weld_table where id is '"+QString::number(job_ID)+
                "' and name is '"+name+"'";

        Hmi_Weldrecs.exec(hmirec);

        if(!Hmi_Weldrecs.next())
        {

            QString insertHmidata = "INSERT INTO Weld_table VALUES("+QString::number(max_id+1)+","+
                    QString::number(job_ID)+","+"\""+name+"\""+","+QString::number(count)+")";

            if(sql_insert_data(Hmi_Weldrecs, insertHmidata) < 0)
            {
                qDebug() << "Error: Failed to insert data!";
            }
            else
            {
                qDebug() << "Success: Add to insert data!";
            }
        }

        //updating weldcount

        else
        {

            qDebug()<<"Data Updating>>>>>>>>>>>>>>>>!";
            QString weld_count ="select count from Weld_table where id is '"+QString::number(job_ID)+"'and name is '"+name+"'";
            count = stud_weld_count(Hmi_Weldrecs, weld_count);
            qDebug() << "table count is:" << count;
            count=count+1;
            qDebug() << "Updated count is:"<< count;
            QString wcount = QString::number(count);
            QString updateHmidata = "update Weld_table set count = '"+(wcount)+"' where id is '"+
                    QString::number(job_ID)+"'and name is '"+name+"'";

            if(!Hmi_Weldrecs.exec(updateHmidata))
            {
                qDebug()<<Hmi_Weldrecs.lastError();
            }
            else
            {
                qDebug()<<"Data Updated!";
            }
        }
    }
}




int Hmidata::sql_insert_data(QSqlQuery Hmi_Datarecs, QString insertDataSql)
{

    if(!Hmi_Datarecs.exec(insertDataSql))
    {
        qDebug() << Hmi_Datarecs.lastError();
        return -1;
    }
    else
    {
        qDebug() << "inserted successfully!";
        return 0;
    }
}





int Hmidata::getjobIds()
{
    int JobID;
    QString x=0;
    jIds.clear();
    QSqlQuery Hmi_WeldReports;
    qDebug() << "Getting JobID's...";
    Hmi_WeldReports.exec(select_id_no);
    while (Hmi_WeldReports.next())    {
        JobID= Hmi_WeldReports.value(0).toInt();
        jIds.append(JobID);
        qDebug()<< Hmi_WeldReports.value(0).toInt();
    }
    return jIds.count();
}

int Hmidata::getjobId(int index){
    return jIds.at(index);
}


int Hmidata::getstudnames(int id)
{

    studnames.clear();
    QSqlQuery Weld_studnames;
    QString select_stud_name = "select name from Weld_table where id is "+QString::number(id)+"";
    qDebug() <<select_stud_name;
    Weld_studnames.exec(select_stud_name);
    while (Weld_studnames.next())    {
        QString Studname= Weld_studnames.value(0).toString();
        studnames.append(Studname);
        qDebug()<< Studname;
    }
    return studnames.count();

}

QString Hmidata::getstudname(int index){
    return studnames.at(index);
    qDebug()<< studnames.at(index);
}





int Hmidata::getstudcounts(int id,QString name)
{
    int studcount;
    QString x=0;
    studcounts.clear();
    QSqlQuery Weld_studcount;
    qDebug() << "Getting Studcount's...";
    QString select_stud_count="select count from Weld_table where id is '"+
            QString::number(id)+"'and name is '"+name+"'";

    Weld_studcount.exec(select_stud_count);
    while (Weld_studcount.next())    {
        studcount= Weld_studcount.value(0).toInt();
        studcounts.append(studcount);
        qDebug()<< Weld_studcount.value(0).toInt();
    }
    return studcount;
}



int Hmidata::getstudcount(int index){
    qDebug() << "Getting Studcount for index ...";
    qDebug()<< studcounts.at(index);
    return studcounts.at(index);
}

