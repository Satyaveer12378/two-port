#ifndef CURRENTGRAPH_H
#define CURRENTGRAPH_H
#include "qcustomplot.h"
#include <QObject>
#include <QtQuick>

#define DATAPATH "/home/RFWSHMI/"

class QCustomPlot;
class QCPAbstractPlottable;

class CurrentGraph : public QQuickPaintedItem
{
    Q_OBJECT

private:
     QCustomPlot* m_CustomPlot;
     QCPAxis *mTimeAxis;
     QCPAxis *mCurrentAxis;
     QCPGraph *mCurrentGraph;


public:
    CurrentGraph( QQuickItem* parent = 0 );
    virtual ~CurrentGraph();
    virtual void paint( QPainter* painter );
    Q_INVOKABLE void showCurrentGraph();
    Q_INVOKABLE void showCurrentGraph(QString fname);


private slots:
  void updateCustomPlotSize();

};

#endif // CURRENTGRAPH_H
