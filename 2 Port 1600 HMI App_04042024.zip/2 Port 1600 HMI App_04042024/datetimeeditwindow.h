#ifndef DATETIMEEDITWINDOW_H
#define DATETIMEEDITWINDOW_H

#include <QWidget>
#include <QDateTimeEdit>

class DateTimeEditWindow : public QWidget
{
    Q_OBJECT
public:
    explicit DateTimeEditWindow(QWidget *parent = 0);

signals:


public slots:
};

#endif // DATETIMEEDITWINDOW_H
