#include <QObject>
#include <QFile>
#include <QDebug>
#include <weldprofile.h>
#include "hmidata.h"
#include "dataoperations.h"


#define ServerIPPath "/home/RFWSHMI/API/temp/ServerIP/"
#define FwVersionPath "/home/RFWSHMI/API/temp/fwver/"
#define HMIVersionPath "/home/RFWSHMI/API/temp/hmiver/"
#define FwUpdatePath "/home/RFWSHMI/API/temp/FWUpdate/"
#define HMIVerUpdatePath "/home/RFWSHMI/API/temp/HMIUpdate/"

#define USBPath "/media/BE_USB_Drive/"



DataOperations::DataOperations(QObject *parent) : QObject(parent)
{
    cbInterface =  new CBInterface(this);
    cbInterface->start();
    QString result = QString(QCryptographicHash::hash(("vijay2019"),QCryptographicHash::Md5).toHex());
    qDebug() << "PSW:" + result;
    createHMIVerFile(QString::number(appVersion,'f',2));
}


DataOperations::~DataOperations()
{

    loginStatus = false;
    inputVoltage = 0;
    gndDetect = 0;

}

void DataOperations::writeDatap(int gunno,int index, QString value)
{
    wProfile.writeDatap(gunno,index,value);
}

QString DataOperations::readDatap(int gunno, int index){
    return wProfile.readDatap(gunno,index);
}

void DataOperations::loadProfile(int gunno, QString pname) {

    wProfile.loadProfile(gunno, pname);

}

bool DataOperations::copyFile(const QString &sourceFile, const QString &destinationDir)
{
    QFileInfo fileInfo(sourceFile);
    QString destinationFile = destinationDir + fileInfo.fileName();
    qDebug() << "File Exists";
    if (QFile::exists(destinationFile))
    {
        QFile::remove(destinationFile);
        qDebug() << "Existing "
                    "file removed";
    }
    qDebug() << sourceFile << "and" << destinationFile;
    bool result = QFile::copy(sourceFile, destinationFile);
    return result;
}

void DataOperations::saveProfile(int gunno, QString pname) {
    qDebug() << "Save Profile " << gunno << "  " << pname;
    wProfile.saveProfile(gunno, pname);
    /*if(gunno == 2)
        wProfile.writeDatap(2,13,pname);
    else
        wProfile.writeDatap(1,13,pname);
    wProfile.saveSystemProfile();*/
}
void DataOperations::saveSystemProfile(int gunno, QString pname, int type) {
    if(gunno == 2)
        wProfile.writeDatap(2,13,pname);
    else
        wProfile.writeDatap(1,13,pname);
    if(gunno == 2)
        wProfile.writeDatap(2,14,QString::number(type));
    else
        wProfile.writeDatap(1,14,QString::number(type));
    wProfile.saveSystemProfile();
}

void DataOperations::saveWeldDetails(int jobID, QString sname, int count)
{
    qDebug() << "Save Weld Details: " << jobID << sname << count ;

    wProfile.saveWeldDetails(jobID,sname,count);
}

void DataOperations::updateWeldStatus(unsigned char gun, int cnt, int amp, int stat) {


    if(gun==1) {
        gun1Count=cnt;
        gun1Current=amp;
        gun1Status=stat;

        qDebug() << "Gun1Status" << stat;

        if(gun1Status == 2)
        {
            g1CurrentProfile = wProfile.getCurrentProfile(1);
            if(g1CurrentProfile == "")
            {
                g1CurrentProfile = "P1 Custom";
            }
            qDebug() << "Trying to update Port1";
            qDebug() << "Profile:" << g1CurrentProfile;
            hmiData.hmiDataupdate(g1CurrentProfile);
        }
    }
    else if(gun==2) {
        gun2Count=cnt;
        gun2Current=amp;
        gun2Status=stat;
        if(gun2Status == 2)
        {
            g2CurrentProfile = wProfile.getCurrentProfile(2);
            if(g2CurrentProfile == "")
            {
                g2CurrentProfile = "P2 Custom";
            }
            qDebug() << "Trying to update Port2";
            qDebug() << "Profile:" << g2CurrentProfile;
            hmiData.hmiDataupdate(g2CurrentProfile);
        }
    }
}

void DataOperations::updateStatus(int bt, int tt, int count1, int count2, long int permntCount1, long int permntCount2, unsigned char stat, unsigned char gstat) {
    bridgeTemp=bt;
    transformerTemp=tt;
    inputVoltage=stat;
    gndDetect = gstat;
    gun1Count=count1;
    gun2Count=count2;
    gun1PermntCount = permntCount1;
    gun2PermntCount = permntCount2;

    QString temp;
    temp= DATAPATH;
    temp = temp + "Count.prf";

    wFile = fopen(temp.toLatin1().data(), "w");

    if(wFile == NULL) {
        qDebug() << "Error while saving count file..";
        return;
    }
    else {
        fprintf(wFile, "%d,%d,%ld,%ld", gun1Count,gun2Count,gun1PermntCount,gun2PermntCount);
    }
    fclose(wFile);
}

void DataOperations::updateWeldCount(unsigned char gun, int count) {
    if(gun==1)
        gun1Count=count;
    else
        gun2Count=count;
}

void DataOperations::contactStatus(unsigned char gun) {
    if(gun==1)
        gun1Contact=0;
    else
        gun2Contact=0;
}

QString DataOperations::getGunCount(int gun) {
    if(gun==1)
        return QString::number(gun1Count);
    else
        return QString::number(gun2Count);
}

QString DataOperations::getGunCurrent(int gun) {
    if(gun==1)
        return QString::number(gun1Current);
    else
        return QString::number(gun2Current);
}

QString DataOperations::getWeldStatus(int gun) {
    if(gun == 1)
        return QString::number(gun1Status);
    else
        return QString::number(gun2Status);
}

QString DataOperations::getGunContactStatus(int gun) {
    if(gun==1)
        return QString::number(gun1Contact);
    else
        return QString::number(gun2Contact);
}

int DataOperations::getBrTemp() {
    return bridgeTemp;
}

int DataOperations::getTrTemp() {
    return transformerTemp;
}

int DataOperations::getIpVoltage() {
    return inputVoltage;
}

int DataOperations::getGndDetectStatus()
{
    return gndDetect;
}
QString DataOperations::getGunPermntCount(int gun)
{
    if(gun==1)
        return QString::number(gun1PermntCount);
    else
        return QString::number(gun2PermntCount);
}
void DataOperations::resetWeldCount(int gun) {
    cbInterface->sendResetCount(gun);
}

QString DataOperations::getCurrentProfile(int gun)
{
    if(gun == 1)
    {
        return wProfile.getCurrentProfile(1);
    }
    else if (gun == 2)
    {
        return wProfile.getCurrentProfile(2);
    }
    else
        return 0;
}

int DataOperations::getjobIds()
{
    return hmiData.getjobIds();
}

int DataOperations::getjobId(int index)
{
    return hmiData.getjobId(index);
}

int DataOperations::getstudnames(int id)
{
    return hmiData.getstudnames(id);
}

QString DataOperations::getstudname(int index)
{
    return hmiData.getstudname(index);
}

int DataOperations::getstudcounts(int id, QString name)
{
    return hmiData.getstudcounts(id,name);
}

int DataOperations::getstudcount(int index)
{
    return hmiData.getstudcount(index);
}

void DataOperations::savejobID(QString job)
{
    hmiData.savejobID(job);
}

void DataOperations::saveJobData(int job)
{
    QString str;
    wFile = NULL;
    QString jobName = USBPath +QString::number(job);
    QString temp = jobName+".log";
    int count = hmiData.getstudnames(job);

    for (int j=0; j<count; j++)
    {
        QString Stud=hmiData.getstudname(j);
        int sCount = hmiData.getstudcounts(job,Stud);

        str += Stud+"-"+QString::number(sCount)+"\n";
    }

    wFile = fopen(temp.toLatin1().data(),"w");
    qDebug() << temp;

    if(wFile == NULL) {
        qDebug() << "Error while saving WeldData..";
        return;
    }

    fprintf(wFile, "%s",str.toLatin1().data());
    fclose(wFile);
}

void DataOperations::updateDate(QString date)
{
    qDebug() << "Updating date";
    QProcess::execute(date);
    qDebug() << "Updated Date to:"<<date;

    QString setRTC = "hwclock -w";
    qDebug() << "Updating RTC";
    QProcess::execute(setRTC);
    qDebug() << "Updated RTC";
}

QString DataOperations::getDateTime()
{
    QString dateTime;

    dateTime = QDateTime::currentDateTime().toString().toLatin1().data();
    qDebug() << "Current Date time is: " << dateTime;

    return dateTime;
}

int DataOperations::initupdateFW()
{

    QString path= FwUpdatePath;

    //QDir dir(path, {".hex"});

    QDir dir(path);

    QDirIterator iterator(dir.absolutePath(), QDir::Files);

    QFile file (iterator.next());

    QString fileName = QFileInfo(file).fileName();

    fileName = path+fileName;

    qDebug() << "Filename is:" << fileName;
    QString data;
    int cnt = 0;
    fwProgress=0;
    rFile.setFileName(fileName.toLatin1().data());
    rFile.open(QIODevice::ReadOnly);

    qDebug() << "Updating Firmware.....";
    while(!rFile.atEnd()) {
        data = rFile.readLine();
        qDebug() << data;
        cnt++;
    }
    qDebug() << cnt;
    cbInterface->startFWUpdate();
    return cnt;
    rFile.close();
}

int DataOperations::getErrorType()
{
    return cbInterface->ErrorType;
}

bool DataOperations::ifError()
{
    if(cbInterface->ErrorType)
        return true;
    return false;
}

void DataOperations::qFWVersion()
{
    cbInterface->getFWVersion();
}

bool DataOperations::fwUpdateFileExists()
{
    QString path= FwUpdatePath;

    QDir dir(path);

    dir.setFilter(QDir::Files);

    if(!(dir.count()))
    {
        return 0;
    }
    return 1;
}

bool DataOperations::hmiAppUpdateFileExists()
{
    QString path= HMIVerUpdatePath;

    QDir dir(path);

    dir.setFilter(QDir::Files);

    if(!(dir.count()))
    {
        return 0;
    }
    return 1;
}

void DataOperations::removeHMIFile()
{
    QString path= HMIVerUpdatePath;

    QDir dir(path);
    dir.setFilter(QDir::Files);

    for(const QString & filename: dir.entryList()){

        if(dir.remove(filename)) {

            qDebug() << "Firmware File removed";
        }
    }
}

void DataOperations::removeFWFile()
{

    QString path= FwUpdatePath;

    QDir dir(path);
    dir.setFilter(QDir::Files);

    for(const QString & filename: dir.entryList()){

        if(dir.remove(filename)) {

            qDebug() << "Firmware File removed";
        }
    }

}

int DataOperations::getFWVersion()
{
    return cbInterface->FWVersion;
}

void DataOperations::updateFwDone()
{
    removeFWFile();
    fwProgress = -1;
}

bool DataOperations::getLoginStatus()
{
    return loginStatus;
}

void DataOperations::setLoginStatus(bool status)
{
    if(status)
        loginStatus = true;

    else
        loginStatus = false;
}

void DataOperations::setCustom(int gun)
{
    wProfile.setDefaultValues(gun);
}

void DataOperations::createFWVerFile(QString filename)
{
    QFile fwVer;
    QString temp;

    QString path= FwVersionPath;

    QDir dir(path);
    dir.setFilter(QDir::Files);

    for(const QString & filename: dir.entryList()){

        if(dir.remove(filename)) {

            qDebug() << "File removed";
        }
    }

    temp = FwVersionPath;
    temp = temp +"firmware_"+filename;
    fwVer.setFileName(temp.toLatin1().data());

    if(!fwVer.open(QIODevice::WriteOnly | QIODevice::Text))
    {
        qDebug() << "Failed to create file or File doesn't exsist";
    }

    QTextStream out(&fwVer);
    out << "firmware_"+filename;
    fwVer.close();
}

void DataOperations::createHMIVerFile(QString filename)
{
    QFile hmiVer;
    QString temp;

    QString path= HMIVersionPath;

    QDir dir(path);
    dir.setFilter(QDir::Files);

    for(const QString & filename: dir.entryList()){

        if(dir.remove(filename)) {

            qDebug() << "File removed";
        }
    }

    temp = HMIVersionPath;
    temp = temp +"BrandSafe_" + filename;
    hmiVer.setFileName(temp.toLatin1().data());

    if(!hmiVer.open(QIODevice::WriteOnly | QIODevice::Text))
    {
        qDebug() << "Failed to create file or File doesn't exsist";
    }

    QTextStream out(&hmiVer);
    out << "BrandSafe_"+filename;
    hmiVer.close();
}

void DataOperations::createServerIPFile(QString ipAddress)
{
    QFile serverIP;
    QString temp;

    QString path= ServerIPPath;

    QDir dir(path);
    dir.setFilter(QDir::Files);

    for(const QString & filename: dir.entryList()){

        if(dir.remove(filename)) {

            qDebug() << "File removed";
        }
    }

    temp = ServerIPPath;
    temp= temp + "Domain.txt";
    serverIP.setFileName(temp.toLatin1().data());

    if(!serverIP.open(QIODevice::WriteOnly | QIODevice::Text))
    {
        qDebug() << "Failed to create file or File doesn't exsist";
    }

    QTextStream out(&serverIP);
    out << ipAddress;
    serverIP.close();

}

int DataOperations::getFwProgress()
{
    return fwProgress;
}

void DataOperations::incFwProgress()
{
    fwProgress++;
    qDebug() << fwProgress;
}

QString DataOperations::readApn() {
     
    QFile rFile;
    QString name;
    QString temp;
    temp = DATAPATH;
    temp = temp + "ApnName.cfg";
    rFile.setFileName(temp.toLatin1().data());
    rFile.open(QIODevice::ReadOnly);
    if(!rFile.atEnd()) {
        name = rFile.readLine();
    }
    return name;
}

void DataOperations::saveApn(QString name)
{
    FILE *wFile;
    QString temp;
    temp = DATAPATH;
    temp = temp + "ApnName.cfg";
    wFile = fopen(temp.toLatin1().data(), "w");

    if(wFile == NULL) {
        qDebug() << "Error while saving Apn Name..";
        return;
    }
    else {
        fprintf(wFile, "%s", name.toLatin1().data());
    }
    fclose(wFile);
}



void DataOperations::setProfData(int gunno,int index, QString value)
{
    if(gunno==3)
        highProfile.writeDatap(1,index,value);
    else if(gunno == 4)
        medProfile.writeDatap(1,index,value);
   /* else if(gunno == 5)
        lowProfile.writeDatap(1,index,value);*/
}

QString DataOperations::getProfData(int gunno, int index){
    qDebug() << "Reading Prof Data:" << index;
    if(gunno==3)
        return highProfile.readDatap(1,index);
    else if(gunno == 4)
        return medProfile.readDatap(1,index);
    /*else if(gunno == 5)
        return lowProfile.readDatap(1,index);*/
}

void DataOperations::readProfiles(QString pname) {
    highProfile.loadProfile(1, pname+"_Stainless");
    medProfile.loadProfile(1, pname);
    //lowProfile.loadProfile(1, pname+"_low");
}

void DataOperations::writeProfiles(QString pname) {
    highProfile.saveProfile(1, pname+"_Stainless");
    medProfile.saveProfile(1, pname);
   // lowProfile.saveProfile(1, pname+"_low");
}

void DataOperations::deleteProfiles(QString pname) {
    qDebug() << "Delete Profile: " << pname;
    QString path = DATAPATH;
    qDebug() << path+"Profiles/"+pname+"_Stainless"+".prf";
    QFile::remove(path+"Profiles/"+pname+"_Stainless"+".prf");
    QFile::remove(path+"Profiles/"+pname+".prf");
 //   QFile::remove(path+"Profiles/"+pname+"_low"+".prf");
    QFile::remove(path+"Images/"+pname+".jpg");
}
