#include "currentgraph.h"

CurrentGraph::CurrentGraph( QQuickItem* parent ) : QQuickPaintedItem( parent )
  , m_CustomPlot(NULL)
{

    m_CustomPlot = new QCustomPlot();
    connect( this, &QQuickPaintedItem::widthChanged, this, &CurrentGraph::updateCustomPlotSize );
    connect( this, &QQuickPaintedItem::heightChanged, this, &CurrentGraph::updateCustomPlotSize );

    m_CustomPlot->setGeometry( 0, 0, width(), height() + 5 );
    m_CustomPlot->setBackground(QColor(226, 228, 228));
    mTimeAxis =m_CustomPlot->xAxis;
    mCurrentAxis = m_CustomPlot->yAxis;

    mTimeAxis->setRange(0, 2);
    mTimeAxis->setLabel("Time");
    mTimeAxis->setLabelFont(QFont(QFont().family(),11,QFont::Bold));
    mTimeAxis->setLabelColor(QColor(138,42,43));


    mCurrentAxis->setRange(0, 1700);
    mCurrentAxis->setLabel("Current");
    mCurrentAxis->setLabelFont(QFont("Helvetica", 11, QFont::Bold));
    mCurrentAxis->setLabelColor(QColor(138,42,43));

    mCurrentGraph = m_CustomPlot->addGraph(mTimeAxis, mCurrentAxis);
    mCurrentGraph->setName(QString("Current"));
    mCurrentGraph->setLineStyle((QCPGraph::LineStyle)(2));
    mCurrentGraph->setPen(QColor(138,42,43));


}

CurrentGraph::~CurrentGraph()
{
    delete m_CustomPlot;
    m_CustomPlot = NULL;
    qDebug()<<"ResultGraph end";
}


void CurrentGraph::paint( QPainter* painter )
{
    if (m_CustomPlot)
    {
        QPixmap    picture( boundingRect().size().toSize() );
        QCPPainter qcpPainter( &picture );

        //m_CustomPlot->replot();
        m_CustomPlot->toPainter( &qcpPainter );

        painter->drawPixmap( QPoint(), picture );
    }
}

void CurrentGraph::updateCustomPlotSize()
{
    if (m_CustomPlot)
    {
        m_CustomPlot->setGeometry( 0, 0, width(), height() + 5 );
        //qDebug() << "Update Plot Size";
    }
}

void CurrentGraph::showCurrentGraph()
{
    QTime time = QTime::currentTime();
    qsrand((uint)time.msec());
    QVector<double> x(101), y(101); // initialize with entries 0..100
    for (int i=0; i<101; ++i)
    {
      x[i] = (qrand()%1500); // x goes from -1 to 1
      qDebug()<< x[i];
      y[i] = i; // let's plot a quadratic function
    }
    mCurrentGraph->setData(y, x);
    m_CustomPlot->replot();
}

void CurrentGraph::showCurrentGraph(QString fname)
{
    QString temp;
    QString pdata;
    QVector<double> x(1024), y(1024); // initialize with entries 0..100
    QFile rFile;
    int i=0;

    temp = fname;
    rFile.setFileName(temp.toLatin1().data());
    rFile.open(QIODevice::ReadOnly);
    while(!rFile.atEnd()) {
        pdata = rFile.readLine();
        x[i] = pdata.toInt();
        qDebug()<< x[i];
        qDebug() << i;
        y[i] = (i+1)*4/1000.0;
        i++;
    }
    double xrange = (i)*4/1000.0 + (i)*4/10000.0;
    qDebug() << xrange;
    mTimeAxis->setRange(0, xrange);
    mCurrentGraph->setName(fname);
    mCurrentGraph->setData(y, x);
    m_CustomPlot->replot();
    update();
}
