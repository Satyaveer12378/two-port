#include "users.h"
#include<QFile>
#include<QFileInfo>
#include<QDebug>
#include <QCryptographicHash>

Users::Users(QObject *parent) : QObject(parent)
{
    QString fileName=USERSPATH;
    fileName=fileName+("admin");
    QFile file(fileName);
    if(!QFileInfo::exists(fileName))
    {
        qDebug () << "Admin user not exist" << endl;
        file.open(QIODevice::ReadWrite | QIODevice::Text);
        QString result = QString(QCryptographicHash::hash(("admin123"),QCryptographicHash::Md5).toHex());
        file.write(result.toLatin1().data());
        file.close();
    }
}

bool Users::verifyAdmin()
{
    qDebug() << "Admin is "<<isAdmin;
    return isAdmin;
}

QString Users::getuserName()
{
    qDebug() << "Name is:" << userName;
    return userName;
}

bool Users::verifyUser(QString userid, QString password) {
    QString fileName=USERSPATH;
    QString psw;
    userName = userid;
    if(userid == "admin")
    {
        isAdmin = true;
    }
    else
        isAdmin = false;
    fileName=fileName+userid;
    QString result = QString(QCryptographicHash::hash((password.toLatin1().data()),QCryptographicHash::Md5).toHex());
    QFile file(fileName);
    if(QFileInfo::exists(fileName))
    {
        file.open(QIODevice::ReadWrite | QIODevice::Text);
        psw =  file.readAll();
        file.close();
    }
    qDebug() << result;
    qDebug() << psw;
    if(result==psw)
        return true;
    return false;
}

int Users::addUser(QString userid, QString password) {
    QString fileName=USERSPATH;
    fileName=fileName+userid;
    QFile file(fileName);
    if(!QFileInfo::exists(fileName))
    {
        file.open(QIODevice::ReadWrite | QIODevice::Text);
        QString result = QString(QCryptographicHash::hash((password.toLatin1().data()),QCryptographicHash::Md5).toHex());
        file.write(result.toLatin1().data());
        file.close();
    }
    else
    {
        return 1;
    }
    return 0;

}

int Users::deleteUser(QString userid) {
    QString fileName=USERSPATH;
    fileName=fileName+userid;
    QFile file(fileName);
    if(QFileInfo::exists(fileName))
    {
        file.remove();
    }
    else
    {
        return 1;
    }
    return 0;

}

int Users::updatePassword(QString userid, QString password, QString newpsw) {
    QString fileName=USERSPATH;
    QString psw;
    fileName=fileName+userid;
    QString result = QString(QCryptographicHash::hash((password.toLatin1().data()),QCryptographicHash::Md5).toHex());
    QFile file(fileName);
    if(QFileInfo::exists(fileName))
    {
        file.open(QIODevice::ReadWrite | QIODevice::Text);
        psw =  file.readAll();
        file.close();
    }
    else
    {
        return 1;
    }
    qDebug() << result;
    qDebug() << psw;
    if(result!=psw)
        return 2;
    file.remove();
    file.open(QIODevice::ReadWrite | QIODevice::Text);
    result = QString(QCryptographicHash::hash((newpsw.toLatin1().data()),QCryptographicHash::Md5).toHex());
    file.write(result.toLatin1().data());
    file.close();
    return 0;
}
