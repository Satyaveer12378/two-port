#ifndef DATAOPERATIONS
#define DATAOPERATIONS
#include <QObject>
#include <QFile>
#include <QDebug>
#include "cbinterface.h"
#include "weldprofile.h"
#include "currentgraph.h"
#include "hmidata.h"


class DataOperations:public QObject {

    Q_OBJECT

    int gun1Count = 0;
    int gun2Count = 0;
    int gun1Current = 0;
    int gun2Current = 0;
    long int gun1PermntCount = 0;
    long int gun2PermntCount = 0;
    int gun1Status = 0;
    int gun2Status = 0;
    int bridgeTemp;
    int transformerTemp;
    int inputVoltage;
    int gndDetect;
    bool gun1Contact;
    bool gun2Contact;
    int fwProgress;

    bool loginStatus;

    float appVersion = 1.0;

    FILE *wFile;
    QFile rFile;


public:
    explicit DataOperations(QObject *parent = 0);
    ~DataOperations();

public:
    Q_INVOKABLE void writeDatap(int gunno,int index,QString value);
    Q_INVOKABLE QString readDatap(int gunno,int index);
    Q_INVOKABLE void saveProfile(int gunno, QString pname);
    Q_INVOKABLE void saveSystemProfile(int gunno, QString pname,int type);
    Q_INVOKABLE void saveWeldDetails(int jobID, QString sname, int count);
    Q_INVOKABLE void loadProfile(int gunno, QString pname);
    Q_INVOKABLE bool copyFile(const QString& sourceFile, const QString& destinationDir);
    Q_INVOKABLE QString getGunCount(int gun);
    Q_INVOKABLE QString getGunCurrent(int gun);
    Q_INVOKABLE QString getWeldStatus(int gun);
    Q_INVOKABLE QString getGunContactStatus(int gun);
    Q_INVOKABLE int getBrTemp();
    Q_INVOKABLE int getTrTemp();
    Q_INVOKABLE int getIpVoltage();
    Q_INVOKABLE int getGndDetectStatus();
    Q_INVOKABLE QString getGunPermntCount(int gun);
    Q_INVOKABLE void resetWeldCount(int gun);

    Q_INVOKABLE QString getCurrentProfile(int gun);

    Q_INVOKABLE int getjobIds();
    Q_INVOKABLE int getjobId(int index);
    Q_INVOKABLE int getstudnames(int id);
    Q_INVOKABLE QString getstudname(int index);
    Q_INVOKABLE int   getstudcounts(int id, QString name);
    Q_INVOKABLE int getstudcount(int index);
    Q_INVOKABLE void savejobID(QString job);

    Q_INVOKABLE void saveJobData(int job);

    Q_INVOKABLE void updateDate(QString date);
    Q_INVOKABLE QString getDateTime();

    Q_INVOKABLE int getFwProgress();
    Q_INVOKABLE int initupdateFW();
    Q_INVOKABLE int getErrorType();
    Q_INVOKABLE bool ifError();

    Q_INVOKABLE int getFWVersion();
    Q_INVOKABLE void qFWVersion();

    Q_INVOKABLE bool fwUpdateFileExists();
    Q_INVOKABLE bool hmiAppUpdateFileExists();
    Q_INVOKABLE void removeFWFile();
    Q_INVOKABLE void removeHMIFile();

    Q_INVOKABLE void setCustom(int gun);

    Q_INVOKABLE void saveApn(QString name);
    Q_INVOKABLE QString readApn();

    Q_INVOKABLE void setProfData(int gunno,int index,QString value);
    Q_INVOKABLE QString getProfData(int gunno,int index);
    Q_INVOKABLE void writeProfiles(QString pname);
    Q_INVOKABLE void readProfiles(QString pname);
    Q_INVOKABLE void deleteProfiles(QString pname);


    void updateWeldStatus(unsigned char gun, int cnt, int amp, int stat);
    void updateStatus(int bt, int tt, int count1, int count2, long int permntCount1, long int permntCount2,unsigned char stat,unsigned char gstat);
    void contactStatus(unsigned char gun);
    void updateWeldCount(unsigned char gun, int count);
    void incFwProgress();
    void updateFwDone();

    bool getLoginStatus();

    Q_INVOKABLE void setLoginStatus(bool status);

    void createFWVerFile(QString filename);
    void createHMIVerFile(QString filename);
    Q_INVOKABLE void createServerIPFile(QString filename);


    QString g1CurrentProfile;
    QString g2CurrentProfile;



public:

    WeldProfile wProfile;
    WeldProfile highProfile;
    WeldProfile medProfile;
    WeldProfile lowProfile;
    Hmidata hmiData;
    CBInterface *cbInterface;
    WeldProfile *weldProfile;

signals:
    void weldSuccess();

public slots:
};

#endif // DATAOPERATIONS

