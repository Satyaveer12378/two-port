#ifndef USERS_H
#define USERS_H

#include <QObject>
#define USERSPATH "/home/RFWSHMI/Users/"
class Users : public QObject
{
    Q_OBJECT
public:
    explicit Users(QObject *parent = 0);

    bool isAdmin;
    QString userName;

    Q_INVOKABLE bool verifyAdmin();
    Q_INVOKABLE QString getuserName();
    Q_INVOKABLE bool verifyUser(QString userid, QString password);
    Q_INVOKABLE int addUser(QString userid, QString password);
    Q_INVOKABLE int deleteUser(QString userid);
    Q_INVOKABLE int updatePassword(QString userid, QString password, QString newpsw);
};

#endif // USERS_H
