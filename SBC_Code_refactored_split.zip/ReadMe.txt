
========================================================================
    WIN32 APPLICATION : Dav_Sub Project Overview
========================================================================

AppWizard has created this Dav_Sub application for you.

This file contains a summary of what you will find in each of the files that
make up your Dav_Sub application.


Dav_Sub.vcproj
    This is the main project file for VC++ projects generated using an Application Wizard.
    It contains information about the version of Visual C++ that generated the file, and
    information about the platforms, configurations, and project features selected with the
    Application Wizard.

src/src/Dav_Sub.cpp
    This is the main application source file.

/////////////////////////////////////////////////////////////////////////////
AppWizard has created the following resources:

Dav_Sub.rc
    This is a listing of all of the Microsoft Windows resources that the
    program uses.  It includes the icons, bitmaps, and cursors that are stored
    in the RES subdirectory.  This file can be directly edited in Microsoft
    Visual C++.

include/include/Resource.h
    This is the standard header file, which defines new resource IDs.
    Microsoft Visual C++ reads and updates this file.

Images/Images/Dav_Sub.ico
    This is an icon file, which is used as the application's icon (32x32).
    This icon is included by the main resource file Dav_Sub.rc.

Images/Images/small.ico
    This is an icon file, which contains a smaller version (16x16)
    of the application's icon. This icon is included by the main resource
    file Dav_Sub.rc.

/////////////////////////////////////////////////////////////////////////////
Other standard files:

StdAfx.h, StdAfx.cpp
    These files are used to build a precompiled header (PCH) file
    named Dav_Sub.pch and a precompiled types file named StdAfx.obj.

/////////////////////////////////////////////////////////////////////////////
Other notes:

AppWizard uses "TODO:" comments to indicate parts of the source code you
should add to or customize.


/*cd /f/Dahlia-Verdin/GTK*/
/* RUN BAT FILE TO EXECUTE PROGRAM --> bash ./gtkboardapp_run.bat*/
/* gcc gtkrow.c src/src/OpenGL.c -o Main `pkg-config --cflags --libs gtk+-3.0` -lm -lwayland-client -lwayland-server -lwayland-egl -lEGL -lGLESv2 */
/* $CC gtkrow.c src/src/OpenGL.c -o Main `pkg-config --cflags --libs gtk+-3.0` -lm -lwayland-client -lwayland-server -lwayland-egl -lEGL -lGLESv2 */
/* $CC gtkrow.c src/src/OpenGL.c -o Main `pkg-config --cflags --libs gtk+-3.0` -lgpiod -lm -lwayland-client -lwayland-server -lwayland-egl -lEGL -lGLESv2 */
/* $CC src/src/Dav_Sub.c src/src/OpenGL.c -o Main `pkg-config --cflags --libs gtk+-3.0` -lgpiod -lm -lwayland-client -lwayland-server -lwayland-egl -lEGL -lGLESv2 */

/*  bash Build_For_brd.sh */     // Use this command to Build the application to run on Board  
// 
//   bash ./Build_For_WSL.sh     // Build for WSL  Environment setti is not rquired
//   cd /mnt/d/  
//  cd WSL_Wayland_Proj/WSL_Prog/Dav_Sub/Dav_Sub
//  . /opt/tdx-xwayland/5.7.1/environment-setup-aarch64-tdx-linux
//    which pkg-config
//    /opt/tdx-xwayland/5.7.1/sysroots/x86_64-tdxsdk-linux/usr/bin/pkg-config
//    bash Build_For_brd.sh
//    export DISPLAY=172.23.144.1:0 && export XDG_RUNTIME_DIR=/tmp/xdg && export RUNLEVEL=3 && weston
//    
//   setup=setenv setupargs console=tty1 console=${console},${baudrate} consoleblank=0 earlycon   // set environment as below so during boot console command would not get display on screen
//   setenv setup 'setenv setupargs vt.global_cursor_default=0 console=${console},${baudrate} consoleblank=0 earlycon'


/////////////////////////////////////////////////////////////////////////////
