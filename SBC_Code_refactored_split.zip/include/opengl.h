#ifndef OPENGL_H
#define OPENGL_H

/* Auto-generated umbrella header for OpenGL.c split */
void egl_wayland_initialization(GdkWindow *gdk_window, int width, int height);
void ogl_initialization(int width, int height);
if (iShaderCompileStatus == GL_FALSE);
if (iInfoLogLength > 0);
if (szInfoLog != NULL);
if (iProgramLinkStatus == GL_FALSE);
if (iInfoLogLength);
void ogl_render(int width, int height);
if (val_ary[SET_REF_PERA] == 1);
if (video_val == 1);
void ogl_update(void);
if (rw_flag == -1 || rw_flag == 0);
else if (bflag == false);
if ((Record_Type_val == 0 || Record_Type_val == 1 || Record_Type_val == 3);
else if (rw_flag == 1);
if (Ascan_peak_flag == true);
if (row_y[i] > Asc_Max[i]);
if (temp > 127);
if (temp > 100);
if (temp < 0);
void ogl_uninitialization(guint signal_id);
if (Ascan_surface);
if (Ascan_pixbuf);
if (ogl.cr);
if (ogl.surface);
if (signal_id != 0);
if (ogl.textureColorbuffer);
if (ogl.framebuffer);
if (ogl.vbo_color);
if (ogl.vbo_position);
if (ogl.ebo);
if (ogl.vao);
if (ogl.shader_program_object);
if (pShaders);
if (ogl.egl_display != EGL_NO_DISPLAY);
if (ogl.egl_context != EGL_NO_CONTEXT);
if (ogl.egl_surface != EGL_NO_SURFACE);
if (ogl.egl_window);
if (ogl.subsurface);
if (ogl.region);
if (ogl.cw_surface);
if (ogl.w_display);
void gl_clear_color_background_data(int width, int height);
if (Asc_Clr_val > 7);
if (val_ary[BEAM_PROF_PERA] == 2);
if (val_ary[OBJ_SHAPE_PERA] == 0);
else if (val_ary[OBJ_SHAPE_PERA] == 1 || val_ary[OBJ_SHAPE_PERA] == 2);
else if (val_ary[OBJ_SHAPE_PERA] == 3);
void get_server_referance(GdkDisplay *gdk_display);
void global_registry_handler(void *data, struct wl_registry *registry, uint32_t id, const char *interface, uint32_t version);
void global_registry_remover(void *data, struct wl_registry *registry, uint32_t id);
void partial_uninitialize(void);
void recreate_surface(int width, int height, int xx_pos, int yy_pos);
void clr_grd_data_function(void);
if (Clr_leg_width < 5);
if (s_x11 > Asc_Width);
if (s_x22 > Asc_Width);
if (i < 235 && (y1 > -1 && y2 > -1);
if (Dac_crv_dB > 0);

#endif
