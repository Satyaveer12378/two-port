#define window_width 972  // 1024
#define window_height 511 // 600

// #define ruler_thickness 24		// RB  -- 765
#define ruler_Height_width 24 // thickness 24		// RB  -- 765

int testMsgNo = 0;
int frame_width_out = 741;	//  765 //785//780   // #define frame_width  741    //  765 //785//780
int frame_height_out = 446; //  465  // 456 // #define frame_height 446    //  465  // 456

int frame_width = 739 + 2;	//  765 //785//780   // #define frame_width  741    //  765 //785//780
int frame_height = 444 + 2; //  465  // 456 // #define frame_height 446    //  465  // 456

#define frame_heighth 545 // for hide buttons functionality

int Asc_Width = 720;  //  750;
int Asc_Height = 430; //  460;
int temp_Asc_Height = 0;

int width_sh = 741;	 //     750+15;  //765 // Width of frame and ogl window during show and hide process by default. This variable is used to change the width.
int height_sh = 446; //    465; // Height of frame and ogl window during show and hide process by default. This variable is used to change the width.

int bsc_height;
int frame_type_num = -1;
char abcdefghig[8] = { "In" };
int recall_read = 0;

int temp_dgsgain = 0;

int Voff = 16; //  // height_sh-Asc_Height;
float prev_sval = 0.0;
#define RED 40	 // RED Color for DAC Curve
#define PLOGIC 1 // GATE Status
#define NLOGIC 2
#define CRV_M 3
#define CRV_1N 4
#define CRV_2N 5
#define CRV_1P 6
#define CRV_2P 7
#define EXPAND 8

#define STOP 0
#define RECORD 1
#define PLAY 2
#define PAUSE 3

#define UNFREEZ 1 // Last ID value 221
#define FREEZ 2

#define BSC_RECORD 0 // BScan Record/Play control
#define BSC_PLAY 1
#define BSC_ANALYSE 2
#define BSC_DETAIL 3
#define BSC_DELETE 4
#define BSC_CPY_ONE 5
#define BSC_CPY_ALL 6

#define button_width 153	//  156 // Top button width
#define button_height 40	//  Height for top, scnd and bottom layer button
#define btntop_height 40
int btm_btnfrm = 765;		// button_width * 5 + some spacing
int tsbtn_width = 190; // 225 - 10; // Width for top, scnd layer button
int tsbtn4_width = 190; // 85 + 30; // Width for 4th top, scnd layer button

int databtn_width = 141; //156; // Data_Value and heading button width
int databtn_hght = 42;	 // Data and Value button height
int databtn8_hght = 55;	 // Data and Value 8 no button height

#define bbutton_width 156 // Height and Width for bottom most button
#define bbutton_hght 41

int btnw_prvnxt = 68; // Next and previous button width
int btnh_prvnxt = 40; // Next and previous button height

#define v_button_width 35  // Stp, Keypad button width
#define v_button_height 39 // Stp, Keypad button height

#define buttonv_width 156	// Data and Value button width
#define buttonh_height 50	// Data and Value 8 no button button width
#define button10_height 40	// For hide and show functionality
#define buttonmnu_height 45 // For hide and show functionality

#define button_shheight 30
#define btnscrhd_width 225

// #define btnw_prvnxt 75 // Next and previous button preview
#define btnscrprvnxt_w 110

#define scrollbar_w 35	   // 30
#define scrollbar_h 470 //382	   // 378 //332
#define scrollbarshw_w 95  //  30  // For hide and show functionality
#define scrollbarshw_h 460 // For hide and show functionality

#define image_w 30	 // 54 // Notication images width and height
#define image_dy 245 // 254 //112
int image_clk = 100; // image_dy - 100;//100;
#define imagei_w 50
#define image_h 40
#define image_sh 38

#define btn_width 150	// new data btn height and width
#define btn_height 42	// 35
#define btn16_height 84 //  80 // exit button height

// #define text_windoww 625 // Size for text boxes window
// #define text_windoww 542
// #define text_windowh 550

#define text_height 25	  // Size of text box in textbox window
#define texthd_width 300  //  390     // width of textbox headings
#define txtdata_width 450 // 400  //width of data textbox

typedef struct tagPOINT
{
	long x;
	long y;
} POINT;

int ogl_x_position = 26; //     0; // OGL GDK WINDOW X POSITION
int ogl_y_position = 41; // 81; //  85; // OGL GDK WINDOW Y POSITION

#define textbox_width 20
#define textbox_height 20

struct gpiod_chip* chip;			//,*chip1;
struct gpiod_line* PWR_KEY; //  *lineRed,  // Red LED

int btn_click = 0;

GtkWidget *window, *window_home, *window_del;
GtkWidget *myGrid, *btn_prv, *btn_next, *btn_scrup, *btn_scrdwn;
GtkWidget *tbtn1, *tbtn2, *tbtn3, *tbtn4, *tbtn5, *tbtn6, *tbtn7;
GtkWidget *bbtnkey, *clbtn, *databtn_frame;
GtkWidget *frame, *drawing_area, *entry_new_value, *vscale;
GtkWidget *lv_scroll_button, *scrollbox, *scrollbar, *t_btnval;
GtkWidget *vbox, *hbox, *v1box, *v2box, *v3box, *v4box, *v5box, *avbox, *ahbox1, *ahbox2, *ahbox3, *ahbox4, *v6box, *v7box, *v8box, *v9box, *v10box, *v11box, *v12box, *v13box, *v14box, *ahbox5;
GtkWidget* lfbox, * rgbox, *spc_box;
GtkWidget *txt_h[14], *img_gain;
GtkWidget *top_btn[10], *t_label[10];
GtkWidget *btn_dv[25];
GtkWidget *label_dv[25];
GtkWidget *b_btn[10];
GtkWidget *b_label[10];
GtkWidget *s_btn[10];
GtkWidget *s_label[10];
GtkWidget *Clock_lab , *Pause_lab, *Batt_Perc;
GtkWidget *nframe[10], *n_draw, *n_image[15], *n_sdcrdfrm;
GtkWidget *label1, *label2, *label3, *label4, *label5, *label6, *label7, *label8, *label9, *label10, *label11, *label12, *label13, *label14, *label15, *label16;
GtkCssProvider *cssProvider;
GtkCssProvider *css_clr_grd_Provider;
GtkAdjustment *adj;
GdkPixbuf *image;
GdkPixbuf *simage;
GdkPixbuf *n_pximage[15];
GdkPixbuf *draw_image;
GtkWidget *d_image, *d1_image;
GtkWidget *b_bframe, *b_btnbox, *b_errorbox, *err_label, *btn_err, *sb_btnbox;
GtkWidget* space51;

gdouble d_scroll_value;
gboolean focus_on_click;
cairo_surface_t *surface_d;
cairo_t *cr;
GtkWidget *dgs_window, *dgs_btn[25], *dgslabel[25];
GtkWidget *Main_lyout, *V1_lyout, *V2_lyout, *V3_lyout;
GtkWidget *f1_box, *f2_box, *overlay, *f3_box, *n_overlay;

GtkWidget *v_ruler_img, *v_box;
cairo_surface_t *v_ruler_surface;
cairo_t *v_ruler_cr;

GtkWidget *h_ruler_img, *h_box;
cairo_surface_t *h_ruler_surface;
cairo_t *h_ruler_cr;

GtkWidget *shape_profiler_rays_image, *prof_box;
cairo_surface_t *shape_profiler_rays_surface;
cairo_t *shape_profiler_rays_cr;

GdkWindow *gdk_window;
GdkDisplay *gdk_display;
gboolean opengl_update = true;
gboolean Dac_Bscan_flag = true; // Bscan = true, Dac = false;
gboolean DGS_ReadFile = false; // 
//********** RB variables ********

typedef unsigned char ubyte_t;

GtkWidget *frame_s1, *frame_s2, *splite_box_1, *splite_box_2;
GtkWidget *frm_box, *plot_bscan_data, *pixbuf_data_grid, *image_scl;

/* **** Pixbuf data variables **** */
GtkWidget *bscan_data_grid;
GdkPixbuf *src_pixbuf, *dest_pixbuf;
ubyte_t *pixbuf_base_address;
gint rgb_count, rowstride;

/* **** Horizantal Rular variables **** */
GtkWidget *surface_rular_image = NULL;
cairo_surface_t *surface_rular = NULL;
cairo_t *cr_rular = NULL;

GtkWidget *surface_clr_image = NULL;
cairo_surface_t *surface_clr = NULL;
cairo_t *cr_clr = NULL;

static GtkGesture* rotate = NULL;
static GtkGesture * zoom = NULL;
GtkGesture* gesture;

gboolean Ascan_image_snap = false;
unsigned char *Ascan_image_data; //[741][446][3]; // full Ascan area Width * Height * RGB = 741*446*3
int h_scr_height = 28;
int h_ruler_height = 25;
int bsc_height;
int ruler_val = 0;

int bsc_frame_no = 0;

int splite_win_flg = 0;
int rw_flag = -1;
int fwbw_flag = 0;
int data_shift = 1;
int spa_thick_log = 0;
int spb_thick_log = 0;

int dgs_fromfile = 0;
long dgs_pnt[256];
long mult_dgspnt[256];
int prev_val = 0;
int max_value;
int l_btnidx = 0;
int gstep = 0;

int reset_value = 0;

int gas = 0, gae = 0, gac = 0;
int new_day = 15, new_month = 5, new_year = 2005;
int new_hour = 1, new_minute = 00, new_second = 00;

//"DAMP   ", "LOW    ", "POWER  ", "HIGH   ", "MODE   ", "SINGLE ", "PRF     ", "LOW    ", "       ", "       ", // 5 //50-60
char all_btnval[400][35] = {
	"ZERO", "00.00 us", "RANGE", "100.00 mm", "MTL VEL", "5920 M/S", "DELAY", "0.00 mm", "GAIN  1", "20.0 dB", // 0 // 0-10

	"GATEa", "OFF    ", "STARTa", "30.0 mm", "ENDa", "40.0 mm", "LEVELa", "30  %", "REF25.0", "dB ", // 1  //10-20

	"GATEb", "OFF    ", "STARTb", "40.1 mm", "ENDb", "50.0 mm", "LEVELb", "40  %  ", "GAIN", "100 ", // 2  //20-30

	"MEMORY", "A-SCAN ", "MEM NO", "0001", "ACTION", "RECALL  ", "<NOTE", "ENTER>", "GAIN", "25.0 dB", // 3 // 30-40

	"DAC(D) ", "OFF    ", "STARTa", "30.0 mm", "PRESS", "OFF    ", "POINT", "0      ", "GAIN", "25.0 dB", // 40-50

	"DAMP   ", "LOW    ", "MODE   ", "SINGLE ", "PRF    ", "AUTO-L ", "TX_VOLT", "  1     ", "       ", "       ", // 5 //50-60

	"REJECT ", "0 %    ", "FREQ      ", ".5-4MHZ     ", "RECTIFY  ", "FULL-W ", "SMOOTH ", "OFF    ", "       ", "       ", // 6 //60-70

	"GRID   ", "   1   ", "COL LEG ", "OFF    ", "VIDEO  ", "ENVELOP", "SET REF", "OFF    ", "       ", "       ", // 7 //70-80

	"SCR THME ", "THEME 1", "A COLOR", "     1 ", "BRIGHT ", "  10 %  ", "SCREEN ", "RIGHT  ", "       ", "       ", // 8 // 80-90

	"XOFF   ", "0.0 mm ", "ANGLE  ", "45.0 DEG", "THICK  ", "1.00 mm ", "TRIG   ", "FLANK  ", "       ", "       ", // 9 // 90-100

	"CLOCK  ", "OFF    ", "HORN   ", "OFF    ", "BEEP   ", "OFF    ", "UNIT    ", "MM      ", "       ", "       ", // 10  // 100-110

	"A CAL  ", "REG ECHO 1", "STARTa ", "30.0 mm ", "DIST 1 ", " 25.00 ", "DIST 2 ", " 100.00", "       ", "       ", // 11  // 110

	"SIZE_EV", " DAC   ", "MEA_POSI1", "OFF    ", "MEA_POSI2", "OFF    ", "       ", "        ", "       ", "       ", // 12 // 120

	"REC TYPE  ", "BSC THK", "MEM NO", "BTH0001", "ACTION ", "RECORD ", "<< ENTER", ">> CLOSE", "       ", "       ", // 13 // 130

	"ENCODER", "OFF    ", "ENC CAL ", "1000   ", "ENC STRT", "     0 ", "       ", "   -   ", "       ", "       ", // 14 // 140

	"W PROF  ", "OFF    ", "BEAM PROF", "OFF  ", "       ", "       ", "PROB POS", "  10  ", "       ", "       ", // 15 // 150

	"MINUTE ", "  00   ", "HOURS  ", "  00   ", "DAY    ", "  01   ", "MONTH  ", "  01   ", "       ", "       ", // 16 // 160

	// "YEAR   ","2023   ","        ","       ","       ","       ","       ","       ","       ","       ", // 17 // 170

	"Scal No", "1      ", "Probe  ", "M1SN   ", "Freq   ", "10.0MHZ", "DelVel ", "1000 M/S", "       ", "       ", // 17   // 180

	"Defect ", "15.0 mm ", "DGS-CRV ", "0.7  mm ", "REFECHO ", "BW      ", "REFSIZE ", "0.7  mm ", "       ", "       ", // 18 //190

	"EXIT   ", "      >>", "AttRef ", "0.0  dB", "AttObj ", "0.0  dB", "AmpCorr", "0.0  dB", "       ", "       ", // 19   //200

	"WELD SHAPE", " V SHAP    ", "TOP WIDTH  ", "  20    ", "TOP HEIGHT ", "  20", "ROOT WIDTH ", "      5", "       ", "       ", // 20  200

	"OBJ SHAPE ", " FLAT     ", "WIDTH     ", "200 mm", "THICKNESS ", "100 mm   ", "WPROF POS ", "   5 mm  ", "       ", "       ", // 21  //210

	"EXIT     ", "     >>", "PROB POS  ", "  5 mm ", "PROBE ANGLE ", "  45  ", "NO OF LEG ", "    2   ", "       ", "       ", // 22/ /220

	"OBJ SHAPE ", " FLAT     ", "PROB POS  ", "20.0   ", "PROBE ANGLE ", " 45.0 ", "NO OF LEG ", "    3 ", "       ", "       ", // 23  230

	"WIDTH     ", "150.0 mm", "THICKNESS", "100.00 ", "EXT_33", "BW     ", "EXT_34", "0.7  mm", "       ", "       ", // 24    240

	"EXIT _41   ", "     >>", "EXT_42 ", "0.0  dB", "EXT_43 ", "0.0  dB", "EXT_44", "0.0  dB", "       ", "       ", // 25   250

	"PROBE DIA ", " 10 MM     ", "PROBE FRE ", " 2 MHZ    ", "        ", "        ", "        ", "        ", "       ", "       ", // 26   // 260

	"        ", "        ", "        ", "        ", "        ", "        ", "        ", "        ", "       ", "       ", // 27  //270

	"BPRF EXT  ", "     >>", "        ", "        ", "        ", "        ", "        ", "        ", "       ", "       ", // 28  //280

	"DIMENSION", " 1 DIM      ", "START THK 1", "   AAAA", "START THK 2", "   AAAA", " ", " ", "       ", "       ", // 29   // 290

	"NOT USED ", "   -   ", "END THK 1", "   AAAA", "END THK 2", "   AAAA", " ", " ", "       ", "       ", // 30  //300

	"EXIT 61 ", "     >> ", "SIZE 1 ", "0", "SIZE 2 ", "0", " ", " ", "       ", "       ", // 31  // 310

	"COLOR METHOD", "   -   ", "START THK 1", "   00", "START THK 2", "   00", "START THK 3", "   AAA00A", "       ", "       ", // 32   // 320

	"NOT USED ", "   -   ", "END THK 1", "   00", "END THK 2", "   00", "END THK 3", "   00", "       ", "       ", // 33  //330

	"EXIT 71", "     >> ", "SET CLR 1 ", "       ", "SET CLR 2 ", "       ", "SET CLR 3 ", "       ", "       ", "       ", // 34  // 340

}; // 200

char gain_btnval[2][35];
gboolean gain_btnval_flag = false;

int val_ary[200] = {260, 10000, 5920, 000, 250, // 0
					0, 250, 950, 30, 259,		// 1    GATE 1  CHANGE THE VALUE 100 FOR REF GAIN
					0, 400, 500, 40, 0,			// 2    Gate 2   10
					0, 0001, 0, 0, 0,			// 3    MEM
					0, 0, 0, 0, 0,				// 4    //20   DAC
					0, 0, 0, 0, 4,				// 5     DAMP,POWER,MODE,PRF
					0, 1, 0, 0, 0,				// 6    //30   REJECT,FRE,RECTIFY,smooth
					0, 0, 5, 0, 25,				// 7     GRID,COLOR LEG,VIDEO,SET REF
					0, 4, 5, 0, 0,				// 8  	//40   SCR THEME, A COLOR, BRIGHT, SCREEN
					0, 450, 2500, 0, 0,			// 9     XOFF, ANGLE, THICK , TRIG,
					0, 0, 1, 0, 0,				// 10    HORN, BEEP, CLOCK, UNIT
					0, 0, 2500, 10000, 0,		// 11    A CAL, START A, DISAT 1 DIST 2
					0, 0, 0, 0, 0,				// 12    SIZE EV, MEAPOS 1, MEAPOS 2, MEAPOS 3
					0, 0, 0, 0, 0,				// 13    REC TYPE, FILE NAME, ACTION, ENTER,
					0, 0, 1, 1, 0,				// 14    ENCODER, ENC CAL ENC START,
					0, 0, 1000, 0, 0,			// 15    W PROF, BEAM PROF, DIAMETER, PROB POS
					1, 0, 0, 1000, 0,			// 16
					150, 0, 0, 0, 0,			// 17
					0, 0, 0, 0, 0,				// 18
					0, 0, 0, 0, 0,				// 19
					0, 0, 0, 0, 0,				// 20
					0, 0, 0, 0, 0,				// 21
					0, 0, 0, 0, 0,				// 22
					0, 5, 15, 2, 0,				// 23
					150, 100, 100, 60, 0,		// 24
					0, 15, 0, 0, 0,				// 25
					0, 0, 0, 0, 0,				// 26
					0, 0, 0, 0, 0,				// 27
					0, 0, 0, 0, 0,				// 28
					0, 0, 0, 0, 0,				// 29
					0, 0, 0, 0, 0,				// 30
					0, 0, 0, 0, 0,				// 31
					0, 0, 0, 0, 0,				// 32
					0, 0, 0, 0, 0,				// 33
					0, 1, 1, 1, 0,				// 34
					0, 0, 0, 0, 0,				// 35
					0, 0, 0, 0, 0,				// 36
					0, 0, 0, 0, 0,				// 37
					0, 0, 0, 0, 0,				// 38
					0, 0, 0, 0, 0};				// 39

int dac_pnt[80] = {
	50, 315, 154, 375, 250, 415, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 	// Ch1 DAC Data   325
	50, 315, 154, 375, 250, 415, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 	// Ch2 DAC Data
	50, 315, 154, 375, 250, 415, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 	// Ch3 DAC Data
	50, 315, 154, 375, 250, 415, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0  	// Ch4 DAC Data
	// 50,315,154,375,250,415,0,0,0,0,0,0,0,0,0,0,0,0,0,0,   				//Ch5 DAC Data
	// 50,315,154,375,250,415,0,0,0,0,0,0,0,0,0,0,0,0,0,0,   				//Ch6 DAC Data
	// 50,315,154,375,250,415,0,0,0,0,0,0,0,0,0,0,0,0,0,0,   				//Ch7 DAC Data
	// 50,315,154,375,250,415,0,0,0,0,0,0,0,0,0,0,0,0,0,0,   				//Ch8 DAC Data
	// 50,315,154,375,250,415,0,0,0,0,0,0,0,0,0,0,0,0,0,0,   				//Ch9 DAC Data
	// 50,315,154,375,250,415,0,0,0,0,0,0,0,0,0,0,0,0,0,0,   				//Ch10 DAC Data
	// 50,315,154,375,250,415,0,0,0,0,0,0,0,0,0,0,0,0,0,0,   				//Ch11 DAC Data
	// 50,315,154,375,250,415,0,0,0,0,0,0,0,0,0,0,0,0,0,0,   				//Ch12 DAC Data
	// 50,315,154,375,250,415,0,0,0,0,0,0,0,0,0,0,0,0,0,0,   				//Ch13 DAC Data
	// 50,315,154,375,250,415,0,0,0,0,0,0,0,0,0,0,0,0,0,0,   				//Ch14 DAC Data
	// 50,315,154,375,250,415,0,0,0,0,0,0,0,0,0,0,0,0,0,0,   				//Ch15 DAC Data
	// 50,315,154,375,250,415,0,0,0,0,0,0,0,0,0,0,0,0,0,0    				//Ch16 DAC Data
};

int DGS_pnt[80] = {12, 405, 25, 395, 37, 385, 50, 375, 62, 365,
				   75, 355, 87, 345, 100, 335, 112, 325, 125, 315,
				   150, 325, 175, 335, 200, 345, 225, 355, 250, 355,
				   0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				   0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				   0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				   0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				   0, 0, 0, 0, 0, 0, 0, 0, 0, 0}; // Curve Data as per value of Dia.

const int dbtoeh[60] = {200, 198, 195, 193, 191, 189, 187, 185, 182, 180, 178, 176, 174, 172, 170, 168, 166, 164, 163, 161, // 0 dB means 100%   6dB means 50%  12 db means 25 % etc
						160, 157, 155, 154, 152, 150, 148, 147, 145, 143, 142, 140, 138, 137, 135, 134, 132, 131, 129, 128,
						126, 125, 123, 122, 121, 119, 118, 116, 115, 114, 113, 111, 110, 109, 107, 106, 105, 104, 103, 101}; // Holds 0.0 to 6.0dB to Per height Value

const int ehtodb[200] = {0, 0, 1, 1, 2, 2, 3, 3, 4, 4,						// Echo Height to DB Conversion
						 4, 5, 5, 6, 6, 7, 7, 8, 8, 9,						// 10    Echo height 200- (2*echo height (0 to 100) 						   9,10,10,11,11,12,12,13,13,14,   //20
						 9, 10, 10, 11, 11, 12, 12, 13, 13, 14,				// 20
						 14, 15, 15, 16, 16, 17, 17, 18, 18, 19,			// 30    returns required db to bring echo to 100% height
						 19, 20, 20, 21, 22, 22, 23, 23, 24, 24,			// 40
						 25, 26, 26, 27, 27, 28, 29, 29, 30, 30,			// 50
						 31, 32, 32, 33, 33, 34, 35, 35, 36, 37,			// 60
						 37, 38, 39, 39, 40, 41, 42, 42, 43, 44,			// 70
						 44, 45, 46, 47, 47, 48, 49, 50, 50, 51,			// 80
						 52, 53, 54, 54, 55, 56, 57, 58, 58, 59,			// 90
						 60, 61, 62, 63, 64, 65, 66, 67, 67, 68,			// 100
						 69, 70, 71, 72, 73, 74, 75, 76, 77, 79,			// 110
						 80, 80, 82, 83, 84, 85, 86, 88, 89, 90,			// 120
						 91, 92, 94, 95, 96, 98, 99, 100, 102, 103,			// 120
						 105, 106, 108, 109, 111, 112, 114, 115, 117, 119,	// 140
						 120, 122, 124, 126, 128, 130, 132, 134, 136, 137,	// 150
						 140, 142, 144, 147, 149, 151, 154, 157, 159, 162,	// 160
						 165, 168, 171, 174, 177, 181, 184, 188, 192, 196,	// 170
						 200, 205, 210, 214, 219, 225, 231, 237, 244, 252,	// 180
						 260, 269, 280, 291, 305, 320, 340, 364, 400, 460}; // 190

const int DGS_CdB[500] = {0x01D7, 0x01C5, 0x01C0, 0x01BA, 0x01B3, 0x01A7, 0x0197, 0x018A, 0x0182, 0x0180, 0x0183, 0x01C7, 0x0207, 0x0236, 0x0258, 0x0279, 0x0291, 0x02AC, 0x02BC, 0x02D1, 0x0349, 0x0390, 0x03C2, 0x03E9, 0x0408, 0x0423, 0x043A, 0x044F, 0x0461, 0x04D9, 0x0520, 0x0552,  // 0.05 N curve   32 Data per Curve
						  0x01B8, 0x01A9, 0x01A3, 0x019C, 0x0191, 0x0182, 0x0178, 0x016E, 0x0168, 0x0165, 0x0168, 0x01AC, 0x01E8, 0x0214, 0x0239, 0x0258, 0x0273, 0x0289, 0x029D, 0x02B1, 0x032A, 0x0370, 0x03A2, 0x03C9, 0x03E9, 0x0403, 0x041B, 0x042F, 0x0441, 0x04BA, 0x0500, 0x0532,  // 0.06 N curve   32
						  0x0190, 0x0181, 0x017C, 0x0170, 0x0168, 0x015E, 0x014F, 0x0146, 0x013D, 0x0139, 0x013D, 0x017C, 0x01B7, 0x01E3, 0x020A, 0x0226, 0x0242, 0x0258, 0x026C, 0x027F, 0x02F8, 0x033E, 0x0370, 0x0397, 0x03B7, 0x03D1, 0x03E9, 0x03FD, 0x040F, 0x0488, 0x04CE, 0x0500,  // 0.08 N curve   64
						  0x0168, 0x015E, 0x0157, 0x014F, 0x0146, 0x013C, 0x0130, 0x0124, 0x011E, 0x011B, 0x011E, 0x0152, 0x0190, 0x01BE, 0x01E1, 0x0202, 0x021C, 0x0232, 0x0247, 0x0259, 0x02D1, 0x0317, 0x0349, 0x0370, 0x0390, 0x03AB, 0x03C2, 0x03D6, 0x03E9, 0x0461, 0x04A7, 0x04D9,  // 0.1 N curve    96
						  0x014A, 0x0146, 0x0140, 0x013A, 0x0130, 0x011F, 0x0114, 0x010E, 0x0107, 0x0103, 0x0108, 0x0139, 0x0172, 0x01A0, 0x01C1, 0x01E5, 0x01FB, 0x0212, 0x0226, 0x0239, 0x02B1, 0x02F8, 0x032A, 0x0351, 0x0370, 0x038B, 0x03A2, 0x03B7, 0x03C9, 0x0441, 0x0488, 0x04BA,  // 0.12 N curve   128
						  0x012C, 0x012B, 0x0127, 0x011B, 0x0110, 0x0101, 0x00F2, 0x00E8, 0x00E0, 0x00DD, 0x00E0, 0x0112, 0x014B, 0x0177, 0x019C, 0x01BA, 0x01D4, 0x01ED, 0x01FE, 0x0212, 0x028B, 0x02D1, 0x0303, 0x032A, 0x0349, 0x0364, 0x037B, 0x0390, 0x03A2, 0x041B, 0x0461, 0x0493,  // 0.15N curve    160
						  0x010E, 0x010B, 0x0103, 0x00F6, 0x00E7, 0x00D7, 0x00C8, 0x00BE, 0x00B6, 0x00B3, 0x00B6, 0x00E5, 0x0119, 0x0147, 0x016E, 0x018B, 0x01A3, 0x01BB, 0x01CD, 0x01E0, 0x0259, 0x029F, 0x02D1, 0x02F8, 0x0317, 0x0332, 0x0349, 0x035E, 0x0370, 0x03E9, 0x042F, 0x0461,  // 0.2 N curve    192
						  0x00F0, 0x00EE, 0x00EA, 0x00DF, 0x00CE, 0x00BD, 0x00AD, 0x00A3, 0x009D, 0x0099, 0x009D, 0x00C8, 0x00FF, 0x0129, 0x014C, 0x0168, 0x0181, 0x019A, 0x01AC, 0x01C1, 0x0239, 0x027F, 0x02B1, 0x02D8, 0x02F8, 0x0313, 0x032A, 0x033E, 0x0351, 0x03C9, 0x040F, 0x0441,  // 0.24 N curve   224
						  0x00D7, 0x00D2, 0x00CB, 0x00BD, 0x00AE, 0x009F, 0x008E, 0x0085, 0x007D, 0x0077, 0x007C, 0x00A1, 0x00D8, 0x0101, 0x0124, 0x0141, 0x015A, 0x0172, 0x0184, 0x019A, 0x0212, 0x0259, 0x028B, 0x02B1, 0x02D1, 0x02EC, 0x0303, 0x0317, 0x032A, 0x03A2, 0x03E9, 0x041B,  // 0.3 N curve    256
						  0x009F, 0x009F, 0x009C, 0x0099, 0x0093, 0x0087, 0x0079, 0x006E, 0x0064, 0x0060, 0x0063, 0x0078, 0x00A9, 0x00D2, 0x00F4, 0x0111, 0x012A, 0x0140, 0x0153, 0x0168, 0x01E0, 0x0227, 0x0259, 0x027F, 0x029F, 0x02BA, 0x02D1, 0x02E6, 0x02F8, 0x0370, 0x03B7, 0x03E9,  // 0.4 N curve  		288
						  0x0080, 0x0080, 0x007F, 0x007C, 0x0077, 0x006D, 0x0065, 0x005E, 0x0058, 0x0055, 0x0057, 0x0066, 0x008C, 0x00B4, 0x00D2, 0x00EF, 0x0109, 0x011F, 0x0133, 0x0148, 0x01C1, 0x0207, 0x0239, 0x0260, 0x027F, 0x029A, 0x02B1, 0x02C6, 0x02D8, 0x0351, 0x0397, 0x03C9,  // 0.48 N curve    320
						  0x0059, 0x0059, 0x0058, 0x0056, 0x0054, 0x0052, 0x0051, 0x0050, 0x004F, 0x004E, 0x004C, 0x0052, 0x006D, 0x008E, 0x00AD, 0x00CB, 0x00E4, 0x00FB, 0x0111, 0x0121, 0x019A, 0x01E0, 0x0212, 0x0239, 0x0259, 0x0273, 0x028B, 0x029F, 0x02B1, 0x032A, 0x0370, 0x03A2,  // 0.6 N curve    352
						  0x001F, 0x001F, 0x001F, 0x0020, 0x0022, 0x0023, 0x0024, 0x0025, 0x0026, 0x0027, 0x0027, 0x002F, 0x004B, 0x0064, 0x007D, 0x0094, 0x00B2, 0x00C5, 0x00DB, 0x00EF, 0x0168, 0x01AE, 0x01E0, 0x0207, 0x0227, 0x0241, 0x0259, 0x026D, 0x027F, 0x02F8, 0x033E, 0x0370,  // 0.8 N curve    384
						  0x0008, 0x0008, 0x000A, 0x000E, 0x0011, 0x0012, 0x0014, 0x0014, 0x0015, 0x0016, 0x0016, 0x0024, 0x003C, 0x0052, 0x0065, 0x007B, 0x008D, 0x00A4, 0x00B7, 0x00C9, 0x0141, 0x0187, 0x01B9, 0x01E0, 0x0200, 0x021B, 0x0232, 0x0246, 0x0259, 0x02D1, 0x0317, 0x0349,  //  SAM_DIA:  ; 1 N curve  416
						  0x0008, 0x0008, 0x000A, 0x000E, 0x0011, 0x0012, 0x0014, 0x0014, 0x0015, 0x0016, 0x0016, 0x0024, 0x003C, 0x0052, 0x0065, 0x0076, 0x0082, 0x008C, 0x0096, 0x009F, 0x00DE, 0x0100, 0x0119, 0x012E, 0x013D, 0x014A, 0x0155, 0x015F, 0x0168, 0x01A7, 0x01C9, 0x01E2}; // BW_CdB:    ; BW  curve  448

const int Dia_ratio[] = {0x0D, 0x0f, 0x14, 0x1A, 0x1f, 0x26, 0x33, 0x3d, 0x4D, 0x66, 0x7b, 0x9a, 0xcd, 0xff}; //  Dia Ratio..
																											  // Dia ratio    0.05 0.06 0.08 0.10 0.12 0.15 0.20 0.24 0.30 0.40 0.48 0.60 0.80 1.00

//  Distance in terms of Nearfield*10 start from 0.1 to 300
const int DGS_RP[] = {0x0001, 0x0002, 0x0003, 0x0004, 0x0005, 0x0006, 0x0007, 0x0008,  // 0  to 7
					  0x0009, 0x000a, 0x000C, 0x0014, 0x001E, 0x0028, 0x0032, 0x003C,  //  8  to f
					  0x0046, 0x0050, 0x005A, 0x0064, 0x00C8, 0x012C, 0x0190, 0x01F4,  //  10 to 17
					  0x0258, 0x02BC, 0x0320, 0x0384, 0x03E8, 0x07D0, 0x0BB8, 0x0FA0}; //  18 to 1f
																					   //  0x1388,0x1770,0x1B58,0x1F40,0x2328,0x2710,0x4E20,0x7530,0x9c40   //  20 to 27

float Red[20] = {1.0, 0.0, 1.0, 1.0, 0.0, 0.41, 1.0, 1.0, 0.1, 1.0, 1.0, 0.0, 1.0, 1.0, 0.0, 0.41, 1.0, 0.98, 0.0, 1.0};
float Green[20] = {0.0, 1.0, 0.7, 1.0, 1.0, 0.0, 0.0, 0.0, 0.1, 0.0, 0.0, 1.0, 0.7, 1.0, 1.0, 0.0, 0.0, 0.2, 0.0, 0.0};
float Blue[20] = {1.0, 1.0, 0.78, 0.0, 0.0, 1.0, 0.0, 1.0, 0.1, 0.0, 1.0, 1.0, 0.78, 0.0, 0.0, 1.0, 0.0, 0.47, 0.0, 0.0};

gdouble Grid_r[20] = {1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 0.2, 0.5, 0.5, 0.0, 1.0, 1.0, 0.0, 0.41, 1.0, 0.98, 0.0, 1.0};
gdouble Grid_g[20] = {1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 0.2, 0.5, 0.5, 0.0, 1.0, 1.0, 0.0, 0.41, 1.0, 0.98, 0.0, 1.0};
gdouble Grid_b[20] = {1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 0.2, 0.5, 0.5, 0.0, 1.0, 1.0, 0.0, 0.41, 1.0, 0.98, 0.0, 1.0};

float key_array[10];

bool Spi_open = true;
bool gain_btnflag = false;

// val_ary[171] = 150;
char dtm_values[5][10];
char char_range[31][15] = {"ON", "OFF", "DAC", "EXPAND", "A-SCAN", "EMPTY", "SAVE", "RECALL", "DELETE", "COPY ALL", "ENTER>", "UNENTER>", "WHITE", "GREY", "ENVELOP", "STREAM", "START", "STOP", "COLR 1", "COLR 2", "UP", "DOWN", "OP", "IP", "ST", "NON-ST", " "};
char Note_var[6][15] = {"SAVED", "Not Saved", "Exist", "Not exist", "Deleted", "Not Deleted"};
char imagename[10][15] = {"Images/Images/n1.png", "Images/Images/n2.png", "Images/Images/n3.png", "Images/Images/n4.png", " ", " ", "Images/Images/n8.png", "Images/Images/test2.png", "9.png"}; // Images/Images/btnimg2_1.png  Images/Images/year.png
gboolean showhide_flag = false;
gboolean key_flag = true;
gboolean btn_flag = true;
gboolean gdac_flag = false;
// gboolean gatea_flag = false;
// gboolean gateb_flag = false;
gboolean step_coarseflag = true;
gboolean line_flag = false;
gboolean timer_flag = true;
gboolean capslock_flag = false;
gboolean shift_flag = false;

int Gatecrs_strt1 = 0, Gatecrs_end1 = 0, Gatecrs_strt2 = 0, Gatecrs_end2 = 0;

double Prb_Near_field = 100, Prb_div_Ht = 50;
double Beam_dv_angle_v, Prb_Near_field_v;

char rep_buf1[40], rep_buf2[40], rep_buf3[40], rep_buf4[40];
char mea_rd[10][15];
char pendrv_path[64];
char sdcard_path[64];

time_t t;	  // System time and date
struct tm tm; // System time and date

char Tmstr[30];
char Battpr[15];
// t = time(NULL);
// tm = *localtime(&t);
int Clk_ref = 0; // Holds Clock Refresh Time on Screen
bool Error_msg = false;

char img_name[128];
char btndv_css[11][15] = {"btnd1-entry", "btnv1-entry", "btnd2-entry", "btnv2-entry", "btnd3-entry", "btnv3-entry", "btnd4-entry", "btnv4-entry", "btnd5-entry", "btnv5-entry", "btnd5_image"};
char btndv_align[10][25] = {"GTK_ALIGN_START", "GTK_ALIGN_CENTER", "GTK_ALIGN_START", "GTK_ALIGN_CENTER", "GTK_ALIGN_START", "GTK_ALIGN_CENTER", "GTK_ALIGN_START", "GTK_ALIGN_CENTER", "GTK_ALIGN_START", "GTK_ALIGN_CENTER"};
char b_ary[20][15] = {"RESET  ", " GATE 1", "GATE 2 ", "MEM    ", "CLOSE  ", " TX    ", "RECEIVER", "GRID   ", "COLOR SCH", " XOFF    ", " HORN    ", "AUTO CAL", "SIZE EVAL", "REC TYPE ", "ENCODER", "WELD PROF", "DAC    ", "DAC    ", "DAC    ", "DAC    "};
//char b_ary[20][15] = { " BASIC ", " GATE 1", "GATE 2 ", "MEM    ", "DAC    ", " TX    ", "RECEIVER", "GRID   ", "COLOR SCH", " XOFF    ", " HORN    ", "AUTO CAL", "SIZE EVAL", "REC TYPE ", "ENCODER", "WELD PROF", "DAC    ", "DAC    ", "DAC    ", "DAC    " };
// char b_ary[10][15] = { "Hide   ","ScrHide","BBtn 3 ","BBtn 4 ","CLOSE   " };
char bbtn_css[10][15] = {"bbtn1-entry", "bbtn2-entry", "bbtn3-entry", "bbtn4-entry", "bbtn5-entry", "bbtn6-entry", "bbtn7-entry"};
char btn_scr[5][10] = {"0", "1"};
char scnd_ary[10][15] = {" ---    ", "   ---  ", "   --- ", "   ---  ", "  --- "};
// char scnd_ary[10][15] = { "CK SPI  ","SND FILT","RD 1K  3","RD KEY  ","READ  " };
char sbtn_css[10][15] = {"sbtn1-entry", "sbtn2-entry", "sbtn3-entry", "sbtn4-entry", "sbtn5-entry"};
char top_ary[10][15] = {" --.-- ", " --.--  ", "  --     ", "  ---  ", "  --    ", "  ---    ", "  ---    "};
// char top_ary[10][15] = { "Img Clk","TButton2","Timer OFF","Init   ","READ BK ","TButton 6","TButton 7" };
char tbtn_css[10][15] = {"tbtn1-entry", "tbtn2-entry", "tbtn3-entry", "tbtn4-entry", "tbtn5-entry", "tbtn6-entry", "tbtn7-entry"};
char menu_lbl[20][15] = {"MENU 1 ", "MENU 2 ", "MENU 3 ", "MENU 4 ", "MENU 5 ", "MENU 6 ", "MENU 7 ", "MENU 8 ", "MENU 9 ", "MENU 10", "MENU 11", "MENU 12", "MENU 13", "MENU 14", "MENU 15", "MENU 16"};
int MM = 0, INCH = 1;
int Unit_v;
int stp_coa = 1;
int Gn_stp = 10; // Gain Step
int gval_chng = 1;
char c_mm[3] = {"mm"};
char c_inch[5] = {"inch"};
char c_db[3] = {"dB"};
char dot[2] = {"."};
int M_RECALL = 0, M_SAVE = 1, M_DETAIL = 2, M_DELETE = 3, M_CPY_ALL = 4;
int unit_key = 0;
int btnstep_val = 0;
int menu_v = 0, pos = 0, pos1 = 0, var_pos = 0, scr_val = 0, num_4, num_5, num_6, num_7, btn_idx = 0, written = 0, scroll_val = 0, page_val = 0;
int zero_val = 0, Range_v = 10000, Mtlvel_val = 5920, Delay_rv = 0, Gain_v = 0, starta_val = 300, enda_val = 700, levela_val = 30, ref25_val = 0, Gate2_v = 0, startb_val = 400, endb_val = 800, levelb_val = 40,
	gain_val = 0, memory_val = 0, memno_val = 0, action_val = 0, note_val = 0, gain_1_val = 0, Theme_color_val = 0, Asc_Clr_val = 4, video_val = 0, setref_val = 0, gain_2_val = 0, horn_val = 0, beep_val = 0, clock_val = 0, Autocal_val = 0, Dist1_val = 2500, Dist2_val = 10000, railtp_val = 0, Color_Leg_v = 0, Grid_v = 0,
	gain_1_2_val = 0, Encoder_val = 0, calfac_val = 0, asccol_val = 0, space_val = 0, gain4_val = 0, strtkm_val = 0, strtmt_val = 0, kmdir_val = 0, defect_val = 0, qr_val = 0, diamet_val = 0, Angle_v = 0, point_val = 0, Dac_tlg_val = 0,
	Damp_val = 0, Mode_val = 0, Reject_val = 0, X_offset_v = 0, Thick_v = 0, Dia_val = 0, trig_val = 0, minute_val = 0, hour_val = 0, day_val = 0, month_val = 0, year_val = 0, Mem_note = 0, Enc_strtP = 0, Dia_v = 0;

int forfile_dgs = 0;
int MPrf_v;
int gate2_Sv, Gstart2_Sv, Gend2_Sv, level2_Sv, Tcg_edit = 0;
int Range_dac; // 10000;
int dac_cv[300];
int dac_trig[300]; // Holds DAC Trigger curve value
int Menu_pre = 0, Sub_st_menu = 0;
int Evaluate_val, Dgs_sub_mnu = 0, Dgs_onoff_v = 0, Near_FD = 0;
int old_enco, Refg_v, Dgs_gain;
long Echo1_posi, Echo2_posi;

//int dgsdb_crv[15] = {36,72,98,128,150,172,188,205,225,235,250,260,270};
//int dgsdb_crv[15] = { 30,72,108,144,180,216,252,288,324,360,396,432,468 };
int dgsdb_crv[15] = { 30,60,90,120,150,180,210,240,270,300,330,360,390 };

int Scal_v = 0, D_efect_vC = 0, Dac_v = 0, Amp_corr_v = 0, Att_ref_v = 0, Ref_size_v = 0;
int i, k, j = 0, key_scr, DAMP_POSI = 0, Dgs_ref_v = 0, D_efect_v = 0;
int Dly_vel_vC = 50, Dly_vel_v = 0, Tl_corr_v = 0, point_v = 0, Dac_tlg_v = 0, Ref_echo_v = 0;
int Att_obg_v = 0, Dgs_crvs_v = 0, Encoder_cal = 0, Bsc_Dsp_v = 0, Cur_pos = 0, Reject_v = 0, Measure_v1 = 0, Measure_v2 = 0, Measure_v3 = 0, Freq_v = 1, Rectify_v = 0;
int Weld_prf_val = 0, Beam_prf_val = 0, Thick_color_val = 0;
int Brightness_v = 0, Scr_Rot_V = 0, Power_v = 0, Prf_v = 0, Smooth_v = 0, Prf_m = 0, Prf_cal = 0, txvolt_v = 0, Prf_condval = 0;
int Record_Type_val = 0, Rec_no = 1, Mem_actBS = 0;
int Bsc_thk_no = 1, Bsc_clr_no = 1, Thkfl_no = 1, Tofd_no = 1, thk_toggle_flag = 1;

int Freez_v, Lock_v, Zoom_v;
int splite_frame_height;

int Video_State;

int Tcg_pnt_v;
int Clr_leg_sta, Clr_leg_width;
int TCG_offGn; // Holds calculated DAC value of DAC 2 used in TCG calculation

// int G1_snd,G1_dp,G1_Amp,G2_snd,G2_sd,G2_dp,G2_Amp;
long int G1_sp1, G1_dp1, G1_sd1, G2_sp2, G2_dp2, G2_sd2; //
int G1_Amp1, G2_Amp2;
long spc, dpc, sdc; // Used for common calculation
int Dac_ph, Crv_db_dif, Ers_v, Echo_peak_pos;
int Dgs_ref_gn, Dgs_ref_Nfg, Dgs_Nfg, Dgs_gn;

int Enc_1p = 0, Enc_2p = 0;
int Enc_pos1, Enc_pos2;
int Enc_prev = 0, Enc_curr = 1;

int All_Ascan_data[1024];
float All_Ascan_peak[512];
gboolean Ascan_peak_flag = false;

int Asc_Max[1024];
POINT pntArray_DACM[256];  // Holds data of DAC Curve main curve
POINT pntArray_DAC1P[256]; // Holds data of DAC Curve Main Curve+dac db
POINT pntArray_DAC2P[256]; // Holds data of DAC Curve Main Curve+ 2*dac db
POINT pntArray_DAC1N[256]; // Holds data of DAC Curve Main Curve - dac db
POINT pntArray_DAC2N[256]; // Holds data of DAC Curve Main Curve - 2*dac db

int CDgs_dat[35] = {12, 405, 25, 395, 37, 385, 50, 375, 62, 365, 75, 355, 87, 345, 100, 335, 112, 325, 125, 315, 150, 325, 175, 335, 200, 345, 225, 355, 250, 355, 0, 0, 0, 0, 0}; // Curve Data as per value of Dia.
int CDgs_Adat[35];																																								   //  Data after atteneuation
int IL_lt, Af_lt, Rt_lt;
int usb_val = 0, sdcrd_val = 0;

gchar gasDisp[8], gaeDisp[8];
int Gate1_v = 0;
int Gstart1_v = 300, Gend1_v = 700, level1_v = 30;
int Gstart2_v = 400, Gend2_v = 900, level2_v = 30;
int Ech_amp;
int Aws_onoff_v = 0, Aws_ref_v = 0, Dac_crv_dB;
int IL_v, Af_v, Rt_v;
int Screen_w;
int dac_npnt; // Holds no point to draw in Polyline
char Gain_glbl[30];
char snum[300];
char Pera_str[20];
int s_x11 = 0, s_x22 = 0, s_y11 = 0, s_y22 = 0, Prb_freq_v = 0, Prb_freq_vC = 0;
//int gain_ref; 
int imgline_count = 540;
int m_val;
char filename[] = "F:/Text/Data/";
char filen[300];
char ext[] = ".txt";
char *path_h;
char* path_report;
char* path_cp;
unsigned char *data;
int sh_val = 0, note_dsp = 0, Mem_act = 0;
int Asc_Dsp = 0;
bool Bsc_Dsp = false;
guint signal_id = 0, st_scrn_time_id = 0;

// int Filt_05to40_old[98]={ 0x8400, 0x4525, 0x447A, 0x8700, 0x453B, 0x444A, 0x8700, 0x454C, 0x44DA, 0x8700, 0x4556, 0x4494, 0x8700, 0x45EB, 0x4478, 0x8700, 0x45F0, 0x44BE, 0x8700, 0x45FD,
//                           0x4415, 0x8700, 0x450F, 0x4483, 0x8700, 0x45FF, 0x4456, 0x8700, 0x45F8, 0x44D5, 0x8700, 0x45F1, 0x44D1, 0x8700, 0x45EC, 0x447E, 0x8700, 0x4501, 0x4455, 0x8700,
//					      0x4503, 0x44E4, 0x8700, 0x4504, 0x44F7, 0x8700, 0x4503, 0x4488, 0x8700, 0x45FB, 0x4471, 0x8700, 0x45FB, 0x443D, 0x8700, 0x45FC, 0x4443, 0x8700, 0x45FE, 0x4477,
//    					      0x8700, 0x4500, 0x4427, 0x8700, 0x45FF, 0x4448, 0x8700, 0x45FE, 0x4401, 0x8700, 0x45FC, 0x4485, 0x8700, 0x45FF, 0x44B1, 0x8700, 0x4500, 0x440D, 0x8700, 0x4500,
//					      0x445C, 0x8700, 0x4500, 0x4476, 0x8700, 0x45FF, 0x4456, 0x8700, 0x45FF, 0x443B, 0x8700, 0x45FF, 0x4448, 0x8700, 0x45FF, 0x4463, 0x8700, 0x8818
//                          };

int Filt_0p5to4p0[98] = {
	0x8400, 0x4523, 0x44FE, 0x8700, 0x453C, 0x449F, 0x8700, 0x4550, 0x44D8, 0x8700, 0x455C, 0x4436, 0x8700, 0x45E9, 0x44FC, 0x8700, 0x45ED, 0x4436, 0x8700, 0x45F8,
	0x44BB, 0x8700, 0x450B, 0x44E1, 0x8700, 0x4503, 0x443A, 0x8700, 0x45FC, 0x44FB, 0x8700, 0x45F4, 0x44D7, 0x8700, 0x45ED, 0x446A, 0x8700, 0x45FE, 0x44FA, 0x8700,
	0x4502, 0x44C4, 0x8700, 0x4505, 0x44AF, 0x8700, 0x4506, 0x4425, 0x8700, 0x45FB, 0x4499, 0x8700, 0x45FA, 0x442A, 0x8700, 0x45FA, 0x4410, 0x8700, 0x45FB, 0x44C0,
	0x8700, 0x4500, 0x44F9, 0x8700, 0x4500, 0x44AA, 0x8700, 0x45FF, 0x447D, 0x8700, 0x45FD, 0x44A5, 0x8700, 0x45FE, 0x44ED, 0x8700, 0x45FF, 0x4448, 0x8700, 0x45FF,
	0x44E6, 0x8700, 0x4500, 0x449D, 0x8700, 0x45FF, 0x44CC, 0x8700, 0x45FF, 0x447D, 0x8700, 0x45FF, 0x442E, 0x8700, 0x45FE, 0x44ED, 0x8700, 0x8818 // 1B 88 1B
};

int Filt_5p0to15p0[98] = {
	0x8400, 0x45F7, 0x44F0, 0x8700, 0x45C1, 0x4468, 0x8700, 0x45E2, 0x4475, 0x8700, 0x455D, 0x4429, 0x8700, 0x450E, 0x44BF, 0x8700, 0x4507, 0x441E, 0x8700, 0x45EF,
	0x444F, 0x8700, 0x45FC, 0x44E7, 0x8700, 0x45FD, 0x4401, 0x8700, 0x4509, 0x44A7, 0x8700, 0x4506, 0x4459, 0x8700, 0x4500, 0x44B8, 0x8700, 0x45FA, 0x44FB, 0x8700,
	0x45FA, 0x44E8, 0x8700, 0x4500, 0x44D2, 0x8700, 0x45FC, 0x4464, 0x8700, 0x4502, 0x44F2, 0x8700, 0x45FF, 0x4414, 0x8700, 0x45FF, 0x449E, 0x8700, 0x4501, 0x4406,
	0x8700, 0x4500, 0x4490, 0x8700, 0x4501, 0x4434, 0x8700, 0x45FF, 0x44D9, 0x8700, 0x4501, 0x44F9, 0x8700, 0x45FF, 0x4442, 0x8700, 0x45FF, 0x44E6, 0x8700, 0x45FF,
	0x4491, 0x8700, 0x45FE, 0x44CC, 0x8700, 0x4500, 0x440D, 0x8700, 0x45FF, 0x44F9, 0x8700, 0x4500, 0x4448, 0x8700, 0x45FF, 0x44CC, 0x8700, 0x8817 // 1B 88 17  1B
};

int Filt_2p0to21p5[98] = {
	0x8400, 0x45F8, 0x444F, 0x8700, 0x4506, 0x44B2, 0x8700, 0x45E4, 0x44B3, 0x8700, 0x454C, 0x4464, 0x8700, 0x4500, 0x44FC, 0x8700, 0x45F9, 0x4417, 0x8700, 0x45FE,
	0x44CF, 0x8700, 0x45FC, 0x448F, 0x8700, 0x45FF, 0x4470, 0x8700, 0x45FA, 0x44AD, 0x8700, 0x4500, 0x44BE, 0x8700, 0x45F8, 0x44F9, 0x8700, 0x45FD, 0x447A, 0x8700,
	0x45FE, 0x44C2, 0x8700, 0x45FE, 0x441E, 0x8700, 0x45FC, 0x44EA, 0x8700, 0x45FE, 0x444F, 0x8700, 0x4500, 0x4403, 0x8700, 0x45FD, 0x44A2, 0x8700, 0x45FF, 0x44C5,
	0x8700, 0x45FF, 0x44BE, 0x8700, 0x45FF, 0x4491, 0x8700, 0x45FF, 0x441E, 0x8700, 0x45FF, 0x44CF, 0x8700, 0x4500, 0x441A, 0x8700, 0x45FF, 0x4491, 0x8700, 0x4500,
	0x440D, 0x8700, 0x45FF, 0x447A, 0x8700, 0x45FF, 0x44FD, 0x8700, 0x45FF, 0x4448, 0x8700, 0x4500, 0x440D, 0x8700, 0x45FF, 0x44C2, 0x8700, 0x8816 // 1B 88 16 1B
};

int Filt_0p2to10p0[98] = {
	0x8400, 0x45E8, 0x440A, 0x8700, 0x45F7, 0x4438, 0x8700, 0x452F, 0x4448, 0x8700, 0x4564, 0x448F, 0x8700, 0x45F8, 0x4493, 0x8700, 0x4505, 0x44BC, 0x8700, 0x450B,
	0x447F, 0x8700, 0x45FB, 0x443D, 0x8700, 0x45FF, 0x44F3, 0x8700, 0x4505, 0x442C, 0x8700, 0x4500, 0x44D2, 0x8700, 0x45F7, 0x4494, 0x8700, 0x4501, 0x44FF, 0x8700,
	0x4501, 0x449D, 0x8700, 0x45FC, 0x44C0, 0x8700, 0x45FA, 0x44BA, 0x8700, 0x4501, 0x4427, 0x8700, 0x45FF, 0x441B, 0x8700, 0x45FC, 0x44F4, 0x8700, 0x45FE, 0x447D,
	0x8700, 0x45FF, 0x44F9, 0x8700, 0x45FE, 0x44A5, 0x8700, 0x45FE, 0x44A5, 0x8700, 0x4500, 0x445C, 0x8700, 0x45FF, 0x4497, 0x8700, 0x45FF, 0x4442, 0x8700, 0x45FF,
	0x44D2, 0x8700, 0x4500, 0x447D, 0x8700, 0x45FF, 0x44CC, 0x8700, 0x45FF, 0x44D9, 0x8700, 0x4500, 0x441A, 0x8700, 0x4500, 0x441A, 0x8700, 0x8817 // 1B 88 17 1B
};

int Filt_0p2to1p2[98] = {
	0x8400, 0x4539, 0x448C, 0x8700, 0x453D, 0x4456, 0x8700, 0x4540, 0x4400, 0x8700, 0x4541, 0x4455, 0x8700, 0x4522, 0x4434, 0x8700, 0x4528, 0x44C1, 0x8700, 0x452F,
	0x4400, 0x8700, 0x4534, 0x44A2, 0x8700, 0x4509, 0x441D, 0x8700, 0x450E, 0x44BF, 0x8700, 0x4514, 0x44FE, 0x8700, 0x451B, 0x4471, 0x8700, 0x45FA, 0x442A, 0x8700,
	0x45FC, 0x44B9, 0x8700, 0x4500, 0x441A, 0x8700, 0x4504, 0x4433, 0x8700, 0x45F7, 0x4466, 0x8700, 0x45F7, 0x4432, 0x8700, 0x45F7, 0x4480, 0x8700, 0x45F8, 0x4486,
	0x8700, 0x45FA, 0x44FB, 0x8700, 0x45F9, 0x44F5, 0x8700, 0x45F8, 0x44D5, 0x8700, 0x45F8, 0x4403, 0x8700, 0x45FE, 0x44AB, 0x8700, 0x45FD, 0x44F4, 0x8700, 0x45FD,
	0x4422, 0x8700, 0x45FC, 0x441C, 0x8700, 0x4500, 0x441A, 0x8700, 0x45FF, 0x44E6, 0x8700, 0x45FF, 0x4497, 0x8700, 0x45FF, 0x4448, 0x8700, 0x8819 // 1B 88 19 1B
};

int Filt_1p5to8p5[98] = {
	0x8400, 0x45E8, 0x4417, 0x8700, 0x4502, 0x446F, 0x8700, 0x452E, 0x4407, 0x8700, 0x454F, 0x449E, 0x8700, 0x4501, 0x4489, 0x8700, 0x4503, 0x4475, 0x8700, 0x45F8,
	0x4438, 0x8700, 0x45E8, 0x44AE, 0x8700, 0x45FD, 0x4484, 0x8700, 0x45F6, 0x44E3, 0x8700, 0x45F3, 0x4482, 0x8700, 0x45F8, 0x4480, 0x8700, 0x45F9, 0x44C7, 0x8700,
	0x45FA, 0x442A, 0x8700, 0x45FD, 0x44D3, 0x8700, 0x4500, 0x445C, 0x8700, 0x45FE, 0x4422, 0x8700, 0x45FF, 0x44C5, 0x8700, 0x45FF, 0x448A, 0x8700, 0x45FC, 0x44B9,
	0x8700, 0x4500, 0x442E, 0x8700, 0x45FF, 0x4463, 0x8700, 0x45FD, 0x44D3, 0x8700, 0x45FD, 0x4415, 0x8700, 0x45FF, 0x44A4, 0x8700, 0x45FF, 0x4421, 0x8700, 0x45FF,
	0x442E, 0x8700, 0x45FF, 0x44D9, 0x8700, 0x45FF, 0x44D9, 0x8700, 0x45FF, 0x44F3, 0x8700, 0x4500, 0x4427, 0x8700, 0x4500, 0x441A, 0x8700, 0x8817 // 1B 88 17 1B
};

int Filt_8p0to24p0[98] = {
	0x8400, 0x45EA, 0x44E8, 0x8700, 0x4507, 0x4452, 0x8700, 0x4595, 0x4432, 0x8700, 0x455B, 0x4423, 0x8700, 0x45F2, 0x444E, 0x8700, 0x450E, 0x44A5, 0x8700, 0x4500,
	0x4434, 0x8700, 0x451E, 0x44ED, 0x8700, 0x4500, 0x44A4, 0x8700, 0x4505, 0x44C3, 0x8700, 0x45F5, 0x441F, 0x8700, 0x45FE, 0x44E6, 0x8700, 0x45FB, 0x440F, 0x8700,
	0x4500, 0x440D, 0x8700, 0x45FE, 0x445D, 0x8700, 0x4507, 0x44BF, 0x8700, 0x4501, 0x4400, 0x8700, 0x4502, 0x44BD, 0x8700, 0x45FF, 0x4476, 0x8700, 0x45FF, 0x44AB,
	0x8700, 0x45FF, 0x4463, 0x8700, 0x45FF, 0x440E, 0x8700, 0x45FE, 0x44CC, 0x8700, 0x4500, 0x44B1, 0x8700, 0x4500, 0x441A, 0x8700, 0x4500, 0x4469, 0x8700, 0x4500,
	0x44AA, 0x8700, 0x4500, 0x4448, 0x8700, 0x4500, 0x4421, 0x8700, 0x45FF, 0x44D9, 0x8700, 0x45FF, 0x44D2, 0x8700, 0x45FF, 0x44AB, 0x8700, 0x8817 // 1B 88 17 1B
};

const int numpoints = 256;
int c_y[256] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 60, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 70,
				71, 72, 73, 74, 75, 76, 77, 77, 78, 79, 79, 80, 80, 80, 80, 79, 79, 79, 78, 78, 78, 77, 77, 77, 76, 76, 75, 75, 75, 74,
				74, 74, 73, 72, 72, 71, 71, 70, 70, 70, 69, 69, 69, 68, 68, 67, 67, 66, 66, 66, 65, 65, 65, 64, 64, 63, 63, 63, 62, 62,
				61, 61, 60, 60, 59, 59, 58, 58, 57, 57, 56, 55, 55, 54, 54, 53, 53, 52, 51, 50, 50, 49, 49, 48, 48, 47, 47, 46, 46, 45,
				45, 45, 44, 44, 43, 43, 42, 42, 41, 41, 40, 40, 39, 39, 38, 38, 38, 37, 37, 37, 36, 36, 36, 35, 35, 35, 35, 35, 34, 34,
				34, 34, 34, 33, 33, 33, 33, 33, 32, 32, 32, 32, 32, 31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29, 29, 29, 29, 29, 28,
				28, 28, 28, 28, 27, 27, 27, 27, 27, 26, 26, 26, 26, 26, 25, 25, 25, 25, 25, 24, 24, 24, 24, 24, 23, 23, 23, 23, 23, 22,
				22, 22, 22, 21, 21, 21, 21, 20, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

char o_name[14][41] = {"MODSONIC                                 ", "TEST 234                                 ", "TEST 345                                 ",
					   "TEST 456                                 ", "TEST 567                                 ", "TEST 678                                 ",
					   "TEST 789                                 ", "TEST 8910                                ", "TEST 91011                               ",
					   "TEST 101112                              ", "TEST 111213                              ", "TEST 121314                              ",
					   "TEST 131415                              ", "TEST 141516                              "};

//char heading_name[24][41] = {"OPERATOR NAME                           ", "PROJECT NAME                            ",
//							 "JOB NAME                                ", "CLIENT NAME                             ",
//							 "TESTING STAGE                           ", "DEFECT DETAIL                           ",
//							 "DEFECT TYPE                             ", "DEFECT LOCATION                         ",
//							 "REMEDY PLAN                             ", "REMARK                                  ",
//							 "MARKING                                 ", "HEAD 12                                 ",
//							 "HEAD 11                                 ", "HEAD 14                                 ",
//							 "HEAD 13                                 ", "HEAD 16                                 ",
//							 "HEAD 15                                 ", "HEAD 18                                 ",
//							 "HEAD 17                                 ", "HEAD 20                                 ",
//							 "HEAD 19                                 ", "HEAD 22                                 ",
//							 "HEAD 2                                  ", "HEAD 24                                 "};

char heading_name[24][41] = { "OPERATOR NAME                           ", "JOB DETAIL                              ",
							 "DEFECT DETAIL                           ", "DEFECT LOCATION                         ",
							 "REMARK                                  ", "PROJECT NAME                            ",
							 "CLIENT                                  ", "DEFECT TYPE                             ",
							 "TESTING STAGE                           ", "REMEDY PLAN                             ",
							 "MARKING                                 ", "HEAD 12                                 ",
							 "HEAD 11                                 ", "HEAD 14                                 ",
							 "HEAD 13                                 ", "HEAD 16                                 ",
							 "HEAD 15                                 ", "HEAD 18                                 ",
							 "HEAD 17                                 ", "HEAD 20                                 ",
							 "HEAD 19                                 ", "HEAD 22                                 ",
							 "HEAD 2                                  ", "HEAD 24                                 " };

// char o_name_o[574] = "ZEROAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQOFFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQGATEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQSAVEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQACTONAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQHORNAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQBEEPAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQCLOCKAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQGAINAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQDACAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQCOLORAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQRAILAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQCALAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQWHITEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQ";
char Note_data[574] = "MODSONIC                                TEST 123                                TEST 456                                TEST 789                                TEST ABC5                               TEST DEF6                               TEST IJK7                               TEST LMN 8                              TEST OPQ 9                              TEST RST 10                             COLOR                                   ";

char topic_name[14][41];
char stringbox[40];
char *text_prefix[28];
char text_values[28][60];
char text_valueskpd[28][39];
GtkWidget *t_window, *txtbox, *txtbox1, *txtbox2, *txtbox3, *txtbox4;
GtkWidget *text_h[14], *t_btnok, *t_btncls;
GtkWidget *txtlabel[14];
int i = 0, k = 0, key_scr, ary_idx = 0;
int ln_no = 0;
long chr_pos = 0;
char as_c;
FILE *ft_h;
char line[28][100];
char buf[560];
bool prior_line_ended = true;
int nchar = 40;
size_t last_idx;
int count = 5;
int temp_count = 0;
char ch;
char gvsum_1[20];
char str_1[10];
char gstr_1[30];
char gstr_2[30];
char gstr_3[30];
int imgh_line1 = 525;

int GateCrsLed_Symb = 0;
int GateCrsLed_Symb1 = 0;

bool Nearfield = false;

/* Color Gradient */
struct COLOR_GRADIENT
{
	gint r;
	gint g;
	gint b;
} clr_rgb[124];

guint color_gradient_arr[124];
guint color_gradient_tfd_arr[100];

#define BSC_TOTAL_DATA 2
extern int bsc_data[16];

int lastCalSetupFlag = 1;

// Only used for test file
FILE *fpTemp = NULL;
void OpenFile(void);
void WriteDataIntoFile(int i,  int gain);
void CloseFile(void);
/*---------------------------*/
FILE *fpCpy = NULL;
void MountUSB(const char *path);
void UmountUSB(void);
/***************************/

void MessageBox(const gchar *title, const char *msg);

void Scr_Clr_f(int key_t);

void OnBtn_press(GtkWidget *widget, GdkEventButton *event, gpointer data);
void activate(GtkApplication *app, gpointer user_data);
void Cmn_Cbtn(int btn_c);
void Create_Directory();
void pwroff_savesetup(void); // void pwroff_writevalues(); // while powering off the device save the current values in a file
void pwroff_readvalues(); // while powering on the device read the last saved values from the file
void pwron_readvalues(); // while powering on the device read the last saved values from the file
void h_read();
void h_write();
void h_detail();
void set_write();
void set_read();
void Update_Note();
void AllProcess(int key_v);
void Zero_f(int key_t);
void Range_f(int key_t);
void Velo_f(int key_t);
void Delay_f(int key_t);
void Gain_f(int key_t);
void Gatea_f(int key_t);
void STARTa_f(int key_t);
void ENDa_f(int key_t);
void LEVELa_f(int key_t);
void GATEb_f(int key_t);
void STARTb_f(int key_t);
void ENDb_f(int key_t);
// void COLOR_f(int key_t);
void LEVELb_f(int key_t);
void MEMORY_f(int key_t);
void MEMNO_f(int key_t);
void ACTION_f(int key_t);
void Mem_Note_f(int key_t);
void Size_Eval_f(int key_t);
void Size_Eval_f1(int key_t);
void Size_Eval_f2(int key_t);
void Size_Eval_f3(int key_t);
void Dac_f(int key_t);
void Send_Tcg_Data();
void AWS_f(int key_t);
void DGS_f(int key_t);
void Scal_f(int key_t);
void D_efect_f(int key_t);
void Dgs_exit_f(int key_t);
void Frame_menu_exit_f(int key_t); // Exit From Frame Menu
void press_f(int key_t);
void Aws_Ref_f(int key_t);
void AWS_rat(); // Calculate AWS Rating
void Refg_f(int key_v);
void Prb_freq_f(int key_t);
void Send_filt_Coef(); //   Send Filter Coeficient to FPGA
void Ref_echo_f(int key_t);
void DGS_Ref_f(int key_t);
void Att_obg_f(int key_t);
void Tl_Corr_f(int key_v);
void Del_Vel_f(int key_t);
void Ref_size_f(int key_t);
void Amp_corr_f(int key_t);
void Dsp_dgs_selection(int Frame_no);
void Dgs_crv_f(int key_t);
void Att_ref_f(int key_t);
void Max_Average_Set_f(); // Used to Set Averaging and Max value of Ascan Data in FPGA
void Video_f(int key_t);
void Setref_f(int key_t);
void HORN_f(int key_t);
void BEEP_f(int key_t);
void Key_Beep(); // Beep / Horn
void CLOCK_f(int key_t); // DATE & TIME Display CLOCK FUNCTION
void Auto_Cal_f(int key_t);
void auto_flname(int key_t);
void DST1_f(int key_t);
void DST2_f(int key_t);
void Auto_cal_range();
void Color_Leg_f(int key_v);
void ColorLeg_refresh(); // Recalculate and Refresh Color Leg On Screen
void Cal_ColorLeg();	 // Calculate value for Color LEG
void Grid_f(int key_v);	 // Select Grid Type
void Grid_Draw_f();		 // Draw Grid as per selection
void Ext_1_f(int key_t);
void Ext_2_f(int key_t);
void refresh_weld_profiler_area(void);

void Record_type_f(int key_t);
void Record_No_f(int key_t);
void Thk_Left_Right_ID(int key_t); // Left Right
void Record_Nob_f(int key_t);
void Bs_Action_Select_f(int key_t);
void Bs_Action_Selectb_f(int key_t);
void Thk_Up_Down_ID(int key_t); // Left Right
void Bs_Perf_Action(int key_t);
void Bsc_Record_Start_f(int key_t);

void ENCODER_f(int key_t);
void ASCCOL_f(int key_t);
void Power_f(int key_t);
void Prf_f(int key_t);
void PrfValue_f(int key_t);
void Smooth_f(int key_t);
void Unit_f(int key_t);
void Brightness_f(int key_t);
void Screen_rotate_f(int key_t);
void ANGLE_f(int key_t);
void Point_f(int key_t);
void DAMP_f(int key_t);
void Mode_f(int key_t);
void Trig_f(int key_t);
void X_OFFSET_f(int key_t);
void THICK_f(int key_t);
void DIAMET_f(int key_t);
void MINUTE_f(int key_t);
void HOUR_f(int key_t);
void DAY_f(int key_t);
void MONTH_f(int key_t);
void YEAR_f(int key_t);
void Menu_Refresh();
void Colour_Theme_Apply(int thmeno); // Color theme of Screen
void Close_Window();
void SplitWindow(int temp); // RB
void refresh_to_plot_data(void); // RB
void Draw_Bsc_Thk();
void Draw_Bscan_Color();
void Draw_Bscan_Color_encoder();
void Draw_TOFD();

void surface_rular_update(void);
void reset_plot_data(void);
float find_max_angle(int OD, int ID);

void Battery_Symbol(int btrper, int chr_no); // // Draw charging battery image(battery %, charge symbol) 0 = No charge symbol, 1 = charge symbol
int ADC_read();								 // Read Battery Voltage
void Measure_f();							 // Read Gate Cross Data
void Measure_Gate1_f();						 // Read Measurement of Gate from FPGA
void Measure_Frz();							 // Measure thickness reading when Freez is activated Calculates SP1 etc + Redraw Ascan +GAte DAC etc
void Cal_Ers_f();
void Get_dbtoCrv_f(); // Measure dB Difference between Curve and Echo signal
void DGS_Ref_on_f();  // Record DGS Ref Gain Value
void DGS_on_f(int key_v);
void Get_Dgs_f(int tempu); // Get DGS Crve points from Lkt as per value of ratio
void Encoder_Reset();	   // Encoder Reset
void Encoder_rd();		   // Read Encoder Count
int Find_peak_posi();	   // Find Peak value and Position
void dac_curve(int *dac_pntt, int *dac_p, int ref_g, long Range, long dly_r, int Crv_clr);
void dac_gen(int *dacT_pnt, int *dac_p, int ref_g, long Range, long dly_r);
void TCG_Cal(int *dacT_pnt, int *dac_p, int ref_g, long Range, long dly_r); // TCG Cal
void TCG_pnt_f(int keyupdn);
void TCG_pnt_gn(int keyupdn);
void TCG_Activate_Deactivate(bool tcgonoff);

void create_bsc_file(const char* file_name);
void open_bsc_file(const char* file_name);
void close_bsc_file(void);
void read_data_using_button_fun(int key);
void read_data_using_button_fun_for_Board(int key);

void Copy_dac_crv();			   // Copy DAc Curve for DAC  Trigger Function
void DAC_Copy_for_Disp(int crvno); // Copy DAC points data for the Display
int GaintoEH(int gain);
void Copy_DGSpnt(void);

void dsp_msg(int msgno);			  // Display Error or warning Message
void Display_warn(char Wrnmessage[]); // Display Warning Message
void Cal_sddp_f();					  // Calculate Depth/Surface Dst on base of SP
void Check_Gate_cross();			  // If Gate is ON and any signal then generate signal for LED

// void Cal_gate();
void fillgl_image();
void npiximage_chang();
void npiximage();
void drawsh_gatea();
void drawsh_gateb();
void drawsh_dac();
void draw_gatea();
// void Update_btn_bk();
void draw_gateb();
void draw_dac();
void draw_time();
void chng_year();
gboolean my_keypress_val(GtkWidget *widget, GdkEventKey *event, gpointer data);
void Set_btn_focus(); // Set Button/Controll Focus /Appropriate Color to indicate Selected
void key_btn();
void stp_coarse();
int gst_adj(int gval, int gsend_val, int gval_pos, int key_t, int gmenu_v, int key_val);
void Size_Eval_Select_f(int key_t);
void Mea_fLn1_f(int key_t);
void Mea_fLn2_f(int key_t);
void Mea_fLn3_f(int key_t);
void Bs_auto_flname(int key_t);
void Bs_Action(int key_t);
void Bs_Perf_Action(int key_t);
void Bs_Scroll_curp(int key_t);
void Enc_CAL_F_f(int key_t);
void Bsc_DSP_f(int key_t);
void Bsc_Analysis_thk_f(int key_t);
void Weld_Prof_f(int key_v);   // WELD_PROF_PERA
void Beam_Prof_f(int key_v);   // BEAM_PROF_PERA
void Thick_color_f(int key_v); // THICK_CLR_PERA break;

void Weld_type_f(int key_t);	   //  WELD_TYPE_PERA
void Weld_Width_f(int key_t);	   //  TOP_WIDTH_PERA
void Weld_TpHeight_f(int key_t);   //  TOP_HEIGHT_PERA
void Weld_Root_width_f(int key_t); //  ROOT_WIDTH_PERA
void Weld_EXT11_f(int key_t);	   //  EXT_11_PERA
void Weld_EXT12_f(int key_t);	   //  EXT_12_PERA
void Weld_EXT13_f(int key_t);	   //  EXT_13_PERA
void Weld_EXT14_f(int key_t);	   //  EXT_14_PERA
void Weld_Exit_f(int key_t);	   //  EXT_21_PERA
void Weld_EXT22_f(int key_t);	   //  EXT_22_PERA
void Weld_EXT23_f(int key_t);	   //  EXT_23_PERA
void Weld_EXT24_f(int key_t);	   //  EXT_24_PERA
void Tst_Obh_shape_f(int key_t);   // OBJ_SHAPE_PERA           //    Test Object Shape Selection
void Probe_pos_f(int key_t);	   //  PROB_POS_PERA
void Change_ogl_probe_pos_f(int key_t); // used from main key
void Probe_angle_f(int key_t);	   // PROBE_ANGLE_PERA
void NoofLeg_f(int key_t);		   //  NOOF_LEGv_PERA
void Obj_width_f(int key_t);	   //  WIDTH_PERA
void Obj_thick_f(int key_t);	   //  HEIGHT_PERA
void Obj_EXT33_f(int key_t);	   //  EXT_33_PERA
void Obj_EXT34_f(int key_t);	   //  EXT_34_PERA
void Obj_Exit_f(int key_t);		   //  EXT_41_PERA
void Obj_Wprof_pos_f(int key_t);   //  EXT_42_PERA   Obj_EXT42_f
void Obj_EXT43_f(int key_t);	   //  EXT_43_PERA
void Obj_EXT44_f(int key_t);	   //  EXT_44_PERA
void Beam_Prof_PDia_f(int key_v);  // BEAM_PROFILE_PERA             // Test Object Shape Configuration
void Beam_Prof_PFreq_f(int key_v); // BEAM_PRF_P12_PERA
void Beam_Profile_Cal_f();

void Beam_Prof_p13_f(int key_v);  // BEAM_PRF_P13_PERA
void Beam_Prof_PFreq_f();		  // Calculate Near Field Value and Angle
void Beam_Prof_p14_f(int key_v);  // BEAM_PRF_P14_PERA
void Beam_Prof_p21_f(int key_v);  // BEAM_PRF_P21_PERA
void Beam_Prof_p22_f(int key_v);  // BEAM_PRF_P22_PERA
void Beam_Prof_p23_f(int key_v);  // BEAM_PRF_P23_PERA
void Beam_Prof_p24_f(int key_v);  // BEAM_PRF_P24_PERA
void Beam_Prof_Exit_f(int key_v); // BEAM_PRF_P31_PERA
void Beam_Prof_p32_f(int key_v);  // BEAM_PRF_P32_PERA
void Beam_Prof_p33_f(int key_v);  // BEAM_PRF_P33_PERA
void Beam_Prof_p34_f(int key_v);  // BEAM_PRF_P34_PERA

void Thk_File_type_f(int key_t);	//  THKFILE_TYPE_PERA           // Thickness file type Selection
void Start_ID_1_f(int key_t);		//  START_ID_1_PERA
void Start_ID_2_f(int key_t);		//  START_ID_2_PERA
void Start_ID_3_f(int key_t);		//  START_ID_3_PERA
void Thk_EXT_51_f(int key_t);		//  EXT_51_PERA
void END_ID_1_f(int key_t);			//  END_ID_1_PERA
void END_ID_2_f(int key_t);			//  END_ID_2_PERA
void END_ID_3_f(int key_t);			//  END_ID_3_PERA
void Thk_File_Exit_f(int key_t);	//  EXIT_PERA
void Dim_1_size_f(int key_t);		//  DIM_1_SIZE_PERA
void Dim_2_size_f(int key_t);		//  DIM_2_SIZE_PERA
void Dim_3_size_f(int key_t);		//  DIM_3_SIZE_PERA
void Thk_Color_method_f(int key_t); //  COLOR_METHOD_PERA  EXIT_PERA+5           // Thickness file Color Selection
void Start_Thk_1_f(int key_t);		//  START_THK_1_PERA
void Start_Thk_2_f(int key_t);		//  START_THK_2_PERA
void Start_Thk_3_f(int key_t);		//  START_THK_3_PERA
void Thk_EXT_61_f(int key_t);		//  EXT_61_PERA
void End_Thk_1_f(int key_t);		//  END_THK_1_PERA
void End_Thk_2_f(int key_t);		//  END_THK_2_PERA
void End_Thk_3_f(int key_t);		//  END_THK_3_PERA
void Thk_Clr_Exit_f(int key_t);		//  EXIT_71_PERA
void Thk_Clr_1_f(int key_t);		//  COLOR_1_PERA
void Thk_Clr_2_f(int key_t);		//  COLOR_2_PERA
void Thk_Clr_3_f(int key_t);		//  COLOR_3_PERA
void Diameter_f(int key_t);           // Diameter Function

void Menu_f(int key_v);
void OntString(int k_tnt);
void Note_Display(int k_tnt);
void Note_ln_f(int key_t);
void Note_Cur_pos_f(int key_t);
void Note_Char_Scroll_f(int key_t);

void Write_NoteText();
void Enc_Start_posF_f(int key_t);
void Timer_Start_Stop();
void timer_signal_function(GtkWidget *widget, gpointer window);
gboolean time_handler_function(void);
void send_data(void);
void send_data_board(void);
void refresh_opengl_display(void);
static void do_drawing(cairo_t *);
void gate_display(void);

void Mode_Symbol(int Symbl, cairo_t *cr);	   // Mode Normal Probe
void Trig_Symbol(int Symbl, cairo_t *cr);	   // Measurement Trigger Symbol
void Reject_Symbol(int Symbl, cairo_t *cr);	   // Rejection Activated Symbol
void Size_Eval_Symbol(int Symbl, cairo_t *cr); // Size Evalution Symbol

void Set_default_val();		  // During Power Up set values of all perameters to default value
void Refresh_Allpera_val_f(); // Refresh all peravalue by calling each function. It is used when Data recall from Memoery
void refresh_thk_clr_data();
void Create_appFolder();

// void Create_Btn_img();
void Creat_bk_img(int imgset, int imgset2);	  // Create Image for Measurement Display Button
void Draw_notificimg(int not_no, int frm_no); // Draw Sybol and DIsplay on Screen
void Cal_Gate_Crss_val(); // Store values for gate cross beep signal

void Cnv_to_inch(); // To convert to inch from mm
void Cnv_to_mm(); // To convert to mm from inch
void keypad_btn(); // Get alphanumeric keypad
void Numerickey_Btn(); // Get numeric keypad
void lftBtn_valchng(GtkWidget* widget);
void rghtBtn_valchng(GtkWidget* widget);
int Brightness_value();
void DetectUsb(); // To Detect pendrive function
void DetectSDCard(); // To Detect SD Card function
void Reset_DGSDAC(); // While Ploting Dgs or Dac when reading from file we use this to reset the dac or dgs function 
void PRF_Set();//void PRF_Set(int PRF_set);
void PRF_Cal();
void PowerKey_ck(); // For Power button press key to write file  
void Txvolt_f(int key_t); // Volt Function
//static gboolean Create_Pdfreport(); // Create pdf Ascan Report function
static gboolean CreateAscan_Pdfreport(); // Create pdf Ascan Report function
void DgsCrv_db(int key_t); // Increase db points to draw multiple dgs curve function
void temp_write(); 
void Delete_PopUp();
void Del_Yes(); // If Yes then Delete.
void Del_No(); // If No the don't Delete.
void Bat_temp(int dd); // Temporary Battery Setup
void ConcaveCal(double OD, double ID, double angle_pos, double angle_prb);
void ConvexCal(double OD, double ID, double angle_pos, double angle_prb);
double sd, flsp, fld, flsd;



void multidac_write();
