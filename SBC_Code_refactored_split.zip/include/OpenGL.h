#ifndef OPENGL_H_
#define OPENGL_H_

#include <gdk/gdkwayland.h>

#include <wayland-client.h>
#include <wayland-server.h>
#include <wayland-egl.h> // Wayland EGL MUST be include before EGL header

// OpenGL header files
#include <GLES3/gl3.h>
#include <GLES3/gl3ext.h>
#include <EGL/egl.h>

// typedef struct tagPOINT
//{
//     long x;
//     long y;
// } POINT ;

extern int val_ary[200];
extern int c_y[256];
extern int s_x11, s_y11, s_x22, s_y22, i;
extern int width_sh, height_sh;
// extern gboolean Gatea_flag;
// extern gboolean gateb_flag;
extern gboolean gdac_flag;
extern int ogl_x_position;
extern int ogl_y_position;

void Cal_vertices();     // Calculate Verteces for Filled/Envelop/Dynmaic etc
void ColorLeg_refresh(); // If COlor Leg is ON then fill accordingly
// float fdiv[120];
// GLubyte row_y[256];

// int idx_fact = 0;

// gboolean bflag = false;

extern int ogl_shape[51];
extern int profiler_cntr_line[11];
extern int ogl_profiler[101];
extern int ogl_probe[101];
extern int ogl_rays[101];
extern int rw_flag;

extern int cur_idx;
extern int num_of_vertices;
extern GLbyte bscfiledata[262144];

extern float All_Ascan_peak[512];
GLushort  All_Ascan_peak_index[512];
extern gboolean Ascan_peak_flag;

struct OGLData
{
    // shader variables
    GLuint vertex_shader, fragment_shader, shader_program_object;

    // OpenGL buffer variables
    GLuint vao, vbo_position, vbo_color, ebo;
    GLuint vao_peak, vbo_pos_peak, vbo_clr_peak, ebo_peak;

    GLfloat vertices_position[4096]; // 1536   //512   No of points * 2
    GLfloat vertices_color[5120];    // 768
    GLuint indices[2048];

    // Framebuffer variables
    unsigned char *data_ptr;
    GLubyte *rgba_color_pixel;
    GLuint framebuffer;
    GLint default_framebuffer;
    GLuint textureColorbuffer;

    // EGL and OpenGL ES variables and function declarations
    EGLDisplay egl_display;
    EGLConfig egl_config;
    EGLContext egl_context;
    EGLSurface egl_surface;

    // Wayland variables and function declarations
    struct wl_display *w_display;
    struct wl_compositor *compositor;
    struct wl_subcompositor *subcompositor;
    struct wl_subsurface *subsurface;

    struct wl_surface *pw_surface;
    struct wl_surface *cw_surface;

    struct wl_egl_window *egl_window;
    struct wl_region *region;

    int win_x_pos, win_y_pos;

    cairo_surface_t *surface;
    cairo_t *cr;
};

// struct OGLData ogl;

extern struct OGLData ogl;

// OpenGL functions declarations
void egl_wayland_initialization(GdkWindow *gdk_window, int width, int height);
void ogl_initialization(int width, int height);
void ogl_render(int width, int height);
void ogl_uninitialization(guint);
void ogl_uninitialization_temp(guint signal_id);
void ogl_update(void);

// Helper function
void write_data_in_file(GLubyte *data);
void gl_clear_color_background_data(int width, int height);

void get_server_referance(GdkDisplay *gdk_display);
void global_registry_handler(void *data, struct wl_registry *registry, uint32_t id, const char *interface, uint32_t version);
void global_registry_remover(void *data, struct wl_registry *registry, uint32_t id);
void partial_uninitialize(void);
void recreate_surface(int width, int height, int xx_pos, int yy_pos); // void recreate_surface(int ui_type, int width, int height);
void clr_grd_data_function(void);
void Grid_Draw_f(cairo_t *cr);      // Draw Grid as per selection
void draw_gate1(cairo_t *cr);       // Draw GateA Line
void draw_gate2(cairo_t *cr);       // Draw GateA Line
void draw_curvedac(cairo_t *cr);    // Draw DAC Curve
void Draw_beamprofile(cairo_t *cr); // If Beam Profile is ON then Draw it

#endif // OPENGL_H_
