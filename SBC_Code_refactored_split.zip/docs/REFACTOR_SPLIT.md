# Split of OpenGL.c and Dav_Sub.c

This refactor split large source files into multiple smaller modules under `src/opengl/` and `src/dav/`.
Umbrella headers were created in `include/`.

Results summary:
OpenGL: {'status': 'ok', 'original': '/mnt/data/SBC_Code_refactor_split/src/OpenGL.c', 'created': ['src/opengl/opengl_init.c', 'src/opengl/opengl_init_2.c', 'src/opengl/opengl_init_3.c', 'src/opengl/opengl_render.c', 'src/opengl/opengl_io.c', 'src/opengl/opengl_math.c', 'src/opengl/opengl_utils.c', 'src/opengl/opengl_utils_2.c', 'src/opengl/opengl_utils_3.c'], 'header': 'include/opengl.h'}
Dav_Sub: {'status': 'ok', 'original': '/mnt/data/SBC_Code_refactor_split/src/Dav_Sub.c', 'created': ['src/dav/dav_sub_init.c', 'src/dav/dav_sub_init_2.c', 'src/dav/dav_sub_init_3.c', 'src/dav/dav_sub_render.c', 'src/dav/dav_sub_io.c', 'src/dav/dav_sub_io_2.c', 'src/dav/dav_sub_io_3.c', 'src/dav/dav_sub_io_4.c', 'src/dav/dav_sub_io_5.c', 'src/dav/dav_sub_io_6.c', 'src/dav/dav_sub_math.c', 'src/dav/dav_sub_math_2.c', 'src/dav/dav_sub_utils.c', 'src/dav/dav_sub_utils_2.c', 'src/dav/dav_sub_utils_3.c', 'src/dav/dav_sub_utils_4.c', 'src/dav/dav_sub_utils_5.c', 'src/dav/dav_sub_utils_6.c', 'src/dav/dav_sub_utils_7.c', 'src/dav/dav_sub_utils_8.c', 'src/dav/dav_sub_utils_9.c', 'src/dav/dav_sub_utils_10.c', 'src/dav/dav_sub_utils_11.c', 'src/dav/dav_sub_utils_12.c', 'src/dav/dav_sub_utils_13.c', 'src/dav/dav_sub_utils_14.c', 'src/dav/dav_sub_utils_15.c', 'src/dav/dav_sub_utils_16.c'], 'header': 'include/dav_sub.h'}

Build files updated: []

Notes:
- Original files were backed up with `_old` suffix.
- Please run a clean build. If some functions were referenced via macros or function pointers, you may need to adjust headers.
- If you want different grouping or function placements, tell me which functions to move.
