#!/bin/sh
# Run clang-format on sources and headers
if command -v clang-format >/dev/null 2>&1; then
  find src include -type f \( -name '*.c' -o -name '*.cpp' -o -name '*.h' -o -name '*.hpp' \) -print0 | xargs -0 clang-format -i
  echo "clang-format applied to src/ and include/"
else
  echo "clang-format not found; install it or run manually."
fi
