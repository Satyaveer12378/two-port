#include "include/include/OpenGL.h"
#include "include/include/Dav_Sub.h"

#define NUM_OF_VERTICES 256

// extern POINT;      // POINT pntArray_DACM[NUM_OF_VERTICES];

typedef struct tagPOINT
{
    long x;
    long y;
} POINT;

extern POINT pntArray_DACM[NUM_OF_VERTICES];  // Holds data of DAC Curve main curve
extern POINT pntArray_DAC1P[NUM_OF_VERTICES]; // Holds data of DAC Curve Main Curve+dac db
extern POINT pntArray_DAC2P[NUM_OF_VERTICES]; // Holds data of DAC Curve Main Curve+ 2*dac db
extern POINT pntArray_DAC1N[NUM_OF_VERTICES]; // Holds data of DAC Curve Main Curve - dac db
extern POINT pntArray_DAC2N[NUM_OF_VERTICES]; // Holds data of DAC Curve Main Curve - 2*dac db
extern int Dac_crv_dB;
extern double Prb_Near_field, Prb_div_Ht;
extern int All_Ascan_data[1024];

extern int Asc_Max[1024];
extern uint8_t rx_cmd[1024];
extern int Asc_Width;
extern int Asc_Height;
extern int frame_width;
extern int splite_frame_height;
extern int Voff;
extern int Dgs_onoff_v, Dac_v;

extern int splite_win_flg;
extern int Asc_Clr_val;
extern int Clr_leg_sta, Clr_leg_width;
extern int Grid_v;
extern int Rectify_v;
extern int video_val; // IF Video Dynamic is selected
extern gdouble Grid_r[20], Grid_g[20], Grid_b[20];

extern float Red[20];
extern float Green[20];
extern float Blue[20];
extern int recall_read;

extern int Record_Type_val;
extern int dgsdb_crv[15];
extern int Dgs_gain;

extern gboolean Dac_Bscan_flag; // Bscan = true, Dac = false;
extern gboolean Ascan_image_snap;
extern unsigned char *Ascan_image_data; //[741][446][3]; // full Ascan area Width * Height * RGB = 741*446*3

extern int dgs_fromfile;
extern long dgs_pnt[256];
extern void Set_default_val();
extern gboolean DGS_ReadFile; // = false;

float fdiv[120];
GLubyte row_y[NUM_OF_VERTICES];

enum
{
    ATTRIBUTE_POSITION = 0,
    ATTRIBUTE_COLOR
};

GLfloat y_coord[] =
    {
        100.0f,
        100.0f,
        100.0f,
        100.0f,
        100.0f,
        60.0f,
        45.0f,
        55.0f,
        28.0f,
        33.0f,
        12.0f,
        13.0f,
        5.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        13.0f,
        37.0f,
        23.0f,
        62.0f,
        48.0f,
        74.0f,
        80.0f,
        76.0f,
        49.0f,
        54.0f,
        23.0f,
        9.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        3.0f,
        17.0f,
        27.0f,
        20.0f,
        39.0f,
        55.0f,
        43.0f,
        25.0f,
        27.0f,
        13.0f,
        5.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        8.0f,
        12.0f,
        19.0f,
        32.0f,
        40.0f,
        37.0f,
        25.0f,
        16.0f,
        9.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        3.0f,
        9.0f,
        19.0f,
        28.0f,
        20.0f,
        15.0f,
        9.0f,
        5.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
};

const struct wl_registry_listener registry_listener = {
    global_registry_handler,
    global_registry_remover};

int idx_fact = 1;
extern int Rectify_v;
gboolean bflag = true;
bool Color_update = false;

cairo_t *Ascan_cr;
cairo_surface_t *Ascan_surface;
GdkPixbuf *Ascan_pixbuf = NULL;

void select_shape(cairo_t *cr, int *offset);
void write_data_in_bsc_file(GLubyte *data);
extern void WriteDataIntoFile(char *str, int i, float data);

//************************************************************************
// OpenGL initialization function
//************************************************************************


/* --- Functions: category init --- */

void egl_wayland_initialization(GdkWindow *gdk_window, int width, int height)
{
    EGLint major_version;
    EGLint minor_version;
    EGLint num_configs;

    // Wayland code
    ogl.pw_surface = gdk_wayland_window_get_wl_surface(gdk_window);

    get_server_referance(gdk_window_get_display(gdk_window));

    ogl.cw_surface = wl_compositor_create_surface(ogl.compositor);
    if (ogl.cw_surface == NULL)
        printf("egl_wayland_initialization() Can't create surface.\n");

    ogl.region = wl_compositor_create_region(ogl.compositor);
    wl_surface_set_input_region(ogl.cw_surface, ogl.region);

    ogl.subsurface = wl_subcompositor_get_subsurface(ogl.subcompositor, ogl.cw_surface, ogl.pw_surface);
    wl_subsurface_set_desync(ogl.subsurface);
    wl_subsurface_set_position(ogl.subsurface, ogl_x_position, ogl_y_position);

    ogl.egl_window = wl_egl_window_create(ogl.cw_surface, width, height);

    EGLint attributes[] =
    {
        EGL_SURFACE_TYPE, EGL_WINDOW_BIT,
        EGL_RED_SIZE, 8,
        EGL_GREEN_SIZE, 8,
        EGL_BLUE_SIZE, 8,
        EGL_RENDERABLE_TYPE, EGL_OPENGL_ES2_BIT,
        EGL_NONE
    };

    EGLint context_attribs[] = { EGL_CONTEXT_CLIENT_VERSION, 2, EGL_NONE };

    // Get Display
    ogl.egl_display = eglGetDisplay((EGLNativeDisplayType)ogl.w_display);
    if (ogl.egl_display == EGL_NO_DISPLAY)
        g_print("eglGetDisplay() function is failed.\n");

    // Initialize OpenGL
    if (!eglInitialize(ogl.egl_display, &major_version, &minor_version))
        g_print("eglInitialize() function is failed.\n");
    // g_print("EGL Version : %d:%d\n", major_version, minor_version);

    eglBindAPI(EGL_OPENGL_ES_API);
    eglGetConfigs(ogl.egl_display, NULL, 0, &num_configs);

    // Chooose Config
    if (!eglChooseConfig(ogl.egl_display, attributes, &ogl.egl_config, 1, &num_configs))
        g_print("eglChooseConfig() function is failed.\n");

    // Create a GL context
    ogl.egl_context = eglCreateContext(ogl.egl_display, ogl.egl_config, EGL_NO_CONTEXT, context_attribs);
    if (ogl.egl_context == EGL_NO_CONTEXT)
        g_print("eglCreateContext() function is failed.\n");

    // Create a surface
    ogl.egl_surface = eglCreateWindowSurface(ogl.egl_display, ogl.egl_config, ogl.egl_window, NULL);
    if (ogl.egl_surface == EGL_NO_CONTEXT)
        g_print("eglCreateWindowSurface() function is failed.\n");

    // Make the context current
    if (!eglMakeCurrent(ogl.egl_display, ogl.egl_surface, ogl.egl_surface, ogl.egl_context))
        g_print("eglMakeCurrent() function is failed.\n");

    clr_grd_data_function();
    ogl_initialization(width, height);

    Ascan_pixbuf = gdk_pixbuf_new(GDK_COLORSPACE_RGB, true, 8, width, height); 
    Ascan_surface = cairo_image_surface_create(CAIRO_FORMAT_ARGB32, width, height);
    Ascan_cr = cairo_create (Ascan_surface);
}


void ogl_initialization(int width, int height)
{
    int i = 0;
    GLint iShaderCompileStatus = 0;
    GLint iProgramLinkStatus = 0;
    GLint iInfoLogLength = 0;
    GLchar *szInfoLog = NULL;

    // Create vertex shader
    ogl.vertex_shader = glCreateShader(GL_VERTEX_SHADER);

    // Write vertex shader code
    const GLchar *vssourcecode = 
    {
        "#version 100                                               \n"

        "attribute vec2 vPosition;                                  \n"
        "attribute vec3 vColor;                                     \n"

        "varying vec3 outColor;                                     \n"

        "void main(void)                                            \n"
        "{                                                          \n"
        "  gl_Position = vec4(vPosition.x, vPosition.y, 0.0, 1.0);  \n"
        "  outColor = vColor;                                       \n"
        "}"
    };

    glShaderSource(ogl.vertex_shader, 1, &vssourcecode, NULL);
    glCompileShader(ogl.vertex_shader);

    glGetShaderiv(ogl.vertex_shader, GL_COMPILE_STATUS, &iShaderCompileStatus);
    if (iShaderCompileStatus == GL_FALSE)
    {
        glGetShaderiv(ogl.vertex_shader, GL_INFO_LOG_LENGTH, &iInfoLogLength);
        if (iInfoLogLength > 0)
        {
            szInfoLog = (GLchar *)malloc(iInfoLogLength);
            if (szInfoLog != NULL)
            {
                GLsizei written;
                glGetShaderInfoLog(ogl.vertex_shader, iInfoLogLength, &written, szInfoLog);
                g_print("VS Log :- %s.", szInfoLog);
                free(szInfoLog);
                exit(0);
            }
        }
    }

    // Create fragment shader
    ogl.fragment_shader = glCreateShader(GL_FRAGMENT_SHADER);

    // Write fragmant shader code
    const GLchar *fssourcecode = 
    {
        "#version 100                               \n"

        "precision mediump float;                   \n"

        "varying vec3 outColor;                     \n"

        "void main(void)                            \n"
        "{                                          \n"
        "  gl_FragColor = vec4(outColor, 1.0);      \n"
        "}"
    };

    glShaderSource(ogl.fragment_shader, 1, &fssourcecode, NULL);
    glCompileShader(ogl.fragment_shader);

    glGetShaderiv(ogl.fragment_shader, GL_COMPILE_STATUS, &iShaderCompileStatus);
    if (iShaderCompileStatus == GL_FALSE)
    {
        glGetShaderiv(ogl.fragment_shader, GL_INFO_LOG_LENGTH, &iInfoLogLength);
        if (iInfoLogLength > 0)
        {
            szInfoLog = (GLchar *)malloc(iInfoLogLength);
            if (szInfoLog != NULL)
            {
                GLsizei written;
                glGetShaderInfoLog(ogl.fragment_shader, iInfoLogLength, &written, szInfoLog);
                g_print("FS Log :- %s.", szInfoLog);
                free(szInfoLog);
                exit(0);
            }
        }
    }

    // Create shader program object
    ogl.shader_program_object = glCreateProgram();
    glAttachShader(ogl.shader_program_object, ogl.vertex_shader);
    glAttachShader(ogl.shader_program_object, ogl.fragment_shader);

    glBindAttribLocation(ogl.shader_program_object, ATTRIBUTE_POSITION, "vPosition");
    glBindAttribLocation(ogl.shader_program_object, ATTRIBUTE_COLOR, "vColor");

    // Link shader
    glLinkProgram(ogl.shader_program_object);

    glGetProgramiv(ogl.shader_program_object, GL_LINK_STATUS, &iProgramLinkStatus);
    if (iProgramLinkStatus == GL_FALSE)
    {
        glGetProgramiv(ogl.shader_program_object, GL_INFO_LOG_LENGTH, &iInfoLogLength);
        if (iInfoLogLength)
        {
            szInfoLog = (GLchar *)malloc(iInfoLogLength);
            if (szInfoLog != NULL)
            {
                GLsizei written;
                glGetProgramInfoLog(ogl.shader_program_object, iInfoLogLength, &written, szInfoLog);
                g_print("LS Log :- %s.", szInfoLog);
                free(szInfoLog);
                exit(0);
            }
        }
    }

    for (i = 0; i < 2048; i++)
    {
        ogl.indices[i] = i; // Indices of vertices
    }

    for (i = 0; i < NUM_OF_VERTICES; i++) // Calculate and fill X position for A-Scan
    {
        ogl.vertices_position[(i * 2) + 0] = ((GLfloat)i - 128.0f) / 128.0f; // On x-axis 255 positions co-ordinates
        ogl.vertices_position[(i * 2) + 512] = ogl.vertices_position[(i * 2) + 0];
        ogl.vertices_position[(i * 2) + 1024] = ogl.vertices_position[(i * 2) + 0];

        ogl.vertices_position[(i * 2) + 1] = (y_coord[i] / 50) - 1.0; // 0.0f;
        // ogl.indices[i] = i; // Indices of vertices
    }

    // Vertices color
    // for (i = 0; i < NUM_OF_VERTICES; i++)
    // {
    //     if (i >= 0 && i <= 100)
    //     {
    //         ogl.vertices_color[(i * 3) + 0] = 1.0f;   //  0000 0000 0000 0000
    //         ogl.vertices_color[(i * 3) + 1] = 0.0f;
    // ogl.vertices_color[(i * 3) + 2] = 0.0f;
    //     }
    //     else if (i >= 101 && i <= 200)
    //     {
    //         ogl.vertices_color[(i * 3) + 0] = 0.0f;
    //         ogl.vertices_color[(i * 3) + 1] = 1.0f;
    // ogl.vertices_color[(i * 3) + 2] = 1.0f;
    //     }
    //     else if (i >= 201)
    //     {
    //         ogl.vertices_color[(i * 3) + 0] = 1.0f;
    //         ogl.vertices_color[(i * 3) + 1] = 0.0f;
    // ogl.vertices_color[(i * 3) + 2] = 1.0f;
    //     }
    // }

    for (i = 0; i < 1536; i++) // Verteces  Color 1536  NUM_OF_VERTICES*2 *3 =1536 for Filled Echo Pattern
    {
        ogl.vertices_color[(i * 3) + 0] = 1.0f;
        ogl.vertices_color[(i * 3) + 1] = 1.0f;
        ogl.vertices_color[(i * 3) + 2] = 0.0f;
    }

    // Generate vao buffer
    glGenVertexArrays(1, &ogl.vao);
    // Bind vao buffer
    glBindVertexArray(ogl.vao);
    // Generate vbo buffer
    glGenBuffers(1, &ogl.vbo_position);
    // Bind vbo buffer
    glBindBuffer(GL_ARRAY_BUFFER, ogl.vbo_position);
    glBufferData(GL_ARRAY_BUFFER, (NUM_OF_VERTICES * 2) * sizeof(GL_FLOAT), NULL, GL_DYNAMIC_DRAW);
    glVertexAttribPointer(ATTRIBUTE_POSITION, 2, GL_FLOAT, GL_FALSE, 0, NULL);
    glEnableVertexAttribArray(ATTRIBUTE_POSITION);
    // Generate vbo buffer
    glGenBuffers(1, &ogl.vbo_color);
    // Bind vbo buffer
    glBindBuffer(GL_ARRAY_BUFFER, ogl.vbo_color);
    glBufferData(GL_ARRAY_BUFFER, sizeof(ogl.vertices_color), ogl.vertices_color, GL_DYNAMIC_DRAW);
    glVertexAttribPointer(ATTRIBUTE_COLOR, 3, GL_FLOAT, GL_FALSE, 0, NULL);
    glEnableVertexAttribArray(ATTRIBUTE_COLOR);
    // Unbind vbo buffer
    glBindBuffer(GL_ARRAY_BUFFER, 0);
    // Generate ebo buffer
    glGenBuffers(1, &ogl.ebo);
    // Bind ebo buffer
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ogl.ebo);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(ogl.indices), ogl.indices, GL_STATIC_DRAW);
    // Unbind ebo buffer
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
    // Unbind vao buffer
    glBindVertexArray(0);
    
    // below code for Setref_f
    for (i = 0; i < NUM_OF_VERTICES; i++)
	{
		All_Ascan_peak[(i * 2) + 0] = ogl.vertices_position[(i * 2) + 0];
        All_Ascan_peak[(i * 2) + 1] = 0.0f;
	}

    All_Ascan_peak_index[0] = 0;
    for (i = 1; i < NUM_OF_VERTICES; i++)
	{
        All_Ascan_peak_index[(i * 2) - 1] = i;
        All_Ascan_peak_index[(i * 2) + 0] = i;
	}
    All_Ascan_peak_index[511] = 1.0f;

    glGenVertexArrays(1, &ogl.vao_peak);
    glBindVertexArray(ogl.vao_peak);

    glGenBuffers(1, &ogl.vbo_pos_peak);
    glBindBuffer(GL_ARRAY_BUFFER, ogl.vbo_pos_peak);
    glBufferData(GL_ARRAY_BUFFER, (NUM_OF_VERTICES * 2) * sizeof(GL_FLOAT), NULL, GL_DYNAMIC_DRAW);
    glVertexAttribPointer(ATTRIBUTE_POSITION, 2, GL_FLOAT, GL_FALSE, 0, NULL);
    glEnableVertexAttribArray(ATTRIBUTE_POSITION);

    glGenBuffers(1, &ogl.vbo_clr_peak);
    glBindBuffer(GL_ARRAY_BUFFER, ogl.vbo_clr_peak);
    glBufferData(GL_ARRAY_BUFFER, sizeof(ogl.vertices_color), ogl.vertices_color, GL_DYNAMIC_DRAW);
    glVertexAttribPointer(ATTRIBUTE_COLOR, 3, GL_FLOAT, GL_FALSE, 0, NULL);
    glEnableVertexAttribArray(ATTRIBUTE_COLOR);
    glBindBuffer(GL_ARRAY_BUFFER, 0);
   
    glGenBuffers(1, &ogl.ebo_peak);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ogl.ebo_peak);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(All_Ascan_peak_index), All_Ascan_peak_index, GL_STATIC_DRAW);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);

    glBindVertexArray(0);

    // Used for Background image
    ogl.surface = cairo_image_surface_create(CAIRO_FORMAT_RGB24, width, height);
    // Using surface create memory context
    ogl.cr = cairo_create(ogl.surface);

    // Framebuffer configuration
    glGenFramebuffers(1, &ogl.framebuffer);
    glBindFramebuffer(GL_FRAMEBUFFER, ogl.framebuffer);

    // Create a color attachment texture
    glGenTextures(1, &ogl.textureColorbuffer);
    glBindTexture(GL_TEXTURE_2D, ogl.textureColorbuffer);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, NULL);
    glGenerateMipmap(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, 0);
    
    //  Bind texture buffer with GL_COLOR_ATTACHMENT0 in framebuffer
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, ogl.textureColorbuffer, 0);
    if (glCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE)
        g_print("ERROR::FRAMEBUFFER:: Framebuffer is not complete..!\n");
    // Unbind framebuffer
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
   
    // Call to create background grid
    gl_clear_color_background_data(width, height);
    
    glBindFramebuffer(GL_READ_FRAMEBUFFER, ogl.framebuffer);
    glBindFramebuffer(GL_DRAW_FRAMEBUFFER, 0);
    glBlitFramebuffer(0, 0, width, height, // Source x, y, width and height
                      0, height, width, 0, // Dest x, y, width and height
                      GL_COLOR_BUFFER_BIT, GL_NEAREST);

    // Set view port
    glViewport(0, 0, (GLsizei)width, (GLsizei)height);
}


}

//*****************************************************************************************************
//*****************************************************************************************************
void Draw_beamprofile(cairo_t *cr) // If Beam Profile is ON then Draw it
{
    int x3, y1, y2, wd; // ,y3;
    x3 = Asc_Width;
    y1 = 20;
    y2 = 20;
    wd = 20;
    // Prb_div_Ht
    cairo_set_source_rgba(cr, 1.0, 1.0, 0.0, 1.0); //
    y1 = 200 + wd;
    y2 = 200 - wd;
    cairo_move_to(cr, 0, y1);
    cairo_line_to(cr, Prb_Near_field, y1);
    cairo_line_to(cr, x3, y1 + Prb_div_Ht); // cairo_stroke(cr);
    // cairo_set_source_rgba(cr, 1.0, 0.0, 0.0, 1.0);        //
    // cairo_move_to(cr, Prb_Near_field, y1); 	cairo_line_to(cr, x3, y1+Prb_div_Ht);
    // cairo_stroke(cr);
    // cairo_set_source_rgba(cr, 1.0, 1.0, 0.0, 1.0);        //
    cairo_move_to(cr, 0, y2);
    cairo_line_to(cr, Prb_Near_field, y2);
    cairo_line_to(cr, x3, y2 - Prb_div_Ht); // cairo_stroke(cr);
    // cairo_set_source_rgba(cr, 1.0, 0.0, 0.0, 1.0);        //
    cairo_move_to(cr, Prb_Near_field, y1);
    cairo_line_to(cr, Prb_Near_field, y2);

    cairo_stroke(cr);
}

//*****************************************************************************************************
//*****************************************************************************************************
void draw_curvedac_test(cairo_t *cr) // Draw DAC Curve
{
    cairo_set_source_rgba(cr, 1.0, 1.0, 0.0, 1.0);
    for (i = 0; i < NUM_OF_VERTICES; i++)
    {
        s_x11 = (i * width_sh) / 250;
        s_x22 = ((i + 1) * width_sh) / 250;

        if (c_y[i] > 5 && c_y[i + 1] > 5) // If Y value / Height > 5 then Drwa curve else drawing is not required
        {
            s_y11 = height_sh - ((c_y[i] * height_sh) / 100);
            s_y22 = height_sh - ((c_y[i + 1] * height_sh) / 100);
            // cairo_set_source_rgba(cr, 1.0, 1.0, 0.0, 1.0);
            // cairo_set_source_rgb(cr, 1.0, 0.0, 0.0);
            cairo_move_to(cr, s_x11, s_y11);
            cairo_line_to(cr, s_x22, s_y22);
            // cairo_stroke(cr);
        }
    }
    cairo_stroke(cr);
}
//*****************************************************************************************************