#include "include/include/OpenGL.h"
#include "include/include/Dav_Sub.h"

#define NUM_OF_VERTICES 256

// extern POINT;      // POINT pntArray_DACM[NUM_OF_VERTICES];

typedef struct tagPOINT
{
    long x;
    long y;
} POINT;

extern POINT pntArray_DACM[NUM_OF_VERTICES];  // Holds data of DAC Curve main curve
extern POINT pntArray_DAC1P[NUM_OF_VERTICES]; // Holds data of DAC Curve Main Curve+dac db
extern POINT pntArray_DAC2P[NUM_OF_VERTICES]; // Holds data of DAC Curve Main Curve+ 2*dac db
extern POINT pntArray_DAC1N[NUM_OF_VERTICES]; // Holds data of DAC Curve Main Curve - dac db
extern POINT pntArray_DAC2N[NUM_OF_VERTICES]; // Holds data of DAC Curve Main Curve - 2*dac db
extern int Dac_crv_dB;
extern double Prb_Near_field, Prb_div_Ht;
extern int All_Ascan_data[1024];

extern int Asc_Max[1024];
extern uint8_t rx_cmd[1024];
extern int Asc_Width;
extern int Asc_Height;
extern int frame_width;
extern int splite_frame_height;
extern int Voff;
extern int Dgs_onoff_v, Dac_v;

extern int splite_win_flg;
extern int Asc_Clr_val;
extern int Clr_leg_sta, Clr_leg_width;
extern int Grid_v;
extern int Rectify_v;
extern int video_val; // IF Video Dynamic is selected
extern gdouble Grid_r[20], Grid_g[20], Grid_b[20];

extern float Red[20];
extern float Green[20];
extern float Blue[20];
extern int recall_read;

extern int Record_Type_val;
extern int dgsdb_crv[15];
extern int Dgs_gain;

extern gboolean Dac_Bscan_flag; // Bscan = true, Dac = false;
extern gboolean Ascan_image_snap;
extern unsigned char *Ascan_image_data; //[741][446][3]; // full Ascan area Width * Height * RGB = 741*446*3

extern int dgs_fromfile;
extern long dgs_pnt[256];
extern void Set_default_val();
extern gboolean DGS_ReadFile; // = false;

float fdiv[120];
GLubyte row_y[NUM_OF_VERTICES];

enum
{
    ATTRIBUTE_POSITION = 0,
    ATTRIBUTE_COLOR
};

GLfloat y_coord[] =
    {
        100.0f,
        100.0f,
        100.0f,
        100.0f,
        100.0f,
        60.0f,
        45.0f,
        55.0f,
        28.0f,
        33.0f,
        12.0f,
        13.0f,
        5.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        13.0f,
        37.0f,
        23.0f,
        62.0f,
        48.0f,
        74.0f,
        80.0f,
        76.0f,
        49.0f,
        54.0f,
        23.0f,
        9.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        3.0f,
        17.0f,
        27.0f,
        20.0f,
        39.0f,
        55.0f,
        43.0f,
        25.0f,
        27.0f,
        13.0f,
        5.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        8.0f,
        12.0f,
        19.0f,
        32.0f,
        40.0f,
        37.0f,
        25.0f,
        16.0f,
        9.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        3.0f,
        9.0f,
        19.0f,
        28.0f,
        20.0f,
        15.0f,
        9.0f,
        5.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
};

const struct wl_registry_listener registry_listener = {
    global_registry_handler,
    global_registry_remover};

int idx_fact = 1;
extern int Rectify_v;
gboolean bflag = true;
bool Color_update = false;

cairo_t *Ascan_cr;
cairo_surface_t *Ascan_surface;
GdkPixbuf *Ascan_pixbuf = NULL;

void select_shape(cairo_t *cr, int *offset);
void write_data_in_bsc_file(GLubyte *data);
extern void WriteDataIntoFile(char *str, int i, float data);

//************************************************************************
// OpenGL initialization function
//************************************************************************


/* --- Functions: category utils --- */

    if (Asc_Clr_val > 7)
    {
        cairo_set_source_rgb(ogl.cr, 1.0, 1.0, 1.0);
    }

    if (Asc_Clr_val > 7)
    {
        cairo_set_source_rgb(ogl.cr, 1.0, 0.0, 0.0);
    }


    if (val_ary[BEAM_PROF_PERA] == 2)
    {
        Draw_beamprofile(ogl.cr);
    }

        if (val_ary[OBJ_SHAPE_PERA] == 0)
        {
            // Draw profiler and sound path
            select_shape(ogl.cr, &profiler_cntr_line[0]);
            select_shape(ogl.cr, &ogl_profiler[1]);
            cairo_set_source_rgb(ogl.cr, 1.0, 1.0, 1.0); // Select Color for UT Beam
            select_shape(ogl.cr, &ogl_probe[0]);
            cairo_set_source_rgb(ogl.cr, 1.0, 0.0, 1.0); // Select Color for UT Beam rays
            select_shape(ogl.cr, &ogl_rays[1]);
        }

        else if (val_ary[OBJ_SHAPE_PERA] == 1 || val_ary[OBJ_SHAPE_PERA] == 2)
        {
            // Draw profiler and sound path
            select_shape(ogl.cr, &profiler_cntr_line[0]);
            select_shape(ogl.cr, &ogl_profiler[1]);
            cairo_set_source_rgb(ogl.cr, 1.0, 1.0, 1.0); // Select Color for UT Beam
            select_shape(ogl.cr, &ogl_probe[20]);
            cairo_set_source_rgb(ogl.cr, 1.0, 0.0, 1.0); // Select Color for UT Beam rays
            select_shape(ogl.cr, &ogl_rays[11]);
        }

        else if (val_ary[OBJ_SHAPE_PERA] == 3)
        {
            // Draw profiler and sound path
            select_shape(ogl.cr, &profiler_cntr_line[0]);
            select_shape(ogl.cr, &ogl_profiler[1]);
            cairo_set_source_rgb(ogl.cr, 1.0, 1.0, 1.0); // Select Color for UT Beam
            select_shape(ogl.cr, &ogl_probe[20]);
            cairo_set_source_rgb(ogl.cr, 1.0, 0.0, 1.0); // Select Color for UT Beam rays
            select_shape(ogl.cr, &ogl_rays[11]);
        }

void get_server_referance(GdkDisplay *gdk_display)
{
    // Create native display
    ogl.w_display = gdk_wayland_display_get_wl_display(gdk_display);
    if (ogl.w_display == NULL)
        printf("wl_display_connect() function is failed.\n");

    struct wl_registry *registry = wl_display_get_registry(ogl.w_display);
    wl_registry_add_listener(registry, &registry_listener, NULL);

    wl_display_dispatch(ogl.w_display);
    wl_display_roundtrip(ogl.w_display);

    if (ogl.compositor == NULL || ogl.subcompositor == NULL)
        printf("Can't find compositer or subcompositor.\n");
}


void global_registry_handler(void *data, struct wl_registry *registry, uint32_t id, const char *interface, uint32_t version)
{
    if (strcmp(interface, "wl_compositor") == 0)
        ogl.compositor = (struct wl_compositor *)wl_registry_bind(registry, id, &wl_compositor_interface, 1);
    else if (!strcmp(interface, "wl_subcompositor"))
        ogl.subcompositor = (struct wl_subcompositor *)wl_registry_bind(registry, id, &wl_subcompositor_interface, 1);
}


void global_registry_remover(void *data, struct wl_registry *registry, uint32_t id)
{
    // printf("Got a registry losing event for %d.\n", id);
}

    if (ogl.surface)
    {
        cairo_surface_destroy(ogl.surface);
        ogl.surface = 0;
    }

    if (ogl.textureColorbuffer)
    {
        glDeleteTextures(1, &ogl.textureColorbuffer);
        ogl.textureColorbuffer = 0;
    }

    if (ogl.framebuffer)
    {
        glDeleteFramebuffers(1, &ogl.framebuffer);
        ogl.framebuffer = 0;
    }

    if (ogl.vbo_position)
    {
        glDeleteBuffers(1, &ogl.vbo_position);
        ogl.vbo_position = 0;
    }

    if (ogl.vbo_color)
    {
        glDeleteBuffers(1, &ogl.vbo_color);
        ogl.vbo_color = 0;
    }

    if (ogl.ebo)
    {
        glDeleteBuffers(1, &ogl.ebo);
        ogl.ebo = 0;
    }

    if (ogl.vao)
    {
        glDeleteVertexArrays(1, &ogl.vao);
        ogl.vao = 0;
    }


    if (ogl.shader_program_object)
    {
        GLsizei shaderCount;
        GLsizei shaderNumber;

        glUseProgram(ogl.shader_program_object);
        // Ask Program How Many Shaders are Attached to you
        glGetProgramiv(ogl.shader_program_object, GL_ATTACHED_SHADERS, &shaderCount);
        GLuint *pShaders = (GLuint *)malloc(sizeof(GLuint) * shaderCount);
        if (pShaders)
        {
            glGetAttachedShaders(ogl.shader_program_object, shaderCount, &shaderCount, pShaders);
            for (shaderNumber = 0; shaderNumber < shaderCount; shaderNumber++)
            {
                glDetachShader(ogl.shader_program_object, pShaders[shaderNumber]);
                glDeleteShader(pShaders[shaderNumber]);
                pShaders[shaderNumber] = 0;
            }
            free(pShaders);
        }
        glDeleteProgram(ogl.shader_program_object);
        ogl.shader_program_object = 0;
        glUseProgram(0);
    }

        if (pShaders)
        {
            glGetAttachedShaders(ogl.shader_program_object, shaderCount, &shaderCount, pShaders);
            for (shaderNumber = 0; shaderNumber < shaderCount; shaderNumber++)
            {
                glDetachShader(ogl.shader_program_object, pShaders[shaderNumber]);
                glDeleteShader(pShaders[shaderNumber]);
                pShaders[shaderNumber] = 0;
            }
            free(pShaders);
        }


    if (ogl.egl_display != EGL_NO_DISPLAY)
    {
        eglMakeCurrent(ogl.egl_display, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
    }

    if (ogl.egl_surface != EGL_NO_SURFACE)
    {
        eglDestroySurface(ogl.egl_display, ogl.egl_surface);
        ogl.egl_surface = EGL_NO_SURFACE;
    }

    if (ogl.egl_window)
    {
        wl_egl_window_destroy(ogl.egl_window);
        ogl.egl_window = NULL;
    }

    if (ogl.subsurface)
    {
        wl_subsurface_destroy(ogl.subsurface);
        ogl.subsurface = NULL;
    }


    if (Asc_Clr_val > 7)
    {
        cairo_set_line_width(cr, 2.0);
    }

        if (Clr_leg_width < 5)
        {
            Clr_leg_width = Asc_Width;
        }

    if (s_x11 > Asc_Width)
    {
        s_x11 = Asc_Width;
    }

    if (s_x22 > Asc_Width)
    {
        s_x22 = Asc_Width;
    }

    if (s_x11 > Asc_Width)
    {
        s_x11 = Asc_Width;
    }

    if (s_x22 > Asc_Width)
    {
        s_x22 = Asc_Width;
    }

			if (i < 235 && (y1 > -1 && y2 > -1)) // if (y1 > 5 && y2 > 5)
			{
                s_y11 = y1; // + Voff; // s_y11 = height_sh - ((y1 * height_sh) / 100);
                s_y22 = y2; // + Voff;
				x1 = pntArray_DACM[i].x;
				x2 = pntArray_DACM[i + 1].x;
				x1 = (x1 * Asc_Width) / 250; // x1 = (x1 * width_sh) / 250;
				x2 = (x2 * Asc_Width) / 250; // x2 = (x2 * width_sh) / 250;
				cairo_move_to(cr, x1, s_y11);
				cairo_line_to(cr, x2, s_y22);
			}


    if (Dac_crv_dB > 0)
    {
        cairo_set_source_rgba(cr, 0.0, 0.0, 1.0, 1.0);
        for (i = 0; i < 250; i++) // FOR DAC 1 Positive curve
        {
            y1 = pntArray_DAC1P[i].y;
            y2 = pntArray_DAC1P[i + 1].y;
            if (y1 > -1 && y2 > -1) // if (y1 > 5 && y2 > 5) // If Y value / Height > 5 then Drwa curve else drawing is not required
            {
                s_y11 = y1 + Voff; // s_y11 = height_sh - ((y1 * height_sh) / 100);
                s_y22 = y2 + Voff; // s_y22 = height_sh - ((y2 * height_sh) / 100);
                x1 = pntArray_DAC1P[i].x;
                x2 = pntArray_DAC1P[i + 1].x;
                x1 = (x1 * Asc_Width) / 250;    // x1 = (x1 * width_sh) / 250;
                x2 = (x2 * Asc_Width) / 250;    // x2 = (x2 * width_sh) / 250;
                cairo_move_to(cr, x1, s_y11);
                cairo_line_to(cr, x2, s_y22);
            }
        }
        cairo_stroke(cr);
       
        for (i = 0; i < 250; i++) // FOR DAC 2 Positive curve
        {
            y1 = pntArray_DAC2P[i].y;
            y2 = pntArray_DAC2P[i + 1].y;
            if (y1 > -1 && y2 > -1) // if (y1 > 5 && y2 > 5) // If Y value / Height > 5 then Drwa curve else drawing is not required
            {
                s_y11 = y1 + Voff; // s_y11 = height_sh - ((y1 * height_sh) / 100);
                s_y22 = y2 + Voff; // s_y22 = height_sh - ((y2 * height_sh) / 100);
                x1 = pntArray_DAC2P[i].x;
                x2 = pntArray_DAC2P[i + 1].x;
                x1 = (x1 * Asc_Width) / 250;    // x1 = (x1 * width_sh) / 250;
                x2 = (x2 * Asc_Width) / 250;    // x2 = (x2 * width_sh) / 250;
                cairo_move_to(cr, x1, s_y11);
                cairo_line_to(cr, x2, s_y22);
            }
        }
        cairo_stroke(cr);

        cairo_set_source_rgba(cr, 0.0, 1.0, 1.0, 1.0);
        for (i = 0; i < 250; i++) // FOR DAC 1 Negative curve
        {
            y1 = pntArray_DAC1N[i].y;
            y2 = pntArray_DAC1N[i + 1].y;
            if (y1 > -1 && y2 > -1) // if (y1 > 5 && y2 > 5) // If Y value / Height > 5 then Drwa curve else drawing is not required
            {
                s_y11 = y1 + Voff; // s_y11 = height_sh - ((y1 * height_sh) / 100);
                s_y22 = y2 + Voff; // s_y22 = height_sh - ((y2 * height_sh) / 100);
                x1 = pntArray_DAC1N[i].x;
                x2 = pntArray_DAC1N[i + 1].x;
                x1 = (x1 * Asc_Width) / 250;    // x1 = (x1 * width_sh) / 250;
                x2 = (x2 * Asc_Width) / 250;    // x2 = (x2 * width_sh) / 250;
                cairo_move_to(cr, x1, s_y11);
                cairo_line_to(cr, x2, s_y22);
            }
        }
        cairo_stroke(cr);

        for (i = 0; i < 250; i++) // FOR DAC 2 Negative curve
        {
            y1 = pntArray_DAC2N[i].y;
            y2 = pntArray_DAC2N[i + 1].y;
            if (y1 > -1 && y2 > -1) // if (y1 > 5 && y2 > 5) // If Y value / Height > 5 then Drwa curve else drawing is not required
            {
                s_y11 = y1 + Voff; // s_y11 = height_sh - ((y1 * height_sh) / 100);
                s_y22 = y2 + Voff; // s_y22 = height_sh - ((y2 * height_sh) / 100);
                x1 = pntArray_DAC2N[i].x;
                x2 = pntArray_DAC2N[i + 1].x;
                x1 = (x1 * Asc_Width) / 250;    // x1 = (x1 * width_sh) / 250;
                x2 = (x2 * Asc_Width) / 250;    // x2 = (x2 * width_sh) / 250;
                cairo_move_to(cr, x1, s_y11);
                cairo_line_to(cr, x2, s_y22);
             }
        }
        cairo_stroke(cr);                                                                                   
    }


}

//*****************************************************************************************************
//*****************************************************************************************************
void Draw_beamprofile(cairo_t *cr) // If Beam Profile is ON then Draw it
{
    int x3, y1, y2, wd; // ,y3;
    x3 = Asc_Width;
    y1 = 20;
    y2 = 20;
    wd = 20;
    // Prb_div_Ht
    cairo_set_source_rgba(cr, 1.0, 1.0, 0.0, 1.0); //
    y1 = 200 + wd;
    y2 = 200 - wd;
    cairo_move_to(cr, 0, y1);
    cairo_line_to(cr, Prb_Near_field, y1);
    cairo_line_to(cr, x3, y1 + Prb_div_Ht); // cairo_stroke(cr);
    // cairo_set_source_rgba(cr, 1.0, 0.0, 0.0, 1.0);        //
    // cairo_move_to(cr, Prb_Near_field, y1); 	cairo_line_to(cr, x3, y1+Prb_div_Ht);
    // cairo_stroke(cr);
    // cairo_set_source_rgba(cr, 1.0, 1.0, 0.0, 1.0);        //
    cairo_move_to(cr, 0, y2);
    cairo_line_to(cr, Prb_Near_field, y2);
    cairo_line_to(cr, x3, y2 - Prb_div_Ht); // cairo_stroke(cr);
    // cairo_set_source_rgba(cr, 1.0, 0.0, 0.0, 1.0);        //
    cairo_move_to(cr, Prb_Near_field, y1);
    cairo_line_to(cr, Prb_Near_field, y2);

    cairo_stroke(cr);
}

//*****************************************************************************************************
//*****************************************************************************************************
void draw_curvedac_test(cairo_t *cr) // Draw DAC Curve
{
    cairo_set_source_rgba(cr, 1.0, 1.0, 0.0, 1.0);
    for (i = 0; i < NUM_OF_VERTICES; i++)
    {
        s_x11 = (i * width_sh) / 250;
        s_x22 = ((i + 1) * width_sh) / 250;

        if (c_y[i] > 5 && c_y[i + 1] > 5) // If Y value / Height > 5 then Drwa curve else drawing is not required
        {
            s_y11 = height_sh - ((c_y[i] * height_sh) / 100);
            s_y22 = height_sh - ((c_y[i + 1] * height_sh) / 100);
            // cairo_set_source_rgba(cr, 1.0, 1.0, 0.0, 1.0);
            // cairo_set_source_rgb(cr, 1.0, 0.0, 0.0);
            cairo_move_to(cr, s_x11, s_y11);
            cairo_line_to(cr, s_x22, s_y22);
            // cairo_stroke(cr);
        }
    }
    cairo_stroke(cr);
}
//*****************************************************************************************************