#include "include/include/OpenGL.h"
#include "include/include/Dav_Sub.h"

#define NUM_OF_VERTICES 256

// extern POINT;      // POINT pntArray_DACM[NUM_OF_VERTICES];

typedef struct tagPOINT
{
    long x;
    long y;
} POINT;

extern POINT pntArray_DACM[NUM_OF_VERTICES];  // Holds data of DAC Curve main curve
extern POINT pntArray_DAC1P[NUM_OF_VERTICES]; // Holds data of DAC Curve Main Curve+dac db
extern POINT pntArray_DAC2P[NUM_OF_VERTICES]; // Holds data of DAC Curve Main Curve+ 2*dac db
extern POINT pntArray_DAC1N[NUM_OF_VERTICES]; // Holds data of DAC Curve Main Curve - dac db
extern POINT pntArray_DAC2N[NUM_OF_VERTICES]; // Holds data of DAC Curve Main Curve - 2*dac db
extern int Dac_crv_dB;
extern double Prb_Near_field, Prb_div_Ht;
extern int All_Ascan_data[1024];

extern int Asc_Max[1024];
extern uint8_t rx_cmd[1024];
extern int Asc_Width;
extern int Asc_Height;
extern int frame_width;
extern int splite_frame_height;
extern int Voff;
extern int Dgs_onoff_v, Dac_v;

extern int splite_win_flg;
extern int Asc_Clr_val;
extern int Clr_leg_sta, Clr_leg_width;
extern int Grid_v;
extern int Rectify_v;
extern int video_val; // IF Video Dynamic is selected
extern gdouble Grid_r[20], Grid_g[20], Grid_b[20];

extern float Red[20];
extern float Green[20];
extern float Blue[20];
extern int recall_read;

extern int Record_Type_val;
extern int dgsdb_crv[15];
extern int Dgs_gain;

extern gboolean Dac_Bscan_flag; // Bscan = true, Dac = false;
extern gboolean Ascan_image_snap;
extern unsigned char *Ascan_image_data; //[741][446][3]; // full Ascan area Width * Height * RGB = 741*446*3

extern int dgs_fromfile;
extern long dgs_pnt[256];
extern void Set_default_val();
extern gboolean DGS_ReadFile; // = false;

float fdiv[120];
GLubyte row_y[NUM_OF_VERTICES];

enum
{
    ATTRIBUTE_POSITION = 0,
    ATTRIBUTE_COLOR
};

GLfloat y_coord[] =
    {
        100.0f,
        100.0f,
        100.0f,
        100.0f,
        100.0f,
        60.0f,
        45.0f,
        55.0f,
        28.0f,
        33.0f,
        12.0f,
        13.0f,
        5.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        13.0f,
        37.0f,
        23.0f,
        62.0f,
        48.0f,
        74.0f,
        80.0f,
        76.0f,
        49.0f,
        54.0f,
        23.0f,
        9.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        3.0f,
        17.0f,
        27.0f,
        20.0f,
        39.0f,
        55.0f,
        43.0f,
        25.0f,
        27.0f,
        13.0f,
        5.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        8.0f,
        12.0f,
        19.0f,
        32.0f,
        40.0f,
        37.0f,
        25.0f,
        16.0f,
        9.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        3.0f,
        9.0f,
        19.0f,
        28.0f,
        20.0f,
        15.0f,
        9.0f,
        5.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
        0.0f,
};

const struct wl_registry_listener registry_listener = {
    global_registry_handler,
    global_registry_remover};

int idx_fact = 1;
extern int Rectify_v;
gboolean bflag = true;
bool Color_update = false;

cairo_t *Ascan_cr;
cairo_surface_t *Ascan_surface;
GdkPixbuf *Ascan_pixbuf = NULL;

void select_shape(cairo_t *cr, int *offset);
void write_data_in_bsc_file(GLubyte *data);
extern void WriteDataIntoFile(char *str, int i, float data);

//************************************************************************
// OpenGL initialization function
//************************************************************************


/* --- Functions: category render --- */

void ogl_render(int width, int height)
{ 
    if (splite_win_flg > 0) // Window is Split
    {
        height = height / 2;
    } // height=height_sh;

    glBlitFramebuffer(0, 0, width, height, // Source x, y, width and height
                      0, height, width, 0, // Dest x, y, width and height
                      GL_COLOR_BUFFER_BIT, GL_NEAREST);

    // Start using OpenGL shader program object
    glUseProgram(ogl.shader_program_object);

    glLineWidth(2.0f);
    
    if (val_ary[SET_REF_PERA] == 1)
    {
        glBindVertexArray(ogl.vao_peak);
        glBindBuffer(GL_ARRAY_BUFFER, ogl.vbo_pos_peak);
        glBufferData(GL_ARRAY_BUFFER, sizeof(All_Ascan_peak), All_Ascan_peak, GL_DYNAMIC_DRAW);
        glVertexAttribPointer(ATTRIBUTE_POSITION, 2, GL_FLOAT, GL_FALSE, 0, NULL);
        glEnableVertexAttribArray(ATTRIBUTE_POSITION);

        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ogl.ebo_peak);
        glDrawElements(GL_LINE_STRIP, 511, GL_UNSIGNED_SHORT, 0); // All_Ascan_peak_index array size is 510
        glBindVertexArray(0);
    }
    
    // Bind vao
    glBindVertexArray(ogl.vao);
    glBindBuffer(GL_ARRAY_BUFFER, ogl.vbo_position);
    glBufferData(GL_ARRAY_BUFFER, sizeof(ogl.vertices_position), ogl.vertices_position, GL_DYNAMIC_DRAW);
    glVertexAttribPointer(ATTRIBUTE_POSITION, 2, GL_FLOAT, GL_FALSE, 0, NULL);
    glEnableVertexAttribArray(ATTRIBUTE_POSITION);

    if (Color_update == true) // Bind vbo buffer
    {
        Color_update = false;
        glBindBuffer(GL_ARRAY_BUFFER, ogl.vbo_color);
        glBufferData(GL_ARRAY_BUFFER, sizeof(ogl.vertices_color), ogl.vertices_color, GL_DYNAMIC_DRAW);
        glVertexAttribPointer(ATTRIBUTE_COLOR, 3, GL_FLOAT, GL_FALSE, 0, NULL);
        glEnableVertexAttribArray(ATTRIBUTE_COLOR);
    }

    int noof_pnt = NUM_OF_VERTICES;
    if (video_val == 1)
    {
        noof_pnt = 768;
    }
    
    if (video_val == 2) // IF Video Dynamic is selected
    {
        glDrawArrays(GL_LINE_STRIP, 768, NUM_OF_VERTICES);
    } // glDrawArrays(GL_LINE_STRIP,NUM_OF_VERTICES,250); }

    
    if (val_ary[SET_REF_PERA] == 1)
    {
        glBindVertexArray(ogl.vao_peak);
        glBindBuffer(GL_ARRAY_BUFFER, ogl.vbo_pos_peak);
        glBufferData(GL_ARRAY_BUFFER, sizeof(All_Ascan_peak), All_Ascan_peak, GL_DYNAMIC_DRAW);
        glVertexAttribPointer(ATTRIBUTE_POSITION, 2, GL_FLOAT, GL_FALSE, 0, NULL);
        glEnableVertexAttribArray(ATTRIBUTE_POSITION);

        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ogl.ebo_peak);
        glDrawElements(GL_LINE_STRIP, 511, GL_UNSIGNED_SHORT, 0); // All_Ascan_peak_index array size is 510
        glBindVertexArray(0);
    }


}

//*****************************************************************************************************
//*****************************************************************************************************
void Draw_beamprofile(cairo_t *cr) // If Beam Profile is ON then Draw it
{
    int x3, y1, y2, wd; // ,y3;
    x3 = Asc_Width;
    y1 = 20;
    y2 = 20;
    wd = 20;
    // Prb_div_Ht
    cairo_set_source_rgba(cr, 1.0, 1.0, 0.0, 1.0); //
    y1 = 200 + wd;
    y2 = 200 - wd;
    cairo_move_to(cr, 0, y1);
    cairo_line_to(cr, Prb_Near_field, y1);
    cairo_line_to(cr, x3, y1 + Prb_div_Ht); // cairo_stroke(cr);
    // cairo_set_source_rgba(cr, 1.0, 0.0, 0.0, 1.0);        //
    // cairo_move_to(cr, Prb_Near_field, y1); 	cairo_line_to(cr, x3, y1+Prb_div_Ht);
    // cairo_stroke(cr);
    // cairo_set_source_rgba(cr, 1.0, 1.0, 0.0, 1.0);        //
    cairo_move_to(cr, 0, y2);
    cairo_line_to(cr, Prb_Near_field, y2);
    cairo_line_to(cr, x3, y2 - Prb_div_Ht); // cairo_stroke(cr);
    // cairo_set_source_rgba(cr, 1.0, 0.0, 0.0, 1.0);        //
    cairo_move_to(cr, Prb_Near_field, y1);
    cairo_line_to(cr, Prb_Near_field, y2);

    cairo_stroke(cr);
}

//*****************************************************************************************************
//*****************************************************************************************************
void draw_curvedac_test(cairo_t *cr) // Draw DAC Curve
{
    cairo_set_source_rgba(cr, 1.0, 1.0, 0.0, 1.0);
    for (i = 0; i < NUM_OF_VERTICES; i++)
    {
        s_x11 = (i * width_sh) / 250;
        s_x22 = ((i + 1) * width_sh) / 250;

        if (c_y[i] > 5 && c_y[i + 1] > 5) // If Y value / Height > 5 then Drwa curve else drawing is not required
        {
            s_y11 = height_sh - ((c_y[i] * height_sh) / 100);
            s_y22 = height_sh - ((c_y[i + 1] * height_sh) / 100);
            // cairo_set_source_rgba(cr, 1.0, 1.0, 0.0, 1.0);
            // cairo_set_source_rgb(cr, 1.0, 0.0, 0.0);
            cairo_move_to(cr, s_x11, s_y11);
            cairo_line_to(cr, s_x22, s_y22);
            // cairo_stroke(cr);
        }
    }
    cairo_stroke(cr);
}
//*****************************************************************************************************