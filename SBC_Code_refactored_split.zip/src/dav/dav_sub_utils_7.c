/*cd /f/Dahlia-Verdin/GTK*/
/* RUN BAT FILE TO EXECUTE PROGRAM --> bash ./gtkboardapp_run.bat*/
/* gcc gtkrow.c src/src/OpenGL.c -o Main `pkg-config --cflags --libs gtk+-3.0` -lm -lwayland-client -lwayland-server -lwayland-egl -lEGL -lGLESv2 */
/* $CC gtkrow.c src/src/OpenGL.c -o Main `pkg-config --cflags --libs gtk+-3.0` -lm -lwayland-client -lwayland-server -lwayland-egl -lEGL -lGLESv2 */
/* $CC gtkrow.c src/src/OpenGL.c -o Main `pkg-config --cflags --libs gtk+-3.0` -lgpiod -lm -lwayland-client -lwayland-server -lwayland-egl -lEGL -lGLESv2 */
/* $CC src/src/Dav_Sub.c src/src/OpenGL.c -o Main `pkg-config --cflags --libs gtk+-3.0` -lgpiod -lm -lwayland-client -lwayland-server -lwayland-egl -lEGL -lGLESv2 */

// cd /mnt/e/2024/08-August_2024/2024-08-21/Dav_Sub
/*  bash Build_For_brd.sh */ // Use this command to Build the application to run on Board
//
//   bash ./Build_For_WSL.sh     // Build for WSL  Environment setti is not rquired
//   cd /mnt/d/
//  cd WSL_Wayland_Proj/WSL_Prog/Dav_Sub/Dav_Sub
//  . /opt/tdx-xwayland/5.7.1/environment-setup-aarch64-tdx-linux
//    which pkg-config
//    /opt/tdx-xwayland/5.7.1/sysroots/x86_64-tdxsdk-linux/usr/bin/pkg-config
//    bash Build_For_brd.sh
//    export DISPLAY=172.23.144.1:0 && export XDG_RUNTIME_DIR=/tmp/xdg && export RUNLEVEL=3 && weston

//   setup=setenv setupargs console=tty1 console=${console},${baudrate} consoleblank=0 earlycon   // set environment as below so during boot console command would not get display on screen
//   setenv setup 'setenv setupargs vt.global_cursor_default=0 console=${console},${baudrate} consoleblank=0 earlycon'
//   setenv setup 'setenv setupargs console=${console},${baudrate} consoleblank=0 earlycon'
// setenv setup 'setenv setupargs fec_mac=${ethaddr} consoleblank=0 no_console_suspend=1 console=${console},${baudrate}n8'
// setenv -> saveenv -> reset
// WSL UBUNTU PATH FROM PROGRAM FOR TESTING PURPOSE = fopen("/home/rnd1/temp1", "r"))
// CHECK DISK SPACE = df -H // To check storage in linux 

#ifdef WIN32
#include <io.h>
#define F_OK 0
#define access _access
#endif

#include <stdio.h>
#include <include/include/gpiod.h> // For WSL it is required to install libgpiod using following command in Ubuntu sudo apt-get install libgpiod-dev
#include <string.h>
#include <stdlib.h>
#include <stdint.h>
#include <math.h>
#include <stdbool.h>
#include <stdint.h>
#include <cairo.h>
#include <cairo-pdf.h>

#include <gtk/gtk.h>

#include "include/include/gtkdeclarations.h"
#include "include/include/Dav_Sub.h"
#include "include/include/dataval.h"
#include "include/include/cbentry.h"
#include "include/include/cbentry_safe1.h"
#include "include/include/OpenGL.h"
#include "include/include/shp_prf.h"
#include "include/include/Ruler.h"
#include "include/include/thick_log.h"
#include "include/include/plot_data.h"

#include <unistd.h>
#include <getopt.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <sys/wait.h>
#include <linux/types.h>
#include <linux/spi/spidev.h>

// #define ARRAY_SIZE(a) (sizeof(a) / sizeof((a)[0]))

gdouble Scr_stp_pre = 10.0;
int fd_SPI;

bool Spi_test = true;
struct OGLData ogl;

int Key_ck = 100;  // Key Check timer counter
int Key_Delay = 0; // Key Delay time control
bool Key_press = false;
int Measure_dsp = 0, Batt_dsp = 0, Batt_val = 0; // Measurement Display rate is controlle by this value
extern int tx_bufidx;
extern int Key_Scn_code;
extern int Key_stp;
extern GLubyte row_y[256];

extern cairo_t *Ascan_cr;
extern cairo_surface_t *Ascan_surface;
extern GdkPixbuf *Ascan_pixbuf;

void Keypad_rd(); // Read Keypad Data
void Read_rd();	  // Read Keypad Data
void Read_rd2();
void Read_Peak_amp();

void Init_all();
int Init_SPI(); // int main(int argc, char *argv[])  //int main(int argc, char *argv[])

void Start_up_Scr();
void Key_function();
void Keypad_ck(); // Read Keypad Data
void Send_SPI(int tx_nofd);
void Send_filt();
void Check_1K();
void Get_Data(); // Transfer data to Opengl Buffer from SPI Buffer
void Send_Data_to_OpenGL(void);
void Smooth_Asc();
void SPI_Receive(); // Receive Data using SPI

void DAC_Copy_for_Disp(int crvno); // Copy DAC points data for the Display
void Cal_Tval();
void Hruler_update();
void Vruler_update();

gboolean Key_perform_F(int keycodet);


/* --- Functions: category utils --- */


		if (pfile)
		{
			fclose(pfile);
			pfile = NULL;
		}

	if (f_h)
	{
		fclose(f_h);
		f_h = NULL;
	}

	if (f_h)
	{
		fclose(f_h);
		f_h = NULL;
	}

			if (ch != 32)
			{
				line_flag = true;
			}

	if (Dgs_onoff_v == 3)
	{
		dgs_fromfile = 1;
	}


	if (file_h)
	{
		fclose(file_h);
		file_h = NULL;
	}

			if (ch != 32)
			{
				line_flag = true;
			}


	if (f_h)
	{
		fclose(f_h);
		f_h = NULL;
	}

			if (ch != 32)
			{
				line_flag = true;
			}


	if (file_h)
	{
		fclose(file_h);
		file_h = NULL;
	}


	if (menu_v == 14 || menu_v == 15 && key_scr == 1)
	{
		sprintf(dtm_values[0], "%02d", val_ary[MINUTE_v]);
		sprintf(dtm_values[1], "%02d", val_ary[HOUR_v]);
		sprintf(dtm_values[2], "%02d", val_ary[DAY_v]);
		sprintf(dtm_values[3], "%02d", val_ary[MONTH_v]);
		sprintf(dtm_values[4], "%04d", val_ary[YEAR_v]);
	}


void chng_year()
{
	draw_time();
	n_pximage[6] = gdk_pixbuf_new_from_file_at_scale(imagename[6], image_dy, image_h, false, NULL);
	gtk_image_set_from_pixbuf(GTK_IMAGE(n_image[6]), n_pximage[6]);
	gtk_widget_set_size_request(GTK_WIDGET(n_image[6]), image_w, image_h);
}

void Creat_bk_img(int imgset, int imgset2)
{
	int imgid, i;
	char buffer[40];

	char MeaTxt[35][6] = {
						  "SPa",  "DPa",  "SDa",   "Ea",	// Gate A
						  "SPb",  "DPb",  "SDb",   "Eb",	// Gate B
						  "DAC",  "C dB", "  ",    "",		// DAC
						  "RG",   "IL",   "AF",    "RT",	// AWS
						  "ERS",  "C dB",  "DGS c", "",     // DGS
						  "E1",   "",   "",    "",    		// ENCODER
						};

	cairo_t *cr;
	imgset = imgset - 1;
	if (imgset < 0)
	{
		imgset = 0;
	}
	if (imgset == 2) //  Check DAC,DGS,AWS
	{
		if (Evaluate_val == 0)
		{
			imgset = 2;
		} // DAC is Selected
		if (Evaluate_val == 1)
		{
			imgset = 3;
		} // AWS is Selected
		if (Evaluate_val == 2)
		{
			imgset = 4;
		} // DGS is Selected
	}
	imgid = imgset * 4;

	cairo_surface_t *surface = cairo_image_surface_create(CAIRO_FORMAT_RGB24, tsbtn_width, btntop_height);
	cr = cairo_create(surface);
	for (i = 0; i < 4; i++)
	{
		cairo_set_source_rgb(cr, 0.234, 0.41, 0.88); // Set Background Color
		//cairo_set_source_rgb(cr, 1.0, 1.0, 1.0);
		if (Theme_color_val == 0)
		{
			//cairo_set_source_rgb(cr, 1.0, 1.0, 1.0); // UNCOMMENT TO MAKE THE MEASURE READING BUTTON WHITE
			cairo_set_source_rgb(cr, 0.0, 0.0, 0.0);
		} // Royal Blue Back Ground
		if (Theme_color_val == 1)
		{
			//cairo_set_source_rgb(cr, 1.0, 1.0, 1.0); // UNCOMMENT TO MAKE THE MEASURE READING BUTTON WHITE
			
			cairo_set_source_rgb(cr, 0.234, 0.41, 0.88);
		} // Black Ground
		if (Theme_color_val == 2)
		{
			//cairo_set_source_rgb(cr, 1.0, 1.0, 1.0); // UNCOMMENT TO MAKE THE MEASURE READING BUTTON WHITE
			cairo_set_source_rgb(cr, 1.0, 0.55, 0.0);
		} // Dark Orange

		cairo_paint(cr);
		cairo_select_font_face(cr, "Purisa", CAIRO_FONT_SLANT_NORMAL, CAIRO_FONT_WEIGHT_BOLD); // CAIRO_FONT_WEIGHT_NORMAL
		
		//  Set Font Color
		cairo_set_source_rgb(cr, 1.0, 0.0, 0.0);
		if (Theme_color_val == 0)
		{
			cairo_set_source_rgb(cr, 1.0, 1.0, 1.0);
			// cairo_set_source_rgb(cr, 1.0, 0.0, 0.0);
		} // Royal Blue Back Ground
		if (Theme_color_val == 1)
		{
			cairo_set_source_rgb(cr, 1.0, 0.0, 0.0);
		} // Black Ground
		if (Theme_color_val == 2)
		{
			cairo_set_source_rgb(cr, 0.0, 0.0, 0.0);
		} // Dark Orange

		cairo_set_font_size(cr, 15 + 5);
		cairo_move_to(cr, 5, 22);

		cairo_show_text(cr, MeaTxt[imgid++]); // if (Measure_v1 == 0)
		cairo_fill(cr);
		sprintf(Dsp_Str, "btnimg%d_%d.png", imgset2, i + 1);

		cairo_surface_write_to_png(surface, Dsp_Str);	
		if (Measure_v1 == 0) // This is MEA_POSI1 == OFF condition, Display nothing
		{
			cairo_surface_write_to_png(surface, "        ");

			gtk_label_set_label(GTK_LABEL(t_label[0]), "      ");
			gtk_label_set_label(GTK_LABEL(t_label[1]), "      ");
			gtk_label_set_label(GTK_LABEL(t_label[2]), "      ");
			gtk_label_set_label(GTK_LABEL(t_label[3]), "      ");
		}

		if (Measure_v2 == 0)  // This is MEA_POSI2 == OFF condition
		{
			cairo_surface_write_to_png(surface, "        ");

			gtk_label_set_label(GTK_LABEL(s_label[0]), "      ");
			gtk_label_set_label(GTK_LABEL(s_label[1]), "      ");
			gtk_label_set_label(GTK_LABEL(s_label[2]), "      ");
			gtk_label_set_label(GTK_LABEL(s_label[3]), "      ");
		}			
	}

	// Colour_Theme(Theme_color_val);               // Color theme of Screen
}

	if (imgset < 0)
	{
		imgset = 0;
	}

	if (imgset == 2) //  Check DAC,DGS,AWS
	{
		if (Evaluate_val == 0)
		{
			imgset = 2;
		} // DAC is Selected
		if (Evaluate_val == 1)
		{
			imgset = 3;
		} // AWS is Selected
		if (Evaluate_val == 2)
		{
			imgset = 4;
		} // DGS is Selected
	}

		if (Evaluate_val == 1)
		{
			imgset = 3;
		}

		if (Evaluate_val == 2)
		{
			imgset = 4;
		}

		if (Theme_color_val == 0)
		{
			//cairo_set_source_rgb(cr, 1.0, 1.0, 1.0); // UNCOMMENT TO MAKE THE MEASURE READING BUTTON WHITE
			cairo_set_source_rgb(cr, 0.0, 0.0, 0.0);
		}

		if (Theme_color_val == 1)
		{
			//cairo_set_source_rgb(cr, 1.0, 1.0, 1.0); // UNCOMMENT TO MAKE THE MEASURE READING BUTTON WHITE
			
			cairo_set_source_rgb(cr, 0.234, 0.41, 0.88);
		}

		if (Theme_color_val == 2)
		{
			//cairo_set_source_rgb(cr, 1.0, 1.0, 1.0); // UNCOMMENT TO MAKE THE MEASURE READING BUTTON WHITE
			cairo_set_source_rgb(cr, 1.0, 0.55, 0.0);
		}

		if (Theme_color_val == 0)
		{
			cairo_set_source_rgb(cr, 1.0, 1.0, 1.0);
			// cairo_set_source_rgb(cr, 1.0, 0.0, 0.0);
		}



//void DetectUsb()  //Detect the usb
//{
//	FILE* f;
//	if (f = popen("mount | grep /media/sda", "r"))
//	{
//		if (NULL != f)
//		{
//			if (EOF == fgetc(f))
//			{
//				//gtk_widget_hide(nframe[9]);
//				gtk_widget_hide(n_image[8]);
//				usb_val = 0;
//			}
//			else
//			{
//				//gtk_widget_show(nframe[9]);
//				gtk_widget_show(n_image[8]);
//				strcpy(pendrv_path, "/media/sda/");
//				usb_val = 1;
//			}
//			pclose(f); /* close the command file */
//		}
//	}
//	else if (f = popen("mount | grep /media/sda1", "r"))
//	{
//		if (NULL != f)
//		{
//			if (EOF == fgetc(f))
//			{
//				//gtk_widget_hide(nframe[9]);
//				gtk_widget_hide(n_image[8]);
//				usb_val = 0;
//			}
//			else
//			{
//				//gtk_widget_show(nframe[9]);
//				gtk_widget_show(n_image[8]);
//				strcpy(pendrv_path, "/media/sda1/");
//				usb_val = 1;
//			}
//			pclose(f); 	/* close the command file */
//		}
//	}
//	else if (f = popen("mount | grep /media/sdb", "r"))
//	{
//		if (NULL != f)
//		{
//			if (EOF == fgetc(f))
//			{
//				//gtk_widget_hide(nframe[9]);
//				gtk_widget_hide(n_image[8]);
//				usb_val = 0;
//			}
//			else
//			{
//				//gtk_widget_show(nframe[9]);
//				gtk_widget_show(n_image[8]);
//				strcpy(pendrv_path, "/media/sdb/");
//				usb_val = 1;
//			}
//			pclose(f); /* close the command file */
//		}
//	}
//	else if (f = popen("mount | grep /media/sdb1", "r"))
//	{
//		if (NULL != f)
//		{
//			if (EOF == fgetc(f))
//			{
//				//gtk_widget_hide(nframe[9]);
//				gtk_widget_hide(n_image[8]);
//				usb_val = 0;
//			}
//			else
//			{
//				//gtk_widget_show(nframe[9]);
//				gtk_widget_show(n_image[8]);
//				strcpy(pendrv_path, "/media/sdb1/");
//				usb_val = 1;
//			}
//			pclose(f); /* close the command file */
//		}
//	}
//	return;
//}

//void DetectUsb()  //Detect the usb
//{
//	//Copy_All();
//	FILE* f;
//	//if (f = popen("mount | grep /home/rnd1/temp1", "r")) //fopen(path_h, "r");
//	if (f = fopen("/home/rnd1/temp1", "r"))
//	{
//		if (NULL != f)
//		{
//			/* test if something has been output by the command */
//			//if (EOF == fgetc(f))
//			if (feof(f))
//			{
//				gtk_widget_hide(nframe[9]);
//				usb_val = 0;
//				//puts("\n/dev/sda1 is NOT mounted");
//			}
//			else
//			{
//				gtk_widget_show(nframe[9]);
//				strcpy(pendrv_path, "/home/rnd1/temp1");
//				//pendrv_path
//				usb_val = 1;
//				//puts("\n/dev/sda1 is mounted");
//			}
//			/* close the command file */
//			//pclose(f);
//			fclose(f);
//		}
//	}
//	//else if (f = popen("mount | grep /home/rnd1/temp2", "r")) // else if (f = fopen("Cal", "r"))
//	else if (f = fopen("/home/rnd1/temp2", "r"))
//	{
//		if (NULL != f)
//		{
//			/* test if something has been output by the command */
//			//if (EOF == fgetc(f))
//			if (feof(f))
//			{
//				gtk_widget_hide(nframe[9]);
//				usb_val = 0;
//				//puts("\n/dev/sda1 is NOT mounted");
//			}
//			else
//			{
//				gtk_widget_show(nframe[9]);
//				strcpy(pendrv_path, "/home/rnd1/temp2");
//				usb_val = 1;
//				//puts("\n/dev/sda1 is mounted");
//			}
//			/* close the command file */
//			//pclose(f);
//			fclose(f);
//		}
//	}
//	return;
//}


void Reset_DGSDAC() // To Reset the DAC and DGS after reading from file
{
	int key_v = 0;
	dgs_fromfile = 0;
	reset_value = 1;
	Set_default_val();

	Dac_f(key_v);
	STARTa_f(key_v);
	Point_f(key_v);
	press_f(key_v);

	Size_Eval_Select_f(key_v); // MENU 12

	Size_Eval_f(key_v);	 // MENU 4   // To be review
	Size_Eval_f1(key_v); // To be review
	Size_Eval_f2(key_v); // To be review
	Size_Eval_f3(key_v); // To be review
}


/****************************************************************************/
/***********************SET THE BOTTOM BUTTON'S******************************/
	/*for (i = 0; i < 5; i++)
	{
		b_btn[i] = gtk_button_new();
		b_label[i] = gtk_label_new(b_ary[i]);
		gtk_container_add(GTK_CONTAINER(b_btn[i]), b_label[i]);
		gtk_label_set_max_width_chars(GTK_LABEL(b_label[i]), 8);
		gtk_label_set_ellipsize(GTK_LABEL(b_label[i]), PANGO_ELLIPSIZE_END);
		gtk_widget_set_halign(GTK_WIDGET(b_label[i]), GTK_ALIGN_CENTER);
		gtk_widget_set_size_request(b_btn[i], button_width, button_height);
		gtk_widget_set_name(b_btn[i], bbtn_css[i]);
	}*/