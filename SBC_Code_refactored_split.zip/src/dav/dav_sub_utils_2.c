/*cd /f/Dahlia-Verdin/GTK*/
/* RUN BAT FILE TO EXECUTE PROGRAM --> bash ./gtkboardapp_run.bat*/
/* gcc gtkrow.c src/src/OpenGL.c -o Main `pkg-config --cflags --libs gtk+-3.0` -lm -lwayland-client -lwayland-server -lwayland-egl -lEGL -lGLESv2 */
/* $CC gtkrow.c src/src/OpenGL.c -o Main `pkg-config --cflags --libs gtk+-3.0` -lm -lwayland-client -lwayland-server -lwayland-egl -lEGL -lGLESv2 */
/* $CC gtkrow.c src/src/OpenGL.c -o Main `pkg-config --cflags --libs gtk+-3.0` -lgpiod -lm -lwayland-client -lwayland-server -lwayland-egl -lEGL -lGLESv2 */
/* $CC src/src/Dav_Sub.c src/src/OpenGL.c -o Main `pkg-config --cflags --libs gtk+-3.0` -lgpiod -lm -lwayland-client -lwayland-server -lwayland-egl -lEGL -lGLESv2 */

// cd /mnt/e/2024/08-August_2024/2024-08-21/Dav_Sub
/*  bash Build_For_brd.sh */ // Use this command to Build the application to run on Board
//
//   bash ./Build_For_WSL.sh     // Build for WSL  Environment setti is not rquired
//   cd /mnt/d/
//  cd WSL_Wayland_Proj/WSL_Prog/Dav_Sub/Dav_Sub
//  . /opt/tdx-xwayland/5.7.1/environment-setup-aarch64-tdx-linux
//    which pkg-config
//    /opt/tdx-xwayland/5.7.1/sysroots/x86_64-tdxsdk-linux/usr/bin/pkg-config
//    bash Build_For_brd.sh
//    export DISPLAY=172.23.144.1:0 && export XDG_RUNTIME_DIR=/tmp/xdg && export RUNLEVEL=3 && weston

//   setup=setenv setupargs console=tty1 console=${console},${baudrate} consoleblank=0 earlycon   // set environment as below so during boot console command would not get display on screen
//   setenv setup 'setenv setupargs vt.global_cursor_default=0 console=${console},${baudrate} consoleblank=0 earlycon'
//   setenv setup 'setenv setupargs console=${console},${baudrate} consoleblank=0 earlycon'
// setenv setup 'setenv setupargs fec_mac=${ethaddr} consoleblank=0 no_console_suspend=1 console=${console},${baudrate}n8'
// setenv -> saveenv -> reset
// WSL UBUNTU PATH FROM PROGRAM FOR TESTING PURPOSE = fopen("/home/rnd1/temp1", "r"))
// CHECK DISK SPACE = df -H // To check storage in linux 

#ifdef WIN32
#include <io.h>
#define F_OK 0
#define access _access
#endif

#include <stdio.h>
#include <include/include/gpiod.h> // For WSL it is required to install libgpiod using following command in Ubuntu sudo apt-get install libgpiod-dev
#include <string.h>
#include <stdlib.h>
#include <stdint.h>
#include <math.h>
#include <stdbool.h>
#include <stdint.h>
#include <cairo.h>
#include <cairo-pdf.h>

#include <gtk/gtk.h>

#include "include/include/gtkdeclarations.h"
#include "include/include/Dav_Sub.h"
#include "include/include/dataval.h"
#include "include/include/cbentry.h"
#include "include/include/cbentry_safe1.h"
#include "include/include/OpenGL.h"
#include "include/include/shp_prf.h"
#include "include/include/Ruler.h"
#include "include/include/thick_log.h"
#include "include/include/plot_data.h"

#include <unistd.h>
#include <getopt.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <sys/wait.h>
#include <linux/types.h>
#include <linux/spi/spidev.h>

// #define ARRAY_SIZE(a) (sizeof(a) / sizeof((a)[0]))

gdouble Scr_stp_pre = 10.0;
int fd_SPI;

bool Spi_test = true;
struct OGLData ogl;

int Key_ck = 100;  // Key Check timer counter
int Key_Delay = 0; // Key Delay time control
bool Key_press = false;
int Measure_dsp = 0, Batt_dsp = 0, Batt_val = 0; // Measurement Display rate is controlle by this value
extern int tx_bufidx;
extern int Key_Scn_code;
extern int Key_stp;
extern GLubyte row_y[256];

extern cairo_t *Ascan_cr;
extern cairo_surface_t *Ascan_surface;
extern GdkPixbuf *Ascan_pixbuf;

void Keypad_rd(); // Read Keypad Data
void Read_rd();	  // Read Keypad Data
void Read_rd2();
void Read_Peak_amp();

void Init_all();
int Init_SPI(); // int main(int argc, char *argv[])  //int main(int argc, char *argv[])

void Start_up_Scr();
void Key_function();
void Keypad_ck(); // Read Keypad Data
void Send_SPI(int tx_nofd);
void Send_filt();
void Check_1K();
void Get_Data(); // Transfer data to Opengl Buffer from SPI Buffer
void Send_Data_to_OpenGL(void);
void Smooth_Asc();
void SPI_Receive(); // Receive Data using SPI

void DAC_Copy_for_Disp(int crvno); // Copy DAC points data for the Display
void Cal_Tval();
void Hruler_update();
void Vruler_update();

gboolean Key_perform_F(int keycodet);


/* --- Functions: category utils --- */

void SPI_Receive()
{
	int i, j, k;
	int lsb, msb, data, ret, ds;
	unsigned char wData;

	// Filt_05to40[i]

	ds = 0;
	// if (horn_val==0)
	//   { tx_cmd[ds++]=0x1B; tx_cmd[ds++]=0x085; tx_cmd[ds++]=0x030; tx_cmd[ds++]=0x1B;  }     // 1B 85 30 1B   Ramp
	// else
	{
		tx_cmd[ds++] = 0x1B;
		tx_cmd[ds++] = 0x085;
		tx_cmd[ds++] = 0x010;
		tx_cmd[ds++] = 0x1B;
	} // 1B 85 10 1B   //RF

	tx_cmd[ds++] = 0x1B;
	tx_cmd[ds++] = 0x004;
	tx_cmd[ds++] = 0x005;
	tx_cmd[ds++] = 0x1B; // 1B 04 05 1B
	tx_cmd[ds++] = 0x1B;
	tx_cmd[ds++] = 0x004;
	tx_cmd[ds++] = 0x004;
	tx_cmd[ds++] = 0x1B; // 1B 04 04 1B

	for (i = 0; i < 500; i++)
	{
		rx_cmd[ds] = 0x0;
		tx_cmd[ds++] = 0x0; //(unsigned char) i;  // tx_cmd[ds++]=0x00;
	}
	// ds=32;
	Send_SPI(ds); // Send data
}

int Check_SPI() // int main(int argc, char *argv[])  //int main(int argc, char *argv[])
{
	int argc;
	char *argv[100];

	int ret = 0;
	int fd;

	parse_opts(argc, argv);

	fd = open(device, O_RDWR);
	if (fd < 0)
		pabort("can't open device");

	/** spi mode **/
	ret = ioctl(fd, SPI_IOC_WR_MODE, &mode);
	if (ret == -1)
		pabort("can't set spi mode");

	ret = ioctl(fd, SPI_IOC_RD_MODE, &mode);
	if (ret == -1)
		pabort("can't get spi mode");

	/** bits per word **/
	ret = ioctl(fd, SPI_IOC_WR_BITS_PER_WORD, &bits);
	if (ret == -1)
		pabort("can't set bits per word");

	ret = ioctl(fd, SPI_IOC_RD_BITS_PER_WORD, &bits);
	if (ret == -1)
		pabort("can't get bits per word");

	/** max speed hz **/
	ret = ioctl(fd, SPI_IOC_WR_MAX_SPEED_HZ, &speed);
	if (ret == -1)
		pabort("can't set max speed hz");

	ret = ioctl(fd, SPI_IOC_RD_MAX_SPEED_HZ, &speed);
	if (ret == -1)
		pabort("can't get max speed hz");

	printf("spi mode: %d\n", mode);
	printf("bits per word: %d\n", bits);
	printf("max speed: %d Hz (%d KHz)\n", speed, speed / 1000);

	transfer(fd);

	// close(fd);
	fd_SPI = fd;

	return ret;
}

	if (ret < 0)
	{
		Spi_open = false;
		printf("SPI ERROR \n");
	}


void Timer_Start_Stop()
{
	int Timer_tm;

	Timer_tm = 50; // Timer_tm=scr_val;   // Time in Milli Second
	if (timer_flag == true)
	{
		signal_id = g_timeout_add((guint)Timer_tm, (GSourceFunc)time_handler_function, NULL);
		timer_flag = false;
	}
	else
	{
		if (signal_id)
		{
			g_source_remove(signal_id);
			signal_id = 0;
		}
		timer_flag = true;
	}
}

	if (timer_flag == true)
	{
		signal_id = g_timeout_add((guint)Timer_tm, (GSourceFunc)time_handler_function, NULL);
		timer_flag = false;
	}

		if (signal_id)
		{
			g_source_remove(signal_id);
			signal_id = 0;
		}

	if (Key_ck > 8)
	{
		Keypad_ck(); // Read Keypad Data
		if (Key_press == true)
		{
			Key_Delay = Key_Delay + 25;
			if (Key_Delay > 100)
			{
				Key_Delay = 100;
			}
			Key_ck = Key_Delay / 10;
			Key_function();
		}
		else
		{
			Key_Delay = 0;
			Key_ck = 8;
		}

		if (opengl_update == true)
		{
			if (Asc_Dsp > 0) // if(Gate1_v>0)
			{
				refresh_opengl_display();
			}
		}
		// For acceleration rate Key_Delay value keep on increase
	}

		if (Key_press == true)
		{
			Key_Delay = Key_Delay + 25;
			if (Key_Delay > 100)
			{
				Key_Delay = 100;
			}
			Key_ck = Key_Delay / 10;
			Key_function();
		}

			if (Key_Delay > 100)
			{
				Key_Delay = 100;
			}


		if (opengl_update == true)
		{
			if (Asc_Dsp > 0) // if(Gate1_v>0)
			{
				refresh_opengl_display();
			}
		}

		if (opengl_update == true)
		{
			if (Asc_Dsp > 0) // if(Gate1_v>0)
			{
				refresh_opengl_display();
			}
		}


	if (lastCalSetupFlag == 1)
	{
		PowerKey_ck();
	}

			if (Error_msg == true)
			{
				gtk_widget_hide(b_errorbox);
				gtk_widget_show(b_btnbox);
				Error_msg = false;
			}

		if (Batt_val > 100)
		{
			Batt_val = 0;
		}


	if (Gate1_v > 0 || Gate2_v > 0)
	{
		Check_Gate_cross(); //*** If echo cross the Gate then Generate Alarm signal
	}

void Get_Data()
{
	int i, temp, dst;
	int RejP, RejN;
	int Src_idx = 13; // Offset is used because starting 12 data is Command and Framing so it should be discard
	GLfloat tmpgl;
	float tfd, offst;
    offst = (50.0f + (((((float)splite_frame_height - 2.0f) - (float)Asc_Height) / 8.0f)));  // offset = 51.750000
	tfd = (50.0f * ((float)splite_frame_height - 2.0f)) / (float)Asc_Height;   				 // tfd = 51.627907

	// Asc_Dsp=1;

	if (Spi_open == false)
	{
		ogl_update(); // Display Artifical Data
		return;
	}

	if (Rectify_v == 3) // IF RF Is selected
	{
		RejP = 50 + (Reject_v / 2);
		RejN = 50 - (Reject_v / 2);

		for (i = 0; i < 256; i++) // 256+13
		{
			temp = rx_cmd[Src_idx++];
			if (temp > 127)
			{
				temp = temp - 127;
			}
			else
			{
				temp = temp + 127;
			}
			temp = temp / 2;
			temp = temp - 13; // 13+ offset 16  //   It comes to 64  (128/2 =64) but we required 50 so 64-13  so it would become about 50
			if (temp > 50 && temp < RejP)
			{
				temp = 50;
			}
			if (temp < 50 && temp > RejN)
			{
				temp = 50;
			}
			// and A-Scan position if offseted by Frameheight- A-Scan hight so that should be compensated so Base line would be at centere of Grid
			if (temp > 100)
			{
				temp = 100;
			}
			if (temp < 0)
			{
				temp = 0;
			}
			All_Ascan_data[i] = temp; // row_y[i];
			temp = temp - 2;
			row_y[i] = (GLubyte)temp;

			if (row_y[i] > 100)
				ogl.vertices_position[(i * 2) + 1] = ((0.0f - offst) / tfd);    
			else if (row_y[i] >= 98)
				ogl.vertices_position[(i * 2) + 1] = ((100.0f - offst) / tfd);
			else
				ogl.vertices_position[(i * 2) + 1] = (((GLfloat)row_y[i] - offst) / tfd);
		}

		if ((Record_Type_val == 0 || Record_Type_val == 1 || Record_Type_val == 3) && (rw_flag == 0))
		{
			write_data_in_bsc_file(&row_y[0]);
		}

		if (Ascan_peak_flag == true)
		{
			for (i = 0; i < 256; i++) // Copy Ascan data from reference
			{
				All_Ascan_peak[(i * 2) + 1] = ogl.vertices_position[(i * 2) + 1];
			}
			Ascan_peak_flag = false;
		}
	}
	else
	{
		if (Smooth_v > 0)
		{
			Smooth_Asc();
		} // For +ve. -ve and Envelop
		for (i = 0; i < 256; i++)
		{
			temp = rx_cmd[Src_idx++];
			if (temp < 0)
			{
				temp = 0;
			}
			if (temp > 100)
			{
				temp = 100;
			}
			if (temp < Reject_v)
			{
				temp = 0;
			}
			row_y[i] = (GLubyte)temp;
			All_Ascan_data[i] = (int)row_y[i];

			// ogl.vertices_position[(i * 2) + 1] = ((GLfloat)row_y[i] - 50.0f) / 50.0f;
			ogl.vertices_position[(i * 2) + 1] = (((GLfloat)row_y[i]) - offst) / tfd; // - 50.0f) / 50.0f;
		}

		if ((Record_Type_val == 0 || Record_Type_val == 1 || Record_Type_val == 3) && (rw_flag == 0))
		{			
			write_data_in_bsc_file(&row_y[0]);
		}

		if (Ascan_peak_flag == true)
		{
			for (i = 0; i < 256; i++) // Copy Ascan data fro referance
			{
				All_Ascan_peak[(i * 2) + 1] = ogl.vertices_position[(i * 2) + 1];
			}
			Ascan_peak_flag = false;
		}
	}

	if (video_val == 1) // IF Video Mode is Filled selected
	{
		for (i = 256; i > 0; i--)
		{
			tmpgl = ogl.vertices_position[(i * 2) + 1]; // Get Value of y
			dst = (i * 6) + 1;
			ogl.vertices_position[dst] = tmpgl;
			ogl.vertices_position[dst + 2] = -1; // tmpgl;
			ogl.vertices_position[dst + 4] = tmpgl;
		}
	}

	if (video_val == 2) // If Video Dynamic is selected
	{
		for (i = 0; i < 256; i++)
		{
			if (row_y[i] > Asc_Max[i])
			{
				Asc_Max[i] = row_y[i];
			}
			ogl.vertices_position[(i * 2) + 1 + 1536] = (((GLfloat)Asc_Max[i] - offst) / tfd);
			// ogl.vertices_position[(i * 2) + 1 + 1536] = (((GLfloat)Asc_Max[i] - 50.0f) / 50.0f);
		}
	}

	if (rx_cmd[12] != 0x1B)
	{
		printf("FRAME ST Error  \n");
	}
}



//void DetectUsb()  //Detect the usb
//{
//	FILE* f;
//	if (f = popen("mount | grep /media/sda", "r"))
//	{
//		if (NULL != f)
//		{
//			if (EOF == fgetc(f))
//			{
//				//gtk_widget_hide(nframe[9]);
//				gtk_widget_hide(n_image[8]);
//				usb_val = 0;
//			}
//			else
//			{
//				//gtk_widget_show(nframe[9]);
//				gtk_widget_show(n_image[8]);
//				strcpy(pendrv_path, "/media/sda/");
//				usb_val = 1;
//			}
//			pclose(f); /* close the command file */
//		}
//	}
//	else if (f = popen("mount | grep /media/sda1", "r"))
//	{
//		if (NULL != f)
//		{
//			if (EOF == fgetc(f))
//			{
//				//gtk_widget_hide(nframe[9]);
//				gtk_widget_hide(n_image[8]);
//				usb_val = 0;
//			}
//			else
//			{
//				//gtk_widget_show(nframe[9]);
//				gtk_widget_show(n_image[8]);
//				strcpy(pendrv_path, "/media/sda1/");
//				usb_val = 1;
//			}
//			pclose(f); 	/* close the command file */
//		}
//	}
//	else if (f = popen("mount | grep /media/sdb", "r"))
//	{
//		if (NULL != f)
//		{
//			if (EOF == fgetc(f))
//			{
//				//gtk_widget_hide(nframe[9]);
//				gtk_widget_hide(n_image[8]);
//				usb_val = 0;
//			}
//			else
//			{
//				//gtk_widget_show(nframe[9]);
//				gtk_widget_show(n_image[8]);
//				strcpy(pendrv_path, "/media/sdb/");
//				usb_val = 1;
//			}
//			pclose(f); /* close the command file */
//		}
//	}
//	else if (f = popen("mount | grep /media/sdb1", "r"))
//	{
//		if (NULL != f)
//		{
//			if (EOF == fgetc(f))
//			{
//				//gtk_widget_hide(nframe[9]);
//				gtk_widget_hide(n_image[8]);
//				usb_val = 0;
//			}
//			else
//			{
//				//gtk_widget_show(nframe[9]);
//				gtk_widget_show(n_image[8]);
//				strcpy(pendrv_path, "/media/sdb1/");
//				usb_val = 1;
//			}
//			pclose(f); /* close the command file */
//		}
//	}
//	return;
//}

//void DetectUsb()  //Detect the usb
//{
//	//Copy_All();
//	FILE* f;
//	//if (f = popen("mount | grep /home/rnd1/temp1", "r")) //fopen(path_h, "r");
//	if (f = fopen("/home/rnd1/temp1", "r"))
//	{
//		if (NULL != f)
//		{
//			/* test if something has been output by the command */
//			//if (EOF == fgetc(f))
//			if (feof(f))
//			{
//				gtk_widget_hide(nframe[9]);
//				usb_val = 0;
//				//puts("\n/dev/sda1 is NOT mounted");
//			}
//			else
//			{
//				gtk_widget_show(nframe[9]);
//				strcpy(pendrv_path, "/home/rnd1/temp1");
//				//pendrv_path
//				usb_val = 1;
//				//puts("\n/dev/sda1 is mounted");
//			}
//			/* close the command file */
//			//pclose(f);
//			fclose(f);
//		}
//	}
//	//else if (f = popen("mount | grep /home/rnd1/temp2", "r")) // else if (f = fopen("Cal", "r"))
//	else if (f = fopen("/home/rnd1/temp2", "r"))
//	{
//		if (NULL != f)
//		{
//			/* test if something has been output by the command */
//			//if (EOF == fgetc(f))
//			if (feof(f))
//			{
//				gtk_widget_hide(nframe[9]);
//				usb_val = 0;
//				//puts("\n/dev/sda1 is NOT mounted");
//			}
//			else
//			{
//				gtk_widget_show(nframe[9]);
//				strcpy(pendrv_path, "/home/rnd1/temp2");
//				usb_val = 1;
//				//puts("\n/dev/sda1 is mounted");
//			}
//			/* close the command file */
//			//pclose(f);
//			fclose(f);
//		}
//	}
//	return;
//}


void Reset_DGSDAC() // To Reset the DAC and DGS after reading from file
{
	int key_v = 0;
	dgs_fromfile = 0;
	reset_value = 1;
	Set_default_val();

	Dac_f(key_v);
	STARTa_f(key_v);
	Point_f(key_v);
	press_f(key_v);

	Size_Eval_Select_f(key_v); // MENU 12

	Size_Eval_f(key_v);	 // MENU 4   // To be review
	Size_Eval_f1(key_v); // To be review
	Size_Eval_f2(key_v); // To be review
	Size_Eval_f3(key_v); // To be review
}


/****************************************************************************/
/***********************SET THE BOTTOM BUTTON'S******************************/
	/*for (i = 0; i < 5; i++)
	{
		b_btn[i] = gtk_button_new();
		b_label[i] = gtk_label_new(b_ary[i]);
		gtk_container_add(GTK_CONTAINER(b_btn[i]), b_label[i]);
		gtk_label_set_max_width_chars(GTK_LABEL(b_label[i]), 8);
		gtk_label_set_ellipsize(GTK_LABEL(b_label[i]), PANGO_ELLIPSIZE_END);
		gtk_widget_set_halign(GTK_WIDGET(b_label[i]), GTK_ALIGN_CENTER);
		gtk_widget_set_size_request(b_btn[i], button_width, button_height);
		gtk_widget_set_name(b_btn[i], bbtn_css[i]);
	}*/