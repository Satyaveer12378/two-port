/*cd /f/Dahlia-Verdin/GTK*/
/* RUN BAT FILE TO EXECUTE PROGRAM --> bash ./gtkboardapp_run.bat*/
/* gcc gtkrow.c src/src/OpenGL.c -o Main `pkg-config --cflags --libs gtk+-3.0` -lm -lwayland-client -lwayland-server -lwayland-egl -lEGL -lGLESv2 */
/* $CC gtkrow.c src/src/OpenGL.c -o Main `pkg-config --cflags --libs gtk+-3.0` -lm -lwayland-client -lwayland-server -lwayland-egl -lEGL -lGLESv2 */
/* $CC gtkrow.c src/src/OpenGL.c -o Main `pkg-config --cflags --libs gtk+-3.0` -lgpiod -lm -lwayland-client -lwayland-server -lwayland-egl -lEGL -lGLESv2 */
/* $CC src/src/Dav_Sub.c src/src/OpenGL.c -o Main `pkg-config --cflags --libs gtk+-3.0` -lgpiod -lm -lwayland-client -lwayland-server -lwayland-egl -lEGL -lGLESv2 */

// cd /mnt/e/2024/08-August_2024/2024-08-21/Dav_Sub
/*  bash Build_For_brd.sh */ // Use this command to Build the application to run on Board
//
//   bash ./Build_For_WSL.sh     // Build for WSL  Environment setti is not rquired
//   cd /mnt/d/
//  cd WSL_Wayland_Proj/WSL_Prog/Dav_Sub/Dav_Sub
//  . /opt/tdx-xwayland/5.7.1/environment-setup-aarch64-tdx-linux
//    which pkg-config
//    /opt/tdx-xwayland/5.7.1/sysroots/x86_64-tdxsdk-linux/usr/bin/pkg-config
//    bash Build_For_brd.sh
//    export DISPLAY=172.23.144.1:0 && export XDG_RUNTIME_DIR=/tmp/xdg && export RUNLEVEL=3 && weston

//   setup=setenv setupargs console=tty1 console=${console},${baudrate} consoleblank=0 earlycon   // set environment as below so during boot console command would not get display on screen
//   setenv setup 'setenv setupargs vt.global_cursor_default=0 console=${console},${baudrate} consoleblank=0 earlycon'
//   setenv setup 'setenv setupargs console=${console},${baudrate} consoleblank=0 earlycon'
// setenv setup 'setenv setupargs fec_mac=${ethaddr} consoleblank=0 no_console_suspend=1 console=${console},${baudrate}n8'
// setenv -> saveenv -> reset
// WSL UBUNTU PATH FROM PROGRAM FOR TESTING PURPOSE = fopen("/home/rnd1/temp1", "r"))
// CHECK DISK SPACE = df -H // To check storage in linux 

#ifdef WIN32
#include <io.h>
#define F_OK 0
#define access _access
#endif

#include <stdio.h>
#include <include/include/gpiod.h> // For WSL it is required to install libgpiod using following command in Ubuntu sudo apt-get install libgpiod-dev
#include <string.h>
#include <stdlib.h>
#include <stdint.h>
#include <math.h>
#include <stdbool.h>
#include <stdint.h>
#include <cairo.h>
#include <cairo-pdf.h>

#include <gtk/gtk.h>

#include "include/include/gtkdeclarations.h"
#include "include/include/Dav_Sub.h"
#include "include/include/dataval.h"
#include "include/include/cbentry.h"
#include "include/include/cbentry_safe1.h"
#include "include/include/OpenGL.h"
#include "include/include/shp_prf.h"
#include "include/include/Ruler.h"
#include "include/include/thick_log.h"
#include "include/include/plot_data.h"

#include <unistd.h>
#include <getopt.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <sys/wait.h>
#include <linux/types.h>
#include <linux/spi/spidev.h>

// #define ARRAY_SIZE(a) (sizeof(a) / sizeof((a)[0]))

gdouble Scr_stp_pre = 10.0;
int fd_SPI;

bool Spi_test = true;
struct OGLData ogl;

int Key_ck = 100;  // Key Check timer counter
int Key_Delay = 0; // Key Delay time control
bool Key_press = false;
int Measure_dsp = 0, Batt_dsp = 0, Batt_val = 0; // Measurement Display rate is controlle by this value
extern int tx_bufidx;
extern int Key_Scn_code;
extern int Key_stp;
extern GLubyte row_y[256];

extern cairo_t *Ascan_cr;
extern cairo_surface_t *Ascan_surface;
extern GdkPixbuf *Ascan_pixbuf;

void Keypad_rd(); // Read Keypad Data
void Read_rd();	  // Read Keypad Data
void Read_rd2();
void Read_Peak_amp();

void Init_all();
int Init_SPI(); // int main(int argc, char *argv[])  //int main(int argc, char *argv[])

void Start_up_Scr();
void Key_function();
void Keypad_ck(); // Read Keypad Data
void Send_SPI(int tx_nofd);
void Send_filt();
void Check_1K();
void Get_Data(); // Transfer data to Opengl Buffer from SPI Buffer
void Send_Data_to_OpenGL(void);
void Smooth_Asc();
void SPI_Receive(); // Receive Data using SPI

void DAC_Copy_for_Disp(int crvno); // Copy DAC points data for the Display
void Cal_Tval();
void Hruler_update();
void Vruler_update();

gboolean Key_perform_F(int keycodet);


/* --- Functions: category math --- */


void Update_Note()
{
	k = 0;
	for (i = 0; i < 10; i++)
	{
		for (j = 0; j < 40; j++)
		{
			Note_data[k] = text_values[i][j];
			k++;
		}
	}
}

void AllProcess(int key_v)
{
	num_4 = (menu_v * 5) + btn_idx;

	switch (num_4)
	{
	case ZERO_PERA:
		Zero_f(key_v);
		break; // MENU 1
	case RANGE_PERA:
		Range_f(key_v);
		dac_gen(&dac_pnt[0], &dac_cv[0], Gain_v, Range_v, Delay_rv);
		break; // If Dac ON then Draw DAC Curvebreak; // MENU 1
	case VELO_PERA:
		Velo_f(key_v);
		dac_gen(&dac_pnt[0], &dac_cv[0], Gain_v, Range_v, Delay_rv);
		break; // If Dac ON then Draw DAC Curve break; // MENU 1
	case DELAY_PERA:
		Delay_f(key_v);
		dac_gen(&dac_pnt[0], &dac_cv[0], Gain_v, Range_v, Delay_rv);
		break; // If Dac ON then Draw DAC Curve  break; // MENU 1
		// case GAIN_PERA: Gain_f(key_v);  break; // MENU 1

	case GATE1_PERA:
		Gatea_f(key_v);
		break; // MENU 2
	case GSTA1_PERA:
		STARTa_f(key_v);
		break; // MENU 2
	case GEND1_PERA:
		ENDa_f(key_v);
		break; // MENU 2
	case GTHE1_PERA:
		LEVELa_f(key_v);
		break; // MENU 2
		// case 9: REF25_f(key_v); break;

	case GATE2_PERA:
		GATEb_f(key_v);
		break; // MENU 3
	case GSTA2_PERA:
		STARTb_f(key_v);
		break; // MENU 3
	case GEND2_PERA:
		ENDb_f(key_v);
		break; // MENU 3
	case GTHE2_PERA:
		LEVELb_f(key_v);
		break; // MENU 3
		// case 14: GAIN_f(key_v); break;

	case MEM_PERA:
		MEMORY_f(key_v);
		break; // MENU 4
	case MEM_NO_PERA:  
		if (note_dsp == 1)
		{
			Note_ln_f(key_v); // MENU 4
		}
		else
		{
			MEMNO_f(key_v);// MENU 4
		}
		break; // MENU 4
	case MEM_ACT_PERA:
		if (note_dsp == 1)
		{
			Note_Cur_pos_f(key_v);
		}
		else
		{
			ACTION_f(key_v);
		}
		break; // MENU 4
	case MEM_NOTE_PERA:
		Mem_Note_f(key_v);
		break; // MENU 4
		// case 19: Gain_1f(key_v); break;

	case DAC_PERA:
		Size_Eval_f(key_v);
		break; // MENU 5
	case CURSOR_PERA:
		Size_Eval_f1(key_v);
		break; // MENU 5
	case PRESS_PERA:
		Size_Eval_f2(key_v);
		break; // MENU 5
	case POINT_PERA:
		Size_Eval_f3(key_v);
		break; // MENU 5

	case DAMP_PERA:
		DAMP_f(key_v);
		break; // MENU 6
	case MODE_PERA:
		Mode_f(key_v);
		break; // MENU 6
	case PRF_PERA:
		Prf_f(key_v);
		break; // MENU 6
	case TXVOLT_PERA:
		Txvolt_f(key_v);
		break; // MENU 6

	case REJECT_PERA:
		Reject_f(key_v);
		break; // MENU 7
	case FREQ_PERA:
		Freq_f(key_v);
		break; // MENU 7
	case RECTIFY_PERA:
		Rectify_f(key_v);
		break; // MENU 7
	case SMOOTH_PERA:
		Smooth_f(key_v);
		break; // MENU 7

	case GRID_PERA:
		Grid_f(key_v);
		break; // MENU 8
	case COL_LEG_PERA:
		Color_Leg_f(key_v);
		break; // MENU 8
	case VIDEO_PERA:
		Video_f(key_v);
		break; // MENU 8
	case SET_REF_PERA:
		Setref_f(key_v);
		break; // MENU 8

	case SCR_THEME_PERA:
		COLOR_Theme_f(key_v);
		break; // MENU 9
	case ACOLOR_PERA:
		COLOR_f(key_v);
		break; // MENU 9
	case BRIGHT_PERA:
		Brightness_f(key_v);
		break; // MENU 9
	case SCREEN_PERA:
		Screen_rotate_f(key_v);
		break; // MENU 9

	case XOFF_PERA:
		X_OFFSET_f(key_v);
		break; // MENU 10
	case ANGLE_PERA:
		ANGLE_f(key_v);
		break; // MENU 10
	case THICK_PERA:
		THICK_f(key_v);
		break; // MENU 10
	case TRIG_PERA:
		Trig_f(key_v);
		break; // MENU 10

	case CLOCK_PERA:
		CLOCK_f(key_v);
		break; // MENU 11
	case HORN_PERA:
		if (val_ary[CLOCK_PERA] == 0 || val_ary[CLOCK_PERA] == 1)
			HORN_f(key_v);
		else if (val_ary[CLOCK_PERA] == 2)
			New_Date_f(key_v);
		else if (val_ary[CLOCK_PERA] == 3)
			New_Houre_f(key_v);
		break; //MENU 11
	case BEEP_PERA:	 //MENU 11
		if (val_ary[CLOCK_PERA] == 0 || val_ary[CLOCK_PERA] == 1)
			BEEP_f(key_v);
		else if (val_ary[CLOCK_PERA] == 2)
			New_Month_f(key_v);
		else if (val_ary[CLOCK_PERA] == 3)
			New_Minute_f(key_v);
		break; // No_refresh = true; Clear_Clock_area(hWnd); break; // Clr_Ascan=true; break; // MENU 11
	case UNIT_PERA: // MENU 11
		if (val_ary[CLOCK_PERA] == 0 || val_ary[CLOCK_PERA] == 1 || val_ary[CLOCK_PERA] == 3)
			Unit_f(key_v); 
		else if (val_ary[CLOCK_PERA] == 2)
			New_Year_f(key_v);
		break;

		// case FLNAME_PERA:             //auto_flname(key_v); break;   //  Set Auto File No  //

		// Auto Cal to be Add here
	case ACAL_PERA:
		Auto_Cal_f(key_v);
		break; // Menu 12
	case STRT_GA_PERA:
		STARTa_f(key_v);
		break; // Menu 12
	case DST1_PERA:
		DST1_f(key_v); 
		break; // Menu 12
	case DST2_PERA:
		DST2_f(key_v);
		break; // Menu 12

	case SIZE_EV_PERA:
		Size_Eval_Select_f(key_v);
		break; // MENU 13
	case MEA_POSI1_PERA:
		Mea_fLn1_f(key_v);
		break; // MENU 13
	case MEA_POSI2_PERA:
		Mea_fLn2_f(key_v);
		break; // MENU 13
	case MEA_POSI3_PERA:
		// Mea_fLn3_f(key_v);
		break; // MENU 13

	case REC_TYPE_PERA:
		Record_type_f(key_v);
		break; // MENU 14
	case RECORD_NO_PERA:
		Record_No_f(key_v);
		break; // MENU 14
	case RECORD_OP_PERA:
		Bs_Action_Select_f(key_v);
		break; // MENU 14
	case REC_ACTION_PERA:
		Bs_Perf_Action(key_v);
		break; // MENU 14

	case ENCODER_PERA:
		ENCODER_f(key_v);
		break; // MENU 15
	case ENC_CAL_PERA:
		Enc_CAL_F_f(key_v);
		break; // MENU 15
	case ENC_STRT_PERA:
		Enc_CAL_F_f(key_v);
		Enc_Start_posF_f(key_v);
		break; //  MENU 15
	case ENC_KMPST_PERA:
		break; // MENU 15
		
	case WELD_PROF_PERA:
		Weld_Prof_f(key_v);
		break; // MENU 16
	case BEAM_PROF_PERA:
		Beam_Prof_f(key_v);
		break; // MENU 16
	case THICK_CLR_PERA:
		//Diameter_f(key_v);
		// Thick_color_f(key_v);
		break; // MENU 16
	case CNG_OGL_PROF_POS:
		Change_ogl_probe_pos_f(key_v);
		break; // MENU 16

	case SCALE_POS_PERA:
		Scal_f(key_v);
		break; // MENU 17 1 MINUTE_v+5              // DGS Configuration
	case PRBNM_POS_PERA:
		break; // SCALE_POS_PERA+1
	case PRFFRE_POS_PERA:
		Prb_freq_f(key_v);
		break; // PRBNM_POS_PERA+1
	case DELVEL_PERA:
		Del_Vel_f(key_v);
		break; // PRFFRE_POS_PERA+1

	case D_EFECT_PERA:
		D_efect_f(key_v);
		break; // MENU 18   SCALE_POS_PERA+5
	case DGS_CRV_PERA:
		Dgs_crv_f(key_v);
		break; // D_EFECT_PERA+1
	case REF_ECHO_PERA:
		Ref_echo_f(key_v);
		break; // DGS_CRV_PERA+1
	case REF_SIZ_PERA:
		Ref_size_f(key_v);
		break; // REF_ECHO_PERA+1

	case DGS_EX_PERA:
		Dgs_exit_f(key_v);
		Frame_menu_exit_f(key_v);
		break; //   // Exit From Frame Menu Dgs_exit_f(key_v); break;   //MENU 19  D_EFECT_PERA+5
	case ATT_REF_PERA:
		Att_ref_f(key_v);
		break; // DGS_EX_PERA+1
	case ATT_OBJ_PERA:
		Att_obg_f(key_v);
		break; // ATT_REF_PERA+1
	case AMP_COR_PERA:
		Amp_corr_f(key_v);
		break; // ATT_OBJ_PERA+1

	case WELD_TYPE_PERA:
		Weld_type_f(key_v);
		break; // MENU 20 WELD_TYPE_PERA
	case TOP_WIDTH_PERA:
		Weld_Width_f(key_v);
		break; // TOP_WIDTH_PERA
	case TOP_HEIGHT_PERA:
		Weld_TpHeight_f(key_v);
		break; // TOP_HEIGHT_PERA
	case ROOT_WIDTH_PERA:
		Weld_Root_width_f(key_v);
		break; // ROOT_WIDTH_PERA

	case OBJ_SHAPE_PERA:
		Tst_Obh_shape_f(key_v);
		break; //  Weld_EXT11_f(key_v); break;       // MENU 21  EXT_11_PERA
	case OBJ_WIDTH_PERA:
		Obj_width_f(key_v);
		break; // Weld_EXT12_f(key_v); break;       // Width / OD
	case OBJ_THICK_PERA:
		Obj_thick_f(key_v);
		break; // Weld_EXT13_f(key_v); break;       // EXT_13_PERA
	case WPROF_POS_PERA:
		Obj_Wprof_pos_f(key_v);
		break; // Weld_EXT14_f(key_v); break;       // EXT_14_PERA

	case EXT_WELD_PRF_PERA:
		Weld_Exit_f(0);
		Frame_menu_exit_f(key_v);
		recreate_surface(width_sh, height_sh, ogl_x_position, ogl_y_position);
		break; // MENU 22    EXT_21_PERA
	case PROB_POS_PERA:
		Probe_pos_f(key_v);
		break; // Weld_EXT22_f(key_v); break;  //  EXT_22_PERA
	case PROBE_ANGLE_PERA:
		Probe_angle_f(key_v);
		break; // Weld_EXT23_f(key_v); break;  //  EXT_23_PERA
	case NOOF_LEGv_PERA:
		NoofLeg_f(key_v);
		break; // Weld_EXT24_f(key_v); break;  //  EXT_24_PERA

	case EXT_21_PERA:
		break; // Tst_Obh_shape_f(key_v); break;   // MENU 23  OBJ_SHAPE_PERA           //    Test Object Shape Selection
	case EXT_22_PERA:
		break; // Probe_pos_f(key_v); break;       // PROB_POS_PERA
	case EXT_23_PERA:
		break; // Probe_angle_f(key_v); break;     // PROBE_ANGLE_PERA
	case EXT_24_PERA:
		break; // NoofLeg_f(key_v); break;      //  NOOF_LEGv_PERA

	case EXT_31_PERA:
		break; // Obj_width_f(key_v); break;      //  MENU 24  OBJ_WIDTH_PERA
	case EXT_32_PERA:
		break; // Obj_thick_f(key_v); break;      //  HEIGHT_PERA
	case EXT_33_PERA:
		break; // Obj_EXT33_f(key_v); break;      //  EXT_33_PERA
	case EXT_34_PERA:
		break; // Obj_EXT34_f(key_v); break;      //  EXT_34_PERA

	case EXT_41_PERA:
		break; // Obj_Exit_f(0); Frame_menu_exit_f(key_v); break;      //  MENU 25  EXT_41_PERA
	case EXT_42_PERA:
		break; // Obj_Wprof_pos_f(key_v); break;      //  EXT_42_PERA:
	case EXT_43_PERA:
		break; // Obj_EXT43_f(key_v); break;      //  EXT_43_PERA
	case EXT_44_PERA:
		break; // Obj_EXT44_f(key_v); break;      //  EXT_44_PERA

	case BEAM_PrbDia_PERA:
		Beam_Prof_PDia_f(key_v);
		break; // EXT_21_PERA+5      //  Probe Near Field Beam Profile
	case BEAM_PrbFreq_PERA:
		Beam_Prof_PFreq_f(key_v);
		break; // Calculate Near Field Value and Angle
	case BEAM_PRF_P13_PERA:
		break; // Beam_Prof_p13_f(key_v); break;
	case BEAM_PRF_P14_PERA:
		break; // Beam_Prof_p14_f(key_v); break;

	case BEAM_PRF_P21_PERA:
		break; // Beam_Prof_p21_f(key_v); break;
	case BEAM_PRF_P22_PERA:
		break; // Beam_Prof_p22_f(key_v); break;
	case BEAM_PRF_P23_PERA:
		break; // Beam_Prof_p23_f(key_v); break;
	case BEAM_PRF_P24_PERA:
		break; // Beam_Prof_p24_f(key_v); break;

	case BEAM_PRF_P31_PERA:
		Beam_Profile_Cal_f();
		Frame_menu_exit_f(key_v);
		break;
	case BEAM_PRF_P32_PERA:
		break; // Beam_Prof_p32_f(key_v); break;
	case BEAM_PRF_P33_PERA:
		break; // Beam_Prof_p33_f(key_v); break;
	case BEAM_PRF_P34_PERA:
		break; // Beam_Prof_p34_f(key_v); break;

	case THKFILE_TYPE_PERA:
		Thk_File_type_f(key_v);
		break; // MENU 26 THKFILE_TYPE_PERA           // Thickness file type Selection
	case START_ID_1_PERA:
		Start_ID_1_f(key_v);
		break; //  START_ID_1_PERA
	case START_ID_2_PERA:
		Start_ID_2_f(key_v);
		break; //  START_ID_2_PERA
	case START_ID_3_PERA:
		// Start_ID_3_f(key_v);
		break; //  START_ID_3_PERA

	case EXT_51_PERA:
		// Thk_EXT_51_f(key_v);  // NOT USED
		break; //  MENU 27  EXT_51_PERA
	case END_ID_1_PERA:
		END_ID_1_f(key_v);
		break; //  END_ID_1_PERA
	case END_ID_2_PERA:
		END_ID_2_f(key_v);
		break; //  END_ID_2_PERA
	case END_ID_3_PERA:
		// END_ID_3_f(key_v);
		break; //  END_ID_3_PERA

	case EXIT_PERA:
		Frame_menu_exit_f(key_v);
		Bsc_Record_Start_f(key_v);
		Thk_File_Exit_f(key_v);
		write_data_into_thk_file();
		break; // MENU 28 EXIT_PERA
	case DIM_1_SIZE_PERA:
		///Dim_1_size_f(key_v);
		break; //  DIM_1_SIZE_PERA
	case DIM_2_SIZE_PERA:
		// Dim_2_size_f(key_v);
		break; //  DIM_2_SIZE_PERA
	case DIM_3_SIZE_PERA:
		// Dim_3_size_f(key_v);
		break; //  DIM_3_SIZE_PERA

	case COLOR_METHOD_PERA:
		// Thk_Color_method_f(key_v);
		break; // MENU 29 COLOR_METHOD_PERA  EXIT_PERA:   +5           // Thickness file Color Selection
	case START_THK_1_PERA:
		Start_Thk_1_f(key_v);
		break; //  START_THK_1_PERA:
	case START_THK_2_PERA:
		Start_Thk_2_f(key_v);
		break; //  START_THK_2_PERA
	case START_THK_3_PERA:
		Start_Thk_3_f(key_v);
		break; //  START_THK_3_PERA

	case EXT_61_PERA:
		// Thk_EXT_61_f(key_v);
		break; // MENU 30 EXT_61_PERA
	case END_THK_1_PERA:
		End_Thk_1_f(key_v);
		break; //  END_THK_1_PERA
	case END_THK_2_PERA:
		End_Thk_2_f(key_v);
		break; //  END_THK_2_PERA
	case END_THK_3_PERA:
		End_Thk_3_f(key_v);
		break; //  END_THK_3_PERA

	case EXIT_71_PERA:
		Frame_menu_exit_f(key_v);
		Bsc_Record_Start_f(key_v);
		Thk_File_Exit_f(key_v);
		break; // MENU 31 EXIT_71_PERA
	case COLOR_1_PERA:
		Thk_Clr_1_f(key_v);
		break; //  COLOR_1_PERA
	case COLOR_2_PERA:
		Thk_Clr_2_f(key_v);
		break; //  COLOR_2_PERA
	case COLOR_3_PERA:
		Thk_Clr_3_f(key_v);
		break; //  COLOR_3_PERA

	case MINUTE_v:
		//MINUTE_f(key_v);
		break; // MENU 15
	case HOUR_v:
		//HOUR_f(key_v);
		break; // MENU 15
	case DAY_v:
		//DAY_f(key_v);
		break; // MENU 15
	case MONTH_v:
		//MONTH_f(key_v);
		break; // MENU 15
	case YEAR_v:
		//YEAR_f(key_v);
		break; // // MENU 15

	case GAIN_PERA:
	case 9: // Gain_f(key_v);  break;
	case 14:
	case 19:
	case 24:
	case 29:
	case 34:
	case 39:
	case 44:
	case 49:
	case 54:
	case 59:

	case 64:
	case 69:
	case 74:
	case 79:
		if (note_dsp == 1)
		{
			Note_Char_Scroll_f(key_v);
		}
		else
		{
			if (((Record_Type_val == 0 && Mem_actBS == 2) || (Record_Type_val == 1 && Mem_actBS == 2)|| (Record_Type_val == 3 && Mem_actBS == 2)) && rw_flag != -1)
			{
				if (gain_btnval_flag == false)
				{
					pos = (GAIN_PERA * 2) + 0;
					strcpy(gain_btnval[0], all_btnval[pos]);
					strcpy(gain_btnval[1], all_btnval[pos + 1]);
					strcpy(all_btnval[pos], "   Scroll   ");
					pos = pos % 10;
					gain_btnval_flag = true;
				}

				if ((key_v > 0) || ((key_v < 0) && (asc_cur_pos > 741)))
					Bsc_Analysis_thk_f(key_v);
			}
			else
			{
				Gain_f(key_v);
				if (Dac_v > 0 || Dgs_onoff_v == 2 || Dgs_onoff_v == 3) // DAC is DRAW or ON
				{
					dac_gen(&dac_pnt[0], &dac_cv[0], Gain_v, Range_v, Delay_rv); // If Dac ON then Draw DAC Curve
				}

				if (gain_btnval_flag == true)
				{
					pos = (GAIN_PERA * 2) + 0;
					strcpy(all_btnval[pos], gain_btnval[0]);
					strcpy(all_btnval[pos + 1], gain_btnval[1]);
					pos = pos % 10;
					gain_btnval_flag = false;
				}
				if (gain_btnflag == true) // To distingush between gain value from keypad and button //change value
				{
					btn_idx = l_btnidx;
				}
			}
		}
		break;

	default:
		break;
	}

	Menu_Refresh();
}



//void DetectUsb()  //Detect the usb
//{
//	FILE* f;
//	if (f = popen("mount | grep /media/sda", "r"))
//	{
//		if (NULL != f)
//		{
//			if (EOF == fgetc(f))
//			{
//				//gtk_widget_hide(nframe[9]);
//				gtk_widget_hide(n_image[8]);
//				usb_val = 0;
//			}
//			else
//			{
//				//gtk_widget_show(nframe[9]);
//				gtk_widget_show(n_image[8]);
//				strcpy(pendrv_path, "/media/sda/");
//				usb_val = 1;
//			}
//			pclose(f); /* close the command file */
//		}
//	}
//	else if (f = popen("mount | grep /media/sda1", "r"))
//	{
//		if (NULL != f)
//		{
//			if (EOF == fgetc(f))
//			{
//				//gtk_widget_hide(nframe[9]);
//				gtk_widget_hide(n_image[8]);
//				usb_val = 0;
//			}
//			else
//			{
//				//gtk_widget_show(nframe[9]);
//				gtk_widget_show(n_image[8]);
//				strcpy(pendrv_path, "/media/sda1/");
//				usb_val = 1;
//			}
//			pclose(f); 	/* close the command file */
//		}
//	}
//	else if (f = popen("mount | grep /media/sdb", "r"))
//	{
//		if (NULL != f)
//		{
//			if (EOF == fgetc(f))
//			{
//				//gtk_widget_hide(nframe[9]);
//				gtk_widget_hide(n_image[8]);
//				usb_val = 0;
//			}
//			else
//			{
//				//gtk_widget_show(nframe[9]);
//				gtk_widget_show(n_image[8]);
//				strcpy(pendrv_path, "/media/sdb/");
//				usb_val = 1;
//			}
//			pclose(f); /* close the command file */
//		}
//	}
//	else if (f = popen("mount | grep /media/sdb1", "r"))
//	{
//		if (NULL != f)
//		{
//			if (EOF == fgetc(f))
//			{
//				//gtk_widget_hide(nframe[9]);
//				gtk_widget_hide(n_image[8]);
//				usb_val = 0;
//			}
//			else
//			{
//				//gtk_widget_show(nframe[9]);
//				gtk_widget_show(n_image[8]);
//				strcpy(pendrv_path, "/media/sdb1/");
//				usb_val = 1;
//			}
//			pclose(f); /* close the command file */
//		}
//	}
//	return;
//}

//void DetectUsb()  //Detect the usb
//{
//	//Copy_All();
//	FILE* f;
//	//if (f = popen("mount | grep /home/rnd1/temp1", "r")) //fopen(path_h, "r");
//	if (f = fopen("/home/rnd1/temp1", "r"))
//	{
//		if (NULL != f)
//		{
//			/* test if something has been output by the command */
//			//if (EOF == fgetc(f))
//			if (feof(f))
//			{
//				gtk_widget_hide(nframe[9]);
//				usb_val = 0;
//				//puts("\n/dev/sda1 is NOT mounted");
//			}
//			else
//			{
//				gtk_widget_show(nframe[9]);
//				strcpy(pendrv_path, "/home/rnd1/temp1");
//				//pendrv_path
//				usb_val = 1;
//				//puts("\n/dev/sda1 is mounted");
//			}
//			/* close the command file */
//			//pclose(f);
//			fclose(f);
//		}
//	}
//	//else if (f = popen("mount | grep /home/rnd1/temp2", "r")) // else if (f = fopen("Cal", "r"))
//	else if (f = fopen("/home/rnd1/temp2", "r"))
//	{
//		if (NULL != f)
//		{
//			/* test if something has been output by the command */
//			//if (EOF == fgetc(f))
//			if (feof(f))
//			{
//				gtk_widget_hide(nframe[9]);
//				usb_val = 0;
//				//puts("\n/dev/sda1 is NOT mounted");
//			}
//			else
//			{
//				gtk_widget_show(nframe[9]);
//				strcpy(pendrv_path, "/home/rnd1/temp2");
//				usb_val = 1;
//				//puts("\n/dev/sda1 is mounted");
//			}
//			/* close the command file */
//			//pclose(f);
//			fclose(f);
//		}
//	}
//	return;
//}


void Reset_DGSDAC() // To Reset the DAC and DGS after reading from file
{
	int key_v = 0;
	dgs_fromfile = 0;
	reset_value = 1;
	Set_default_val();

	Dac_f(key_v);
	STARTa_f(key_v);
	Point_f(key_v);
	press_f(key_v);

	Size_Eval_Select_f(key_v); // MENU 12

	Size_Eval_f(key_v);	 // MENU 4   // To be review
	Size_Eval_f1(key_v); // To be review
	Size_Eval_f2(key_v); // To be review
	Size_Eval_f3(key_v); // To be review
}


/****************************************************************************/
/***********************SET THE BOTTOM BUTTON'S******************************/
	/*for (i = 0; i < 5; i++)
	{
		b_btn[i] = gtk_button_new();
		b_label[i] = gtk_label_new(b_ary[i]);
		gtk_container_add(GTK_CONTAINER(b_btn[i]), b_label[i]);
		gtk_label_set_max_width_chars(GTK_LABEL(b_label[i]), 8);
		gtk_label_set_ellipsize(GTK_LABEL(b_label[i]), PANGO_ELLIPSIZE_END);
		gtk_widget_set_halign(GTK_WIDGET(b_label[i]), GTK_ALIGN_CENTER);
		gtk_widget_set_size_request(b_btn[i], button_width, button_height);
		gtk_widget_set_name(b_btn[i], bbtn_css[i]);
	}*/