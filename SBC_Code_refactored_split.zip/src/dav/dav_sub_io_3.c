/*cd /f/Dahlia-Verdin/GTK*/
/* RUN BAT FILE TO EXECUTE PROGRAM --> bash ./gtkboardapp_run.bat*/
/* gcc gtkrow.c src/src/OpenGL.c -o Main `pkg-config --cflags --libs gtk+-3.0` -lm -lwayland-client -lwayland-server -lwayland-egl -lEGL -lGLESv2 */
/* $CC gtkrow.c src/src/OpenGL.c -o Main `pkg-config --cflags --libs gtk+-3.0` -lm -lwayland-client -lwayland-server -lwayland-egl -lEGL -lGLESv2 */
/* $CC gtkrow.c src/src/OpenGL.c -o Main `pkg-config --cflags --libs gtk+-3.0` -lgpiod -lm -lwayland-client -lwayland-server -lwayland-egl -lEGL -lGLESv2 */
/* $CC src/src/Dav_Sub.c src/src/OpenGL.c -o Main `pkg-config --cflags --libs gtk+-3.0` -lgpiod -lm -lwayland-client -lwayland-server -lwayland-egl -lEGL -lGLESv2 */

// cd /mnt/e/2024/08-August_2024/2024-08-21/Dav_Sub
/*  bash Build_For_brd.sh */ // Use this command to Build the application to run on Board
//
//   bash ./Build_For_WSL.sh     // Build for WSL  Environment setti is not rquired
//   cd /mnt/d/
//  cd WSL_Wayland_Proj/WSL_Prog/Dav_Sub/Dav_Sub
//  . /opt/tdx-xwayland/5.7.1/environment-setup-aarch64-tdx-linux
//    which pkg-config
//    /opt/tdx-xwayland/5.7.1/sysroots/x86_64-tdxsdk-linux/usr/bin/pkg-config
//    bash Build_For_brd.sh
//    export DISPLAY=172.23.144.1:0 && export XDG_RUNTIME_DIR=/tmp/xdg && export RUNLEVEL=3 && weston

//   setup=setenv setupargs console=tty1 console=${console},${baudrate} consoleblank=0 earlycon   // set environment as below so during boot console command would not get display on screen
//   setenv setup 'setenv setupargs vt.global_cursor_default=0 console=${console},${baudrate} consoleblank=0 earlycon'
//   setenv setup 'setenv setupargs console=${console},${baudrate} consoleblank=0 earlycon'
// setenv setup 'setenv setupargs fec_mac=${ethaddr} consoleblank=0 no_console_suspend=1 console=${console},${baudrate}n8'
// setenv -> saveenv -> reset
// WSL UBUNTU PATH FROM PROGRAM FOR TESTING PURPOSE = fopen("/home/rnd1/temp1", "r"))
// CHECK DISK SPACE = df -H // To check storage in linux 

#ifdef WIN32
#include <io.h>
#define F_OK 0
#define access _access
#endif

#include <stdio.h>
#include <include/include/gpiod.h> // For WSL it is required to install libgpiod using following command in Ubuntu sudo apt-get install libgpiod-dev
#include <string.h>
#include <stdlib.h>
#include <stdint.h>
#include <math.h>
#include <stdbool.h>
#include <stdint.h>
#include <cairo.h>
#include <cairo-pdf.h>

#include <gtk/gtk.h>

#include "include/include/gtkdeclarations.h"
#include "include/include/Dav_Sub.h"
#include "include/include/dataval.h"
#include "include/include/cbentry.h"
#include "include/include/cbentry_safe1.h"
#include "include/include/OpenGL.h"
#include "include/include/shp_prf.h"
#include "include/include/Ruler.h"
#include "include/include/thick_log.h"
#include "include/include/plot_data.h"

#include <unistd.h>
#include <getopt.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <sys/wait.h>
#include <linux/types.h>
#include <linux/spi/spidev.h>

// #define ARRAY_SIZE(a) (sizeof(a) / sizeof((a)[0]))

gdouble Scr_stp_pre = 10.0;
int fd_SPI;

bool Spi_test = true;
struct OGLData ogl;

int Key_ck = 100;  // Key Check timer counter
int Key_Delay = 0; // Key Delay time control
bool Key_press = false;
int Measure_dsp = 0, Batt_dsp = 0, Batt_val = 0; // Measurement Display rate is controlle by this value
extern int tx_bufidx;
extern int Key_Scn_code;
extern int Key_stp;
extern GLubyte row_y[256];

extern cairo_t *Ascan_cr;
extern cairo_surface_t *Ascan_surface;
extern GdkPixbuf *Ascan_pixbuf;

void Keypad_rd(); // Read Keypad Data
void Read_rd();	  // Read Keypad Data
void Read_rd2();
void Read_Peak_amp();

void Init_all();
int Init_SPI(); // int main(int argc, char *argv[])  //int main(int argc, char *argv[])

void Start_up_Scr();
void Key_function();
void Keypad_ck(); // Read Keypad Data
void Send_SPI(int tx_nofd);
void Send_filt();
void Check_1K();
void Get_Data(); // Transfer data to Opengl Buffer from SPI Buffer
void Send_Data_to_OpenGL(void);
void Smooth_Asc();
void SPI_Receive(); // Receive Data using SPI

void DAC_Copy_for_Disp(int crvno); // Copy DAC points data for the Display
void Cal_Tval();
void Hruler_update();
void Vruler_update();

gboolean Key_perform_F(int keycodet);


/* --- Functions: category io --- */


void pwron_readvalues_old()
{
	FILE* file_h;
	int dmydata;
	GLubyte local_row_y[256];

	file_h = fopen("Pwr1off.set", "r");
	
	for (i = 0; i < 5; i++)
	{
		fread(&text_values[i], sizeof(char), 40, file_h); // sizeof(array_name[index])  sizeof(text_values[i])
		fscanf(file_h, "\n");
	}

	for (i = 0; i < 256; i++)
	{
		fscanf(file_h, "%hhd ", &local_row_y[i]);
		fscanf(file_h, "\n");
	}

	for (i = 0; i < 256; i++)  // Write Ascan data Peak values to memory
	{
		fscanf(file_h, "%f ", &All_Ascan_peak[i]);
		fscanf(file_h, "\n");
	}

	fscanf(file_h, "%d %d %d %d %d ", &Dac_v, &point_v, &Range_dac, &Dac_tlg_v, &Dac_crv_dB);
	fscanf(file_h, "%d %d %d ", &Ers_v, &Crv_db_dif, &Dac_ph);
	fscanf(file_h, "%d %d %d %d ", &Dgs_ref_gn, &Dgs_gn, &Dgs_ref_Nfg, &Dgs_gn);
	fscanf(file_h, "%d ", &dgs_fromfile);

	fscanf(file_h, "\n");
	// Read Dac Point data
	for (i = 0; i < 40; i++)  // Write Dac Point data to memory
	{
		fscanf(file_h, "%d ", &dac_pnt[i]);
	}

	fscanf(file_h, "\n");
	for (i = 0; i < 256; i++)  // Write DGS Point data to memory
	{
		fscanf(file_h, "%ld ", &dgs_pnt[i]);
	}

	for (i = 0; i < 256; i++)  // Write Ascan data Peak values to memory
	{
		fscanf(file_h, "%d ", &dmydata);
	}   //  Main DAC
	for (i = 0; i < 256; i++)  // Write Ascan data Peak values to memory
	{
		fscanf(file_h, "%d ", &dmydata);
	}   //  1P DAC
	for (i = 0; i < 256; i++)  // Write Ascan data Peak values to memory
	{
		fscanf(file_h, "%d ", &dmydata);
	}   //  2P DAC curve data
	for (i = 0; i < 256; i++)  // Write Ascan data Peak values to memory
	{
		fscanf(file_h, "%d ", &dmydata);
	}   //  1N DAC curve data
	for (i = 0; i < 256; i++)  // Write Ascan data Peak values to memory
	{
		fscanf(file_h, "%d ", &dmydata);
	}   // 2N DAC curve data

	fscanf(file_h, "\n");
	for (i = 0; i < 160; i++)
	{
		fscanf(file_h, "%d ", &val_ary[i]);
	}

	for (i = 0; i < 5; i++)
	{
		line_flag = false;
		for (j = 0; j < sizeof(text_values[i]); j++)
		{
			ch = text_values[i][j];
			if (ch != 32)
			{
				line_flag = true;
			}

			if (ch == 10 || ch == 13) // (ch == '\n') LF
			{
				text_values[i][j] = 0;
				break;
			}
		}
		last_idx = strlen(line[i]) - 1;

		if (text_values[i][0] == 0) // SPACE OR EMPTY LINE
		{
			break;
		}
		gtk_entry_set_text(GTK_ENTRY(text_h[i]), text_values[i]);
	}
	if (Dgs_onoff_v == 3)
	{
		dgs_fromfile = 1;
	}

	if (file_h)
	{
		fclose(file_h);
		file_h = NULL;
	}

	Refresh_Allpera_val_f(); // Required to change the values of all menu parameters according to the file
	Update_Note(); // REQUIRED TO CHANGE THE NOTE_DATA ARRAY VALUE WHILE RECALLING OR DETAIL OF THE NOTE //Menu_Refresh();

	opengl_update = false;
	Dac_Bscan_flag = false;

	for (i = 0; i < 256; i++)
	{
		row_y[i] = local_row_y[i];
	}
	Send_Data_to_OpenGL();
	ogl_render(frame_width, frame_height); // Call Opengl to display the Data
}


void pwron_readvalues(void)
{
	FILE* pfile = NULL;;
	int dmydata;
	GLubyte local_row_y[256];
	
	pfile = fopen("LastCalSet.set", "r");
	if (pfile != NULL)
	{
		// Note Data
		for (i = 0; i < 5; i++)
		{
			fread(&text_values[i], sizeof(char), 40, pfile); // sizeof(array_name[index])  sizeof(text_values[i])
			fscanf(pfile, "\n");
		}
		fscanf(pfile, "\n");

		// Menu Data
		for (i = 0; i < 160; i++)
		{
			fscanf(pfile, "%d ", &val_ary[i]);
		}
		fscanf(pfile, "\n");

		// Ascan Data
		for (i = 0; i < 256; i++)
		{
			fscanf(pfile, "%hhd ", &local_row_y[i]);		
		}	
		fscanf(pfile, "\n");	

		// Main DAC points 
		for (i = 0; i < 256; i++)
			fscanf(pfile, "%d ", (int*)(&pntArray_DACM[i].y));
		fscanf(pfile, "\n");

		// Main 1 positive DAC
		for (i = 0; i < 256; i++)
			fscanf(pfile, "%d ", (int*)(&pntArray_DAC1P[i].y));
		fscanf(pfile, "\n");

		// Main 2 positive DAC
		for (i = 0; i < 256; i++)
			fscanf(pfile, "%d ", (int*)(&pntArray_DAC2P[i].y));
		fscanf(pfile, "\n");

		//  Main 1 negative DAC
		for (i = 0; i < 256; i++)
			fscanf(pfile, "%d ", (int*)(&pntArray_DAC1N[i].y));
		fscanf(pfile, "\n");

		//  Main 2 negative DAC
		for (i = 0; i < 256; i++)
			fscanf(pfile, "%d ", (int*)(&pntArray_DAC2N[i].y));
		fscanf(pfile, "\n");

		for (i = 0; i < 256; i++)  // Write Ascan data Peak values to memory
		{
			fscanf(pfile, "%f ", &All_Ascan_peak[i]);
			fscanf(pfile, "\n");
		}

		fscanf(pfile, "%d %d %d %d %d ", &Dac_v, &point_v, &Range_dac, &Dac_tlg_v, &Dac_crv_dB);
		fscanf(pfile, "%d %d %d ", &Ers_v, &Crv_db_dif, &Dac_ph);
		fscanf(pfile, "%d %d %d %d ", &Dgs_ref_gn, &Dgs_gn, &Dgs_ref_Nfg, &Dgs_gn);
		fscanf(pfile, "%d", &dgs_fromfile);
		fscanf(pfile, "\n");

		// Read Dac Point data
		for (i = 0; i < 40; i++)  // Write Dac Point data to memory
			fscanf(pfile, "%d ", &dac_pnt[i]);
		fscanf(pfile, "\n");

		if (val_ary[DAC_PERA] == 3)
			dgs_fromfile = 1;

		for (i = 0; i < 250; i++)  // Write DGS y Point data to memory
			fscanf(pfile, "%ld ", &dgs_pnt[i]);
		fscanf(pfile, "\n");

		if (Measure_v1 > 0)   // Measure 1 Read values
		{
			for (i = 0; i < 4; i++)
			{
				fscanf(pfile, "%s ", mea_rd[i]);
				fscanf(pfile, "\n");
			}
		}

		if (Measure_v2 > 0) // Measure 2 Read values
		{
			for (i = 4; i < 8; i++)
			{
				fscanf(pfile, "%s ", mea_rd[i]);
				fscanf(pfile, "\n");
			}
		}

		///fscanf(pfile, "%ld %ld %ld %d", &G1_sp1, &G1_dp1, &G1_sd1, &G1_Amp1); // Sound path, Depth, Surface Distance, Amplitude
		// fscanf(pfile, "%ld %ld %ld %d", &G2_sp2, &G2_dp2, &G2_sd2, &G2_Amp2); // Sound path, Depth, Surface Distance, Amplitude
		fscanf(pfile, "%d %d %d ", &IL_v, &Af_v, &Rt_v); // AWS PARAMETER defect echo start, Width, height

		if (pfile)
		{
			fclose(pfile);
			pfile = NULL;
		}
	}
	else
	{
		g_print("Failed to open file for read data from LastCalSet file.\n");
	}
}



//void DetectUsb()  //Detect the usb
//{
//	FILE* f;
//	if (f = popen("mount | grep /media/sda", "r"))
//	{
//		if (NULL != f)
//		{
//			if (EOF == fgetc(f))
//			{
//				//gtk_widget_hide(nframe[9]);
//				gtk_widget_hide(n_image[8]);
//				usb_val = 0;
//			}
//			else
//			{
//				//gtk_widget_show(nframe[9]);
//				gtk_widget_show(n_image[8]);
//				strcpy(pendrv_path, "/media/sda/");
//				usb_val = 1;
//			}
//			pclose(f); /* close the command file */
//		}
//	}
//	else if (f = popen("mount | grep /media/sda1", "r"))
//	{
//		if (NULL != f)
//		{
//			if (EOF == fgetc(f))
//			{
//				//gtk_widget_hide(nframe[9]);
//				gtk_widget_hide(n_image[8]);
//				usb_val = 0;
//			}
//			else
//			{
//				//gtk_widget_show(nframe[9]);
//				gtk_widget_show(n_image[8]);
//				strcpy(pendrv_path, "/media/sda1/");
//				usb_val = 1;
//			}
//			pclose(f); 	/* close the command file */
//		}
//	}
//	else if (f = popen("mount | grep /media/sdb", "r"))
//	{
//		if (NULL != f)
//		{
//			if (EOF == fgetc(f))
//			{
//				//gtk_widget_hide(nframe[9]);
//				gtk_widget_hide(n_image[8]);
//				usb_val = 0;
//			}
//			else
//			{
//				//gtk_widget_show(nframe[9]);
//				gtk_widget_show(n_image[8]);
//				strcpy(pendrv_path, "/media/sdb/");
//				usb_val = 1;
//			}
//			pclose(f); /* close the command file */
//		}
//	}
//	else if (f = popen("mount | grep /media/sdb1", "r"))
//	{
//		if (NULL != f)
//		{
//			if (EOF == fgetc(f))
//			{
//				//gtk_widget_hide(nframe[9]);
//				gtk_widget_hide(n_image[8]);
//				usb_val = 0;
//			}
//			else
//			{
//				//gtk_widget_show(nframe[9]);
//				gtk_widget_show(n_image[8]);
//				strcpy(pendrv_path, "/media/sdb1/");
//				usb_val = 1;
//			}
//			pclose(f); /* close the command file */
//		}
//	}
//	return;
//}

//void DetectUsb()  //Detect the usb
//{
//	//Copy_All();
//	FILE* f;
//	//if (f = popen("mount | grep /home/rnd1/temp1", "r")) //fopen(path_h, "r");
//	if (f = fopen("/home/rnd1/temp1", "r"))
//	{
//		if (NULL != f)
//		{
//			/* test if something has been output by the command */
//			//if (EOF == fgetc(f))
//			if (feof(f))
//			{
//				gtk_widget_hide(nframe[9]);
//				usb_val = 0;
//				//puts("\n/dev/sda1 is NOT mounted");
//			}
//			else
//			{
//				gtk_widget_show(nframe[9]);
//				strcpy(pendrv_path, "/home/rnd1/temp1");
//				//pendrv_path
//				usb_val = 1;
//				//puts("\n/dev/sda1 is mounted");
//			}
//			/* close the command file */
//			//pclose(f);
//			fclose(f);
//		}
//	}
//	//else if (f = popen("mount | grep /home/rnd1/temp2", "r")) // else if (f = fopen("Cal", "r"))
//	else if (f = fopen("/home/rnd1/temp2", "r"))
//	{
//		if (NULL != f)
//		{
//			/* test if something has been output by the command */
//			//if (EOF == fgetc(f))
//			if (feof(f))
//			{
//				gtk_widget_hide(nframe[9]);
//				usb_val = 0;
//				//puts("\n/dev/sda1 is NOT mounted");
//			}
//			else
//			{
//				gtk_widget_show(nframe[9]);
//				strcpy(pendrv_path, "/home/rnd1/temp2");
//				usb_val = 1;
//				//puts("\n/dev/sda1 is mounted");
//			}
//			/* close the command file */
//			//pclose(f);
//			fclose(f);
//		}
//	}
//	return;
//}


void Reset_DGSDAC() // To Reset the DAC and DGS after reading from file
{
	int key_v = 0;
	dgs_fromfile = 0;
	reset_value = 1;
	Set_default_val();

	Dac_f(key_v);
	STARTa_f(key_v);
	Point_f(key_v);
	press_f(key_v);

	Size_Eval_Select_f(key_v); // MENU 12

	Size_Eval_f(key_v);	 // MENU 4   // To be review
	Size_Eval_f1(key_v); // To be review
	Size_Eval_f2(key_v); // To be review
	Size_Eval_f3(key_v); // To be review
}


/****************************************************************************/
/***********************SET THE BOTTOM BUTTON'S******************************/
	/*for (i = 0; i < 5; i++)
	{
		b_btn[i] = gtk_button_new();
		b_label[i] = gtk_label_new(b_ary[i]);
		gtk_container_add(GTK_CONTAINER(b_btn[i]), b_label[i]);
		gtk_label_set_max_width_chars(GTK_LABEL(b_label[i]), 8);
		gtk_label_set_ellipsize(GTK_LABEL(b_label[i]), PANGO_ELLIPSIZE_END);
		gtk_widget_set_halign(GTK_WIDGET(b_label[i]), GTK_ALIGN_CENTER);
		gtk_widget_set_size_request(b_btn[i], button_width, button_height);
		gtk_widget_set_name(b_btn[i], bbtn_css[i]);
	}*/