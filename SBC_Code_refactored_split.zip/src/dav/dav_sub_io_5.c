/*cd /f/Dahlia-Verdin/GTK*/
/* RUN BAT FILE TO EXECUTE PROGRAM --> bash ./gtkboardapp_run.bat*/
/* gcc gtkrow.c src/src/OpenGL.c -o Main `pkg-config --cflags --libs gtk+-3.0` -lm -lwayland-client -lwayland-server -lwayland-egl -lEGL -lGLESv2 */
/* $CC gtkrow.c src/src/OpenGL.c -o Main `pkg-config --cflags --libs gtk+-3.0` -lm -lwayland-client -lwayland-server -lwayland-egl -lEGL -lGLESv2 */
/* $CC gtkrow.c src/src/OpenGL.c -o Main `pkg-config --cflags --libs gtk+-3.0` -lgpiod -lm -lwayland-client -lwayland-server -lwayland-egl -lEGL -lGLESv2 */
/* $CC src/src/Dav_Sub.c src/src/OpenGL.c -o Main `pkg-config --cflags --libs gtk+-3.0` -lgpiod -lm -lwayland-client -lwayland-server -lwayland-egl -lEGL -lGLESv2 */

// cd /mnt/e/2024/08-August_2024/2024-08-21/Dav_Sub
/*  bash Build_For_brd.sh */ // Use this command to Build the application to run on Board
//
//   bash ./Build_For_WSL.sh     // Build for WSL  Environment setti is not rquired
//   cd /mnt/d/
//  cd WSL_Wayland_Proj/WSL_Prog/Dav_Sub/Dav_Sub
//  . /opt/tdx-xwayland/5.7.1/environment-setup-aarch64-tdx-linux
//    which pkg-config
//    /opt/tdx-xwayland/5.7.1/sysroots/x86_64-tdxsdk-linux/usr/bin/pkg-config
//    bash Build_For_brd.sh
//    export DISPLAY=172.23.144.1:0 && export XDG_RUNTIME_DIR=/tmp/xdg && export RUNLEVEL=3 && weston

//   setup=setenv setupargs console=tty1 console=${console},${baudrate} consoleblank=0 earlycon   // set environment as below so during boot console command would not get display on screen
//   setenv setup 'setenv setupargs vt.global_cursor_default=0 console=${console},${baudrate} consoleblank=0 earlycon'
//   setenv setup 'setenv setupargs console=${console},${baudrate} consoleblank=0 earlycon'
// setenv setup 'setenv setupargs fec_mac=${ethaddr} consoleblank=0 no_console_suspend=1 console=${console},${baudrate}n8'
// setenv -> saveenv -> reset
// WSL UBUNTU PATH FROM PROGRAM FOR TESTING PURPOSE = fopen("/home/rnd1/temp1", "r"))
// CHECK DISK SPACE = df -H // To check storage in linux 

#ifdef WIN32
#include <io.h>
#define F_OK 0
#define access _access
#endif

#include <stdio.h>
#include <include/include/gpiod.h> // For WSL it is required to install libgpiod using following command in Ubuntu sudo apt-get install libgpiod-dev
#include <string.h>
#include <stdlib.h>
#include <stdint.h>
#include <math.h>
#include <stdbool.h>
#include <stdint.h>
#include <cairo.h>
#include <cairo-pdf.h>

#include <gtk/gtk.h>

#include "include/include/gtkdeclarations.h"
#include "include/include/Dav_Sub.h"
#include "include/include/dataval.h"
#include "include/include/cbentry.h"
#include "include/include/cbentry_safe1.h"
#include "include/include/OpenGL.h"
#include "include/include/shp_prf.h"
#include "include/include/Ruler.h"
#include "include/include/thick_log.h"
#include "include/include/plot_data.h"

#include <unistd.h>
#include <getopt.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <sys/wait.h>
#include <linux/types.h>
#include <linux/spi/spidev.h>

// #define ARRAY_SIZE(a) (sizeof(a) / sizeof((a)[0]))

gdouble Scr_stp_pre = 10.0;
int fd_SPI;

bool Spi_test = true;
struct OGLData ogl;

int Key_ck = 100;  // Key Check timer counter
int Key_Delay = 0; // Key Delay time control
bool Key_press = false;
int Measure_dsp = 0, Batt_dsp = 0, Batt_val = 0; // Measurement Display rate is controlle by this value
extern int tx_bufidx;
extern int Key_Scn_code;
extern int Key_stp;
extern GLubyte row_y[256];

extern cairo_t *Ascan_cr;
extern cairo_surface_t *Ascan_surface;
extern GdkPixbuf *Ascan_pixbuf;

void Keypad_rd(); // Read Keypad Data
void Read_rd();	  // Read Keypad Data
void Read_rd2();
void Read_Peak_amp();

void Init_all();
int Init_SPI(); // int main(int argc, char *argv[])  //int main(int argc, char *argv[])

void Start_up_Scr();
void Key_function();
void Keypad_ck(); // Read Keypad Data
void Send_SPI(int tx_nofd);
void Send_filt();
void Check_1K();
void Get_Data(); // Transfer data to Opengl Buffer from SPI Buffer
void Send_Data_to_OpenGL(void);
void Smooth_Asc();
void SPI_Receive(); // Receive Data using SPI

void DAC_Copy_for_Disp(int crvno); // Copy DAC points data for the Display
void Cal_Tval();
void Hruler_update();
void Vruler_update();

gboolean Key_perform_F(int keycodet);


/* --- Functions: category io --- */


void h_detail()
{
	int tempval_ary[200]; 
	float All_Ascan_peak12[512];
	char t_mea_rd[10][15];
	GLubyte row_y12[256];
	FILE* file_h;
	int dmydata;
	float tfd, offst;
	tfd = (50.0f * ((float)splite_frame_height - 2.0f)) / (float)Asc_Height;
    offst = (50.0f + ((((float)splite_frame_height - 2.0f) - (float)Asc_Height) / 8.0f));

	// char *path_f = filen;
	// key_scr = 0;

	file_h = fopen(path_h, "r");

	for (i = 0; i < 5; i++)
	{
		fread(&text_values[i], sizeof(char), 40, file_h);
		fscanf(file_h, "\n");
	}

	// for (i = 0; i < 256; i++)
	{
		fread(&row_y12[0], sizeof(char) * 256, 1, file_h);
		fscanf(file_h, "\n");
		ogl.vertices_position[(i * 2) + 1] = ((GLfloat)row_y12[i] - offst) / tfd;
		// ogl.vertices_position[(i * 2) + 1] = ((GLfloat)row_y12[i] - 50.0f) / 50.0f;
	}

	// Ascan peak data write
	// for (i = 0; i < 512; i++)
	{
		fread(&All_Ascan_peak12[0], 1, sizeof(float) * 512, file_h);
		fscanf(file_h, "\n");
	}

	fscanf(file_h, "%d %d %d %d %d ", &Dac_v, &point_v, &Range_dac, &Dac_tlg_v, &Dac_crv_dB);
	fscanf(file_h, "%d %d %d ", &Ers_v, &Crv_db_dif, &Dac_ph);
	fscanf(file_h, "%d %d %d %d ", &Dgs_ref_gn, &Dgs_gn, &Dgs_ref_Nfg, &Dgs_gn);

	fscanf(file_h, "\n");
	// Read Dac Point data
	for (i = 0; i < 40; i++)  // Write Dac Point data to memory
	{
		fscanf(file_h, "%d ", &dac_pnt[i]);
	}

	for (i = 0; i < 256; i++)  // Write Ascan data Peak values to memory
	{
		fscanf(file_h, "%d ", &dmydata);
	}   //  Main DAC
	for (i = 0; i < 256; i++)  // Write Ascan data Peak values to memory
	{
		fscanf(file_h, "%d ", &dmydata);
	}   //  1P DAC
	for (i = 0; i < 256; i++)  // Write Ascan data Peak values to memory
	{
		fscanf(file_h, "%d ", &dmydata);
	}   //  2P DAC curve data
	for (i = 0; i < 256; i++)  // Write Ascan data Peak values to memory
	{
		fscanf(file_h, "%d ", &dmydata);
	}   //  1N DAC curve data
	for (i = 0; i < 256; i++)  // Write Ascan data Peak values to memory
	{
		fscanf(file_h, "%d ", &dmydata);
	}   //  2N DAC curve data

	fscanf(file_h, "\n");
	for (i = 0; i < 160; i++) // Read all menu values
	{
		fscanf(file_h, "%d ", &tempval_ary[i]);
		fscanf(file_h, "\n");
	}

	fscanf(file_h, "\n");
	if (Measure_v1 > 0)   // Measure 1 Read values
	{
		for (i = 0; i < 4; i++)
		{
			fscanf(file_h, "%s ", t_mea_rd[i]);
			//fprintf(f_h, "%s ", mea_rd[i]);
			fscanf(file_h, "\n");
		}
	}

	if (Measure_v2 > 0) // Measure 2 Read values
	{
		for (i = 4; i < 8; i++)
		{
			fscanf(file_h, "%s ", t_mea_rd[i]);
			//fprintf(f_h, "%s ", mea_rd[i]);
			fscanf(file_h, "\n");
		}
	}

	for (i = 0; i < 5; i++)
	{
		line_flag = false;
		for (j = 0; j < sizeof(text_values[i]); j++)
		{
			ch = text_values[i][j];
			if (ch != 32)
			{
				line_flag = true;
			}
			if (ch == 10 || ch == 13) // (ch == '\n') LF
			{
				text_values[i][j] = 0;
				break;
			}
		}
		last_idx = strlen(line[i]) - 1;
		if (text_values[i][0] == 0) // SPACE OR EMPTY LINE
		{
			break;
		}
		gtk_entry_set_text(GTK_ENTRY(text_h[i]), text_values[i]);
	}

	if (file_h)
	{
		fclose(file_h);
		file_h = NULL;
	}

	Update_Note(); // REQUIRED TO CHANGE THE NOTE_DATA ARRAY VALUE WHILE RECALLING OR DETAIL OF THE NOTE
}


void Write_NoteText()
{
	FILE *f_h;
	// char* path_f = filen;

	f_h = fopen("Note1.txt", "w");
	for (i = 0; i < 14; i++)
	{
		fwrite(heading_name[i], sizeof(char), 40, f_h);
		fprintf(f_h, "\n");
	}
	fclose(f_h);
}


void Key_function()
{ 
	// Key_Scn_code=data;
	if (beep_val == 1)
	{
		Key_Beep();
	}
	if ((Key_Scn_code & Menu_UP_K) > 0)
	{
		Key_perform_F(Menu_UP_K);
	}  // Menu UP Key {printf("Menu UP");}   // 0x1F7F  E080
	if ((Key_Scn_code & Menu_DN_K) > 0)
	{
		Key_perform_F(Menu_DN_K);
	}  // 0x1EFF  E100
	if ((Key_Scn_code & GAIN_UP_K) > 0)
	{
		Key_perform_F(GAIN_UP_K);
	}  // 0x1FFD  E002
	if ((Key_Scn_code & GAIN_DN_K) > 0)
	{
		Key_perform_F(GAIN_DN_K);
	}  // 0x1FFE  E001
	if ((Key_Scn_code & Pera_UP_K) > 0)
	{
		Key_perform_F(Pera_UP_K);
	}  // 0x1FEF  E010
	if ((Key_Scn_code & Pera_DN_K) > 0)
	{
		Key_perform_F(Pera_DN_K);
	}  // 0x1FFB  E004
	if ((Key_Scn_code & SLCT_UP_K) > 0)
	{
		Key_perform_F(SLCT_UP_K);
	}  // 0x1FF7  E008
	if ((Key_Scn_code & SLCT_DN_K) > 0)
	{
		Key_perform_F(SLCT_DN_K);
	}  // 0x1FBF  E040
}


void Read_rd2()
{

}


void Close_StScreen()
{
	g_source_remove(st_scrn_time_id);
	st_scrn_time_id = 0;
	gtk_widget_destroy(GTK_WIDGET(window_home));
	Init_all(); // Init/Start Main Application

	//Set_default_val(); // During Power Up set values of all perameters to default value
	
	//path_h = "Pwr1off.set";
	//if(access(path_h, F_OK) != -1) // During Power Up Read values of all perameters
	//{
	//	pwron_readvalues();
	//}
	//else
	{
		Refresh_Allpera_val_f(); // Refresh all peravalue by calling each function. It is used when Data recall from Memoery
	}
	Menu_f(0);
	menu_v = 0;
	printf("App Started \n\n");
}

void activate(GtkApplication *app, gpointer user_data)
{
	// Set s/w clock time from h/w clock
	// system("hwclock -s");

	int fixSzie = 0;
	window = gtk_application_window_new(app);
	if (fixSzie == 1)
	{
    	gtk_window_set_default_size(GTK_WINDOW(window), 1024, 600); // Set window size
	}
	else
	{
		gtk_window_set_default_size(GTK_WINDOW(window), -1, -1);
		gtk_window_fullscreen(GTK_WINDOW(window));
		gtk_window_set_decorated(GTK_WINDOW(window), false); // Set false to remove topmost taskbar
	}

	/*******************OPENGL WINDOW DISPLAY**************************/
	/******************************************************************/
		
	gtk_widget_realize(window);
	gdk_window = gtk_widget_get_window(GTK_WIDGET(window));
	if (!GDK_IS_WAYLAND_WINDOW(gdk_window))
		printf("Can't GDK_IS_WAYLAND_WINDOW.\n");

	gdk_display = gdk_window_get_display(gdk_window);

	cssProvider = gtk_css_provider_new();
	css_clr_grd_Provider = gtk_css_provider_new();
	gtk_css_provider_load_from_path(GTK_CSS_PROVIDER(css_clr_grd_Provider), "color_grd_css.css", NULL);
	gtk_style_context_add_provider_for_screen(gdk_screen_get_default(), GTK_STYLE_PROVIDER(css_clr_grd_Provider), GTK_STYLE_PROVIDER_PRIORITY_USER);

	create_color_gradient_data();	  // Color Gradient For Color Coding
	create_color_gradient_tfd_data(); // Color Gradient For TOFD

	Set_default_val(); // During Power Up set values of all perameters to default value

	///*****SET VALUE THE DRAW FOR DRAWING OBJECTS, PROFILER AND RAYS ******/
	///*********************************************************************/
	//// Shape values initialize
	init_shape_value();

	//// Profiler values initialize
	initialize_profiler_data();
	init_profiler_value();
	copy_profiler_data();

	// Rays values initialize
	initialize_ray_data();
	init_rays_value();
	copy_rays_data();

	init_bsc_data();
	set_zero_data();

	bsc_height = (height_sh / 2) - (h_ruler_height);
	splite_frame_height = frame_height;

	pwron_readvalues();

	/*********SET VALUE OF THE REFERENCE FOR GAIN VALUE************/
	/**************************************************************/

	// gain_ref = val_ary[9];

	// sprintf(gstr_1, "%d", gain_ref);
	// sprintf(gstr_2, "%s", "\n  REF  ");

	// if (gain_ref > 0 && gain_ref < 100)
	// {
	// 	gstr_3[0] = gstr_1[0];
	// 	gstr_3[1] = dot[0];
	// 	gstr_3[2] = gstr_1[1];
	// }
	// if (gain_ref >= 100 && gain_ref < 1000)
	// {
	// 	gstr_3[0] = gstr_1[0];
	// 	gstr_3[1] = gstr_1[1];
	// 	gstr_3[2] = dot[0];
	// 	gstr_3[3] = gstr_1[2];
	// }
	// strcat(gstr_2, gstr_3);

	/****************************/
	/*CREATING MAIN VERTICAL BOX*/
	/****************************/
	avbox = gtk_box_new(GTK_ORIENTATION_VERTICAL, 0);

	/***********************************************/
	/*CREATING HORIZONTAL FIRST BOX FOR NOTIFICATION IMAGES*/
	/***********************************************/
	ahbox1 = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
	gtk_box_pack_start(GTK_BOX(avbox), ahbox1, false, false, 0);
	space51 = gtk_label_new("       ");
	gtk_widget_set_name(space51, "space51-label");
	gtk_widget_set_size_request(space51, 540, 40); // 550
	gtk_box_pack_start(GTK_BOX(ahbox1), space51, false, false, 0);

	/******************************************************************************/
	/***************SET FIRST LAYER OF NOTIFICATION IMG****************************/

	v2box = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
	/*gtk_box_pack_start(GTK_BOX(ahbox1), v2box, false, false, 0);*/

	int img_wt = image_w;
	// IMAGE OF DUAL, SINGLE, DAC, DGS, AWS ,REJECT, BATTERY etc. shown in frame over here
	for (i = 0; i < 7; i++) // for (i = 0; i < 6; i++)
	{
		if (i == 6)
		{
			img_wt = img_wt + 20;
		}
		nframe[i] = gtk_frame_new(NULL);
		gtk_frame_set_shadow_type(GTK_FRAME(nframe[i]), GTK_SHADOW_NONE); // GTK_SHADOW_IN);  //img_wtbat
		gtk_widget_set_size_request(nframe[i], img_wt, image_h);
		//n_pximage[i] = gdk_pixbuf_new_from_file_at_scale(imagename[i], img_wt, image_h, false, NULL);
		n_image[i] = gtk_image_new_from_pixbuf(n_pximage[i]);
		gtk_widget_set_size_request(GTK_WIDGET(n_image[i]), img_wt, image_h);
		gtk_container_add(GTK_CONTAINER(nframe[i]), n_image[i]);
		gtk_box_pack_start(GTK_BOX(v2box), nframe[i], false, false, 0);
	}

	Batt_Perc = gtk_label_new("     "); //Clock_lab = gtk_label_new("11:36 Dt:05/02/2023");
	//gtk_widget_set_name(Batt_Perc, "BattPer-entry");
	gtk_widget_set_halign(GTK_WIDGET(Batt_Perc), GTK_ALIGN_START);
	gtk_label_set_max_width_chars(GTK_LABEL(Batt_Perc), 25);
	gtk_label_set_ellipsize(GTK_LABEL(Batt_Perc), PANGO_ELLIPSIZE_END);
	gtk_container_add(GTK_CONTAINER(v2box), Batt_Perc);

	/*****************************************************************************************/
	/************************LAYER OF BSCAN PAUSE AND PLAY AND USB IMG************************/
	/*****************************************************************************************/

	nframe[8] = gtk_frame_new(NULL);
	gtk_frame_set_shadow_type(GTK_FRAME(nframe[8]), GTK_SHADOW_NONE); // GTK_SHADOW_IN);
	gtk_widget_set_size_request(nframe[8], image_clk, image_h);
	Pause_lab = gtk_label_new("     ");
	gtk_widget_set_halign(GTK_WIDGET(Pause_lab), GTK_ALIGN_START);
	gtk_label_set_max_width_chars(GTK_LABEL(Pause_lab), 25);
	gtk_label_set_ellipsize(GTK_LABEL(Pause_lab), PANGO_ELLIPSIZE_END);
	gtk_widget_set_name(Pause_lab, "Pause-entry");
	gtk_container_add(GTK_CONTAINER(nframe[8]), Pause_lab);
	gtk_box_pack_start(GTK_BOX(ahbox1), nframe[8], false, false, 0); // PAUSE OR PLAY FOR BSCAN RECORD

	n_sdcrdfrm = gtk_frame_new(NULL);
	gtk_frame_set_shadow_type(GTK_FRAME(n_sdcrdfrm), GTK_SHADOW_NONE); // GTK_SHADOW_IN);
	gtk_widget_set_size_request(n_sdcrdfrm, image_w, 35); // SD_Card.PNG

	n_pximage[11] = gdk_pixbuf_new_from_file_at_scale("Images/Images/sd.png", image_w, 35, false, NULL);
	n_image[11] = gtk_image_new_from_pixbuf(n_pximage[11]);
	gtk_widget_set_size_request(GTK_WIDGET(n_image[11]), image_w, 35);
	gtk_container_add(GTK_CONTAINER(n_sdcrdfrm), n_image[11]);

	nframe[9] = gtk_frame_new(NULL);
	gtk_frame_set_shadow_type(GTK_FRAME(nframe[9]), GTK_SHADOW_NONE); // GTK_SHADOW_IN);
	gtk_widget_set_size_request(nframe[9], image_w + 18, 24);

	n_pximage[8] = gdk_pixbuf_new_from_file_at_scale("Images/Images/usb_size_1.png", image_w + 15, 22, false, NULL);
	n_image[8] = gtk_image_new_from_pixbuf(n_pximage[8]);
	gtk_widget_set_size_request(GTK_WIDGET(n_image[8]), image_w + 15, 22);
	gtk_container_add(GTK_CONTAINER(nframe[9]), n_image[8]);

	gtk_box_pack_start(GTK_BOX(ahbox1), n_sdcrdfrm, false, false, 5);
	gtk_box_pack_start(GTK_BOX(ahbox1), nframe[9], false, false, 5); // USB attached logo
	gtk_box_pack_start(GTK_BOX(ahbox1), v2box, false, false, 0); // Notification Images and Battery Image

	/**********************************************************/
	/****CREATING HORIZONTAL BOX FOR FRAME AND DATA BUTTONS****/
	/**********************************************************/
	ahbox3 = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
	gtk_box_pack_start(GTK_BOX(avbox), ahbox3, false, false, 1);

	/*CREATE THE FRAME FOR DRAWING AREA*/
	frame = gtk_frame_new(NULL);
	overlay = gtk_overlay_new();
	//gtk_frame_set_shadow_type(GTK_FRAME(frame), GTK_SHADOW_IN);
	gtk_widget_set_size_request(frame, frame_width, frame_height);

	/**********************************************************/
	/***********************OPENGL PART************************/
	/**********************************************************/

	egl_wayland_initialization(gdk_window, frame_width, frame_height);
	ogl_render(frame_width, frame_height);

	/**********************************************************/
	/*********************SPLIT WINDOW PART********************/
	/**********************************************************/

	frame_s1 = gtk_frame_new(NULL);
	gtk_widget_set_size_request(frame_s1, width_sh, (height_sh / 2));

	// Bscan
	dest_pixbuf = gdk_pixbuf_new(GDK_COLORSPACE_RGB, false, 8, width_sh, bsc_height);
	gdk_pixbuf_fill(dest_pixbuf, 0x000000FF);
	plot_bscan_data = gtk_image_new_from_pixbuf(dest_pixbuf);

	bscan_data_grid = gtk_event_box_new();
    gtk_widget_set_size_request(bscan_data_grid, width_sh, bsc_height);
	gtk_container_add(GTK_CONTAINER(bscan_data_grid), plot_bscan_data);

	// register callback function to os for get mouse co-ordinates
	g_signal_connect(bscan_data_grid, "motion-notify-event", G_CALLBACK(get_mouse_coordinates), NULL); // Get Mouse position X,Y
	gtk_widget_set_events(bscan_data_grid, GDK_POINTER_MOTION_MASK);

	src_pixbuf = gdk_pixbuf_new(GDK_COLORSPACE_RGB, false, 8, width_sh * 2, bsc_height);
	gdk_pixbuf_fill(src_pixbuf, 0x000000FF);

	pixbuf_base_address = gdk_pixbuf_get_pixels(dest_pixbuf);
	rgb_count = gdk_pixbuf_get_n_channels(dest_pixbuf);
	rowstride = gdk_pixbuf_get_rowstride(dest_pixbuf);

	// Bscan rular
	surface_rular = cairo_image_surface_create(CAIRO_FORMAT_RGB24, width_sh, h_ruler_height);
	cr_rular = cairo_create(surface_rular);
	surface_rular_image = gtk_image_new_from_surface(surface_rular);
	surface_rular_update();

	frm_box = gtk_box_new(GTK_ORIENTATION_VERTICAL, 0);
	gtk_box_pack_start(GTK_BOX(frm_box), bscan_data_grid, false, false, 0);
	gtk_box_pack_start(GTK_BOX(frm_box), surface_rular_image, false, false, 0);
	gtk_container_add(GTK_CONTAINER(frame_s1), frm_box);

	frame_s2 = gtk_frame_new(NULL);
	gtk_widget_set_size_request(frame_s2, width_sh, (height_sh / 2));

	surface_clr = cairo_image_surface_create(CAIRO_FORMAT_RGB24, width_sh, (height_sh / 2));
	cr_clr = cairo_create(surface_clr);
	surface_clr_image = gtk_image_new_from_surface(surface_clr);
	draw_thick_log();

	gtk_container_add(GTK_CONTAINER(frame_s2), surface_clr_image);

	splite_box_1 = gtk_box_new(GTK_ORIENTATION_VERTICAL, 0);
	splite_box_2 = gtk_box_new(GTK_ORIENTATION_VERTICAL, 0);
	gtk_box_pack_start(GTK_BOX(splite_box_1), frame_s1, false, false, 0);
	gtk_box_pack_start(GTK_BOX(splite_box_2), frame_s2, false, false, 0);

	/****************************************************************/
	/***************CREATE THE DATA BTN AREA*************************/
	/****************************************************************/

	f2_box = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);

	Main_lyout = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);

	/*Develop button and give the size of the button*/
	for (i = 0; i < 24; i++)
	{
		dgs_btn[i] = gtk_button_new();
		gtk_widget_set_size_request(dgs_btn[i], btn_width, btn_height);
	}

	V1_lyout = gtk_box_new(GTK_ORIENTATION_VERTICAL, 0);
	gtk_box_pack_start(GTK_BOX(Main_lyout), V1_lyout, false, false, 1);

	for (i = 0, j = 180; i < 8, j < 188; i++, j++)
	{
		gtk_box_pack_start(GTK_BOX(V1_lyout), dgs_btn[i], false, false, 0);
		dgslabel[i] = gtk_label_new(all_btnval[j]);
		gtk_container_add(GTK_CONTAINER(dgs_btn[i]), dgslabel[i]);
		gtk_widget_set_name(dgs_btn[i], btndv_css[i]);
	}

	V2_lyout = gtk_box_new(GTK_ORIENTATION_VERTICAL, 0);
	gtk_box_pack_start(GTK_BOX(Main_lyout), V2_lyout, false, false, 1);

	for (i = 8, j = 190, k = 0; i < 16; i++, j++, k++) //for (i = 8, j = 190, k = 0; i < 16, j < 198, k < 8; i++, j++, k++)
	{
		gtk_box_pack_start(GTK_BOX(V2_lyout), dgs_btn[i], false, false, 0);
		dgslabel[i] = gtk_label_new(all_btnval[j]);
		gtk_container_add(GTK_CONTAINER(dgs_btn[i]), dgslabel[i]);
		gtk_widget_set_name(dgs_btn[i], btndv_css[k]);
	}

	V3_lyout = gtk_box_new(GTK_ORIENTATION_VERTICAL, 0);
	gtk_box_pack_start(GTK_BOX(Main_lyout), V3_lyout, false, false, 1);

	for (i = 16, j = 202, k = 0; i < 24; i++, j++, k++) // for (i = 17, j = 202, k = 0; i < 24, j < 208, k < 8; i++, j++, k++)
	{
		gtk_box_pack_start(GTK_BOX(V3_lyout), dgs_btn[i], false, false, 0);
		dgslabel[i] = gtk_label_new(all_btnval[j]);
		gtk_container_add(GTK_CONTAINER(dgs_btn[i]), dgslabel[i]);
		gtk_widget_set_name(dgs_btn[i], btndv_css[k]);
	}

	for (k = 0; k < 16; k = k + 2)
	{
		gtk_widget_set_halign(GTK_WIDGET(dgslabel[k]), GTK_ALIGN_START);
	}

	for (i = 16; i < 24; i = i + 2)
	{
		gtk_widget_set_halign(GTK_WIDGET(dgslabel[i]), GTK_ALIGN_START);
	}

	prof_box = gtk_box_new(GTK_ORIENTATION_VERTICAL, 0);
	shape_profiler_rays_surface = cairo_image_surface_create(CAIRO_FORMAT_RGB24, profiler_drawing_area_width, profiler_drawing_area_height);
	shape_profiler_rays_cr = cairo_create(shape_profiler_rays_surface);
	shape_profiler_rays_image = gtk_image_new_from_surface(shape_profiler_rays_surface);
	gtk_box_pack_start(GTK_BOX(prof_box), shape_profiler_rays_image, false, false, 0);
	draw_function();

	gtk_box_pack_start(GTK_BOX(f2_box), prof_box, false, false, 0);	  //
	gtk_box_pack_start(GTK_BOX(f2_box), Main_lyout, false, false, 0); // DGS , WELD PROF BOXES 

	// gtk_box_pack_start(GTK_BOX(f2_box), Main_lyout, false, false, 325);  // Set Left postion of DGS Selection

	/**************************************************************************/
	/**********************NOTE TEXTBOX AREA CREATED***************************/
	/**************************************************************************/
	f3_box = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);

	ft_h = fopen("Note4.txt", "r");

	for (i = 0; i < 10; i++)
	{
		fgets(line[i], sizeof(line[i]), ft_h);
	}

	fclose(ft_h);

	///////////////////////////////////////////////////////////////

	txtbox = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 1);

	txtbox1 = gtk_box_new(GTK_ORIENTATION_VERTICAL, 0);
	gtk_box_pack_start(GTK_BOX(txtbox), txtbox1, false, false, 0);

	txtbox2 = gtk_box_new(GTK_ORIENTATION_VERTICAL, 0);
	gtk_box_pack_start(GTK_BOX(txtbox), txtbox2, false, false, 0);

	/**********************************/
	/**CREATE READ ONLY TEXT ENTRIES**/

	for (i = 5; i < 10; i++) // for (i = 14; i < 28; i++)
	{
		// FOR TEXT HEADING LABELS
		text_h[i] = gtk_entry_new();
		gtk_widget_set_size_request(text_h[i], texthd_width, 0);
		gtk_box_pack_start(GTK_BOX(txtbox1), text_h[i], false, false, 1);
	}

	for (i = 0; i < 5; i++) // for (i = 0; i < 14; i++)
	{
		// FOR TEXT DATA VALUES
		text_h[i] = gtk_entry_new();
		gtk_widget_set_size_request(text_h[i], txtdata_width, 0);

		gtk_widget_set_can_focus(GTK_WIDGET(text_h[i]), false);
		gtk_box_pack_start(GTK_BOX(txtbox2), text_h[i], false, false, 1);
		gtk_widget_add_events(text_h[i], GDK_KEY_PRESS_MASK);
		gtk_widget_set_name(text_h[i], "text-entry");
	}

	/////////////////READ HEADINGS TEXT FROM FILE/////////////////////

	for (i = 0; i < 5; i++) // for (i = 0; i < 14; i++)
	{
		gtk_entry_set_text(GTK_ENTRY(text_h[count]), heading_name[i]); // Display Heading of Note Data
		j = i * 40;
		for (k = 0; k < 40; k++)
		{
			stringbox[k] = Note_data[j++];
		}
		gchar *ret = g_locale_to_utf8(stringbox, 40, NULL, NULL, NULL); // CONVERT TO UTF8 STRING
		gtk_entry_set_text(GTK_ENTRY(text_h[temp_count]), ret);	// Display Data of Note Data //gtk_entry_set_text(GTK_ENTRY(text_h[ln_no]), ret); // gchar* ret =o_name[i];

		count = count + 1;	// TO COUNT THE NUMBER OF LINES FOR HEADING
		temp_count = temp_count + 1; // COUNT NUMBER OF DATA LINES
		imgline_count = imgline_count + 20;
		imgh_line1 = imgh_line1 + 20;
		if (temp_count > 4)
		{
			temp_count = 4;
		} // if (temp_count > 13) { temp_count = 14; }
	}

	for (i = 5; i < 10; i++)
	{
		gtk_widget_set_halign(GTK_WIDGET(text_h[i]), GTK_ALIGN_START);
		gtk_widget_set_name(text_h[i], "labeltext-entry");
	}

	gtk_box_pack_start(GTK_BOX(f3_box), txtbox, false, false, 5);

	/************************************************************/
	/***********OVERLAY FOR MULTIPLE BOXES DISPLAY **************/

	gtk_overlay_add_overlay(GTK_OVERLAY(overlay), splite_box_1);
	gtk_overlay_add_overlay(GTK_OVERLAY(overlay), splite_box_2);
	gtk_overlay_add_overlay(GTK_OVERLAY(overlay), f2_box); // f2_box for DGS selection
	gtk_overlay_add_overlay(GTK_OVERLAY(overlay), f3_box); // f3 Box for Note Data

	/**************************************************************/
	/**************************************************************/
	gtk_container_add(GTK_CONTAINER(frame), overlay);

	v_ruler_surface = cairo_image_surface_create(CAIRO_FORMAT_RGB24, ruler_Height_width, frame_height);
	v_ruler_cr = cairo_create(v_ruler_surface);
	v_ruler_img = gtk_image_new_from_surface(v_ruler_surface);
	vertical_ruler();

	h_ruler_surface = cairo_image_surface_create(CAIRO_FORMAT_RGB24, frame_width + ruler_Height_width + 1, ruler_Height_width);
	h_ruler_cr = cairo_create(h_ruler_surface);
	h_ruler_img = gtk_image_new_from_surface(h_ruler_surface);
	horizontal_ruler();

	h_box = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
	gtk_container_add(GTK_CONTAINER(h_box), v_ruler_img);
	gtk_container_add(GTK_CONTAINER(h_box), frame);

	v_box = gtk_box_new(GTK_ORIENTATION_VERTICAL, 0);
	gtk_container_add(GTK_CONTAINER(v_box), h_box);
	gtk_container_add(GTK_CONTAINER(v_box), h_ruler_img);

	gtk_box_pack_start(GTK_BOX(ahbox3), v_box, false, false, 1); // gtk_box_pack_start(GTK_BOX(ahbox3), frame, false, false, 1);

	/***************************************************************************************************/
	/*************************SET THE LEFT KEYS AROUND DATA BTNS****************************************/
	/***************************************************************************************************/
	int iwd = 20;
	lfbox = gtk_box_new(GTK_ORIENTATION_VERTICAL, 0);
	gtk_box_pack_start(GTK_BOX(ahbox3), lfbox, false, false, 1);

	GtkWidget* space1 = gtk_label_new("");
	gtk_widget_set_size_request(space1, 0, databtn_hght);
	gtk_box_pack_start(GTK_BOX(lfbox), space1, false, false, 0);

	btn_dv[20] = gtk_button_new();
	label_dv[10] = gtk_label_new("◄");
	gtk_container_add(GTK_CONTAINER(btn_dv[20]), label_dv[10]);
	gtk_box_pack_start(GTK_BOX(lfbox), btn_dv[20], false, false, 0);
	gtk_widget_set_size_request(btn_dv[20], iwd, databtn_hght);
	gtk_widget_set_name(btn_dv[20], btndv_css[8]);

	GtkWidget* space2 = gtk_label_new("");
	gtk_widget_set_size_request(space2, 0, databtn_hght);
	gtk_box_pack_start(GTK_BOX(lfbox), space2, false, false, 0);

	btn_dv[11] = gtk_button_new();
	label_dv[11] = gtk_label_new("◄");
	gtk_container_add(GTK_CONTAINER(btn_dv[11]), label_dv[11]);
	gtk_box_pack_start(GTK_BOX(lfbox), btn_dv[11], false, false, 0);
	gtk_widget_set_size_request(btn_dv[11], iwd, databtn_hght);
	gtk_widget_set_name(btn_dv[11], btndv_css[8]);

	GtkWidget* space3 = gtk_label_new("");
	gtk_widget_set_size_request(space3, 0, databtn_hght);
	gtk_box_pack_start(GTK_BOX(lfbox), space3, false, false, 0);

	btn_dv[12] = gtk_button_new();
	label_dv[12] = gtk_label_new("◄");
	gtk_container_add(GTK_CONTAINER(btn_dv[12]), label_dv[12]);
	gtk_box_pack_start(GTK_BOX(lfbox), btn_dv[12], false, false, 0);
	gtk_widget_set_size_request(btn_dv[12], iwd, databtn_hght);
	gtk_widget_set_name(btn_dv[12], btndv_css[8]);

	GtkWidget* space4 = gtk_label_new("");
	gtk_widget_set_size_request(space4, 0, databtn_hght);
	gtk_box_pack_start(GTK_BOX(lfbox), space4, false, false, 0);

	btn_dv[13] = gtk_button_new();
	label_dv[13] = gtk_label_new("◄");
	gtk_container_add(GTK_CONTAINER(btn_dv[13]), label_dv[13]);
	gtk_box_pack_start(GTK_BOX(lfbox), btn_dv[13], false, false, 0);
	gtk_widget_set_size_request(btn_dv[13], iwd, databtn_hght);
	gtk_widget_set_name(btn_dv[13], btndv_css[8]);

	GtkWidget* space5 = gtk_label_new("");
	gtk_widget_set_size_request(space5, 0, databtn8_hght); // Gain btn height required
	gtk_box_pack_start(GTK_BOX(lfbox), space5, false, false, 0);

	btn_dv[14] = gtk_button_new();
	label_dv[14] = gtk_label_new("◄");
	gtk_container_add(GTK_CONTAINER(btn_dv[14]), label_dv[14]);
	gtk_box_pack_start(GTK_BOX(lfbox), btn_dv[14], false, false, 0);
	gtk_widget_set_size_request(btn_dv[14], iwd, databtn_hght);
	gtk_widget_set_name(btn_dv[14], btndv_css[8]);

	gtk_widget_set_halign(GTK_WIDGET(lfbox), GTK_ALIGN_START);

	hbox = gtk_box_new(GTK_ORIENTATION_VERTICAL, 0);
	gtk_box_pack_start(GTK_BOX(ahbox3), hbox, false, false, 1);

	/****************************************************************************/
	/**********************SET THE DATA VALUE AND HEADING************************/
	for (i = 0; i < 7; i = i + 2)
	{
		btn_dv[i] = gtk_button_new();
		label_dv[i] = gtk_label_new(all_btnval[i]);
		gtk_label_set_max_width_chars(GTK_LABEL(label_dv[i]), 11);			  // Sets the desired maximum width in characters of label   to restrict the size of control even caption text is big
		gtk_label_set_ellipsize(GTK_LABEL(label_dv[i]), PANGO_ELLIPSIZE_END); // The text will be ellipsized if there is not enough space to render the entire string.
		gtk_container_add(GTK_CONTAINER(btn_dv[i]), label_dv[i]);
		gtk_widget_set_size_request(btn_dv[i], databtn_width, databtn_hght);
		gtk_widget_get_style_context(btn_dv[i]);
		gtk_widget_set_name(btn_dv[i], btndv_css[i]); // "btnd1-entry"
	}
	
	for (i = 1; i < 8; i = i + 2)
	{
		btn_dv[i] = gtk_button_new();
		label_dv[i] = gtk_label_new(all_btnval[i]);
		gtk_label_set_max_width_chars(GTK_LABEL(label_dv[i]), 11);			  // Sets the desired maximum width in characters of label   to restrict the size of control even caption text is big
		gtk_label_set_ellipsize(GTK_LABEL(label_dv[i]), PANGO_ELLIPSIZE_END); // The text will be ellipsized if there is not enough space to render the entire string.
		gtk_container_add(GTK_CONTAINER(btn_dv[i]), label_dv[i]);
		gtk_widget_set_size_request(btn_dv[i], databtn_width, databtn_hght);
		gtk_widget_get_style_context(btn_dv[i]);
		gtk_widget_set_name(btn_dv[i], btndv_css[i]); // "btnd1-entry"
	}

	for (i = 0; i < 8; i++)
	{
		gtk_box_pack_start(GTK_BOX(hbox), btn_dv[i], false, false, 0);
	}

	/**************************************************************************/
	/*************HIGHLIGHT THE FIRST BUTTON OF DATA VALUE*********************/
	/**************************************************************************/

	gtk_widget_set_can_focus(GTK_WIDGET(btn_dv[1]), true);
	gtk_widget_grab_focus(GTK_WIDGET(btn_dv[1]));
	gtk_widget_set_name(btn_dv[1], "btnv1_1-entry");

	/*************************BUTTON 8 DATA HEADING************************/
	btn_dv[8] = gtk_button_new();
	strcpy(Gain_glbl, all_btnval[8]);
	strcat(all_btnval[8], gstr_2);
	label_dv[8] = gtk_label_new(all_btnval[8]);
	gtk_label_set_max_width_chars(GTK_LABEL(label_dv[8]), 11);			  
	gtk_label_set_ellipsize(GTK_LABEL(label_dv[8]), PANGO_ELLIPSIZE_END); 
	gtk_box_pack_start(GTK_BOX(hbox), btn_dv[8], false, false, 0);
	gtk_container_add(GTK_CONTAINER(btn_dv[8]), label_dv[8]);
	gtk_widget_set_size_request(btn_dv[8], databtn_width, databtn8_hght);
	gtk_widget_set_name(btn_dv[8], btndv_css[8]);
	gtk_widget_set_halign(GTK_WIDGET(label_dv[8]), GTK_ALIGN_START);

	/**************************BUTTON 9 DATA VALUE*************************/
	btn_dv[9] = gtk_button_new();
	label_dv[9] = gtk_label_new(all_btnval[9]);
	gtk_label_set_max_width_chars(GTK_LABEL(label_dv[9]), 0);			  
	gtk_label_set_ellipsize(GTK_LABEL(label_dv[9]), PANGO_ELLIPSIZE_END);
	gtk_box_pack_start(GTK_BOX(hbox), btn_dv[9], false, false, 0);
	gtk_container_add(GTK_CONTAINER(btn_dv[9]), label_dv[9]);
	gtk_widget_set_size_request(btn_dv[9], databtn_width, button_height);
	gtk_widget_get_style_context(btn_dv[9]);
	gtk_widget_set_name(btn_dv[9], btndv_css[9]);

	btn_dv[10] = gtk_button_new();
	label_dv[10] = gtk_label_new(menu_lbl[0]);
	gtk_label_set_max_width_chars(GTK_LABEL(label_dv[10]), 7);			   
	gtk_label_set_ellipsize(GTK_LABEL(label_dv[10]), PANGO_ELLIPSIZE_END); 
	gtk_box_pack_start(GTK_BOX(hbox), btn_dv[10], false, false, 0);
	gtk_container_add(GTK_CONTAINER(btn_dv[10]), label_dv[10]);
	gtk_widget_set_size_request(btn_dv[10], databtn_width, button_height);
	gtk_widget_get_style_context(btn_dv[10]);
	gtk_widget_set_name(btn_dv[10], "btndmenu-entry");

	for (i = 0, j = 1; i < 8, j < 8; i = i + 2, j = j + 2)
	{
		gtk_widget_set_halign(GTK_WIDGET(label_dv[i]), GTK_ALIGN_START);
		gtk_widget_set_halign(GTK_WIDGET(label_dv[j]), GTK_ALIGN_CENTER);
	}

	gtk_widget_set_halign(GTK_WIDGET(hbox), GTK_ALIGN_START);

	/***************************************************************************************************/
    /*************************SET THE RIGHT KEYS AROUND DATA BTNS***************************************/
    /***************************************************************************************************/
	rgbox = gtk_box_new(GTK_ORIENTATION_VERTICAL, 0);
	gtk_box_pack_start(GTK_BOX(ahbox3), rgbox, false, false, 1);

	GtkWidget* space6 = gtk_label_new("");
	gtk_widget_set_size_request(space6, 5, databtn_hght);
	gtk_box_pack_start(GTK_BOX(rgbox), space6, false, false, 0);

	btn_dv[15] = gtk_button_new();
	label_dv[15] = gtk_label_new("►");
	gtk_container_add(GTK_CONTAINER(btn_dv[15]), label_dv[15]);
	gtk_box_pack_start(GTK_BOX(rgbox), btn_dv[15], false, false, 0);
	gtk_widget_set_size_request(btn_dv[15], 5, databtn_hght);
	gtk_widget_set_name(btn_dv[15], btndv_css[8]);

	GtkWidget* space7 = gtk_label_new("");
	gtk_widget_set_size_request(space7, 5, databtn_hght);
	gtk_box_pack_start(GTK_BOX(rgbox), space7, false, false, 0);

	btn_dv[16] = gtk_button_new();
	label_dv[16] = gtk_label_new("►");
	gtk_container_add(GTK_CONTAINER(btn_dv[16]), label_dv[16]);
	gtk_box_pack_start(GTK_BOX(rgbox), btn_dv[16], false, false, 0);
	gtk_widget_set_size_request(btn_dv[16], 5, databtn_hght);
	gtk_widget_set_name(btn_dv[16], btndv_css[8]);

	GtkWidget* space8 = gtk_label_new("");
	gtk_widget_set_size_request(space8, 5, databtn_hght);
	gtk_box_pack_start(GTK_BOX(rgbox), space8, false, false, 0);

	btn_dv[17] = gtk_button_new();
	label_dv[17] = gtk_label_new("►");
	gtk_container_add(GTK_CONTAINER(btn_dv[17]), label_dv[17]);
	gtk_box_pack_start(GTK_BOX(rgbox), btn_dv[17], false, false, 0);
	gtk_widget_set_size_request(btn_dv[17], 5, databtn_hght);
	gtk_widget_set_name(btn_dv[17], btndv_css[8]);

	GtkWidget* space9 = gtk_label_new("");
	gtk_widget_set_size_request(space9, 5, databtn_hght);
	gtk_box_pack_start(GTK_BOX(rgbox), space9, false, false, 0);

	btn_dv[18] = gtk_button_new();
	label_dv[18] = gtk_label_new("►");
	gtk_container_add(GTK_CONTAINER(btn_dv[18]), label_dv[18]);
	gtk_box_pack_start(GTK_BOX(rgbox), btn_dv[18], false, false, 0);
	gtk_widget_set_size_request(btn_dv[18], 5, databtn_hght);
	gtk_widget_set_name(btn_dv[18], btndv_css[8]);

	GtkWidget* space10 = gtk_label_new("");
	gtk_widget_set_size_request(space10, 5, databtn8_hght);
	gtk_box_pack_start(GTK_BOX(rgbox), space10, false, false, 0);

	btn_dv[19] = gtk_button_new();
	label_dv[19] = gtk_label_new("►");
	gtk_container_add(GTK_CONTAINER(btn_dv[19]), label_dv[19]);
	gtk_box_pack_start(GTK_BOX(rgbox), btn_dv[19], false, false, 0);
	gtk_widget_set_size_request(btn_dv[19], 5, databtn_hght);
	gtk_widget_set_name(btn_dv[19], btndv_css[8]);

	gtk_widget_set_halign(GTK_WIDGET(rgbox), GTK_ALIGN_START);

	/****************************************************************************/
	/**********************SET THE SCROLLBAR*************************************/
	/****************************************************************************/

	vbox = gtk_box_new(GTK_ORIENTATION_VERTICAL, 1);
	gtk_box_pack_start(GTK_BOX(ahbox3), vbox, false, false, 1);

	adj = gtk_adjustment_new(
		0.0,	   // initial value
		0.0,	   // minimum value
		1000000.0, // maximum value10000000.0 /10000000.0
		1.0,	   // step increment
		1.0,	   // page increment
		0.0);	   // page size

	scrollbar = gtk_scrollbar_new(GTK_ORIENTATION_VERTICAL, adj);
	gtk_box_pack_start(GTK_BOX(vbox), scrollbar, false, false, 1);
	gtk_widget_set_size_request(scrollbar, scrollbar_w, scrollbar_h);
	gtk_widget_set_halign(GTK_WIDGET(vbox), GTK_ALIGN_END); // scr_bckgrnd
	gtk_widget_set_name(scrollbar, "scr_bckgrnd");

	/******************************************************************************************************************************/
	/*********************CREATING HORIZONTAL FOURTH BOX FOR FRAME BTM BUTTONS FOR ERROR MSG AND VALUES****************************/
	/*****************************************************************************************************************************/

	ahbox4 = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
	gtk_box_pack_start(GTK_BOX(avbox), ahbox4, false, false, 0);
	gtk_box_set_spacing(GTK_BOX(ahbox4), 0);

	b_bframe = gtk_frame_new(NULL); // Message Button Box
	gtk_frame_set_shadow_type(GTK_FRAME(b_bframe), GTK_SHADOW_NONE);
	gtk_widget_set_size_request(b_bframe, btm_btnfrm, button_height);
	n_overlay = gtk_overlay_new();
	b_btnbox = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
	sb_btnbox = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);

	/******************************************************************************************************************/
	/*********************************SET THE SECOND LAST ROW OF BUTTON************************************************/
	/******************************************************************************************************************/

	for (i = 0; i < 4; i++)
	{
		top_btn[i] = gtk_button_new();
		t_label[i] = gtk_label_new(top_ary[i]);
		gtk_widget_set_size_request(top_btn[i], tsbtn_width, btntop_height);
		gtk_label_set_max_width_chars(GTK_LABEL(t_label[i]), 12);			 
		gtk_label_set_ellipsize(GTK_LABEL(t_label[i]), PANGO_ELLIPSIZE_END); 
		gtk_widget_set_halign(GTK_WIDGET(t_label[i]), GTK_ALIGN_END);		 // GTK_ALIGN_START
		gtk_widget_set_valign(GTK_WIDGET(t_label[i]), GTK_ALIGN_END);		 // GTK_ALIGN_START

		gtk_container_add(GTK_CONTAINER(top_btn[i]), t_label[i]);
		gtk_widget_set_name(top_btn[i], tbtn_css[i]);
	}

	// top_btn[3] = gtk_button_new();
	// t_label[3] = gtk_label_new(top_ary[3]);
	// gtk_widget_set_size_request(top_btn[3], tsbtn4_width, btntop_height);
	// gtk_label_set_max_width_chars(GTK_LABEL(t_label[3]), 10); //Sets the desired maximum width in characters of label
	// gtk_label_set_ellipsize(GTK_LABEL(t_label[3]), PANGO_ELLIPSIZE_END); // The text will be ellipsized if there is not enough space to render the entire string.
	// gtk_widget_set_halign(GTK_WIDGET(t_label[3]), GTK_ALIGN_START);
	// gtk_widget_set_valign(GTK_WIDGET(t_label[3]), GTK_ALIGN_START);

	// gtk_container_add(GTK_CONTAINER(top_btn[3]), t_label[3]);
	// gtk_widget_set_name(top_btn[3], tbtn_css[3]);

	for (i = 0; i < 4; i++)
	{
		gtk_box_pack_start(GTK_BOX(b_btnbox), top_btn[i], false, false, 0);
	}
	// gtk_box_pack_start(GTK_BOX(b_btnbox), top_btn[3], false, false, 0);


	/******************************************************************************************************************************/
	/******************************TO DISPLAY ERROR MESSAGES INSTEAD OF BUTTONS****************************************************/
	/******************************************************************************************************************************/

	b_errorbox = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
	btn_err = gtk_button_new();  // DISPLAY WARNING MESSAGE BUTTON 
	gtk_widget_set_size_request(btn_err, btm_btnfrm, button_height);
	err_label = gtk_label_new(" DISPLAY WARNING MESSAGE ");
	gtk_container_add(GTK_CONTAINER(btn_err), err_label);
	gtk_widget_set_name(btn_err, "err_msg"); // gtk_widget_set_name(btn_err, "err_msg");
	/*gtk_box_pack_start(GTK_BOX(b_errorbox), err_label, false, false, 0);*/
	gtk_box_pack_start(GTK_BOX(b_errorbox), btn_err, false, false, 0);

	gtk_overlay_add_overlay(GTK_OVERLAY(n_overlay), b_btnbox); //SECOND LAST LAYER OF BUTTON on OVERLAY
	gtk_overlay_add_overlay(GTK_OVERLAY(n_overlay), b_errorbox); // ERROR BUTTON on Overlay
	gtk_container_add(GTK_CONTAINER(b_bframe), n_overlay); // ADD overlay to frame

	gtk_box_pack_start(GTK_BOX(ahbox4), b_bframe, false, false, 1);
	// gtk_box_set_spacing(GTK_BOX(b_btnbox), 2);

	v1box = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
	gtk_box_pack_start(GTK_BOX(ahbox4), v1box, false, false, 2);
	// gtk_box_set_spacing(GTK_BOX(v1box), 0);


	/****************************************************************************************************/
	/*******************************STP Key BUTTON OF 1 and 10 ******************************************/
	/****************************************************************************************************/
	b_btn[6] = gtk_button_new(); // b_btn[6] : Stp Coarse btn
	b_label[6] = gtk_label_new(btn_scr[1]);
	gtk_container_add(GTK_CONTAINER(b_btn[6]), b_label[6]);
	gtk_label_set_max_width_chars(GTK_LABEL(b_label[6]), 8); // Sets the desired maximum width in characters of label
	gtk_label_set_ellipsize(GTK_LABEL(b_label[6]), PANGO_ELLIPSIZE_END); // The text will be ellipsized if there is not enough space to render the entire string.
	gtk_widget_set_halign(GTK_WIDGET(b_label[6]), GTK_ALIGN_CENTER);
	gtk_box_pack_start(GTK_BOX(v1box), b_btn[6], false, false, 1);
	gtk_widget_set_size_request(b_btn[6], v_button_width + 5, v_button_height);
	gtk_widget_set_name(b_btn[6], bbtn_css[6]);


	/*********************************************************************************/
	/***********************SET THE PREVIOUS MENU BUTTON******************************/
	/*********************************************************************************/
	btn_prv = gtk_button_new();
	label14 = gtk_label_new("<<");
	gtk_container_add(GTK_CONTAINER(btn_prv), label14);
	gtk_label_set_max_width_chars(GTK_LABEL(label14), 3);			  
	gtk_label_set_ellipsize(GTK_LABEL(label14), PANGO_ELLIPSIZE_END); 
	gtk_widget_set_halign(GTK_WIDGET(label14), GTK_ALIGN_CENTER);
	gtk_widget_set_size_request(btn_prv, btnw_prvnxt, btnh_prvnxt);
	gtk_box_pack_start(GTK_BOX(v1box), btn_prv, false, false, 0);
	// gtk_box_pack_start(GTK_BOX(ahbox4), btn_prv, false, false, 4);
	gtk_widget_set_name(btn_prv, "btnprv-entry");


	/********************************************************************************/
	/************************SET THE NEXT MENU BUTTON********************************/
	/********************************************************************************/
	btn_next = gtk_button_new();
	label15 = gtk_label_new(">>");
	gtk_container_add(GTK_CONTAINER(btn_next), label15);
	gtk_label_set_max_width_chars(GTK_LABEL(label15), 3);			  
	gtk_label_set_ellipsize(GTK_LABEL(label15), PANGO_ELLIPSIZE_END); 
	gtk_widget_set_halign(GTK_WIDGET(label15), GTK_ALIGN_CENTER);
	gtk_widget_set_size_request(btn_next, btnw_prvnxt, btnh_prvnxt);
	gtk_widget_set_name(btn_next, "btnnxt-entry");
	gtk_box_pack_end(GTK_BOX(v1box), btn_next, false, false, 0);

	v4box = gtk_box_new(GTK_ORIENTATION_VERTICAL, 0);
	gtk_box_pack_start(GTK_BOX(ahbox4), v4box, false, false, 0);


	/****************************************************************************/
	/************************SET THE KEYPAD BUTTON*******************************/
	/****************************************************************************/
	bbtnkey = gtk_button_new();
	label13 = gtk_label_new("Key");
	gtk_container_add(GTK_CONTAINER(bbtnkey), label13);
	gtk_label_set_max_width_chars(GTK_LABEL(label13), 3);			 
	gtk_label_set_ellipsize(GTK_LABEL(label13), PANGO_ELLIPSIZE_END); 
	gtk_widget_set_halign(GTK_WIDGET(label13), GTK_ALIGN_CENTER);
	gtk_widget_set_size_request(bbtnkey, v_button_width, v_button_height);
	gtk_box_pack_start(GTK_BOX(v4box), bbtnkey, false, false, 0);
	gtk_widget_set_name(bbtnkey, "bbtnkey-entry");

	ahbox5 = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
	gtk_box_pack_start(GTK_BOX(avbox), ahbox5, false, false, 0);
	gtk_box_set_spacing(GTK_BOX(ahbox5), 0);


	/*************************************************************************************************************************/
	/****************************************BOTTOM MOST ROW OF BUTTON AND CLOCK**********************************************/
	/*************************************************************************************************************************/
	for (i = 0; i < 3; i++)
	{
		s_btn[i] = gtk_button_new();
		s_label[i] = gtk_label_new(scnd_ary[i]);
		gtk_widget_set_size_request(s_btn[i], tsbtn_width, button_height);
		gtk_label_set_max_width_chars(GTK_LABEL(s_label[i]), 12);	//Sets the desired maximum width in characters of label
		gtk_label_set_ellipsize(GTK_LABEL(s_label[i]), PANGO_ELLIPSIZE_END); //The text will be ellipsized if there is not enough space to render the entire string.
		gtk_widget_set_halign(GTK_WIDGET(s_label[i]), GTK_ALIGN_END);
		gtk_widget_set_valign(GTK_WIDGET(s_label[i]), GTK_ALIGN_END); // GTK_ALIGN_START
		gtk_container_add(GTK_CONTAINER(s_btn[i]), s_label[i]);
		gtk_widget_set_name(s_btn[i], sbtn_css[i]);
		gtk_box_pack_start(GTK_BOX(sb_btnbox), s_btn[i], false, false, 0);
	}

	s_btn[3] = gtk_button_new();
	s_label[3] = gtk_label_new(scnd_ary[3]);
	gtk_widget_set_size_request(s_btn[3], tsbtn4_width, button_height);
	gtk_label_set_max_width_chars(GTK_LABEL(s_label[3]), 10); //Sets the desired maximum width in characters of label
	gtk_label_set_ellipsize(GTK_LABEL(s_label[3]), PANGO_ELLIPSIZE_END); //The text will be ellipsized if there is not enough space to render the entire string.
	gtk_widget_set_halign(GTK_WIDGET(s_label[3]), GTK_ALIGN_END);
	gtk_widget_set_valign(GTK_WIDGET(s_label[3]), GTK_ALIGN_END); // GTK_ALIGN_START
	gtk_container_add(GTK_CONTAINER(s_btn[3]), s_label[3]);
	gtk_widget_set_name(s_btn[3], sbtn_css[3]);
	gtk_box_pack_start(GTK_BOX(sb_btnbox), s_btn[3], false, false, 0);

	s_btn[4] = gtk_button_new();
	s_label[4] = gtk_label_new("--");
	gtk_widget_set_size_request(s_btn[4], 135, button_height);
	gtk_label_set_max_width_chars(GTK_LABEL(s_label[4]), 20); //Sets the desired maximum width in characters of label
	gtk_label_set_ellipsize(GTK_LABEL(s_label[4]), PANGO_ELLIPSIZE_END); //The text will be ellipsized if there is not enough space to render the entire string.
	gtk_widget_set_halign(GTK_WIDGET(s_label[4]), GTK_ALIGN_START);
	gtk_widget_set_valign(GTK_WIDGET(s_label[4]), GTK_ALIGN_START); // GTK_ALIGN_START
	gtk_container_add(GTK_CONTAINER(s_btn[4]), s_label[4]);
	gtk_widget_set_name(s_btn[4], sbtn_css[4]);
	gtk_box_pack_start(GTK_BOX(sb_btnbox), s_btn[4], false, false, 0);

	gtk_box_pack_start(GTK_BOX(ahbox5), sb_btnbox, false, false, 0); //SECOND LAYER OF BOTTOM BUTTONS

	/*********************************************************************************/
	/*************************** CLOCK DATE AND TIME *********************************/
	/*********************************************************************************/
	nframe[7] = gtk_frame_new(NULL);
	n_overlay = gtk_overlay_new();
	gtk_frame_set_shadow_type(GTK_FRAME(nframe[7]), GTK_SHADOW_NONE); // GTK_SHADOW_IN);
	gtk_widget_set_size_request(nframe[7], image_clk, image_h);

	Clock_lab = gtk_label_new(" "); //Clock_lab = gtk_label_new("11:36 Dt:05/02/2023");
	gtk_widget_set_halign(GTK_WIDGET(Clock_lab), GTK_ALIGN_START);
	gtk_label_set_max_width_chars(GTK_LABEL(Clock_lab), 25);
	gtk_label_set_ellipsize(GTK_LABEL(Clock_lab), PANGO_ELLIPSIZE_END);
	gtk_container_add(GTK_CONTAINER(nframe[7]), Clock_lab);

	gtk_box_pack_start(GTK_BOX(ahbox5), nframe[7], false, false, 2);


	/******************************************************************************/
	/************CONNECT THE WIDGETS WITH THEIR PARTICULAR FUNCTIONS***************/
	/******************************************************************************/
	g_signal_connect(window, "destroy", G_CALLBACK(gtk_main_quit), NULL); //Delete_PopUp()

	g_signal_connect(top_btn[0], "clicked", G_CALLBACK(Delete_PopUp), NULL);

	g_signal_connect(btn_dv[1], "clicked", G_CALLBACK(OnBtn_press), NULL); // button-press-event  clicked
	g_signal_connect(btn_dv[3], "clicked", G_CALLBACK(OnBtn_press), NULL); // button-press-event
	g_signal_connect(btn_dv[5], "clicked", G_CALLBACK(OnBtn_press), NULL); // button-press-event
	g_signal_connect(btn_dv[7], "clicked", G_CALLBACK(OnBtn_press), NULL); // button-press-event
	g_signal_connect(btn_dv[9], "clicked", G_CALLBACK(OnBtn_press), NULL); // button-press-event

	g_signal_connect(btn_dv[20], "clicked", G_CALLBACK(lftBtn_valchng), NULL); // For left traverse key
	g_signal_connect(btn_dv[11], "clicked", G_CALLBACK(lftBtn_valchng), NULL); // For left traverse key
	g_signal_connect(btn_dv[12], "clicked", G_CALLBACK(lftBtn_valchng), NULL); // For left traverse key
	g_signal_connect(btn_dv[13], "clicked", G_CALLBACK(lftBtn_valchng), NULL); // For left traverse key
	g_signal_connect(btn_dv[14], "clicked", G_CALLBACK(lftBtn_valchng), NULL); // For left traverse key
	
	for (i = 15; i < 20; i++)
	{
		g_signal_connect(btn_dv[i], "clicked", G_CALLBACK(rghtBtn_valchng), NULL); // For Right traverse key
	}

	g_signal_connect(btn_prv, "clicked", G_CALLBACK(PrvBtnClick), NULL);
	g_signal_connect(btn_next, "clicked", G_CALLBACK(NxtBtnClick), NULL);
	g_signal_connect(bbtnkey, "clicked", G_CALLBACK(keypad_btn), NULL);
	g_signal_connect(adj, "value-changed", G_CALLBACK(OnScroll), NULL);
	g_signal_connect(window, "key_press_event", G_CALLBACK(my_keypress_val), NULL);
	g_signal_connect(b_btn[6], "clicked", G_CALLBACK(stp_coarse), NULL);
	g_signal_connect(dgs_btn[17], "clicked", G_CALLBACK(OnBtn_press), NULL); // Exit From Frame Menu      Dgs_exit_f), NULL);

	for (i = 1; i < 24; i = i + 2)
	{
		g_signal_connect(dgs_btn[i], "clicked", G_CALLBACK(OnBtn_press), NULL);
	}

	Creat_bk_img(Measure_v1, 1); // Create Image for Measurement Display Button
	Creat_bk_img(Measure_v2, 2); // Create Image for Measurement Display Button
	Colour_Theme_Apply(0);

	gtk_container_add(GTK_CONTAINER(window), avbox);
	gtk_widget_show_all(window);

	gtk_widget_hide(f2_box); // HIDE THE EXTRA DATA BTN
	gtk_widget_hide(f3_box); // HIDE THE TEXTBOX FRAME
	gtk_widget_hide(b_errorbox);

	Start_up_Scr();
	gtk_widget_show_all(window_home);

	gtk_widget_hide(splite_box_1);
	gtk_widget_hide(splite_box_2);
	//gtk_widget_hide(nframe[7]); 
	//gtk_widget_hide(nframe[8]);
	//gtk_widget_show(nframe[9]);

	gtk_main();
	// pwron_readvalues();
	// return(0);
}



//void DetectUsb()  //Detect the usb
//{
//	FILE* f;
//	if (f = popen("mount | grep /media/sda", "r"))
//	{
//		if (NULL != f)
//		{
//			if (EOF == fgetc(f))
//			{
//				//gtk_widget_hide(nframe[9]);
//				gtk_widget_hide(n_image[8]);
//				usb_val = 0;
//			}
//			else
//			{
//				//gtk_widget_show(nframe[9]);
//				gtk_widget_show(n_image[8]);
//				strcpy(pendrv_path, "/media/sda/");
//				usb_val = 1;
//			}
//			pclose(f); /* close the command file */
//		}
//	}
//	else if (f = popen("mount | grep /media/sda1", "r"))
//	{
//		if (NULL != f)
//		{
//			if (EOF == fgetc(f))
//			{
//				//gtk_widget_hide(nframe[9]);
//				gtk_widget_hide(n_image[8]);
//				usb_val = 0;
//			}
//			else
//			{
//				//gtk_widget_show(nframe[9]);
//				gtk_widget_show(n_image[8]);
//				strcpy(pendrv_path, "/media/sda1/");
//				usb_val = 1;
//			}
//			pclose(f); 	/* close the command file */
//		}
//	}
//	else if (f = popen("mount | grep /media/sdb", "r"))
//	{
//		if (NULL != f)
//		{
//			if (EOF == fgetc(f))
//			{
//				//gtk_widget_hide(nframe[9]);
//				gtk_widget_hide(n_image[8]);
//				usb_val = 0;
//			}
//			else
//			{
//				//gtk_widget_show(nframe[9]);
//				gtk_widget_show(n_image[8]);
//				strcpy(pendrv_path, "/media/sdb/");
//				usb_val = 1;
//			}
//			pclose(f); /* close the command file */
//		}
//	}
//	else if (f = popen("mount | grep /media/sdb1", "r"))
//	{
//		if (NULL != f)
//		{
//			if (EOF == fgetc(f))
//			{
//				//gtk_widget_hide(nframe[9]);
//				gtk_widget_hide(n_image[8]);
//				usb_val = 0;
//			}
//			else
//			{
//				//gtk_widget_show(nframe[9]);
//				gtk_widget_show(n_image[8]);
//				strcpy(pendrv_path, "/media/sdb1/");
//				usb_val = 1;
//			}
//			pclose(f); /* close the command file */
//		}
//	}
//	return;
//}

//void DetectUsb()  //Detect the usb
//{
//	//Copy_All();
//	FILE* f;
//	//if (f = popen("mount | grep /home/rnd1/temp1", "r")) //fopen(path_h, "r");
//	if (f = fopen("/home/rnd1/temp1", "r"))
//	{
//		if (NULL != f)
//		{
//			/* test if something has been output by the command */
//			//if (EOF == fgetc(f))
//			if (feof(f))
//			{
//				gtk_widget_hide(nframe[9]);
//				usb_val = 0;
//				//puts("\n/dev/sda1 is NOT mounted");
//			}
//			else
//			{
//				gtk_widget_show(nframe[9]);
//				strcpy(pendrv_path, "/home/rnd1/temp1");
//				//pendrv_path
//				usb_val = 1;
//				//puts("\n/dev/sda1 is mounted");
//			}
//			/* close the command file */
//			//pclose(f);
//			fclose(f);
//		}
//	}
//	//else if (f = popen("mount | grep /home/rnd1/temp2", "r")) // else if (f = fopen("Cal", "r"))
//	else if (f = fopen("/home/rnd1/temp2", "r"))
//	{
//		if (NULL != f)
//		{
//			/* test if something has been output by the command */
//			//if (EOF == fgetc(f))
//			if (feof(f))
//			{
//				gtk_widget_hide(nframe[9]);
//				usb_val = 0;
//				//puts("\n/dev/sda1 is NOT mounted");
//			}
//			else
//			{
//				gtk_widget_show(nframe[9]);
//				strcpy(pendrv_path, "/home/rnd1/temp2");
//				usb_val = 1;
//				//puts("\n/dev/sda1 is mounted");
//			}
//			/* close the command file */
//			//pclose(f);
//			fclose(f);
//		}
//	}
//	return;
//}


void Reset_DGSDAC() // To Reset the DAC and DGS after reading from file
{
	int key_v = 0;
	dgs_fromfile = 0;
	reset_value = 1;
	Set_default_val();

	Dac_f(key_v);
	STARTa_f(key_v);
	Point_f(key_v);
	press_f(key_v);

	Size_Eval_Select_f(key_v); // MENU 12

	Size_Eval_f(key_v);	 // MENU 4   // To be review
	Size_Eval_f1(key_v); // To be review
	Size_Eval_f2(key_v); // To be review
	Size_Eval_f3(key_v); // To be review
}


/****************************************************************************/
/***********************SET THE BOTTOM BUTTON'S******************************/
	/*for (i = 0; i < 5; i++)
	{
		b_btn[i] = gtk_button_new();
		b_label[i] = gtk_label_new(b_ary[i]);
		gtk_container_add(GTK_CONTAINER(b_btn[i]), b_label[i]);
		gtk_label_set_max_width_chars(GTK_LABEL(b_label[i]), 8);
		gtk_label_set_ellipsize(GTK_LABEL(b_label[i]), PANGO_ELLIPSIZE_END);
		gtk_widget_set_halign(GTK_WIDGET(b_label[i]), GTK_ALIGN_CENTER);
		gtk_widget_set_size_request(b_btn[i], button_width, button_height);
		gtk_widget_set_name(b_btn[i], bbtn_css[i]);
	}*/