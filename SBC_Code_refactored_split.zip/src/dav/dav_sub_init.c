/*cd /f/Dahlia-Verdin/GTK*/
/* RUN BAT FILE TO EXECUTE PROGRAM --> bash ./gtkboardapp_run.bat*/
/* gcc gtkrow.c src/src/OpenGL.c -o Main `pkg-config --cflags --libs gtk+-3.0` -lm -lwayland-client -lwayland-server -lwayland-egl -lEGL -lGLESv2 */
/* $CC gtkrow.c src/src/OpenGL.c -o Main `pkg-config --cflags --libs gtk+-3.0` -lm -lwayland-client -lwayland-server -lwayland-egl -lEGL -lGLESv2 */
/* $CC gtkrow.c src/src/OpenGL.c -o Main `pkg-config --cflags --libs gtk+-3.0` -lgpiod -lm -lwayland-client -lwayland-server -lwayland-egl -lEGL -lGLESv2 */
/* $CC src/src/Dav_Sub.c src/src/OpenGL.c -o Main `pkg-config --cflags --libs gtk+-3.0` -lgpiod -lm -lwayland-client -lwayland-server -lwayland-egl -lEGL -lGLESv2 */

// cd /mnt/e/2024/08-August_2024/2024-08-21/Dav_Sub
/*  bash Build_For_brd.sh */ // Use this command to Build the application to run on Board
//
//   bash ./Build_For_WSL.sh     // Build for WSL  Environment setti is not rquired
//   cd /mnt/d/
//  cd WSL_Wayland_Proj/WSL_Prog/Dav_Sub/Dav_Sub
//  . /opt/tdx-xwayland/5.7.1/environment-setup-aarch64-tdx-linux
//    which pkg-config
//    /opt/tdx-xwayland/5.7.1/sysroots/x86_64-tdxsdk-linux/usr/bin/pkg-config
//    bash Build_For_brd.sh
//    export DISPLAY=172.23.144.1:0 && export XDG_RUNTIME_DIR=/tmp/xdg && export RUNLEVEL=3 && weston

//   setup=setenv setupargs console=tty1 console=${console},${baudrate} consoleblank=0 earlycon   // set environment as below so during boot console command would not get display on screen
//   setenv setup 'setenv setupargs vt.global_cursor_default=0 console=${console},${baudrate} consoleblank=0 earlycon'
//   setenv setup 'setenv setupargs console=${console},${baudrate} consoleblank=0 earlycon'
// setenv setup 'setenv setupargs fec_mac=${ethaddr} consoleblank=0 no_console_suspend=1 console=${console},${baudrate}n8'
// setenv -> saveenv -> reset
// WSL UBUNTU PATH FROM PROGRAM FOR TESTING PURPOSE = fopen("/home/rnd1/temp1", "r"))
// CHECK DISK SPACE = df -H // To check storage in linux 

#ifdef WIN32
#include <io.h>
#define F_OK 0
#define access _access
#endif

#include <stdio.h>
#include <include/include/gpiod.h> // For WSL it is required to install libgpiod using following command in Ubuntu sudo apt-get install libgpiod-dev
#include <string.h>
#include <stdlib.h>
#include <stdint.h>
#include <math.h>
#include <stdbool.h>
#include <stdint.h>
#include <cairo.h>
#include <cairo-pdf.h>

#include <gtk/gtk.h>

#include "include/include/gtkdeclarations.h"
#include "include/include/Dav_Sub.h"
#include "include/include/dataval.h"
#include "include/include/cbentry.h"
#include "include/include/cbentry_safe1.h"
#include "include/include/OpenGL.h"
#include "include/include/shp_prf.h"
#include "include/include/Ruler.h"
#include "include/include/thick_log.h"
#include "include/include/plot_data.h"

#include <unistd.h>
#include <getopt.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <sys/wait.h>
#include <linux/types.h>
#include <linux/spi/spidev.h>

// #define ARRAY_SIZE(a) (sizeof(a) / sizeof((a)[0]))

gdouble Scr_stp_pre = 10.0;
int fd_SPI;

bool Spi_test = true;
struct OGLData ogl;

int Key_ck = 100;  // Key Check timer counter
int Key_Delay = 0; // Key Delay time control
bool Key_press = false;
int Measure_dsp = 0, Batt_dsp = 0, Batt_val = 0; // Measurement Display rate is controlle by this value
extern int tx_bufidx;
extern int Key_Scn_code;
extern int Key_stp;
extern GLubyte row_y[256];

extern cairo_t *Ascan_cr;
extern cairo_surface_t *Ascan_surface;
extern GdkPixbuf *Ascan_pixbuf;

void Keypad_rd(); // Read Keypad Data
void Read_rd();	  // Read Keypad Data
void Read_rd2();
void Read_Peak_amp();

void Init_all();
int Init_SPI(); // int main(int argc, char *argv[])  //int main(int argc, char *argv[])

void Start_up_Scr();
void Key_function();
void Keypad_ck(); // Read Keypad Data
void Send_SPI(int tx_nofd);
void Send_filt();
void Check_1K();
void Get_Data(); // Transfer data to Opengl Buffer from SPI Buffer
void Send_Data_to_OpenGL(void);
void Smooth_Asc();
void SPI_Receive(); // Receive Data using SPI

void DAC_Copy_for_Disp(int crvno); // Copy DAC points data for the Display
void Cal_Tval();
void Hruler_update();
void Vruler_update();

gboolean Key_perform_F(int keycodet);


/* --- Functions: category init --- */

static gboolean CreateAscan_Pdfreport()
{
	cairo_t* cr;

	// *********************************  CODE TO GET ASCAN SCREENSHOT ON TO THE PDF *****************************************//
	// **************************  Take a Ascan screenshot to add in Ascan report image *************************************//
	Ascan_image_data = gdk_pixbuf_get_pixels(Ascan_pixbuf);

	glBindFramebuffer(GL_READ_FRAMEBUFFER, ogl.default_framebuffer);
	glReadPixels(0, 0, frame_width, frame_height, GL_RGBA, GL_UNSIGNED_BYTE, Ascan_image_data);

	Ascan_pixbuf = gdk_pixbuf_flip(Ascan_pixbuf, false);
	/* Draw the pixbuf */
	gdk_cairo_set_source_pixbuf(Ascan_cr, Ascan_pixbuf, 0, 0);
	cairo_paint(Ascan_cr);
	cairo_surface_write_to_png(Ascan_surface, "Images/Images/screenshot.png");

	glBindFramebuffer(GL_READ_FRAMEBUFFER, ogl.framebuffer);
	glBindFramebuffer(GL_DRAW_FRAMEBUFFER, 0);
	glBlitFramebuffer(0, 0, frame_width, frame_height, // Source x, y, width and height
		0, frame_height, frame_width, 0, // Dest x, y, width and height
		GL_COLOR_BUFFER_BIT, GL_NEAREST);

	for (i = 0; i < 5; i++)
	{
		sprintf(text_values[i], "%s", gtk_entry_get_text(GTK_ENTRY(text_h[i])));
	}

	/******************************CODE TO CREATE A PDF FILE******************************************/
	cairo_surface_t* surface;

	surface = cairo_pdf_surface_create(path_h, 595, 842);
	cr = cairo_create(surface);

	cairo_set_source_rgb(cr, 0, 0, 0);
	cairo_select_font_face(cr, "Sans", CAIRO_FONT_SLANT_NORMAL, CAIRO_FONT_WEIGHT_BOLD);
	cairo_set_font_size(cr, 10.0);

	cairo_move_to(cr, 200.0, 20.0);
	cairo_show_text(cr, "ULTRASONIC TEST REPORT");
	cairo_fill(cr);
	cairo_move_to(cr, 200, 25);
	cairo_line_to(cr, 350, 25);
	cairo_stroke(cr);

	image = gdk_pixbuf_new_from_file_at_scale("Images/Images/screenshot.png", frame_width, frame_height, false, NULL);
	simage = gdk_pixbuf_scale_simple(image, 380, 250, GDK_INTERP_BILINEAR); // Create a new pixbuf containing a copy of src scaled to dest_width x dest_height
	gdk_cairo_set_source_pixbuf(cr, simage, 100.0, 30.0);
	cairo_paint(cr);

	/******************************************************************************************************************/
	/***********************************For Menu Data and Values Section***********************************************/
	/******************************************************************************************************************/
	cairo_set_source_rgb(cr, 0.0, 0.0, 0.0);
	cairo_move_to(cr, 25, 305);
	cairo_line_to(cr, 145, 305);
	cairo_move_to(cr, 25, 305);
	cairo_line_to(cr, 25, 325);
	cairo_move_to(cr, 145, 305);
	cairo_line_to(cr, 145, 325);
	cairo_stroke(cr);

	cairo_move_to(cr, 30, 315); // TO DISPLAY THE GAIN VALUE
	cairo_show_text(cr, "GAIN");
	cairo_show_text(cr, all_btnval[9]);

	if (Measure_v1 == 1) // FOR ON G A VALUES
	{
		cairo_move_to(cr, 200, 300); 
		cairo_show_text(cr, "SPa: ");
		cairo_show_text(cr, mea_rd[0]);
		cairo_move_to(cr, 280, 300); 
		cairo_show_text(cr, "DPa: ");
		cairo_show_text(cr, mea_rd[1]);
		cairo_move_to(cr, 360, 300); 
		cairo_show_text(cr, "SDa: ");
		cairo_show_text(cr, mea_rd[2]);
		cairo_move_to(cr, 420, 300); 
		cairo_show_text(cr, "Ea: ");
		cairo_show_text(cr, mea_rd[3]);
	}
	else if (Measure_v1 == 2) // FOR ON G B VALUES
	{
		cairo_move_to(cr, 200, 315); 
		cairo_show_text(cr, "SPb: ");
		cairo_show_text(cr, mea_rd[0]);
		cairo_move_to(cr, 280, 315); 
		cairo_show_text(cr, "DPb: ");
		cairo_show_text(cr, mea_rd[1]);
		cairo_move_to(cr, 360, 315); 
		cairo_show_text(cr, "SDb: ");
		cairo_show_text(cr, mea_rd[2]);
		cairo_move_to(cr, 420, 315); 
		cairo_show_text(cr, "Eb: ");
		cairo_show_text(cr, mea_rd[3]);
	}
	else if (Measure_v1 == 3) // FOR DAC AWS OR DGS VALUES
	{
		if (Dac_v == 2)  // If DAC is ON
		{
			cairo_move_to(cr, 200, 315); 
			cairo_show_text(cr, "DAC: ");
			cairo_show_text(cr, mea_rd[0]);
			cairo_move_to(cr, 280, 315); 
			cairo_show_text(cr, "C dB: ");
			cairo_show_text(cr, mea_rd[1]);
			cairo_move_to(cr, 360, 315); 
			cairo_show_text(cr, " ");
			cairo_move_to(cr, 420, 315); 
			cairo_show_text(cr, "Ea: ");
			cairo_show_text(cr, mea_rd[3]);
		}
		else if (Dgs_onoff_v == 3) // If DGS is ON
		{
			cairo_move_to(cr, 200, 315);
			cairo_show_text(cr, "C dB: ");
			cairo_show_text(cr, mea_rd[0]);
			cairo_move_to(cr, 280, 315);
			cairo_show_text(cr, "ERS: ");
			cairo_show_text(cr, mea_rd[1]);
			cairo_move_to(cr, 360, 315);
			cairo_show_text(cr, "DGS c: ");
			cairo_show_text(cr, mea_rd[2]);
			cairo_move_to(cr, 420, 315);
			cairo_show_text(cr, "Ea: ");
			cairo_show_text(cr, mea_rd[3]);
		}
		else if (Aws_onoff_v == 2) // If AWS is ON then Display Reading of AWS
		{
			cairo_move_to(cr, 200, 315); 
			cairo_show_text(cr, "RG: ");
			cairo_show_text(cr, mea_rd[0]);
			cairo_move_to(cr, 280, 315); 
			cairo_show_text(cr, "IL: ");
			cairo_show_text(cr, mea_rd[1]);
			cairo_move_to(cr, 360, 315); 
			cairo_show_text(cr, "AF: ");
			cairo_show_text(cr, mea_rd[2]);
			cairo_move_to(cr, 420, 315); 
			cairo_show_text(cr, "RT: ");
			cairo_show_text(cr, mea_rd[3]);
		}
	}

	if (Measure_v2 == 1) // FOR ON G A VALUES
	{
		cairo_move_to(cr, 200, 340);
		cairo_show_text(cr, "SPa: ");
		cairo_show_text(cr, mea_rd[0]);
		cairo_move_to(cr, 280, 340);
		cairo_show_text(cr, "DPa: ");
		cairo_show_text(cr, mea_rd[1]);
		cairo_move_to(cr, 360, 340);
		cairo_show_text(cr, "SDa: ");
		cairo_show_text(cr, mea_rd[2]);
		cairo_move_to(cr, 420, 340);
		cairo_show_text(cr, "Ea: ");
		cairo_show_text(cr, mea_rd[3]);
	}
	else if (Measure_v2 == 2) // FOR ON G B VALUES
	{
		cairo_move_to(cr, 200, 315);
		cairo_show_text(cr, "SPb: ");
		cairo_show_text(cr, mea_rd[0]);
		cairo_move_to(cr, 280, 315);
		cairo_show_text(cr, "DPb: ");
		cairo_show_text(cr, mea_rd[1]);
		cairo_move_to(cr, 360, 315);
		cairo_show_text(cr, "SDb: ");
		cairo_show_text(cr, mea_rd[2]);
		cairo_move_to(cr, 420, 315);
		cairo_show_text(cr, "Eb: ");
		cairo_show_text(cr, mea_rd[3]);
	}
	else if (Measure_v2 == 3) // FOR DAC AWS OR DGS VALUES
	{
		if (Dac_v == 2)  // If DAC is ON
		{
			cairo_move_to(cr, 200, 315);
			cairo_show_text(cr, "DAC: ");
			cairo_show_text(cr, mea_rd[1]);
			cairo_move_to(cr, 280, 315);
			cairo_show_text(cr, "C dB: ");
			cairo_show_text(cr, mea_rd[2]);
			cairo_move_to(cr, 360, 315);
			cairo_show_text(cr, " ");
			cairo_move_to(cr, 420, 315);
			cairo_show_text(cr, "Ea: ");
			cairo_show_text(cr, mea_rd[3]);
		}
		else if (Dgs_onoff_v == 3) // If DGS is ON
		{
			cairo_move_to(cr, 200, 315);
			cairo_show_text(cr, "C dB: ");
			cairo_show_text(cr, mea_rd[0]);
			cairo_move_to(cr, 280, 315);
			cairo_show_text(cr, "ERS: ");
			cairo_show_text(cr, mea_rd[1]);
			cairo_move_to(cr, 360, 315);
			cairo_show_text(cr, "DGS c: ");
			cairo_show_text(cr, mea_rd[2]);
			cairo_move_to(cr, 420, 315);
			cairo_show_text(cr, "Ea: ");
			cairo_show_text(cr, mea_rd[3]);
		}
		else if (Aws_onoff_v == 2) // If AWS is ON then Display Reading of AWS
		{
			cairo_move_to(cr, 200, 315);
			cairo_show_text(cr, "RG: ");
			cairo_show_text(cr, mea_rd[0]);
			cairo_move_to(cr, 280, 315);
			cairo_show_text(cr, "IL: ");
			cairo_show_text(cr, mea_rd[1]);
			cairo_move_to(cr, 360, 315);
			cairo_show_text(cr, "AF: ");
			cairo_show_text(cr, mea_rd[2]);
			cairo_move_to(cr, 420, 315);
			cairo_show_text(cr, "RT: ");
			cairo_show_text(cr, mea_rd[3]);
		}
	}

	cairo_set_source_rgb(cr, 0.0, 0.0, 0.0);
	//for (i = 300; i < 695; i = i + 20) // For 3rd Vertical line border
	for (i = 325; i < 720; i = i + 20)
	{
		cairo_move_to(cr, 25, i);
		cairo_line_to(cr, 560, i);
		cairo_stroke(cr);
	}

	cairo_move_to(cr, 25, 325); // FIRST VERTICAL LINE
	cairo_line_to(cr, 25, 705);
	cairo_stroke(cr);

	cairo_move_to(cr, 560, 325); // LAST VERTICAL LINE
	cairo_line_to(cr, 560, 705);
	cairo_stroke(cr);

	cairo_move_to(cr, 155, 325); // FIRST COLUMN VERTICAL LINE
	cairo_line_to(cr, 155, 705);
	cairo_stroke(cr);

	cairo_move_to(cr, 285, 325); // SECOND COLUMN VERTICAL LINE
	cairo_line_to(cr, 285, 705);
	cairo_stroke(cr);

	cairo_move_to(cr, 415, 325); // THIRD COLUMN VERTICAL LINE
	cairo_line_to(cr, 415, 705);
	cairo_stroke(cr);

	for (j = 330; j < 710; j = j + 20) // FIRST VERTICAL DASHED LINE
	{
		cairo_move_to(cr, 87, j);
		cairo_line_to(cr, 87, j + 10);
		cairo_stroke(cr);
	}

	for (j = 330; j < 710; j = j + 20) // SECOND VERTICAL DASHED LINE
	{
		cairo_move_to(cr, 221, j); // 215
		cairo_line_to(cr, 221, j + 10); // 215
		cairo_stroke(cr);
	}

	for (j = 330; j < 710; j = j + 20) // THIRD VERTICAL DASHED LINE
	{
		cairo_move_to(cr, 350, j); //345 
		cairo_line_to(cr, 350, j + 10); // 345
		cairo_stroke(cr);
	}

	for (j = 330; j < 710; j = j + 20) // FOURTH VERTICAL DASHED LINE
	{
		cairo_move_to(cr, 477, j);
		cairo_line_to(cr, 477, j + 10);
		cairo_stroke(cr);
	}

	cairo_set_source_rgb(cr, 0, 0, 0);
	cairo_select_font_face(cr, "Sans", CAIRO_FONT_SLANT_NORMAL, CAIRO_FONT_WEIGHT_NORMAL);
	cairo_set_font_size(cr, 10.0);

	j = 340;  // VALUES OF 1st MENU IN 1st ROW
	for (i = 30, k = 0; i < 490, k < 8; i = i + 65, k++)
	{
		cairo_move_to(cr, i, j);
		cairo_show_text(cr, all_btnval[k]);
	}

	j = 360;  // VALUES OF 2nd MENU IN 2nd ROW
	for (i = 30, k = 10; i < 490, k < 18; i = i + 65, k++)
	{
		cairo_move_to(cr, i, j);
		cairo_show_text(cr, all_btnval[k]);
	}

	j = 380;  // VALUES OF 3rd MENU IN 3rd ROW
	for (i = 30, k = 20; i < 490, k < 28; i = i + 65, k++)
	{
		cairo_move_to(cr, i, j);
		cairo_show_text(cr, all_btnval[k]);
	}

	j = 400;  // VALUES OF 4th MENU IN 4th ROW
	for (i = 30, k = 30; i < 490, k < 38; i = i + 65, k++)
	{
		cairo_move_to(cr, i, j);
		cairo_show_text(cr, all_btnval[k]);
	}

	j = 420;  // VALUES OF 5th MENU IN 5th ROW
	for (i = 30, k = 40; i < 490, k < 48; i = i + 65, k++)
	{
		cairo_move_to(cr, i, j);
		cairo_show_text(cr, all_btnval[k]);
	}

	j = 440;  // VALUES OF 6th MENU IN 6th ROW
	for (i = 30, k = 50; i < 490, k < 58; i = i + 65, k++)
	{
		cairo_move_to(cr, i, j);
		cairo_show_text(cr, all_btnval[k]);
	}

	j = 460;  // VALUES OF 7th MENU IN 7th ROW
	for (i = 30, k = 60; i < 490, k < 68; i = i + 65, k++)
	{
		cairo_move_to(cr, i, j);
		cairo_show_text(cr, all_btnval[k]);
	}

	j = 480;  // VALUES OF 8th MENU IN 8th ROW
	for (i = 30, k = 70; i < 490, k < 78; i = i + 65, k++)
	{
		cairo_move_to(cr, i, j);
		cairo_show_text(cr, all_btnval[k]);
	}

	j = 500;  // VALUES OF 9th MENU IN 9th ROW
	for (i = 30, k = 80; i < 490, k < 88; i = i + 65, k++)
	{
		cairo_move_to(cr, i, j);
		cairo_show_text(cr, all_btnval[k]);
	}

	j = 520;  // VALUES OF 10th MENU IN 10th ROW
	for (i = 30, k = 90; i < 490, k < 98; i = i + 65, k++)
	{
		cairo_move_to(cr, i, j);
		cairo_show_text(cr, all_btnval[k]);
	}

	j = 540;  // VALUES OF 11th MENU IN 11th ROW
	for (i = 30, k = 100; i < 490, k < 108; i = i + 65, k++)
	{
		cairo_move_to(cr, i, j);
		cairo_show_text(cr, all_btnval[k]);
	}

	j = 560;  // VALUES OF 12th MENU IN 12th ROW
	cairo_move_to(cr, 30, j);
	cairo_show_text(cr, all_btnval[110]);
	cairo_move_to(cr, 90, j);
	cairo_show_text(cr, all_btnval[111]);
	for (i = 160, k = 112; i < 490, k < 118; i = i + 65, k++) // 30, 110
	{
		cairo_move_to(cr, i, j);
		cairo_show_text(cr, all_btnval[k]);
	}

	j = 580;  // VALUES OF 13th MENU IN 13th ROW
	for (i = 30, k = 120; i < 490, k < 128; i = i + 65, k++)
	{
		cairo_move_to(cr, i, j);
		cairo_show_text(cr, all_btnval[k]);
	}

	j = 600;  // VALUES OF 14th MENU IN 14th ROW
	for (i = 30, k = 130; i < 490, k < 138; i = i + 65, k++)
	{
		cairo_move_to(cr, i, j);
		cairo_show_text(cr, all_btnval[k]);
	}

	j = 620;  // VALUES OF 15th MENU IN 15th ROW
	for (i = 30, k = 140; i < 490, k < 148; i = i + 65, k++)
	{
		cairo_move_to(cr, i, j);
		cairo_show_text(cr, all_btnval[k]);
	}

	j = 640;  // VALUES OF 16th MENU IN 16th ROW
	for (i = 30, k = 150; i < 490, k < 158; i = i + 65, k++)
	{
		cairo_move_to(cr, i, j);
		cairo_show_text(cr, all_btnval[k]);
	}

	if (Evaluate_val == 2)
	{
		j = 660;  // VALUES OF DGS_FORM SCAL< DEFECT ETC.
		for (i = 30, k = 170; i < 490, k < 178; i = i + 65, k++)
		{
			cairo_move_to(cr, i, j);
			cairo_show_text(cr, all_btnval[k]);
		}

		j = 680;  // VALUES OF DGS_FORM SCAL< DEFECT ETC.
		for (i = 30, k = 180; i < 490, k < 188; i = i + 65, k++)
		{
			cairo_move_to(cr, i, j);
			cairo_show_text(cr, all_btnval[k]);
		}

		j = 700;  // VALUES OF DGS_FORM SCAL< DEFECT ETC.
		for (i = 30, k = 190; i < 490, k < 198; i = i + 65, k++)
		{
			cairo_move_to(cr, i, j);
			cairo_show_text(cr, all_btnval[k]);
		}
	}

	/***************************************************************************************************************************************/
	/********************************************FOR NOTE DETAIL SECTION *******************************************************************/
	/***************************************************************************************************************************************/
	//for (i = 525; i < imgh_line1; i = i + 20) // For 1st Vertical line border
	
	cairo_move_to(cr, 25.0, 726.0);
	cairo_select_font_face(cr, "Purisa", CAIRO_FONT_SLANT_NORMAL, CAIRO_FONT_WEIGHT_BOLD);
	cairo_show_text(cr, "NOTE DETAILS");
	cairo_fill(cr);

	cairo_set_source_rgb(cr, 0.0, 0.0, 0.0);
	for (i = 735; i < 825; i = i + 20) // For 1st Vertical line border
	{
		cairo_move_to(cr, 25, i);
		cairo_line_to(cr, 25, i + 20);
		cairo_stroke(cr);
	}

	for (i = 735; i < 825; i = i + 20) // For last Vertical line border
	{
		cairo_move_to(cr, 565, i);
		cairo_line_to(cr, 565, i + 20);
		cairo_stroke(cr);
	}

	for (i = 735; i < 825 + 20; i = i + 20) // For all Horizontal lines
	{
		cairo_move_to(cr, 25, i);
		cairo_line_to(cr, 565, i);
		cairo_stroke(cr);
	}

	for (i = 735; i < 825; i = i + 20) // For middle vertical line separating columns
	{
		cairo_move_to(cr, 295, i);
		cairo_line_to(cr, 295, i + 20);
		cairo_stroke(cr);
	}

	cairo_select_font_face(cr, "Purisa", CAIRO_FONT_SLANT_NORMAL, CAIRO_FONT_WEIGHT_NORMAL);
	cairo_set_source_rgb(cr, 1.0, 0.0, 1.0);

	// For 1st column data
	i = 30;
	for (j = 750, k = 0; j < 830, k < 5; j = j + 20, k++)
	{
		cairo_move_to(cr, i, j);
		cairo_show_text(cr, heading_name[k]);
	}

	cairo_set_source_rgb(cr, 1.0, 0.0, 0.0);
	// For 2nd column data
	i = 300;
	for (j = 750, k = 0; j < 830, k < 5; j = j + 20, k++)
	{
		cairo_move_to(cr, i, j);
		cairo_show_text(cr, text_values[k]);
	}

	cairo_show_page(cr);
	cairo_surface_destroy(surface);
	cairo_destroy(cr);
}



//void DetectUsb()  //Detect the usb
//{
//	FILE* f;
//	if (f = popen("mount | grep /media/sda", "r"))
//	{
//		if (NULL != f)
//		{
//			if (EOF == fgetc(f))
//			{
//				//gtk_widget_hide(nframe[9]);
//				gtk_widget_hide(n_image[8]);
//				usb_val = 0;
//			}
//			else
//			{
//				//gtk_widget_show(nframe[9]);
//				gtk_widget_show(n_image[8]);
//				strcpy(pendrv_path, "/media/sda/");
//				usb_val = 1;
//			}
//			pclose(f); /* close the command file */
//		}
//	}
//	else if (f = popen("mount | grep /media/sda1", "r"))
//	{
//		if (NULL != f)
//		{
//			if (EOF == fgetc(f))
//			{
//				//gtk_widget_hide(nframe[9]);
//				gtk_widget_hide(n_image[8]);
//				usb_val = 0;
//			}
//			else
//			{
//				//gtk_widget_show(nframe[9]);
//				gtk_widget_show(n_image[8]);
//				strcpy(pendrv_path, "/media/sda1/");
//				usb_val = 1;
//			}
//			pclose(f); 	/* close the command file */
//		}
//	}
//	else if (f = popen("mount | grep /media/sdb", "r"))
//	{
//		if (NULL != f)
//		{
//			if (EOF == fgetc(f))
//			{
//				//gtk_widget_hide(nframe[9]);
//				gtk_widget_hide(n_image[8]);
//				usb_val = 0;
//			}
//			else
//			{
//				//gtk_widget_show(nframe[9]);
//				gtk_widget_show(n_image[8]);
//				strcpy(pendrv_path, "/media/sdb/");
//				usb_val = 1;
//			}
//			pclose(f); /* close the command file */
//		}
//	}
//	else if (f = popen("mount | grep /media/sdb1", "r"))
//	{
//		if (NULL != f)
//		{
//			if (EOF == fgetc(f))
//			{
//				//gtk_widget_hide(nframe[9]);
//				gtk_widget_hide(n_image[8]);
//				usb_val = 0;
//			}
//			else
//			{
//				//gtk_widget_show(nframe[9]);
//				gtk_widget_show(n_image[8]);
//				strcpy(pendrv_path, "/media/sdb1/");
//				usb_val = 1;
//			}
//			pclose(f); /* close the command file */
//		}
//	}
//	return;
//}

//void DetectUsb()  //Detect the usb
//{
//	//Copy_All();
//	FILE* f;
//	//if (f = popen("mount | grep /home/rnd1/temp1", "r")) //fopen(path_h, "r");
//	if (f = fopen("/home/rnd1/temp1", "r"))
//	{
//		if (NULL != f)
//		{
//			/* test if something has been output by the command */
//			//if (EOF == fgetc(f))
//			if (feof(f))
//			{
//				gtk_widget_hide(nframe[9]);
//				usb_val = 0;
//				//puts("\n/dev/sda1 is NOT mounted");
//			}
//			else
//			{
//				gtk_widget_show(nframe[9]);
//				strcpy(pendrv_path, "/home/rnd1/temp1");
//				//pendrv_path
//				usb_val = 1;
//				//puts("\n/dev/sda1 is mounted");
//			}
//			/* close the command file */
//			//pclose(f);
//			fclose(f);
//		}
//	}
//	//else if (f = popen("mount | grep /home/rnd1/temp2", "r")) // else if (f = fopen("Cal", "r"))
//	else if (f = fopen("/home/rnd1/temp2", "r"))
//	{
//		if (NULL != f)
//		{
//			/* test if something has been output by the command */
//			//if (EOF == fgetc(f))
//			if (feof(f))
//			{
//				gtk_widget_hide(nframe[9]);
//				usb_val = 0;
//				//puts("\n/dev/sda1 is NOT mounted");
//			}
//			else
//			{
//				gtk_widget_show(nframe[9]);
//				strcpy(pendrv_path, "/home/rnd1/temp2");
//				usb_val = 1;
//				//puts("\n/dev/sda1 is mounted");
//			}
//			/* close the command file */
//			//pclose(f);
//			fclose(f);
//		}
//	}
//	return;
//}


void Reset_DGSDAC() // To Reset the DAC and DGS after reading from file
{
	int key_v = 0;
	dgs_fromfile = 0;
	reset_value = 1;
	Set_default_val();

	Dac_f(key_v);
	STARTa_f(key_v);
	Point_f(key_v);
	press_f(key_v);

	Size_Eval_Select_f(key_v); // MENU 12

	Size_Eval_f(key_v);	 // MENU 4   // To be review
	Size_Eval_f1(key_v); // To be review
	Size_Eval_f2(key_v); // To be review
	Size_Eval_f3(key_v); // To be review
}


/****************************************************************************/
/***********************SET THE BOTTOM BUTTON'S******************************/
	/*for (i = 0; i < 5; i++)
	{
		b_btn[i] = gtk_button_new();
		b_label[i] = gtk_label_new(b_ary[i]);
		gtk_container_add(GTK_CONTAINER(b_btn[i]), b_label[i]);
		gtk_label_set_max_width_chars(GTK_LABEL(b_label[i]), 8);
		gtk_label_set_ellipsize(GTK_LABEL(b_label[i]), PANGO_ELLIPSIZE_END);
		gtk_widget_set_halign(GTK_WIDGET(b_label[i]), GTK_ALIGN_CENTER);
		gtk_widget_set_size_request(b_btn[i], button_width, button_height);
		gtk_widget_set_name(b_btn[i], bbtn_css[i]);
	}*/