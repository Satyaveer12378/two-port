#ifndef TOPBAR_H
#define TOPBAR_H
#include <gtk/gtk.h>
GtkWidget* topbar_new(void);
#endif
