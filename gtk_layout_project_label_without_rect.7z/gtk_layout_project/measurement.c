#include "measurement.h"
#include <gtk/gtk.h>

GtkWidget* measurement_area_new(void) {
    // Top-level as a GtkFrame but make it borderless
    GtkWidget *frame = gtk_frame_new(NULL);
    gtk_widget_set_size_request(frame, 740, -1);
    gtk_widget_set_vexpand(frame, TRUE);
    gtk_widget_set_hexpand(frame, TRUE);

    // Disable rectangle line (shadow) and padding
    gtk_frame_set_shadow_type(GTK_FRAME(frame), GTK_SHADOW_NONE);
    gtk_container_set_border_width(GTK_CONTAINER(frame), 0);

    // Apply global "no border + neutral bg" class from main.c
    GtkStyleContext *fctx = gtk_widget_get_style_context(frame);
    gtk_style_context_add_class(fctx, "app-frame");
    // Local class so we can target this frame precisely in CSS
    gtk_style_context_add_class(fctx, "measurement-panel");

    // Inner layout
    GtkWidget *box = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
    gtk_container_add(GTK_CONTAINER(frame), box);

    GtkWidget *left  = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
    GtkWidget *right = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
    GtkWidget *label = gtk_label_new("Measurement area");
    gtk_widget_set_halign(label, GTK_ALIGN_CENTER);
    gtk_widget_set_valign(label, GTK_ALIGN_CENTER);

    // White text on dark background (from your app CSS)
    gtk_style_context_add_class(gtk_widget_get_style_context(label), "app-label");

    gtk_box_pack_start(GTK_BOX(box), left,  TRUE,  TRUE, 0);
    gtk_box_pack_start(GTK_BOX(box), label, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(box), right, TRUE,  TRUE, 0);

    // Local CSS to ensure NO theme border is drawn for this frame
    const char *css =
        "frame.measurement-panel {"
        "  border: none;"
        "  border-width: 0;"
        "  box-shadow: none;"
        "  background: transparent;"   /* no color */
        "}"
        "frame.measurement-panel > border {"
        "  border: none;"
        "  border-width: 0;"
        "  box-shadow: none;"
        "  background: transparent;"
        "}";

    GtkCssProvider *provider = gtk_css_provider_new();
    gtk_css_provider_load_from_data(provider, css, -1, NULL);
    gtk_style_context_add_provider(fctx, GTK_STYLE_PROVIDER(provider),
                                   GTK_STYLE_PROVIDER_PRIORITY_USER);
    g_object_unref(provider);

    return frame;
}
