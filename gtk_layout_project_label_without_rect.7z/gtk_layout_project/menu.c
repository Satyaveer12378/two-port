#include "menu.h"
#include <gtk/gtk.h>
#include <stdlib.h>

 const char *css =
		 /*
		 " eventbox.label-box {"
		 " background-color: #2e3436;"
		 " background-image: none;"
		 " border-radius: 6px;"
		 " border : 2px solid rgba(255, 255, 255, 0.06);"
		 " padding: 6px 8px;"
		 " min-width: 140px;"
		 "}"
		 */
		 "eventbox.label-box { background-color:red;}"

    		" eventbox.label-box label {"
    		" color: white;"
    		" font-weight: 800;"
    		" font-size: 14px;"

    		"}"

        " .button.value-rect {"
    	    " background-color: #000000;"
    		" background-image: none;"
		" border-radius: 6px;"
    		" border: 2px solid rgba(0,0,0, 0.6);"
    		" padding: 8px 10px;"
		" min-width: 140px;"
    		" font-size: 18px;"
    		" font-weight: 800;"
    		" color: #00ff66;"
    		"}"

    		".button.value-rect.selected {"
    		" background-color: #ffffff;"
    		" color: #333333;"
		" border : 2px solid #e6b04d;"
    		"}";



static void load_menu_css(void ) {
	static gboolean loaded = FALSE;
	if(loaded) return;
    GtkCssProvider *provider = gtk_css_provider_new();
    GError *err = NULL;
    if(!gtk_css_provider_load_from_data(provider, css, -1, &err)) {
    		g_printerr("Failed to load menu CSS:%s\n",err ? err->message : "(unknown)");
    		g_clear_error(&err);
    } else {
    		gtk_style_context_add_provider_for_screen(gdk_screen_get_default(),
    	                                              GTK_STYLE_PROVIDER(provider),
    	                                              GTK_STYLE_PROVIDER_PRIORITY_APPLICATION);
    		loaded = TRUE;
    }

    g_object_unref(provider);
}

static GtkWidget *g_selected_value_btn = NULL;


static void on_value_clicked(GtkButton *btn, gpointer user_data) {

	(void)user_data;

	if(g_selected_value_btn && GTK_IS_WIDGET(g_selected_value_btn)) {
		GtkStyleContext *ctx_prv = gtk_widget_get_style_context(g_selected_value_btn);
		gtk_style_context_remove_class(ctx_prv, "selected");
	}

	g_selected_value_btn = GTK_WIDGET(btn);
	GtkStyleContext *ctx = gtk_widget_get_style_context(g_selected_value_btn);
	gtk_style_context_add_class(ctx, "selected");

	const char *label = gtk_button_get_label(btn);
	if(label) {
		int n = atoi(label);
		if(n != 0 || (label[0] == '0' && label[1] == '\0')) {
			n += 1;
			char buf[64];
			g_snprintf(buf, sizeof(buf), "%d", n);
			gtk_button_set_label(btn, buf);
		}
	}

	const char *menu_name = g_object_get_data(G_OBJECT(btn), "menu-name");
	g_print("Value clicked for %s -> %s\n", menu_name ? menu_name :"(unknown)",
			gtk_button_get_label(btn));
}

static void debug_print_classes(GtkWidget *w){
	GtkStyleContext *ctx = gtk_widget_get_style_context(w);
	GList *classes = gtk_style_context_list_classes(ctx);
	g_print("==== classes for widget(%p) ===\n",(void*)w);
	for(GList *l = classes; l; l= l->next) {
		g_print("class:%s\n",(char *)l->data);
	}
	g_list_free(classes);
}

GtkWidget* create_value_row(const gchar *menu_text, const gchar *value_text) {
    GtkWidget *vbox = gtk_box_new(GTK_ORIENTATION_VERTICAL, 4);


    GtkWidget *menu_box = gtk_event_box_new();
    gtk_event_box_set_visible_window(GTK_EVENT_BOX(menu_box),TRUE);
    gtk_widget_set_size_request(menu_box, 150, 36);

    GtkWidget *menu_label = gtk_label_new(menu_text);
    gtk_container_add(GTK_CONTAINER(menu_box), menu_label);

    gtk_style_context_add_class(gtk_widget_get_style_context(menu_box), "label-box");

    debug_print_classes(menu_box);

    // --- Value Button ---
    GtkWidget *value_btn = gtk_button_new_with_label(value_text);
    gtk_style_context_add_class(gtk_widget_get_style_context(value_btn), "value-rect");


    g_object_set_data_full(G_OBJECT(value_btn), "menu-name", g_strdup(menu_text), g_free);

    // Connect click handler
    g_signal_connect(value_btn, "clicked", G_CALLBACK(on_value_clicked), NULL);


    gtk_widget_set_size_request(value_btn, 150, 44);


    // pack into vbox
    gtk_box_pack_start(GTK_BOX(vbox), menu_box, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(vbox), value_btn, FALSE, FALSE, 0);

    gtk_widget_show_all(vbox);

    return vbox;


}




// Main menu panel
GtkWidget* menu_panel_new(void) {
    GtkWidget *frame = gtk_frame_new(NULL);
    gtk_widget_set_size_request(frame, 170, -1);
    gtk_widget_set_vexpand(frame, TRUE);
    gtk_frame_set_shadow_type(GTK_FRAME(frame), GTK_SHADOW_NONE);
    gtk_container_set_border_width(GTK_CONTAINER(frame), 0);

    GtkStyleContext *fctx = gtk_widget_get_style_context(frame);
    gtk_style_context_add_class(fctx, "app-frame");

    GtkWidget *vbox = gtk_box_new(GTK_ORIENTATION_VERTICAL, 6);
    gtk_container_add(GTK_CONTAINER(frame), vbox);

    load_menu_css();

    // Editable value rows
    gtk_box_pack_start(GTK_BOX(vbox), create_value_row("MENU-1", "100"), FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(vbox), create_value_row("MENU-2", "100"), FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(vbox), create_value_row("MENU-3", "100"), FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(vbox), create_value_row("MENU-4", "100"), FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(vbox), create_value_row("MENU-5", "100"), FALSE, FALSE, 0);

    GList *children = gtk_container_get_children(GTK_CONTAINER(vbox));
    if(children) {
    		GtkWidget *first_row = GTK_WIDGET(children->data);
    		if(GTK_IS_WIDGET(first_row)) {
    			GList *inner = gtk_container_get_children(GTK_CONTAINER(first_row));
    			if(inner && inner->next) {
    				GtkWidget *btn = GTK_WIDGET(inner->next->data);
    				g_selected_value_btn = btn;
    				gtk_style_context_add_class(gtk_widget_get_style_context(btn),"selected");
    			}
    			if(inner) g_list_free(inner);
    		}
    		g_list_free(children);
    }

    return frame;
}
