// topbar.c
#include "topbar.h"
#include <gtk/gtk.h>

GtkWidget* topbar_new(void) {
    // Create the frame for the top bar
    GtkWidget *frame = gtk_frame_new(NULL);
    gtk_widget_set_size_request(frame, -1, 50);
    gtk_widget_set_hexpand(frame, TRUE);

    // IMPORTANT: Disable the frame border/shadow
    gtk_frame_set_shadow_type(GTK_FRAME(frame), GTK_SHADOW_NONE);
    gtk_container_set_border_width(GTK_CONTAINER(frame), 0);

    // Apply the shared app frame class (black background, no borders)
    GtkStyleContext *frame_ctx = gtk_widget_get_style_context(frame);
    gtk_style_context_add_class(frame_ctx, "app-frame");

    // Create a horizontal box to center the label
    GtkWidget *hbox = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
    gtk_container_add(GTK_CONTAINER(frame), hbox);

    // Create label and apply style class
    GtkWidget *label = gtk_label_new("Top Bar");
    gtk_widget_set_halign(label, GTK_ALIGN_CENTER);
    gtk_widget_set_valign(label, GTK_ALIGN_CENTER);
    gtk_style_context_add_class(gtk_widget_get_style_context(label), "app-label");

    // Centering trick: left spacer + label + right spacer
    GtkWidget *left = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
    GtkWidget *right = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
    gtk_box_pack_start(GTK_BOX(hbox), left, TRUE, TRUE, 0);
    gtk_box_pack_start(GTK_BOX(hbox), label, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(hbox), right, TRUE, TRUE, 0);

    return frame;
}
