#include <gtk/gtk.h>
#include <gdk/gdk.h>
#include "topbar.h"
#include "graph.h"
#include "measurement.h"
#include "menu.h"

int main(int argc, char *argv[]) {
    GtkWidget *window;
    GtkWidget *grid;
    GtkWidget *graph_grid;

    gtk_init(&argc, &argv);

    /* ------------------ Screen size detection (GTK 3) ------------------ */
    int screen_width = 1024;
    int screen_height = 600;

    GdkDisplay *display = gdk_display_get_default();
    if (display) {
        /* GTK 3.22+: GdkMonitor is available; use if present at runtime */
        GdkMonitor *monitor = gdk_display_get_monitor_at_point(display, 0, 0);
        if (monitor) {
            GdkRectangle geometry;
            gdk_monitor_get_geometry(monitor, &geometry);
            screen_width = 1024;//geometry.width;
            screen_height = 600;//geometry.height;
            g_print("Detected screen size: %d x %d\n", screen_width, screen_height);
        } else {
            /* Fallback to the older GdkScreen API */
            G_GNUC_BEGIN_IGNORE_DEPRECATIONS
            GdkScreen *screen = gdk_screen_get_default();
            if (screen) {
                screen_width = gdk_screen_get_width(screen);
                screen_height = gdk_screen_get_height(screen);
                g_print("Detected screen size (screen API): %d x %d\n", screen_width, screen_height);
            } else {
                g_warning("Monitor/Screen not detected. Using fallback size: %d x %d\n", screen_width, screen_height);
            }
            G_GNUC_END_IGNORE_DEPRECATIONS
        }
    }

    /* ------------------------------ CSS setup ------------------------------ */
    const char *app_css =
        /* App window: solid black background */
        ".app-window {"
        "  background-color: #000000;"
        "}"
        /* Generic area styling: no borders/shadows, black bg */
        ".app-frame {"
        "  background-color: #000000;"
        "  border: none;"
        "  border-width: 0;"
        "  border-color: transparent;"
        "  box-shadow: none;"
        "}"
        /* Labels on dark background */
        ".app-label {"
        "  color: #ffffff;"
        "}"
        ".topbar-level {"
        "  color: #ffffff;"
        "  font-weight: bold;"
        "  font-size: 15px;"
        "}"
        /* Hide borders/shadows for ALL GtkFrame, regardless of theme */
        "frame, .frame {"
        "  border: none;"
        "  border-width: 0;"
        "  border-color: transparent;"
        "  box-shadow: none;"
        "  outline: none;"
        "  background-image: none;"
        "  background-color: transparent;"
        "  padding: 0;"
        "}"
        /* Defensive: some themes add hairlines to scrolled windows/viewport */
        "scrolledwindow, scrolledwindow > viewport, scrolledwindow > viewport > * {"
        "  border: none;"
        "  border-width: 0;"
        "  border-color: transparent;"
        "  box-shadow: none;"
        "  background-color: transparent;"
        "}"
        /* Defensive: separators can appear as thin lines */
        "separator {"
        "  background-color: transparent;"
        "  border: none;"
        "  min-height: 0;"
        "  min-width: 0;"
        "}";

    GtkCssProvider *provider = gtk_css_provider_new();
    gtk_css_provider_load_from_data(provider, app_css, -1, NULL);

    /* GTK 3 API: apply provider for default screen */
    G_GNUC_BEGIN_IGNORE_DEPRECATIONS
    gtk_style_context_add_provider_for_screen(
        gdk_screen_get_default(),
        GTK_STYLE_PROVIDER(provider),
        GTK_STYLE_PROVIDER_PRIORITY_USER
    );
    G_GNUC_END_IGNORE_DEPRECATIONS

    g_object_unref(provider);

    /* ------------------------------ Window/UI ------------------------------ */
    window = gtk_window_new(GTK_WINDOW_TOPLEVEL);

    GtkStyleContext *wctx = gtk_widget_get_style_context(window);
    gtk_style_context_add_class(wctx, "app-window");

    gtk_window_set_decorated(GTK_WINDOW(window), FALSE);
    gtk_window_set_default_size(GTK_WINDOW(window), screen_width, screen_height);
    gtk_window_set_resizable(GTK_WINDOW(window), FALSE);
    gtk_window_fullscreen(GTK_WINDOW(window));
    gtk_window_set_title(GTK_WINDOW(window), "UFD-Fullscreen");

    g_signal_connect(window, "destroy", G_CALLBACK(gtk_main_quit), NULL);

    /* Root grid */
    grid = gtk_grid_new();
    gtk_grid_set_row_spacing(GTK_GRID(grid), 6);
    gtk_grid_set_column_spacing(GTK_GRID(grid), 6);
    gtk_container_add(GTK_CONTAINER(window), grid);
    /* Ensure the root grid takes the same black bg and no borders */
    {
        GtkStyleContext *ctx = gtk_widget_get_style_context(grid);
        gtk_style_context_add_class(ctx, "app-frame");
    }

    /* Top bar */
    GtkWidget *top = topbar_new();
    {
        GtkStyleContext *top_ctx = gtk_widget_get_style_context(top);
        gtk_style_context_add_class(top_ctx, "app-frame");
    }
    gtk_grid_attach(GTK_GRID(grid), top, 0, 0, 2, 1);
    gtk_widget_set_hexpand(top, TRUE);

    /* Graph area grid */
    graph_grid = gtk_grid_new();
    gtk_grid_set_row_spacing(GTK_GRID(graph_grid), 2);
    gtk_grid_set_column_spacing(GTK_GRID(graph_grid), 2);
    gtk_grid_attach(GTK_GRID(grid), graph_grid, 0, 1, 1, 1);
    {
        GtkStyleContext *ctx = gtk_widget_get_style_context(graph_grid);
        gtk_style_context_add_class(ctx, "app-frame");
    }

    /* Y Axis frame (borderless) */
    GtkWidget *y_axis = gtk_frame_new(NULL);
    gtk_widget_set_size_request(y_axis, 40, 360);
    gtk_frame_set_label(GTK_FRAME(y_axis), "Y Axis");
    gtk_frame_set_shadow_type(GTK_FRAME(y_axis), GTK_SHADOW_NONE); /* hide border */
    {
        GtkStyleContext *ctx = gtk_widget_get_style_context(y_axis);
        gtk_style_context_add_class(ctx, "app-frame");
    }
    gtk_grid_attach(GTK_GRID(graph_grid), y_axis, 0, 0, 1, 2);

    /* Graph view */
    GtkWidget *graph = graph_view_new();
    gtk_grid_attach(GTK_GRID(graph_grid), graph, 1, 0, 1, 1);
    gtk_widget_set_vexpand(graph, TRUE);
    gtk_widget_set_hexpand(graph, TRUE);
    {
        GtkStyleContext *ctx = gtk_widget_get_style_context(graph);
        gtk_style_context_add_class(ctx, "app-frame");
    }

    /* X Axis frame (borderless) */
    GtkWidget *x_axis = gtk_frame_new(NULL);
    gtk_widget_set_size_request(x_axis, 700, 30);
    gtk_frame_set_label(GTK_FRAME(x_axis), "X Axis");
    gtk_frame_set_shadow_type(GTK_FRAME(x_axis), GTK_SHADOW_NONE); /* hide border */
    {
        GtkStyleContext *ctx = gtk_widget_get_style_context(x_axis);
        gtk_style_context_add_class(ctx, "app-frame");
    }
    gtk_grid_attach(GTK_GRID(graph_grid), x_axis, 1, 1, 1, 1);

    /* Measurement area */
    GtkWidget *measurement = measurement_area_new();
    gtk_grid_attach(GTK_GRID(grid), measurement, 0, 2, 1, 1);
    gtk_widget_set_vexpand(measurement, TRUE);
    {
        GtkStyleContext *mctx = gtk_widget_get_style_context(measurement);
        gtk_style_context_add_class(mctx, "app-frame");
    }

    /* Menu panel */
    GtkWidget *menu = menu_panel_new();
    gtk_grid_attach(GTK_GRID(grid), menu, 1, 1, 1, 2);
    gtk_widget_set_vexpand(menu, TRUE);
    {
        GtkStyleContext *menuctx = gtk_widget_get_style_context(menu);
        gtk_style_context_add_class(menuctx, "app-frame");
    }

    gtk_widget_show_all(window);
    gtk_main();
    return 0;
}
