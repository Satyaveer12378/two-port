#ifndef MENU_H
#define MENU_H
#include <gtk/gtk.h>
GtkWidget* menu_panel_new(void);
GtkWidget* create_value_row(const gchar *label_text, const gchar *default_value);
#endif
