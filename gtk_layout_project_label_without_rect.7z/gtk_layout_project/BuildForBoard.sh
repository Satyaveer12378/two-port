$CC -w main.c graph.c menu.c measurement.c topbar.c -o gtk_layout `pkg-config --cflags --libs gtk+-3.0` -lgpiod -lm -lwayland-client -lwayland-server -lwayland-egl -lEGL -lGLESv2
