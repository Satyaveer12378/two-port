#include "graph.h"
#include <gtk/gtk.h>

/* Draw a simple grid background inside the drawing area */
static gboolean on_draw(GtkWidget *widget, cairo_t *cr, gpointer user_data) {
    GtkAllocation alloc;
    gtk_widget_get_allocation(widget, &alloc);
    double w = alloc.width;
    double h = alloc.height;

    /* Subtle white grid on dark background */
    cairo_set_source_rgba(cr, 1.0, 1.0, 1.0, 0.2);
    cairo_set_line_width(cr, 1.0);

    for (int x = 0; x < (int)w; x += 50) {
        cairo_move_to(cr, x + 0.5, 0.0);
        cairo_line_to(cr, x + 0.5, h);
    }
    for (int y = 0; y < (int)h; y += 50) {
        cairo_move_to(cr, 0.0, y + 0.5);
        cairo_line_to(cr, w, y + 0.5);
    }
    cairo_stroke(cr);
    return FALSE; /* let default handler run if needed */
}

GtkWidget* graph_view_new(void) {
    /* Keep GtkFrame but disable its border (Option A) */
    GtkWidget *frame = gtk_frame_new(NULL);
    gtk_widget_set_size_request(frame, 750, -1); // 750 to 800
    gtk_widget_set_vexpand(frame, TRUE);
    gtk_widget_set_hexpand(frame, TRUE);

    /* Disable the frame's border/shadow */
    gtk_frame_set_shadow_type(GTK_FRAME(frame), GTK_SHADOW_NONE);
    gtk_container_set_border_width(GTK_CONTAINER(frame), 0);

    /* Apply your shared style class (black bg, no borders) */
    GtkStyleContext *fctx = gtk_widget_get_style_context(frame);
    gtk_style_context_add_class(fctx, "app-frame");

    /* Use an overlay so we can place a centered label above the drawing area */
    GtkWidget *overlay = gtk_overlay_new();

    /* Drawing area for the graph content */
    GtkWidget *drawing = gtk_drawing_area_new();
    gtk_widget_set_hexpand(drawing, TRUE);
    gtk_widget_set_vexpand(drawing, TRUE);
    g_signal_connect(drawing, "draw", G_CALLBACK(on_draw), NULL);

    gtk_container_add(GTK_CONTAINER(overlay), drawing);

    /* Optional centered label */
    GtkWidget *label = gtk_label_new("Graph Area");
    gtk_style_context_add_class(gtk_widget_get_style_context(label), "app-label");
    gtk_widget_set_halign(label, GTK_ALIGN_CENTER);
    gtk_widget_set_valign(label, GTK_ALIGN_CENTER);
    gtk_overlay_add_overlay(GTK_OVERLAY(overlay), label);

    /* Put the overlay inside the (now borderless) frame */
    gtk_container_add(GTK_CONTAINER(frame), overlay);

    return frame;
}
